import os
import threading
import queue
import math
import tkinter as tk
from tkinter import filedialog, ttk, scrolledtext
from wand.image import Image
from wand.exceptions import WandError

class SVGtoPNGApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SVG to PNG Converter (72x72) - High Quality")
        self.root.geometry("600x450")

        # Variables
        self.input_folder = tk.StringVar()
        self.bg_color = tk.StringVar(value="transparent")
        self.fit_mode = tk.StringVar(value="contain")  # "contain" or "cover"

        # GUI Layout
        main_frame = ttk.Frame(root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Folder selection
        ttk.Label(main_frame, text="Source folder:").grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Entry(main_frame, textvariable=self.input_folder, width=50).grid(row=0, column=1, padx=5)
        ttk.Button(main_frame, text="Browse...", command=self.browse_folder).grid(row=0, column=2)

        # Background dropdown
        ttk.Label(main_frame, text="Background:").grid(row=1, column=0, sticky=tk.W, pady=5)
        bg_combo = ttk.Combobox(main_frame, textvariable=self.bg_color,
                                values=["transparent", "white", "black"], state="readonly")
        bg_combo.grid(row=1, column=1, sticky=tk.W, padx=5)

        # Fit mode dropdown
        ttk.Label(main_frame, text="Fit mode:").grid(row=2, column=0, sticky=tk.W, pady=5)
        fit_combo = ttk.Combobox(main_frame, textvariable=self.fit_mode,
                                 values=["contain", "cover"], state="readonly")
        fit_combo.grid(row=2, column=1, sticky=tk.W, padx=5)

        # Process button
        self.process_btn = ttk.Button(main_frame, text="Process", command=self.start_conversion)
        self.process_btn.grid(row=3, column=0, columnspan=3, pady=10)

        # Log area
        self.log = scrolledtext.ScrolledText(main_frame, wrap=tk.WORD, height=15, width=70)
        self.log.grid(row=4, column=0, columnspan=3, pady=5)
        self.log.config(state=tk.DISABLED)

        # Threading
        self.queue = queue.Queue()
        self.update_log()

    def browse_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.input_folder.set(folder)

    def log_message(self, msg):
        """Thread-safe logging via queue"""
        self.queue.put(msg)

    def update_log(self):
        """Check queue for new messages and update the log widget"""
        while not self.queue.empty():
            msg = self.queue.get()
            self.log.config(state=tk.NORMAL)
            self.log.insert(tk.END, msg + "\n")
            self.log.see(tk.END)
            self.log.config(state=tk.DISABLED)
        self.root.after(100, self.update_log)

    def start_conversion(self):
        """Start the conversion in a separate thread"""
        folder = self.input_folder.get().strip()
        if not folder:
            self.log_message("Please select a folder first.")
            return
        if not os.path.isdir(folder):
            self.log_message("Selected folder does not exist.")
            return

        self.process_btn.config(state=tk.DISABLED)
        thread = threading.Thread(target=self.convert_all, args=(folder,))
        thread.daemon = True
        thread.start()

    def convert_all(self, source_root):
        """Main conversion routine – walks the folder tree and processes each SVG"""
        bg = self.bg_color.get()
        fit = self.fit_mode.get()
        source_root = os.path.abspath(source_root)
        base_name = os.path.basename(source_root)
        parent_dir = os.path.dirname(source_root)
        output_root = os.path.join(parent_dir, f"{base_name}_png")

        self.log_message(f"Output folder: {output_root}")

        # Collect all SVG files
        svg_files = []
        for root, dirs, files in os.walk(source_root):
            for file in files:
                if file.lower().endswith('.svg'):
                    svg_files.append(os.path.join(root, file))

        total = len(svg_files)
        if total == 0:
            self.log_message("No SVG files found.")
            self.root.after(0, lambda: self.process_btn.config(state=tk.NORMAL))
            return

        self.log_message(f"Found {total} SVG file(s). Starting conversion...")

        for idx, svg_path in enumerate(svg_files, 1):
            try:
                self.convert_one(svg_path, source_root, output_root, bg, fit)
                self.log_message(f"[{idx}/{total}] Converted: {os.path.basename(svg_path)}")
            except Exception as e:
                self.log_message(f"[{idx}/{total}] ERROR: {os.path.basename(svg_path)} – {str(e)}")

        self.log_message("Conversion finished.")
        self.root.after(0, lambda: self.process_btn.config(state=tk.NORMAL))

    def convert_one(self, svg_path, source_root, output_root, bg, fit):
        """Convert a single SVG file to a 72x72 PNG with high quality and proper transparency."""
        # Build output PNG path (preserve relative subfolder structure)
        rel_path = os.path.relpath(svg_path, source_root)
        png_name = os.path.splitext(os.path.basename(rel_path))[0] + ".png"
        png_rel_dir = os.path.dirname(rel_path)
        png_dir = os.path.join(output_root, png_rel_dir)
        os.makedirs(png_dir, exist_ok=True)
        png_path = os.path.join(png_dir, png_name)

        # Step 1: Render SVG at high resolution to preserve details
        # Use 300 DPI and force transparent background (no white filling)
        with Image(filename=svg_path, resolution=300, background='none') as svg_img:
            # Get original dimensions after high-res rendering
            orig_w, orig_h = svg_img.width, svg_img.height

            # Step 2: Determine target size based on fit mode
            target_w, target_h = 72, 72

            if fit == "contain":
                # Scale to fit inside 72x72, preserving aspect ratio
                scale = min(target_w / orig_w, target_h / orig_h)
                new_w = int(orig_w * scale)
                new_h = int(orig_h * scale)
                # Resize using high-quality Lanczos filter
                svg_img.resize(new_w, new_h, filter='lanczos')
            else:  # cover
                # Scale to cover 72x72, preserving aspect ratio (may crop)
                scale = max(target_w / orig_w, target_h / orig_h)
                new_w = int(orig_w * scale)
                new_h = int(orig_h * scale)
                svg_img.resize(new_w, new_h, filter='lanczos')
                # Now the image is at least 72 in both dimensions; we'll centre it on the canvas
                # The canvas will clip the excess

            # Step 3: Create the final canvas with the chosen background
            if bg == "transparent":
                canvas_bg = None  # fully transparent
            else:
                canvas_bg = bg    # solid colour

            with Image(width=72, height=72, background=canvas_bg) as canvas:
                # Calculate centred position
                left = (72 - svg_img.width) // 2
                top = (72 - svg_img.height) // 2
                # Composite the SVG onto the canvas
                canvas.composite(svg_img, left=left, top=top)
                # Save as PNG (preserves transparency)
                canvas.save(filename=png_path)

def main():
    root = tk.Tk()
    app = SVGtoPNGApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()