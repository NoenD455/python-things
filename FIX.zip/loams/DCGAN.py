import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing

# ==================== Neural Network ====================

class SimpleDCGAN:
    def __init__(self, image_size=64, latent_dim=100):
        self.image_size = image_size
        self.latent_dim = latent_dim
        
        # Set PyTorch to use 2 cores
        torch.set_num_threads(2)
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Generator
        class Generator(nn.Module):
            def __init__(self, image_size, latent_dim):
                super().__init__()
                self.main = nn.Sequential(
                    # Input: latent_dim x 1 x 1
                    nn.ConvTranspose2d(latent_dim, 512, 4, 1, 0, bias=False),
                    nn.BatchNorm2d(512),
                    nn.ReLU(True),
                    # 512 x 4 x 4
                    nn.ConvTranspose2d(512, 256, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(256),
                    nn.ReLU(True),
                    # 256 x 8 x 8
                    nn.ConvTranspose2d(256, 128, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(128),
                    nn.ReLU(True),
                    # 128 x 16 x 16
                )
                
                if image_size == 64:
                    self.main.add_module('upscale1', nn.ConvTranspose2d(128, 64, 4, 2, 1, bias=False))
                    self.main.add_module('bn4', nn.BatchNorm2d(64))
                    self.main.add_module('relu4', nn.ReLU(True))
                    # 64 x 32 x 32
                    self.main.add_module('upscale2', nn.ConvTranspose2d(64, 3, 4, 2, 1, bias=False))
                else:  # 32x32
                    self.main.add_module('upscale1', nn.ConvTranspose2d(128, 3, 4, 2, 1, bias=False))
                
                self.main.add_module('tanh', nn.Tanh())
                
            def forward(self, x):
                return self.main(x)
        
        # Discriminator
        class Discriminator(nn.Module):
            def __init__(self, image_size):
                super().__init__()
                self.main = nn.Sequential(
                    # Input: 3 x image_size x image_size
                    nn.Conv2d(3, 64, 4, 2, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    # 64 x image_size/2 x image_size/2
                    nn.Conv2d(64, 128, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(128),
                    nn.LeakyReLU(0.2, inplace=True),
                    # 128 x image_size/4 x image_size/4
                    nn.Conv2d(128, 256, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(256),
                    nn.LeakyReLU(0.2, inplace=True),
                    # 256 x image_size/8 x image_size/8
                )
                
                if image_size == 64:
                    self.main.add_module('conv4', nn.Conv2d(256, 512, 4, 2, 1, bias=False))
                    self.main.add_module('bn4', nn.BatchNorm2d(512))
                    self.main.add_module('relu4', nn.LeakyReLU(0.2, inplace=True))
                    # 512 x 4 x 4
                    self.main.add_module('final', nn.Conv2d(512, 1, 4, 1, 0, bias=False))
                else:  # 32x32
                    self.main.add_module('final', nn.Conv2d(256, 1, 4, 1, 0, bias=False))
                
                self.main.add_module('sigmoid', nn.Sigmoid())
                
            def forward(self, x):
                return self.main(x).view(-1, 1).squeeze(1)
        
        self.generator = Generator(image_size, latent_dim)
        self.discriminator = Discriminator(image_size)
        
        # Loss and optimizers
        self.criterion = nn.BCELoss()
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.generator.to(self.device)
        self.discriminator.to(self.device)

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=64):
        self.image_paths = image_paths
        self.image_size = image_size
        
        # Only nearest neighbor resizing
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size), Image.NEAREST),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            # Return a black image as fallback
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class DCGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Simple DCGAN Trainer - 2 Cores")
        self.root.geometry("850x650")  # Slightly larger window
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Performance tracking
        self.num_workers = 2  # Use 2 worker threads for data loading
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)
    
    def setup_gui(self):
        # Create main container with padding
        main_container = tk.Frame(self.root, padx=5, pady=5)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Left panel for controls - use grid for better control
        left_frame = tk.Frame(main_container, width=280)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title with core info
        title_label = tk.Label(left_frame, text="DCGAN Trainer - 2 Cores", 
                              font=("Arial", 12, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 10), sticky="w")
        
        # Image size selection
        tk.Label(left_frame, text="Image Size:").grid(row=1, column=0, sticky="w", pady=(0, 5))
        self.size_var = tk.StringVar(value="64")
        size_frame = tk.Frame(left_frame)
        size_frame.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        tk.Radiobutton(size_frame, text="32x32", variable=self.size_var, value="32").pack(side=tk.LEFT, padx=(0, 10))
        tk.Radiobutton(size_frame, text="64x64", variable=self.size_var, value="64").pack(side=tk.LEFT)
        
        # Add images button
        tk.Button(left_frame, text="Add Training Images", 
                 command=self.add_images, height=2).grid(row=3, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Image list with scrollbar
        tk.Label(left_frame, text="Training Images:").grid(row=4, column=0, sticky="w", pady=(10, 5))
        
        # Create frame for listbox and scrollbar
        list_frame = tk.Frame(left_frame)
        list_frame.grid(row=5, column=0, columnspan=2, sticky="nsew", pady=(0, 10))
        
        # Configure grid weights for list_frame
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.grid(row=0, column=0, sticky="nsew")
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.grid(row=0, column=1, sticky="ns")
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Clear button
        tk.Button(left_frame, text="Clear All Images", 
                 command=self.clear_images).grid(row=6, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Training controls
        tk.Label(left_frame, text="Training Controls:").grid(row=7, column=0, sticky="w", pady=(10, 5))
        
        tk.Button(left_frame, text="Initialize GAN", 
                 command=self.initialize_gan, height=2).grid(row=8, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Label(left_frame, text="Epochs:").grid(row=9, column=0, sticky="w")
        self.epoch_var = tk.StringVar(value="100")
        epoch_entry = tk.Entry(left_frame, textvariable=self.epoch_var)
        epoch_entry.grid(row=10, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        tk.Button(left_frame, text="Start Training", 
                 command=self.start_training, height=2, bg="lightgreen").grid(row=11, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Stop Training", 
                 command=self.stop_training, height=2, bg="salmon").grid(row=12, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Generate Sample", 
                 command=self.generate_sample, height=2).grid(row=13, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Performance info - smaller and compact
        perf_frame = tk.LabelFrame(left_frame, text="Performance", padx=5, pady=2)
        perf_frame.grid(row=14, column=0, columnspan=2, sticky="ew", pady=(10, 5))
        
        self.perf_label = tk.Label(perf_frame, 
                                  text="CPU Threads: 2\nData Workers: 2", 
                                  font=("Arial", 9),
                                  justify=tk.LEFT)
        self.perf_label.pack()
        
        # Status - make sure it's visible
        tk.Label(left_frame, text="Status:").grid(row=15, column=0, sticky="w", pady=(10, 5))
        self.status_label = tk.Label(left_frame, text="Ready", 
                                    relief=tk.SUNKEN, 
                                    height=2,
                                    anchor="w",
                                    padx=5)
        self.status_label.grid(row=16, column=0, columnspan=2, sticky="ew", pady=(0, 5))
        
        # Configure grid weights for left_frame
        left_frame.grid_rowconfigure(5, weight=1)  # Listbox row expands
        left_frame.grid_columnconfigure(0, weight=1)
        left_frame.grid_columnconfigure(1, weight=1)
        
        # Right panel for preview
        right_frame = tk.Frame(main_container)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display
        tk.Label(right_frame, text="Generated Image:").pack(anchor=tk.W)
        
        # Frame for image display
        image_display_frame = tk.Frame(right_frame, relief=tk.SUNKEN, bd=1)
        image_display_frame.pack(pady=10)
        
        self.image_label = tk.Label(image_display_frame, width=256, height=256)
        self.image_label.pack(padx=5, pady=5)
        
        # Training log with frame
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        # Configure log_frame grid
        log_frame.grid_rowconfigure(0, weight=1)
        log_frame.grid_columnconfigure(0, weight=1)
        
        self.log_text = tk.Text(log_frame, height=12, width=50, font=("Courier", 9))
        self.log_text.grid(row=0, column=0, sticky="nsew")
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.config(yscrollcommand=scrollbar.set)
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
                # Update status with first 40 chars
                status_text = message[:40] + "..." if len(message) > 40 else message
                self.status_label.config(text=status_text)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")
    
    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")
    
    def initialize_gan(self):
        try:
            image_size = int(self.size_var.get())
            self.gan = SimpleDCGAN(image_size=image_size)
            self.log_message(f"Initialized DCGAN for {image_size}x{image_size} images")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            # Update performance label
            self.perf_label.config(text=f"CPU Threads: {torch.get_num_threads()}\nData Workers: {self.num_workers}")
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
    
    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            image_size = int(self.size_var.get())
            
            self.training = True
            self.current_epoch = 0
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, image_size),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Using {self.num_workers} worker threads for data loading")
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
    
    def train_gan(self, epochs, image_size):
        try:
            # Create dataset and dataloader with 2 worker threads
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=8, 
                shuffle=True,
                num_workers=self.num_workers,  # Use 2 worker processes
                pin_memory=torch.cuda.is_available(),  # Pin memory if using CUDA
                persistent_workers=True  # Keep workers alive between epochs
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                
                for i, real_images in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    batch_size = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # Train Discriminator
                    self.gan.optimizerD.zero_grad()
                    
                    # Real images
                    real_labels = torch.ones(batch_size).to(self.gan.device)
                    output_real = self.gan.discriminator(real_images)
                    loss_real = self.gan.criterion(output_real, real_labels)
                    
                    # Fake images
                    noise = torch.randn(batch_size, self.gan.latent_dim, 1, 1).to(self.gan.device)
                    fake_images = self.gan.generator(noise)
                    fake_labels = torch.zeros(batch_size).to(self.gan.device)
                    output_fake = self.gan.discriminator(fake_images.detach())
                    loss_fake = self.gan.criterion(output_fake, fake_labels)
                    
                    # Total discriminator loss
                    loss_d = (loss_real + loss_fake) / 2
                    loss_d.backward()
                    self.gan.optimizerD.step()
                    
                    # Train Generator
                    self.gan.optimizerG.zero_grad()
                    
                    output_fake = self.gan.discriminator(fake_images)
                    loss_g = self.gan.criterion(output_fake, real_labels)
                    loss_g.backward()
                    self.gan.optimizerG.step()
                    
                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    
                    self.log_message(f"Epoch {epoch+1}/{epochs} | D Loss: {avg_loss_d:.4f} | G Loss: {avg_loss_g:.4f}")
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
                
                # Generate sample image every 10 epochs
                if (epoch + 1) % 10 == 0:
                    self.generate_sample_internal(show=False)
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            # Clean up
            if hasattr(dataloader, '_iterator'):
                del dataloader._iterator
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")
    
    def generate_sample_internal(self, show=True):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            # Generate image
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise)
                
                # Convert to PIL Image
                img = generated[0].cpu()
                img = (img + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
                img = transforms.ToPILImage()(img)
                
                # Resize for display
                img = img.resize((256, 256), Image.NEAREST)
                
                if show:
                    self.display_image(img)
                
                return img
        except Exception as e:
            self.log_message(f"Generation error: {str(e)}")
    
    def generate_sample(self):
        img = self.generate_sample_internal(show=True)
        if img:
            self.log_message("Generated new sample image")
    
    def display_image(self, img):
        # Convert to PhotoImage for Tkinter
        photo = ImageTk.PhotoImage(img)
        self.image_label.config(image=photo)
        self.image_label.image = photo  # Keep reference

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting DCGAN Trainer with 2 cores...")
    print("Note: This uses ONLY nearest-neighbor resizing")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    
    # Set multiprocessing start method for compatibility
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = DCGANApp(root)
    root.mainloop()