import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np

# ==================== WORKING GAN ARCHITECTURE ====================

class WorkingGAN:
    def __init__(self, image_size=64, latent_dim=100):
        self.image_size = image_size
        self.latent_dim = latent_dim
        
        # Set PyTorch to use 2 cores
        torch.set_num_threads(2)
        print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # ========== GENERATOR ==========
        class Generator(nn.Module):
            def __init__(self, latent_dim, image_size):
                super().__init__()
                self.latent_dim = latent_dim
                
                # Calculate number of upsampling layers
                if image_size == 64:
                    # 4→8→16→32→64
                    layers = [
                        (latent_dim, 512, 4, 1, 0),  # 4x4
                        (512, 256, 4, 2, 1),         # 8x8
                        (256, 128, 4, 2, 1),         # 16x16
                        (128, 64, 4, 2, 1),          # 32x32
                        (64, 3, 4, 2, 1)             # 64x64
                    ]
                else:  # 32x32
                    # 4→8→16→32
                    layers = [
                        (latent_dim, 256, 4, 1, 0),  # 4x4
                        (256, 128, 4, 2, 1),         # 8x8
                        (128, 64, 4, 2, 1),          # 16x16
                        (64, 3, 4, 2, 1)             # 32x32
                    ]
                
                # Build generator
                modules = []
                for i, (in_ch, out_ch, kernel, stride, pad) in enumerate(layers):
                    modules.append(
                        nn.ConvTranspose2d(in_ch, out_ch, kernel, stride, pad, bias=False)
                    )
                    
                    if i < len(layers) - 1:  # Not the last layer
                        modules.append(nn.BatchNorm2d(out_ch))
                        modules.append(nn.ReLU(True))
                    else:  # Last layer
                        modules.append(nn.Tanh())
                
                self.main = nn.Sequential(*modules)
                
            def forward(self, x):
                # Reshape latent vector
                x = x.view(x.size(0), self.latent_dim, 1, 1)
                return self.main(x)
        
        # ========== DISCRIMINATOR ==========
        class Discriminator(nn.Module):
            def __init__(self, image_size):
                super().__init__()
                
                # Calculate number of downsampling layers
                if image_size == 64:
                    # 64→32→16→8→4→1
                    layers = [
                        (3, 64, 4, 2, 1),    # 64→32
                        (64, 128, 4, 2, 1),   # 32→16
                        (128, 256, 4, 2, 1),  # 16→8
                        (256, 512, 4, 2, 1),  # 8→4
                        (512, 1, 4, 1, 0)     # 4→1
                    ]
                else:  # 32x32
                    # 32→16→8→4→1
                    layers = [
                        (3, 64, 4, 2, 1),    # 32→16
                        (64, 128, 4, 2, 1),   # 16→8
                        (128, 256, 4, 2, 1),  # 8→4
                        (256, 1, 4, 1, 0)     # 4→1
                    ]
                
                # Build discriminator
                modules = []
                for i, (in_ch, out_ch, kernel, stride, pad) in enumerate(layers):
                    modules.append(
                        nn.Conv2d(in_ch, out_ch, kernel, stride, pad, bias=False)
                    )
                    
                    if i < len(layers) - 1:  # Not the last layer
                        if i > 0:  # Add batch norm after first layer
                            modules.append(nn.BatchNorm2d(out_ch))
                        modules.append(nn.LeakyReLU(0.2, inplace=True))
                    else:  # Last layer
                        modules.append(nn.Sigmoid())
                
                self.main = nn.Sequential(*modules)
                
            def forward(self, x):
                x = self.main(x)
                return x.view(-1, 1).squeeze(1)  # Flatten to [batch_size]
        
        # Create networks
        self.generator = Generator(latent_dim, image_size)
        self.discriminator = Discriminator(image_size)
        
        # Print model info
        g_params = sum(p.numel() for p in self.generator.parameters())
        d_params = sum(p.numel() for p in self.discriminator.parameters())
        print(f"Generator parameters: {g_params:,}")
        print(f"Discriminator parameters: {d_params:,}")
        print(f"Total parameters: {g_params + d_params:,}")
        
        # Loss and optimizers
        self.criterion = nn.BCELoss()
        
        self.optimizerG = optim.Adam(self.generator.parameters(), 
                                     lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), 
                                     lr=0.0002, betas=(0.5, 0.999))
        
        # Learning rate schedulers
        self.schedulerG = optim.lr_scheduler.StepLR(self.optimizerG, step_size=50, gamma=0.8)
        self.schedulerD = optim.lr_scheduler.StepLR(self.optimizerD, step_size=50, gamma=0.8)
        
        # Device
        self.device = torch.device("cpu")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
        
        # Training stats
        self.d_losses = []
        self.g_losses = []
    
    def train_step(self, real_images):
        """Single training step - classic GAN loss"""
        batch_size = real_images.size(0)
        
        # Real and fake labels (with label smoothing for stability)
        real_labels = torch.ones(batch_size, device=self.device) * 0.9
        fake_labels = torch.zeros(batch_size, device=self.device)
        
        # ===== TRAIN DISCRIMINATOR =====
        self.optimizerD.zero_grad()
        
        real_images = real_images.to(self.device)
        
        # Real images
        d_real = self.discriminator(real_images)
        loss_real = self.criterion(d_real, real_labels)
        
        # Fake images
        z = torch.randn(batch_size, self.latent_dim, device=self.device)
        fake_images = self.generator(z).detach()
        d_fake = self.discriminator(fake_images)
        loss_fake = self.criterion(d_fake, fake_labels)
        
        # Total discriminator loss
        d_loss = (loss_real + loss_fake) / 2
        
        d_loss.backward()
        self.optimizerD.step()
        
        # ===== TRAIN GENERATOR =====
        self.optimizerG.zero_grad()
        
        # Generate new fake images
        z = torch.randn(batch_size, self.latent_dim, device=self.device)
        fake_images = self.generator(z)
        d_fake = self.discriminator(fake_images)
        
        # Generator tries to fool discriminator
        g_loss = self.criterion(d_fake, real_labels)
        
        g_loss.backward()
        self.optimizerG.step()
        
        return d_loss.item(), g_loss.item()

# ==================== SIMPLE DATASET ====================

class SimpleImageDataset(Dataset):
    def __init__(self, image_paths, image_size=64):
        self.image_paths = image_paths
        self.image_size = image_size
        
        # Simple transform
        self.transform = transforms.Compose([
            transforms.Resize(image_size),
            transforms.CenterCrop(image_size),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
        
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image: {e}")
            # Return a black image as fallback
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI APPLICATION ====================

class WorkingGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Working GAN Trainer")
        self.root.geometry("850x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Fixed noise for consistent generation
        self.fixed_noise = None
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)
    
    def setup_gui(self):
        # Main container
        main_container = tk.Frame(self.root, padx=10, pady=10)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Left panel
        left_frame = tk.Frame(main_container, width=250)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Working GAN Trainer", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Info
        info_text = """Working GAN Features:
• Classic DCGAN architecture
• Batch normalization
• Label smoothing
• Stable training
• Good for diverse images"""
        
        tk.Label(left_frame, text=info_text, justify=tk.LEFT,
                relief=tk.GROOVE, padx=10, pady=10, wraplength=230).pack(pady=(0, 10))
        
        # Size selection
        tk.Label(left_frame, text="Image Size:").pack(anchor=tk.W)
        
        self.size_var = tk.StringVar(value="64")
        size_frame = tk.Frame(left_frame)
        size_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Radiobutton(size_frame, text="32x32", variable=self.size_var, 
                      value="32").pack(side=tk.LEFT)
        tk.Radiobutton(size_frame, text="64x64", variable=self.size_var, 
                      value="64").pack(side=tk.LEFT, padx=(10, 0))
        
        # Load images button
        tk.Button(left_frame, text="Load Images", 
                 command=self.load_images, height=2).pack(fill=tk.X, pady=5)
        
        # Image list
        list_frame = tk.LabelFrame(left_frame, text="Loaded Images", padx=5, pady=5)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.image_listbox.yview)
        
        # Clear button
        tk.Button(left_frame, text="Clear All", 
                 command=self.clear_images).pack(fill=tk.X, pady=5)
        
        # Training params
        param_frame = tk.LabelFrame(left_frame, text="Training Parameters", padx=10, pady=10)
        param_frame.pack(fill=tk.X, pady=10)
        
        # Epochs
        tk.Label(param_frame, text="Epochs:").grid(row=0, column=0, sticky=tk.W)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(param_frame, textvariable=self.epoch_var, width=10).grid(row=0, column=1, sticky=tk.E)
        
        # Batch size
        tk.Label(param_frame, text="Batch Size:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.batch_var = tk.StringVar(value="8")
        tk.Entry(param_frame, textvariable=self.batch_var, width=10).grid(row=1, column=1, sticky=tk.E, pady=5)
        
        # Latent dimension
        tk.Label(param_frame, text="Latent Dim:").grid(row=2, column=0, sticky=tk.W)
        self.latent_var = tk.StringVar(value="100")
        tk.Entry(param_frame, textvariable=self.latent_var, width=10).grid(row=2, column=1, sticky=tk.E)
        
        # Controls
        control_frame = tk.Frame(left_frame)
        control_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(control_frame, text="Initialize GAN", 
                 command=self.initialize_gan, width=12).pack(side=tk.LEFT, padx=2)
        tk.Button(control_frame, text="Start Training", 
                 command=self.start_training, bg="lightgreen", width=12).pack(side=tk.LEFT, padx=2)
        
        tk.Button(control_frame, text="Stop Training", 
                 command=self.stop_training, bg="salmon", width=12).pack(side=tk.LEFT, padx=2)
        
        # Generation
        gen_frame = tk.Frame(left_frame)
        gen_frame.pack(fill=tk.X, pady=5)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=15).pack(side=tk.LEFT, padx=2)
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=15).pack(side=tk.LEFT, padx=2)
        
        # Status
        self.status_label = tk.Label(left_frame, text="Ready to load images", 
                                    relief=tk.SUNKEN, height=2,
                                    anchor=tk.W, padx=10)
        self.status_label.pack(fill=tk.X, pady=10)
        
        # Right panel
        right_frame = tk.Frame(main_container)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Image display
        display_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.image_label = tk.Label(display_frame)
        self.image_label.pack(expand=True)
        
        # Log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=12, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.log_text.yview)
        
        # Loss display
        loss_frame = tk.Frame(right_frame)
        loss_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(loss_frame, text="Discriminator Loss:").pack(side=tk.LEFT, padx=5)
        self.d_loss_label = tk.Label(loss_frame, text="0.0000", font=("Courier", 10))
        self.d_loss_label.pack(side=tk.LEFT, padx=5)
        
        tk.Label(loss_frame, text="Generator Loss:").pack(side=tk.LEFT, padx=5)
        self.g_loss_label = tk.Label(loss_frame, text="0.0000", font=("Courier", 10))
        self.g_loss_label.pack(side=tk.LEFT, padx=5)
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=message[:30] + "..." if len(message) > 30 else message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def load_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                display_name = filename[:25] + "..." if len(filename) > 25 else filename
                self.image_listbox.insert(tk.END, display_name)
        
        self.log_message(f"Loaded {len(files)} images. Total: {len(self.image_paths)}")
    
    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images")
    
    def initialize_gan(self):
        try:
            image_size = int(self.size_var.get())
            latent_dim = int(self.latent_var.get())
            
            self.gan = WorkingGAN(image_size=image_size, latent_dim=latent_dim)
            self.log_message(f"Initialized GAN for {image_size}x{image_size} images")
            self.log_message(f"Latent dimension: {latent_dim}")
            
            # Create fixed noise for consistent generation
            self.fixed_noise = torch.randn(1, latent_dim, device=self.gan.device)
            
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
    
    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images loaded!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            batch_size = int(self.batch_var.get())
            image_size = int(self.size_var.get())
            
            self.training = True
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, image_size),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")
    
    def train_gan(self, epochs, batch_size, image_size):
        try:
            # Create dataset
            dataset = SimpleImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=True,
                num_workers=0  # Keep it simple for stability
            )
            
            self.log_message(f"Training on {len(dataset)} images")
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                total_d_loss = 0
                total_g_loss = 0
                batch_count = 0
                
                for batch in dataloader:
                    if not self.training:
                        break
                    
                    d_loss, g_loss = self.gan.train_step(batch)
                    
                    total_d_loss += d_loss
                    total_g_loss += g_loss
                    batch_count += 1
                    
                    # Update loss display every few batches
                    if batch_count % 5 == 0:
                        self.root.after(0, self.update_loss_display, d_loss, g_loss)
                
                if batch_count > 0:
                    avg_d_loss = total_d_loss / batch_count
                    avg_g_loss = total_g_loss / batch_count
                    
                    self.log_message(f"Epoch {epoch+1}/{epochs} | D Loss: {avg_d_loss:.4f} | G Loss: {avg_g_loss:.4f}")
                
                # Update learning rates
                self.gan.schedulerG.step()
                self.gan.schedulerD.step()
                
                # Generate sample every 10 epochs
                if (epoch + 1) % 10 == 0:
                    self.generate_sample_internal()
                
                # Small delay to keep UI responsive
                import time
                time.sleep(0.01)
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            import traceback
            traceback.print_exc()
            self.training = False
    
    def update_loss_display(self, d_loss, g_loss):
        self.d_loss_label.config(text=f"{d_loss:.4f}")
        self.g_loss_label.config(text=f"{g_loss:.4f}")
    
    def generate_sample_internal(self):
        if not self.gan:
            return
        
        try:
            with torch.no_grad():
                # Generate from fixed noise
                if self.fixed_noise is None:
                    latent_dim = int(self.latent_var.get())
                    self.fixed_noise = torch.randn(1, latent_dim, device=self.gan.device)
                
                generated = self.gan.generator(self.fixed_noise)
                
                # Convert to PIL Image
                img = generated[0].cpu()
                img = (img + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
                img = torch.clamp(img, 0, 1)
                img = transforms.ToPILImage()(img)
                
                # Resize for display
                display_size = 256
                img = img.resize((display_size, display_size), Image.NEAREST)
                
                # Update display
                self.display_image(img)
                
        except Exception as e:
            self.log_message(f"Generation error: {str(e)}")
    
    def generate_sample(self):
        self.generate_sample_internal()
        if self.gan:
            self.log_message("Generated sample image")
    
    def generate_grid(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            with torch.no_grad():
                # Generate 3x3 grid
                grid_size = 3
                latent_dim = int(self.latent_var.get())
                noise = torch.randn(grid_size * grid_size, latent_dim, device=self.gan.device)
                generated = self.gan.generator(noise)
                
                # Create grid image
                images = []
                for i in range(grid_size * grid_size):
                    img = generated[i].cpu()
                    img = (img + 1) / 2
                    img = torch.clamp(img, 0, 1)
                    img = transforms.ToPILImage()(img)
                    images.append(img)
                
                # Combine into grid
                img_size = images[0].size[0]
                grid_img = Image.new('RGB', (img_size * grid_size, img_size * grid_size))
                
                for i, img in enumerate(images):
                    row = i // grid_size
                    col = i % grid_size
                    grid_img.paste(img, (col * img_size, row * img_size))
                
                # Resize for display
                display_size = 256
                grid_img = grid_img.resize((display_size, display_size), Image.NEAREST)
                
                # Update display
                self.display_image(grid_img)
                
                self.log_message(f"Generated {grid_size}x{grid_size} grid")
                
        except Exception as e:
            self.log_message(f"Grid generation error: {str(e)}")
    
    def display_image(self, img):
        photo = ImageTk.PhotoImage(img)
        self.image_label.config(image=photo)
        self.image_label.image = photo
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

# ==================== MAIN ====================

if __name__ == "__main__":
    print("Working GAN Trainer")
    print("Simple, stable GAN for diverse image collections")
    print("-" * 50)
    
    root = tk.Tk()
    app = WorkingGANApp(root)
    root.mainloop()