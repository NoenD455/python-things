import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import librosa
import librosa.display
import soundfile as sf
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import warnings
warnings.filterwarnings('ignore')

# Audio processing
class AudioProcessor:
    def __init__(self, sr=22050, n_fft=2048, hop_length=512, n_mels=128, segment_duration=1.472,
                 spec_width=64, spec_height=64):
        self.sr = sr
        self.n_fft = n_fft
        self.hop_length = hop_length
        self.n_mels = n_mels
        self.segment_duration = segment_duration
        self.segment_samples = int(sr * segment_duration)
        self.spec_width = spec_width  # Time dimension
        self.spec_height = spec_height  # Frequency dimension
        
        # Calculate hop length to achieve desired width
        if spec_width > 0:
            self.hop_length = max(256, int((segment_duration * sr) / spec_width))
            # Recalculate actual width
            self.actual_width = int(sr * segment_duration / self.hop_length) + 1
        else:
            self.actual_width = spec_width
    
    def audio_to_segments(self, audio_path, max_segments=None):
        """Split audio into segments and convert each to mel-spectrogram"""
        try:
            # Load entire audio file
            audio, sr = librosa.load(audio_path, sr=self.sr)
            
            # Calculate number of segments
            num_segments = len(audio) // self.segment_samples
            if num_segments == 0:  # Audio shorter than segment
                num_segments = 1
            
            if max_segments and num_segments > max_segments:
                num_segments = max_segments
            
            segments = []
            segment_audios = []
            
            for i in range(num_segments):
                start = i * self.segment_samples
                end = start + self.segment_samples
                segment_audio = audio[start:end]
                
                if len(segment_audio) < self.segment_samples:
                    segment_audio = np.pad(segment_audio, (0, self.segment_samples - len(segment_audio)), mode='constant')
                
                # Create mel-spectrogram for this segment
                mel_spec = librosa.feature.melspectrogram(
                    y=segment_audio, 
                    sr=sr,
                    n_fft=self.n_fft,
                    hop_length=self.hop_length,
                    n_mels=self.n_mels,
                    fmax=8000
                )
                
                mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
                mel_spec_norm = (mel_spec_db - mel_spec_db.min()) / (mel_spec_db.max() - mel_spec_db.min() + 1e-8)
                
                # Convert to PIL Image (grayscale)
                mel_spec_img = (mel_spec_norm * 255).astype(np.uint8)
                img = Image.fromarray(mel_spec_img)
                
                # Resize to desired spectrogram dimensions
                target_size = (self.spec_width, self.spec_height)
                img = img.resize(target_size, Image.Resampling.LANCZOS)
                
                segments.append(img)
                segment_audios.append(segment_audio)
            
            return segments, segment_audios, audio
            
        except Exception as e:
            print(f"Error processing {audio_path}: {e}")
            return [], [], np.zeros(self.segment_samples)
    
    def segment_to_mel(self, segment_audio):
        """Convert a single audio segment to mel-spectrogram image"""
        if len(segment_audio) < self.segment_samples:
            segment_audio = np.pad(segment_audio, (0, self.segment_samples - len(segment_audio)), mode='constant')
        
        mel_spec = librosa.feature.melspectrogram(
            y=segment_audio, 
            sr=self.sr,
            n_fft=self.n_fft,
            hop_length=self.hop_length,
            n_mels=self.n_mels,
            fmax=8000
        )
        
        mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
        mel_spec_norm = (mel_spec_db - mel_spec_db.min()) / (mel_spec_db.max() - mel_spec_db.min() + 1e-8)
        
        mel_spec_img = (mel_spec_norm * 255).astype(np.uint8)
        img = Image.fromarray(mel_spec_img)
        
        # Resize to desired spectrogram dimensions
        target_size = (self.spec_width, self.spec_height)
        img = img.resize(target_size, Image.Resampling.LANCZOS)
        
        return img, mel_spec_db
    
    def mel_to_audio(self, mel_image, use_griffin_lim=True):
        """Convert mel-spectrogram image back to audio"""
        try:
            mel_img = np.array(mel_image.convert('L')).astype(float)
            mel_img = mel_img / 255.0
            
            # Resize back to original mel dimensions for reconstruction
            target_shape = (self.n_mels, self.actual_width)
            if mel_img.shape != target_shape:
                img = Image.fromarray((mel_img * 255).astype(np.uint8))
                img = img.resize((target_shape[1], target_shape[0]), Image.Resampling.LANCZOS)
                mel_img = np.array(img).astype(float) / 255.0
            
            mel_img = np.clip(mel_img, 0, 1)
            mel_linear = librosa.db_to_power(mel_img * 80 - 80)
            
            if use_griffin_lim:
                audio = librosa.feature.inverse.mel_to_audio(
                    mel_linear,
                    sr=self.sr,
                    n_fft=self.n_fft,
                    hop_length=self.hop_length,
                    n_iter=32
                )
            else:
                audio = np.random.randn(self.segment_samples) * 0.01
            
            if np.max(np.abs(audio)) > 0:
                audio = audio / np.max(np.abs(audio)) * 0.9
            
            return audio[:self.segment_samples]
            
        except Exception as e:
            print(f"Error converting mel to audio: {e}")
            return np.zeros(self.segment_samples)
    
    def save_audio(self, audio, filename):
        sf.write(filename, audio, self.sr)
    
    def play_audio(self, audio):
        try:
            import simpleaudio as sa
            audio_int = (audio * 32767).astype(np.int16)
            play_obj = sa.play_buffer(audio_int, 1, 2, self.sr)
            return play_obj
        except ImportError:
            temp_file = "temp_generated.wav"
            self.save_audio(audio, temp_file)
            os.system(f"start {temp_file}" if os.name == 'nt' else f"afplay {temp_file}")

# DCGAN for audio spectrograms - SIMPLIFIED FIXED ARCHITECTURE
class SimpleAudioDCGAN:
    def __init__(self, image_width=64, image_height=64, latent_dim=100, ngf=64, ndf=64):
        self.image_width = image_width
        self.image_height = image_height
        self.latent_dim = latent_dim
        
        torch.set_num_threads(multiprocessing.cpu_count())
        print(f"Using CPU with {torch.get_num_threads()} threads")
        
        class Generator(nn.Module):
            def __init__(self, image_width, image_height, latent_dim, ngf):
                super().__init__()
                
                # SIMPLIFIED: Always use adaptive layers that work for any size
                self.main = nn.Sequential(
                    # Input: latent_dim x 1 x 1
                    nn.ConvTranspose2d(latent_dim, ngf * 8, 4, 1, 0, bias=False),
                    nn.BatchNorm2d(ngf * 8),
                    nn.ReLU(True),
                    # State: ngf*8 x 4 x 4
                    
                    nn.ConvTranspose2d(ngf * 8, ngf * 4, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf * 4),
                    nn.ReLU(True),
                    # State: ngf*4 x 8 x 8
                    
                    nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf * 2),
                    nn.ReLU(True),
                    # State: ngf*2 x 16 x 16
                    
                    nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf),
                    nn.ReLU(True),
                    # State: ngf x 32 x 32
                    
                    # Adaptive layer to reach target dimensions
                    nn.ConvTranspose2d(ngf, ngf // 2, 
                                      kernel_size=(4 if image_height > 32 else 1, 
                                                   4 if image_width > 32 else 1),
                                      stride=(2 if image_height > 32 else 1, 
                                              2 if image_width > 32 else 1),
                                      padding=(1 if image_height > 32 else 0, 
                                               1 if image_width > 32 else 0),
                                      bias=False),
                    nn.BatchNorm2d(ngf // 2),
                    nn.ReLU(True),
                    # State: ngf//2 x (64 or 32) x (64 or 32)
                    
                    # Final adaptive layer to get exact dimensions
                    nn.ConvTranspose2d(ngf // 2, 1,
                                      kernel_size=((image_height + 31) // 32 * 4 - 3 if image_height > 32 else 1,
                                                   (image_width + 31) // 32 * 4 - 3 if image_width > 32 else 1),
                                      stride=(1, 1),
                                      padding=(0, 0),
                                      bias=False),
                    nn.Tanh()
                    # Output: 1 x image_height x image_width
                )
                
            def forward(self, x):
                return self.main(x)
        
        class Discriminator(nn.Module):
            def __init__(self, image_width, image_height, ndf):
                super().__init__()
                
                # SIMPLIFIED: Always output [batch_size, 1] with adaptive pooling
                self.conv_layers = nn.Sequential(
                    # Input: 1 x image_height x image_width
                    nn.Conv2d(1, ndf, 4, 2, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf x H/2 x W/2
                    
                    nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 2),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf*2 x H/4 x W/4
                    
                    nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 4),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf*4 x H/8 x W/8
                    
                    nn.Conv2d(ndf * 4, ndf * 8, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 8),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf*8 x H/16 x W/16
                )
                
                # Adaptive pooling to ensure consistent output size
                self.adaptive_pool = nn.AdaptiveAvgPool2d((4, 4))
                
                self.final_conv = nn.Sequential(
                    nn.Conv2d(ndf * 8, 1, 4, 1, 0, bias=False),
                    # Output: 1 x 1 x 1
                )
                
            def forward(self, x):
                x = self.conv_layers(x)
                x = self.adaptive_pool(x)  # Always [batch_size, ndf*8, 4, 4]
                x = self.final_conv(x)     # Always [batch_size, 1, 1, 1]
                return x.view(-1, 1)       # Always [batch_size, 1]
        
        self.generator = Generator(image_width, image_height, latent_dim, ngf)
        self.discriminator = Discriminator(image_width, image_height, ndf)
        
        self.criterion = nn.BCEWithLogitsLoss()
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        
        self.device = torch.device("cpu")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
        
        self.audio_processor = AudioProcessor(segment_duration=1.472,
                                              spec_width=image_width,
                                              spec_height=image_height)

# Audio dataset
class AudioDataset(Dataset):
    def __init__(self, audio_paths, image_width=64, image_height=64, max_segments_per_file=0):
        self.audio_paths = audio_paths
        self.image_width = image_width
        self.image_height = image_height
        self.max_segments_per_file = max_segments_per_file
        
        # Create audio processor with correct dimensions
        self.audio_processor = AudioProcessor(segment_duration=1.472,
                                              spec_width=image_width,
                                              spec_height=image_height)
        
        self.transform = transforms.Compose([
            transforms.Resize((image_height, image_width)),  # Note: (height, width)
            transforms.ToTensor(),
            transforms.Normalize([0.5], [0.5])
        ])
        
        # Preprocess all audio files
        self.segments = []
        self.total_segments = 0
        
        print(f"Loading segments from {len(audio_paths)} audio files...")
        print(f"Spectrogram dimensions: {image_width}x{image_height} (width×height)")
        
        for file_idx, audio_path in enumerate(audio_paths):
            try:
                mel_segments, _, _ = self.audio_processor.audio_to_segments(
                    audio_path, 
                    max_segments=self.max_segments_per_file if self.max_segments_per_file > 0 else None
                )
                
                if mel_segments:
                    self.segments.extend(mel_segments)
                    self.total_segments += len(mel_segments)
                    print(f"  {os.path.basename(audio_path)}: {len(mel_segments)} segments")
                    
            except Exception as e:
                print(f"Error loading audio {audio_path}: {e}")
        
        print(f"Total loaded: {self.total_segments} audio segments from {len(audio_paths)} files")
    
    def __len__(self):
        return len(self.segments)
    
    def __getitem__(self, idx):
        try:
            img = self.segments[idx]
            return self.transform(img)
        except:
            return torch.zeros(1, self.image_height, self.image_width)

# Main application
class AudioDCGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Audio DCGAN Trainer - Fixed Architecture")
        self.root.geometry("1100x750")
        
        self.audio_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        self.current_audio = None
        self.is_playing = False
        
        # Store audio segments for preview
        self.audio_segments = {}
        self.current_preview_segment = 0
        
        # Updated settings with width/height separation
        self.settings = {
            'image_width': tk.IntVar(value=64),
            'image_height': tk.IntVar(value=64),
            'latent_dim': tk.IntVar(value=100),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=4),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(2, multiprocessing.cpu_count())),
            'generate_interval': tk.IntVar(value=5),
            'segment_duration': tk.DoubleVar(value=1.472),
            'max_segments_per_file': tk.IntVar(value=0),
            'use_label_smoothing': tk.BooleanVar(value=True),
            'label_smoothing_value': tk.DoubleVar(value=0.1),
            'clip_gradients': tk.BooleanVar(value=True),
            'gradient_clip_value': tk.DoubleVar(value=0.01),
        }
        
        self.num_workers = min(2, multiprocessing.cpu_count())
        self.start_time = None
        self.generated_audio = []
        
        self.setup_gui()
        self.root.after(100, self.process_messages)
        self.audio_processor = AudioProcessor(segment_duration=1.472,
                                              spec_width=self.settings['image_width'].get(),
                                              spec_height=self.settings['image_height'].get())

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        self.preview_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.preview_tab, text='Mel Preview')
        self.setup_preview_tab()
        
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()
        
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        tk.Label(left_frame, text="Audio DCGAN Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Display spectrogram dimensions
        self.spec_size_display = tk.Label(left_frame, text=f"Spectrogram: {self.settings['image_width'].get()}×{self.settings['image_height'].get()}")
        self.spec_size_display.pack(pady=(0, 10))
        
        audio_frame = tk.LabelFrame(left_frame, text="Training Audio", padx=10, pady=10)
        audio_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(audio_frame, text="Add Audio Files", 
                 command=self.add_audio_files, width=20).pack(pady=5)
        tk.Button(audio_frame, text="Clear All", 
                 command=self.clear_audio, width=20).pack(pady=5)
        
        list_frame = tk.Frame(audio_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.audio_listbox = tk.Listbox(list_frame, height=8)
        self.audio_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.audio_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.audio_listbox.config(yscrollcommand=list_scrollbar.set)
        
        tk.Button(audio_frame, text="Preview Selected", 
                 command=self.preview_selected_audio, width=20).pack(pady=5)
        
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize GAN", 
                 command=self.initialize_gan, width=20).pack(pady=5)
        
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="50")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        stats_frame = tk.LabelFrame(left_frame, text="Segment Statistics", padx=10, pady=10)
        stats_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.segment_count_label = tk.Label(stats_frame, text="Segments loaded: 0")
        self.segment_count_label.pack(pady=2)
        
        self.file_count_label = tk.Label(stats_frame, text="Audio files: 0")
        self.file_count_label.pack(pady=2)
        
        self.segment_duration_label = tk.Label(stats_frame, text="Segment duration: 1.472s")
        self.segment_duration_label.pack(pady=2)
        
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate & Play", 
                 command=self.generate_and_play, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        preview_frame = tk.LabelFrame(right_frame, text="Generated Spectrogram", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.spec_frame = tk.Frame(preview_frame, width=256, height=256, bg='gray')
        self.spec_frame.pack(pady=10)
        self.spec_frame.pack_propagate(False)
        
        self.spec_label = tk.Label(self.spec_frame, text="No spectrogram generated", bg='gray')
        self.spec_label.pack(fill=tk.BOTH, expand=True)
        
        audio_controls = tk.Frame(preview_frame)
        audio_controls.pack(pady=5)
        
        tk.Button(audio_controls, text="Play", 
                 command=self.play_generated_audio, width=10).pack(side=tk.LEFT, padx=5)
        tk.Button(audio_controls, text="Stop", 
                 command=self.stop_audio, width=10).pack(side=tk.LEFT, padx=5)
        tk.Button(audio_controls, text="Save", 
                 command=self.save_generated_audio, width=10).pack(side=tk.LEFT, padx=5)
        
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_preview_tab(self):
        main_frame = tk.Frame(self.preview_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Mel-Spectrogram Preview", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        select_frame = tk.LabelFrame(main_frame, text="Select Audio File", padx=10, pady=10)
        select_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(select_frame, text="Audio File:").pack(side=tk.LEFT, padx=5)
        
        self.preview_audio_var = tk.StringVar()
        self.preview_audio_combo = ttk.Combobox(select_frame, textvariable=self.preview_audio_var, 
                                               state="readonly", width=50)
        self.preview_audio_combo.pack(side=tk.LEFT, padx=5)
        self.preview_audio_combo.bind("<<ComboboxSelected>>", self.on_preview_audio_selected)
        
        tk.Button(select_frame, text="Load All Segments", 
                 command=self.load_audio_segments, width=20).pack(side=tk.LEFT, padx=5)
        
        nav_frame = tk.LabelFrame(main_frame, text="Segment Navigation", padx=10, pady=10)
        nav_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(nav_frame, text="Segment:").pack(side=tk.LEFT, padx=5)
        
        self.segment_var = tk.IntVar(value=0)
        self.segment_spinbox = tk.Spinbox(nav_frame, from_=0, to=0, textvariable=self.segment_var,
                                         width=10, command=self.update_segment_preview)
        self.segment_spinbox.pack(side=tk.LEFT, padx=5)
        
        self.segment_total_label = tk.Label(nav_frame, text="of 0")
        self.segment_total_label.pack(side=tk.LEFT, padx=5)
        
        tk.Button(nav_frame, text="◀ Prev", 
                 command=self.prev_segment, width=10).pack(side=tk.LEFT, padx=5)
        tk.Button(nav_frame, text="Next ▶", 
                 command=self.next_segment, width=10).pack(side=tk.LEFT, padx=5)
        
        display_frame = tk.LabelFrame(main_frame, text="Segment Preview", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        top_frame = tk.Frame(display_frame)
        top_frame.pack(fill=tk.BOTH, expand=True)
        
        left_display = tk.Frame(top_frame, width=300)
        left_display.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        tk.Label(left_display, text="Mel-Spectrogram Image", 
                font=("Arial", 10, "bold")).pack(pady=(0, 5))
        
        self.mel_image_frame = tk.Frame(left_display, width=256, height=256, bg='gray')
        self.mel_image_frame.pack()
        self.mel_image_frame.pack_propagate(False)
        
        self.mel_image_label = tk.Label(self.mel_image_frame, text="No image", bg='gray')
        self.mel_image_label.pack(fill=tk.BOTH, expand=True)
        
        right_display = tk.Frame(top_frame)
        right_display.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        tk.Label(right_display, text="Segment Information", 
                font=("Arial", 10, "bold")).pack(pady=(0, 5))
        
        info_frame = tk.Frame(right_display)
        info_frame.pack(fill=tk.BOTH, expand=True)
        
        self.segment_info_text = tk.Text(info_frame, height=10, font=("Courier", 9))
        self.segment_info_text.pack(fill=tk.BOTH, expand=True)
        
        controls_frame = tk.Frame(display_frame)
        controls_frame.pack(fill=tk.X, pady=(10, 0))
        
        tk.Button(controls_frame, text="Play Original Segment", 
                 command=self.play_preview_segment, width=20).pack(side=tk.LEFT, padx=5)
        tk.Button(controls_frame, text="Play Reconstructed", 
                 command=self.play_reconstructed_segment, width=20).pack(side=tk.LEFT, padx=5)
        tk.Button(controls_frame, text="Play Full Audio", 
                 command=self.play_full_preview_audio, width=20).pack(side=tk.LEFT, padx=5)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Audio Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load Generator", 
                 command=self.load_generator, width=20).pack(pady=5)
        
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Segments:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=4)
        tk.Scale(gen_frame, from_=1, to=32, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Sequence", 
                 command=self.generate_sequence, width=20).pack(pady=10)
        
        self.audio_display_frame = tk.LabelFrame(main_frame, text="Generated Segments", 
                                                padx=10, pady=10)
        self.audio_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.audio_canvas = tk.Canvas(self.audio_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.audio_display_frame, orient="vertical", 
                                command=self.audio_canvas.yview)
        self.audio_scroll_frame = tk.Frame(self.audio_canvas)
        
        self.audio_scroll_frame.bind(
            "<Configure>",
            lambda e: self.audio_canvas.configure(scrollregion=self.audio_canvas.bbox("all"))
        )
        
        self.audio_canvas.create_window((0, 0), window=self.audio_scroll_frame, anchor="nw")
        self.audio_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.audio_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        tk.Label(scrollable_frame, text="Audio DCGAN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Spectrogram dimensions
        spec_frame = tk.LabelFrame(scrollable_frame, text="Spectrogram Dimensions", padx=10, pady=10)
        spec_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Width selection
        width_frame = tk.Frame(spec_frame)
        width_frame.pack(fill=tk.X, pady=5)
        tk.Label(width_frame, text="Width (Time):", width=25, anchor='w').pack(side=tk.LEFT)
        
        for width in [32, 64, 128]:
            tk.Radiobutton(width_frame, text=f"{width}", variable=self.settings['image_width'], 
                          value=width, command=self.update_spec_display).pack(side=tk.LEFT, padx=5)
        
        tk.Label(width_frame, text="pixels", font=("Arial", 9)).pack(side=tk.LEFT, padx=5)
        
        # Height selection
        height_frame = tk.Frame(spec_frame)
        height_frame.pack(fill=tk.X, pady=5)
        tk.Label(height_frame, text="Height (Frequency):", width=25, anchor='w').pack(side=tk.LEFT)
        
        for height in [32, 64, 128]:
            tk.Radiobutton(height_frame, text=f"{height}", variable=self.settings['image_height'], 
                          value=height, command=self.update_spec_display).pack(side=tk.LEFT, padx=5)
        
        tk.Label(height_frame, text="pixels", font=("Arial", 9)).pack(side=tk.LEFT, padx=5)
        
        # Preset combinations
        preset_frame = tk.Frame(spec_frame)
        preset_frame.pack(fill=tk.X, pady=5)
        tk.Label(preset_frame, text="Presets:", width=25, anchor='w').pack(side=tk.LEFT)
        
        presets = [
            ("High Quality (64×128)", 64, 128),
            ("Deep Audio (128×64)", 128, 64),
            ("Standard (64×64)", 64, 64),
            ("Compact (32×64)", 32, 64),
            ("Fast (32×32)", 32, 32),
        ]
        
        for preset_name, width_val, height_val in presets:
            btn = tk.Button(preset_frame, text=preset_name, width=15,
                          command=lambda w=width_val, h=height_val: self.set_preset(w, h))
            btn.pack(side=tk.LEFT, padx=2)
        
        # Segment settings
        segment_frame = tk.LabelFrame(scrollable_frame, text="Segment Settings", padx=10, pady=10)
        segment_frame.pack(fill=tk.X, pady=(0, 10))
        
        duration_frame = tk.Frame(segment_frame)
        duration_frame.pack(fill=tk.X, pady=5)
        tk.Label(duration_frame, text="Segment Duration (seconds):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(duration_frame, from_=0.5, to=10.0, variable=self.settings['segment_duration'],
                orient=tk.HORIZONTAL, length=200, resolution=0.001).pack(side=tk.RIGHT)
        tk.Label(duration_frame, textvariable=self.settings['segment_duration'], width=5).pack(side=tk.RIGHT, padx=5)
        
        seg_frame = tk.Frame(segment_frame)
        seg_frame.pack(fill=tk.X, pady=5)
        tk.Label(seg_frame, text="Max Segments per File:", width=25, anchor='w').pack(side=tk.LEFT)
        
        seg_input_frame = tk.Frame(seg_frame)
        seg_input_frame.pack(side=tk.RIGHT)
        
        tk.Label(seg_input_frame, text="(0 = all):").pack(side=tk.LEFT, padx=(0, 5))
        
        self.max_segments_entry = tk.Entry(seg_input_frame, width=10)
        self.max_segments_entry.pack(side=tk.LEFT)
        self.max_segments_entry.insert(0, "0")
        
        tk.Button(seg_input_frame, text="Apply", 
                 command=self.apply_max_segments, width=8).pack(side=tk.LEFT, padx=5)
        
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 10, 500),
            ("Generator Features (ngf):", 'ngf', 32, 256),
            ("Discriminator Features (ndf):", 'ndf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 32),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        stability_frame = tk.LabelFrame(scrollable_frame, text="Training Stability", padx=10, pady=10)
        stability_frame.pack(fill=tk.X, pady=(0, 10))
        
        stability_settings = [
            ("Use Label Smoothing:", 'use_label_smoothing'),
            ("Label Smoothing Value:", 'label_smoothing_value', 0.0, 0.3),
            ("Clip Gradients:", 'clip_gradients'),
            ("Gradient Clip Value:", 'gradient_clip_value', 0.001, 0.1),
        ]
        
        for i, (label_text, var_name, *args) in enumerate(stability_settings):
            frame = tk.Frame(stability_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            
            if len(args) == 0:
                tk.Checkbutton(frame, variable=self.settings[var_name]).pack(side=tk.LEFT)
            else:
                min_val, max_val = args
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=150, resolution=0.001).pack(side=tk.RIGHT)
                tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(4, multiprocessing.cpu_count())),
            ("Generate Interval (epochs):", 'generate_interval', 1, 20),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Spectrogram: {self.settings['image_width'].get()}×{self.settings['image_height'].get()}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save Settings", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Settings", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Test Segment Processing", 
                 command=self.test_segment_processing, width=20).pack(side=tk.LEFT, padx=5)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def set_preset(self, width, height):
        """Set spectrogram dimensions from preset"""
        self.settings['image_width'].set(width)
        self.settings['image_height'].set(height)
        self.update_spec_display()
        self.log_message(f"Set spectrogram dimensions to {width}×{height}")

    def update_spec_display(self):
        """Update spectrogram size display in training tab"""
        width = self.settings['image_width'].get()
        height = self.settings['image_height'].get()
        self.spec_size_display.config(text=f"Spectrogram: {width}×{height}")

    def apply_max_segments(self):
        try:
            value = int(self.max_segments_entry.get())
            if value < 0:
                value = 0
            self.settings['max_segments_per_file'].set(value)
            self.log_message(f"Max segments per file set to: {value} (0 = all segments)")
        except ValueError:
            self.log_message("Error: Please enter a valid number for max segments")

    # Preview tab methods
    def update_preview_list(self):
        files = [os.path.basename(p) for p in self.audio_paths]
        self.preview_audio_combo['values'] = files
        if files:
            self.preview_audio_combo.current(0)

    def on_preview_audio_selected(self, event=None):
        self.load_audio_segments()

    def load_audio_segments(self):
        selection = self.preview_audio_combo.current()
        if selection < 0 or selection >= len(self.audio_paths):
            return
        
        audio_path = self.audio_paths[selection]
        filename = os.path.basename(audio_path)
        
        self.log_message(f"Loading segments from {filename}...")
        
        try:
            # Update audio processor with current settings
            segment_duration = self.settings['segment_duration'].get()
            width = self.settings['image_width'].get()
            height = self.settings['image_height'].get()
            
            self.audio_processor = AudioProcessor(
                segment_duration=segment_duration,
                spec_width=width,
                spec_height=height
            )
            
            max_segments = self.settings['max_segments_per_file'].get()
            if max_segments == 0:
                max_segments = None
            
            mel_images, segment_audios, full_audio = self.audio_processor.audio_to_segments(
                audio_path, 
                max_segments=max_segments
            )
            
            self.audio_segments[filename] = {
                'mel_images': mel_images,
                'segment_audios': segment_audios,
                'full_audio': full_audio,
                'num_segments': len(mel_images)
            }
            
            max_segments_display = len(mel_images) - 1
            self.segment_var.set(0)
            self.segment_spinbox.config(from_=0, to=max_segments_display)
            self.segment_total_label.config(text=f"of {max_segments_display}")
            
            self.update_segment_preview()
            
            if max_segments is None:
                self.log_message(f"Loaded ALL {len(mel_images)} segments from {filename}")
            else:
                self.log_message(f"Loaded {len(mel_images)} segments from {filename} (limited to {max_segments} per file)")
            
        except Exception as e:
            self.log_message(f"Error loading segments: {str(e)}")

    def update_segment_preview(self):
        filename = self.preview_audio_var.get()
        if not filename or filename not in self.audio_segments:
            return
        
        segment_idx = self.segment_var.get()
        data = self.audio_segments[filename]
        
        if segment_idx >= len(data['mel_images']):
            return
        
        # Update mel image
        mel_img = data['mel_images'][segment_idx]
        
        # Maintain aspect ratio for display
        display_width = 256
        display_height = 256
        
        # Calculate display size maintaining aspect ratio
        orig_width, orig_height = mel_img.size
        aspect = orig_width / orig_height
        
        if aspect > 1:  # Wider than tall
            display_width = 256
            display_height = int(256 / aspect)
        else:  # Taller than wide or square
            display_height = 256
            display_width = int(256 * aspect)
        
        mel_img_display = mel_img.resize((display_width, display_height), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(mel_img_display)
        
        self.mel_image_label.config(image=photo, text="")
        self.mel_image_label.image = photo
        
        # Update segment info
        self.segment_info_text.delete(1.0, tk.END)
        
        segment_audio = data['segment_audios'][segment_idx]
        segment_duration = len(segment_audio) / self.audio_processor.sr
        
        self.segment_info_text.insert(tk.END, f"File: {filename}\n")
        self.segment_info_text.insert(tk.END, f"{'='*40}\n")
        self.segment_info_text.insert(tk.END, f"Segment: {segment_idx + 1}/{data['num_segments']}\n")
        self.segment_info_text.insert(tk.END, f"Duration: {segment_duration:.3f}s\n")
        self.segment_info_text.insert(tk.END, f"Time: {segment_idx * segment_duration:.2f}s - {(segment_idx + 1) * segment_duration:.2f}s\n")
        self.segment_info_text.insert(tk.END, f"Samples: {len(segment_audio)}\n")
        self.segment_info_text.insert(tk.END, f"Max Amplitude: {np.max(np.abs(segment_audio)):.3f}\n")
        self.segment_info_text.insert(tk.END, f"Spectrogram: {mel_img.size[0]}×{mel_img.size[1]}\n")
        self.segment_info_text.insert(tk.END, f"Hop Length: {self.audio_processor.hop_length} samples\n")
        
        # Calculate some audio features
        rms = np.sqrt(np.mean(segment_audio**2))
        zero_crossings = np.sum(np.abs(np.diff(np.sign(segment_audio)))) / len(segment_audio)
        
        self.segment_info_text.insert(tk.END, f"RMS Energy: {rms:.4f}\n")
        self.segment_info_text.insert(tk.END, f"Zero Crossings: {zero_crossings:.2f} per sample\n")
        
        # Store current segment for playback
        self.current_preview_segment = segment_idx

    def prev_segment(self):
        current = self.segment_var.get()
        if current > 0:
            self.segment_var.set(current - 1)
            self.update_segment_preview()

    def next_segment(self):
        filename = self.preview_audio_var.get()
        if filename in self.audio_segments:
            data = self.audio_segments[filename]
            current = self.segment_var.get()
            if current < data['num_segments'] - 1:
                self.segment_var.set(current + 1)
                self.update_segment_preview()

    def play_preview_segment(self):
        filename = self.preview_audio_var.get()
        if filename not in self.audio_segments:
            return
        
        segment_idx = self.current_preview_segment
        segment_audio = self.audio_segments[filename]['segment_audios'][segment_idx]
        
        self.play_audio_array(segment_audio, self.audio_processor.sr)
        self.log_message(f"Playing segment {segment_idx + 1} of {filename}")

    def play_reconstructed_segment(self):
        filename = self.preview_audio_var.get()
        if filename not in self.audio_segments:
            return
        
        segment_idx = self.current_preview_segment
        mel_img = self.audio_segments[filename]['mel_images'][segment_idx]
        
        reconstructed_audio = self.audio_processor.mel_to_audio(mel_img)
        self.play_audio_array(reconstructed_audio, self.audio_processor.sr)
        self.log_message(f"Playing reconstructed segment {segment_idx + 1}")

    def play_full_preview_audio(self):
        filename = self.preview_audio_var.get()
        if filename not in self.audio_segments:
            return
        
        full_audio = self.audio_segments[filename]['full_audio']
        self.play_audio_array(full_audio, self.audio_processor.sr)
        self.log_message(f"Playing full audio: {filename}")

    # Audio file management
    def add_audio_files(self):
        files = filedialog.askopenfilenames(
            title="Select audio files",
            filetypes=[
                ("Audio files", "*.wav *.mp3 *.ogg *.flac *.m4a"),
                ("WAV files", "*.wav"),
                ("MP3 files", "*.mp3"),
                ("All files", "*.*")
            ]
        )
        
        for file in files:
            if file not in self.audio_paths:
                self.audio_paths.append(file)
                filename = os.path.basename(file)
                self.audio_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} audio file{'s' if count != 1 else ''}. Total: {len(self.audio_paths)}")
        
        self.update_preview_list()
        self.file_count_label.config(text=f"Audio files: {len(self.audio_paths)}")

    def clear_audio(self):
        self.audio_paths = []
        self.audio_listbox.delete(0, tk.END)
        self.audio_segments = {}
        self.log_message("Cleared all audio files")
        
        self.update_preview_list()
        self.file_count_label.config(text=f"Audio files: 0")
        self.segment_count_label.config(text=f"Segments loaded: 0")

    def preview_selected_audio(self):
        selection = self.audio_listbox.curselection()
        if not selection:
            self.log_message("No audio file selected!")
            return
        
        idx = selection[0]
        audio_path = self.audio_paths[idx]
        
        try:
            audio, sr = librosa.load(audio_path, sr=22050, duration=5.0)
            self.play_audio_array(audio, sr)
            self.log_message(f"Playing: {os.path.basename(audio_path)}")
        except Exception as e:
            self.log_message(f"Error playing audio: {str(e)}")

    # Audio playback
    def play_audio_array(self, audio, sr=22050):
        try:
            self.stop_audio()
            import simpleaudio as sa
            audio_int = (audio * 32767).astype(np.int16)
            self.current_audio = sa.play_buffer(audio_int, 1, 2, sr)
            self.is_playing = True
            threading.Thread(target=self.monitor_playback, daemon=True).start()
        except ImportError:
            self.log_message("Install simpleaudio: pip install simpleaudio")
            temp_file = "temp_preview.wav"
            sf.write(temp_file, audio, sr)
            os.system(f"start {temp_file}" if os.name == 'nt' else f"afplay {temp_file}")

    def monitor_playback(self):
        while self.is_playing and self.current_audio and self.current_audio.is_playing():
            time.sleep(0.1)
        self.is_playing = False

    def stop_audio(self):
        self.is_playing = False
        if self.current_audio:
            self.current_audio.stop()
            self.current_audio = None

    # GAN methods
    def initialize_gan(self):
        try:
            width = self.settings['image_width'].get()
            height = self.settings['image_height'].get()
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            
            self.gan = SimpleAudioDCGAN(
                image_width=width,
                image_height=height,
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf
            )
            
            segment_duration = self.settings['segment_duration'].get()
            self.gan.audio_processor = AudioProcessor(
                segment_duration=segment_duration,
                spec_width=width,
                spec_height=height
            )
            self.audio_processor = AudioProcessor(
                segment_duration=segment_duration,
                spec_width=width,
                spec_height=height
            )
            
            self.segment_duration_label.config(text=f"Segment duration: {segment_duration}s")
            self.spec_size_display.config(text=f"Spectrogram: {width}×{height}")
            
            self.log_message(f"Initialized Audio DCGAN for {width}×{height} spectrograms")
            self.log_message(f"Segment duration: {segment_duration}s")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        if not self.audio_paths:
            self.log_message("Error: No audio files added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            generate_interval = self.settings['generate_interval'].get()
            
            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            for param_group in self.gan.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            thread = threading.Thread(
                target=self.train_audio_gan,
                args=(epochs, batch_size, num_workers, generate_interval),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Spectrogram: {self.settings['image_width'].get()}×{self.settings['image_height'].get()}")
            self.log_message(f"Segment duration: {self.settings['segment_duration'].get()}s")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_audio_gan(self, epochs, batch_size, num_workers, generate_interval):
        try:
            width = self.settings['image_width'].get()
            height = self.settings['image_height'].get()
            
            use_label_smoothing = self.settings['use_label_smoothing'].get()
            label_smoothing = self.settings['label_smoothing_value'].get()
            clip_gradients = self.settings['clip_gradients'].get()
            gradient_clip = self.settings['gradient_clip_value'].get()
            
            max_segments = self.settings['max_segments_per_file'].get()
            if max_segments == 0:
                max_segments = None
            
            dataset = AudioDataset(
                self.audio_paths, 
                width,
                height,
                max_segments_per_file=0 if max_segments is None else max_segments
            )
            
            if len(dataset) == 0:
                self.log_message("Error: No audio segments loaded!")
                self.training = False
                return
            
            self.segment_count_label.config(text=f"Segments loaded: {len(dataset)}")
            self.root.update()
            
            self.log_message(f"Training on {len(dataset)} audio segments...")
            self.log_message(f"Spectrogram dimensions: {width}×{height}")
            
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=False,
                persistent_workers=False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                epoch_start = time.time()
                
                for real_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # Train discriminator
                    self.gan.optimizerD.zero_grad()
                    
                    if use_label_smoothing:
                        real_labels = torch.ones(batch_size_actual, 1, device=self.gan.device) * (1.0 - label_smoothing)
                    else:
                        real_labels = torch.ones(batch_size_actual, 1, device=self.gan.device)
                    
                    output_real = self.gan.discriminator(real_images)
                    loss_real = self.gan.criterion(output_real, real_labels)
                    
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, 1, 1, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    
                    if use_label_smoothing:
                        fake_labels = torch.zeros(batch_size_actual, 1, device=self.gan.device) + label_smoothing
                    else:
                        fake_labels = torch.zeros(batch_size_actual, 1, device=self.gan.device)
                    
                    output_fake = self.gan.discriminator(fake_images.detach())
                    loss_fake = self.gan.criterion(output_fake, fake_labels)
                    
                    loss_d = (loss_real + loss_fake) / 2
                    loss_d.backward()
                    
                    if clip_gradients:
                        torch.nn.utils.clip_grad_norm_(self.gan.discriminator.parameters(), gradient_clip)
                    
                    self.gan.optimizerD.step()
                    
                    # Train generator
                    self.gan.optimizerG.zero_grad()
                    
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, 1, 1, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    output_fake = self.gan.discriminator(fake_images)
                    
                    loss_g = self.gan.criterion(output_fake, real_labels)
                    loss_g.backward()
                    
                    if clip_gradients:
                        torch.nn.utils.clip_grad_norm_(self.gan.generator.parameters(), gradient_clip)
                    
                    self.gan.optimizerG.step()
                    
                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"D Loss: {avg_loss_d:.4f} | "
                                   f"G Loss: {avg_loss_g:.4f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Total: {elapsed:.1f}s")
                    
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_sample()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_training_sample(self):
        if not self.gan:
            return
        
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
                
                img_tensor = generated[0]
                img_tensor = (img_tensor + 1) / 2
                img_tensor = img_tensor.clamp(0, 1)
                
                img = transforms.ToPILImage()(img_tensor)
                audio = self.gan.audio_processor.mel_to_audio(img)
                
                self.generated_audio = audio
                
                # Maintain aspect ratio for display
                display_width = 256
                display_height = 256
                
                orig_width, orig_height = img.size
                aspect = orig_width / orig_height
                
                if aspect > 1:
                    display_width = 256
                    display_height = int(256 / aspect)
                else:
                    display_height = 256
                    display_width = int(256 * aspect)
                
                img_display = img.resize((display_width, display_height), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img_display)
                
                self.spec_label.config(image=photo, text="")
                self.spec_label.image = photo
                
                self.log_message(f"Generated training sample at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def generate_and_play(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
                
                img_tensor = generated[0]
                img_tensor = (img_tensor + 1) / 2
                img_tensor = img_tensor.clamp(0, 1)
                img = transforms.ToPILImage()(img_tensor)
                
                audio = self.gan.audio_processor.mel_to_audio(img)
                self.generated_audio = audio
                
                # Maintain aspect ratio for display
                display_width = 256
                display_height = 256
                
                orig_width, orig_height = img.size
                aspect = orig_width / orig_height
                
                if aspect > 1:
                    display_width = 256
                    display_height = int(256 / aspect)
                else:
                    display_height = 256
                    display_width = int(256 * aspect)
                
                img_display = img.resize((display_width, display_height), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img_display)
                self.spec_label.config(image=photo, text="")
                self.spec_label.image = photo
                
                self.play_generated_audio()
                
                self.log_message("Generated and playing audio segment")
                
        except Exception as e:
            self.log_message(f"Error generating audio: {str(e)}")

    def play_generated_audio(self):
        if self.generated_audio is not None and len(self.generated_audio) > 0:
            self.play_audio_array(self.generated_audio, self.gan.audio_processor.sr)
            self.log_message("Playing generated audio segment")
        else:
            self.log_message("No audio generated yet!")

    def save_generated_audio(self):
        if self.generated_audio is None or len(self.generated_audio) == 0:
            self.log_message("No audio to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".wav",
            filetypes=[("WAV files", "*.wav"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                self.gan.audio_processor.save_audio(self.generated_audio, filename)
                self.log_message(f"Audio segment saved to {filename}")
            except Exception as e:
                self.log_message(f"Error saving audio: {str(e)}")

    def generate_sequence(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            num_segments = self.num_gen_var.get()
            
            with torch.no_grad():
                noise = torch.randn(num_segments, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
            
            for widget in self.audio_scroll_frame.winfo_children():
                widget.destroy()
            
            cols = 2
            rows = (num_segments + cols - 1) // cols
            
            generated_segments = []
            
            for i in range(rows):
                row_frame = tk.Frame(self.audio_scroll_frame)
                row_frame.pack(pady=10)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_segments:
                        clip_frame = tk.LabelFrame(row_frame, text=f"Segment {idx+1}", padx=10, pady=10)
                        clip_frame.pack(side=tk.LEFT, padx=10)
                        
                        img_tensor = generated[idx]
                        img_tensor = (img_tensor + 1) / 2
                        img_tensor = img_tensor.clamp(0, 1)
                        img = transforms.ToPILImage()(img_tensor)
                        
                        # Resize for display maintaining aspect ratio
                        display_width = 128
                        display_height = 128
                        
                        orig_width, orig_height = img.size
                        aspect = orig_width / orig_height
                        
                        if aspect > 1:
                            display_width = 128
                            display_height = int(128 / aspect)
                        else:
                            display_height = 128
                            display_width = int(128 * aspect)
                        
                        img_display = img.resize((display_width, display_height), Image.Resampling.LANCZOS)
                        photo = ImageTk.PhotoImage(img_display)
                        
                        img_label = tk.Label(clip_frame, image=photo)
                        img_label.image = photo
                        img_label.pack()
                        
                        audio = self.gan.audio_processor.mel_to_audio(img)
                        generated_segments.append(audio)
                        
                        btn_frame = tk.Frame(clip_frame)
                        btn_frame.pack(pady=5)
                        
                        def make_play_callback(audio_clip, seg_num):
                            return lambda: (self.play_audio_array(audio_clip, self.gan.audio_processor.sr),
                                          self.log_message(f"Playing segment {seg_num}"))
                        
                        tk.Button(btn_frame, text="Play", 
                                 command=make_play_callback(audio, idx+1), width=8).pack(side=tk.LEFT, padx=2)
                        
                        def make_save_callback(audio_clip, seg_num):
                            return lambda: self.save_single_audio(audio_clip, seg_num)
                        
                        tk.Button(btn_frame, text="Save", 
                                 command=make_save_callback(audio, idx+1), width=8).pack(side=tk.LEFT, padx=2)
            
            self.generated_segments = generated_segments
            
            self.log_message(f"Generated {num_segments} audio segments")
            
        except Exception as e:
            self.log_message(f"Error generating sequence: {str(e)}")

    def save_single_audio(self, audio, clip_num):
        filename = filedialog.asksaveasfilename(
            defaultextension=".wav",
            filetypes=[("WAV files", "*.wav"), ("All files", "*.*")],
            initialfile=f"generated_segment_{clip_num}.wav"
        )
        
        if filename:
            try:
                self.gan.audio_processor.save_audio(audio, filename)
                self.log_message(f"Segment {clip_num} saved to {filename}")
            except Exception as e:
                self.log_message(f"Error saving segment: {str(e)}")

    def save_model(self):
        if not self.gan:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'discriminator_state_dict': self.gan.discriminator.state_dict(),
                    'optimizerG_state_dict': self.gan.optimizerG.state_dict(),
                    'optimizerD_state_dict': self.gan.optimizerD.state_dict(),
                    'image_width': self.settings['image_width'].get(),
                    'image_height': self.settings['image_height'].get(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                    'segment_duration': self.settings['segment_duration'].get(),
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_generator(self):
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                for key in ['image_width', 'image_height', 'latent_dim', 'ngf', 'ndf', 'segment_duration']:
                    if key in checkpoint and key in self.settings:
                        self.settings[key].set(checkpoint[key])
                
                self.initialize_gan()
                self.gan.generator.load_state_dict(checkpoint['generator_state_dict'])
                
                self.log_message(f"Loaded model from {filename}")
                if 'epoch' in checkpoint:
                    self.log_message(f"Model was trained for {checkpoint['epoch']} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def save_defaults(self):
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('audio_dcgan_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        try:
            import json
            if os.path.exists('audio_dcgan_defaults.json'):
                with open('audio_dcgan_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                if 'max_segments_per_file' in defaults:
                    self.max_segments_entry.delete(0, tk.END)
                    self.max_segments_entry.insert(0, str(defaults['max_segments_per_file']))
                
                self.update_spec_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def test_segment_processing(self):
        if not self.audio_paths:
            self.log_message("No audio files to test!")
            return
        
        audio_path = self.audio_paths[0]
        
        try:
            self.log_message(f"Testing segment processing on: {os.path.basename(audio_path)}")
            
            segment_duration = self.settings['segment_duration'].get()
            width = self.settings['image_width'].get()
            height = self.settings['image_height'].get()
            
            self.audio_processor = AudioProcessor(
                segment_duration=segment_duration,
                spec_width=width,
                spec_height=height
            )
            
            max_segments = self.settings['max_segments_per_file'].get()
            if max_segments == 0:
                max_segments = None
            
            mel_images, segment_audios, _ = self.audio_processor.audio_to_segments(
                audio_path, 
                max_segments=3  # Just test with 3 for speed
            )
            
            self.log_message(f"Created {len(mel_images)} segments of {segment_duration}s each")
            self.log_message(f"Spectrogram dimensions: {width}×{height}")
            
            # Play first segment original
            self.log_message("Playing original segment 1...")
            self.play_audio_array(segment_audios[0], self.audio_processor.sr)
            time.sleep(segment_duration + 0.5)
            
            # Play first segment reconstructed
            reconstructed_audio = self.audio_processor.mel_to_audio(mel_images[0])
            self.log_message("Playing reconstructed segment 1...")
            self.play_audio_array(reconstructed_audio, self.audio_processor.sr)
            
            self.log_message("Segment processing test complete!")
            
        except Exception as e:
            self.log_message(f"Error in segment processing test: {str(e)}")

    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def log_message(self, message):
        self.message_queue.put(message)

    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

# Main
if __name__ == "__main__":
    print("Starting Audio DCGAN Trainer - Fixed Architecture")
    print(f"CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch threads: {torch.get_num_threads()}")
    print("\nFixed architecture now supports all dimensions (32, 64, 128)")
    print("Segment duration can be set from 0.5 to 10.0 seconds")
    
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = AudioDCGANApp(root)
    root.mainloop()