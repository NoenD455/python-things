import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import math
import json

# ==================== Enhanced Neural Network ====================

class EnhancedGenerator(nn.Module):
    """Generator with skip connections and attention for better learning"""
    
    def __init__(self, latent_dim=100, ngf=64, use_attention=True, use_residual=True):
        super().__init__()
        self.latent_dim = latent_dim
        self.ngf = ngf
        self.use_attention = use_attention
        self.use_residual = use_residual
        
        # Project and reshape latent vector
        self.projection = nn.Linear(latent_dim, ngf * 8 * 4 * 4)
        
        # Generator for 32x32 images
        self.conv1 = self._upsample_block(ngf * 8, ngf * 4)  # 8x8
        self.conv2 = self._upsample_block(ngf * 4, ngf * 2)  # 16x16
        
        if use_attention:
            self.attention = SelfAttention(ngf * 2)
        
        self.conv3 = self._upsample_block(ngf * 2, ngf)      # 32x32
        self.final = nn.Sequential(
            nn.Conv2d(ngf, 3, 3, padding=1),
            nn.Tanh()
        )
    
    def _upsample_block(self, in_channels, out_channels):
        """Upsample block with optional residual connection"""
        if self.use_residual and in_channels == out_channels:
            # Add residual connection
            return ResidualUpsampleBlock(in_channels, out_channels)
        
        layers = [
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(in_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(True)
        ]
        
        return nn.Sequential(*layers)
    
    def forward(self, z):
        # Project and reshape
        x = self.projection(z)
        x = x.view(-1, self.ngf * 8, 4, 4)
        
        # Progressive upsampling
        x = self.conv1(x)  # 8x8
        x = self.conv2(x)  # 16x16
        
        # Apply attention if enabled
        if self.use_attention and hasattr(self, 'attention'):
            x = self.attention(x)
        
        x = self.conv3(x)  # 32x32
        
        return self.final(x)


class ResidualUpsampleBlock(nn.Module):
    """Residual block with upsampling for better gradient flow"""
    
    def __init__(self, in_channels, out_channels):
        super().__init__()
        
        self.main = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels)
        )
        
        self.shortcut = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels)
        )
        
        self.relu = nn.ReLU(True)
    
    def forward(self, x):
        residual = self.shortcut(x)
        x = self.main(x)
        x += residual
        return self.relu(x)


class SelfAttention(nn.Module):
    """Self-attention mechanism to capture global dependencies"""
    
    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels
        
        # Query, Key, Value projections
        self.query = nn.Conv2d(in_channels, in_channels // 8, 1)
        self.key = nn.Conv2d(in_channels, in_channels // 8, 1)
        self.value = nn.Conv2d(in_channels, in_channels, 1)
        
        # Gamma parameter (learnable)
        self.gamma = nn.Parameter(torch.zeros(1))
        
        self.softmax = nn.Softmax(dim=-1)
    
    def forward(self, x):
        batch_size, C, height, width = x.size()
        
        # Reshape for attention
        query = self.query(x).view(batch_size, -1, height * width).permute(0, 2, 1)  # (B, N, C')
        key = self.key(x).view(batch_size, -1, height * width)  # (B, C', N)
        value = self.value(x).view(batch_size, -1, height * width)  # (B, C, N)
        
        # Attention weights
        attention = torch.bmm(query, key)  # (B, N, N)
        attention = self.softmax(attention / (C ** 0.5))
        
        # Apply attention
        out = torch.bmm(value, attention.permute(0, 2, 1))
        out = out.view(batch_size, C, height, width)
        
        # Residual connection
        return self.gamma * out + x


class EnhancedDiscriminator(nn.Module):
    """Discriminator with spectral normalization and residual connections"""
    
    def __init__(self, ndf=64, use_spectral_norm=True, use_attention=True):
        super().__init__()
        
        def conv_block(in_channels, out_channels, stride=2):
            layers = [
                nn.Conv2d(in_channels, out_channels, 4, stride=stride, padding=1, bias=False)
            ]
            
            if use_spectral_norm:
                layers[0] = nn.utils.spectral_norm(layers[0])
            
            layers.extend([
                nn.BatchNorm2d(out_channels),
                nn.LeakyReLU(0.2, inplace=True)
            ])
            return nn.Sequential(*layers)
        
        self.conv1 = conv_block(3, ndf)  # 16x16
        self.conv2 = conv_block(ndf, ndf * 2)  # 8x8
        
        if use_attention:
            self.attention = SelfAttention(ndf * 2)
        
        self.conv3 = conv_block(ndf * 2, ndf * 4)  # 4x4
        self.final = nn.Conv2d(ndf * 4, 1, 4, 1, 0)
        
        if use_spectral_norm:
            self.final = nn.utils.spectral_norm(self.final)
    
    def forward(self, x):
        x = self.conv1(x)  # 16x16
        x = self.conv2(x)  # 8x8
        
        if hasattr(self, 'attention'):
            x = self.attention(x)
        
        x = self.conv3(x)  # 4x4
        x = self.final(x)
        return x.view(-1, 1)


class SimpleDCGAN:
    def __init__(self, latent_dim=100, ngf=64, ndf=64, 
                 use_attention=True, use_residual=True, use_spectral_norm=True):
        self.latent_dim = latent_dim
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        self.generator = EnhancedGenerator(
            latent_dim=latent_dim,
            ngf=ngf,
            use_attention=use_attention,
            use_residual=use_residual
        )
        
        self.discriminator = EnhancedDiscriminator(
            ndf=ndf,
            use_spectral_norm=use_spectral_norm,
            use_attention=use_attention
        )
        
        # Enhanced loss functions
        self.criterion = nn.BCEWithLogitsLoss()
        
        # Separate learning rates for G and D (often beneficial)
        self.optimizerG = optim.Adam(
            self.generator.parameters(), 
            lr=0.0002, 
            betas=(0.5, 0.999),
            weight_decay=1e-5  # L2 regularization
        )
        self.optimizerD = optim.Adam(
            self.discriminator.parameters(), 
            lr=0.0002, 
            betas=(0.5, 0.999),
            weight_decay=1e-5
        )
        
        # Learning rate scheduler
        self.schedulerG = optim.lr_scheduler.CosineAnnealingLR(self.optimizerG, T_max=100, eta_min=1e-6)
        self.schedulerD = optim.lr_scheduler.CosineAnnealingLR(self.optimizerD, T_max=100, eta_min=1e-6)
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
        
        # Gradient penalty lambda for WGAN-GP (optional)
        self.lambda_gp = 10.0
        
        # EMA for generator weights (smoother training)
        self.generator_ema = None
        self.ema_decay = 0.999

    def compute_gradient_penalty(self, real_images, fake_images):
        """Calculate gradient penalty for WGAN-GP"""
        batch_size = real_images.size(0)
        
        # Random interpolation between real and fake
        alpha = torch.rand(batch_size, 1, 1, 1).to(self.device)
        interpolated = (alpha * real_images + (1 - alpha) * fake_images).requires_grad_(True)
        
        # Calculate critic scores
        d_interpolated = self.discriminator(interpolated)
        
        # Get gradients w.r.t. interpolated
        grad = torch.autograd.grad(
            outputs=d_interpolated,
            inputs=interpolated,
            grad_outputs=torch.ones_like(d_interpolated),
            create_graph=True,
            retain_graph=True,
            only_inputs=True
        )[0]
        
        # Gradient penalty
        grad_norm = grad.view(batch_size, -1).norm(2, dim=1)
        gradient_penalty = ((grad_norm - 1) ** 2).mean()
        
        return gradient_penalty

    def update_ema(self):
        """Update Exponential Moving Average of generator weights"""
        if self.generator_ema is None:
            # Initialize EMA with current generator weights
            self.generator_ema = {k: v.clone().detach() for k, v in self.generator.named_parameters()}
        else:
            # Update EMA weights
            for name, param in self.generator.named_parameters():
                self.generator_ema[name] = self.ema_decay * self.generator_ema[name] + \
                                          (1 - self.ema_decay) * param.detach()

    def generate_with_ema(self, noise):
        """Generate images using EMA weights"""
        if self.generator_ema is None:
            return self.generator(noise)
        
        # Save original parameters
        original_params = {k: v.clone() for k, v in self.generator.named_parameters()}
        
        # Load EMA weights
        for name, param in self.generator.named_parameters():
            param.data.copy_(self.generator_ema[name])
        
        # Generate
        with torch.no_grad():
            images = self.generator(noise)
        
        # Restore original parameters
        for name, param in self.generator.named_parameters():
            param.data.copy_(original_params[name])
        
        return images


# ==================== Enhanced Dataset with Augmentation ====================

class EnhancedImageDataset(Dataset):
    """Dataset with data augmentation for small datasets"""
    
    def __init__(self, image_paths, augment=True):
        self.image_paths = image_paths
        self.augment = augment
        
        # Base transforms for 32x32
        base_transforms = [
            transforms.Resize((32, 32)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ]
        
        # Add augmentation for small datasets
        if augment and len(image_paths) < 100:
            print(f"Dataset small ({len(image_paths)} images), applying augmentation")
            augmentation_transforms = [
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomRotation(degrees=10),
                transforms.ColorJitter(brightness=0.2, contrast=0.2),
                transforms.RandomAffine(degrees=0, translate=(0.1, 0.1)),
            ]
            # Insert augmentation before normalization
            self.transform = transforms.Compose(augmentation_transforms + base_transforms)
        else:
            self.transform = transforms.Compose(base_transforms)
    
    def __len__(self):
        return len(self.image_paths) * (4 if self.augment and len(self.image_paths) < 100 else 1)
    
    def __getitem__(self, idx):
        try:
            # For small datasets, use the same image multiple times with different augmentations
            actual_idx = idx % len(self.image_paths)
            img = Image.open(self.image_paths[actual_idx]).convert('RGB')
            
            # Apply deterministic augmentation for reproducibility
            if self.augment and len(self.image_paths) < 100:
                # Use idx to determine augmentation parameters
                torch.manual_seed(idx)
                return self.transform(img)
            else:
                return self.transform(img)
                
        except Exception as e:
            print(f"Error loading image {self.image_paths[actual_idx]}: {e}")
            # Return a black image as fallback
            return torch.zeros(3, 32, 32)


# ==================== GUI Application ====================

class DCGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Enhanced DCGAN Trainer (32x32) - Multi-Core")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Enhanced settings
        self.settings = {
            'latent_dim': tk.IntVar(value=128),  # Increased for more expressiveness
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=16),  # Increased batch size
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
            'generate_interval': tk.IntVar(value=5),
            'use_attention': tk.BooleanVar(value=True),
            'use_residual': tk.BooleanVar(value=True),
            'use_spectral_norm': tk.BooleanVar(value=True),
            'use_augmentation': tk.BooleanVar(value=True),
            'use_ema': tk.BooleanVar(value=True),
            'use_gradient_penalty': tk.BooleanVar(value=True),
            'lambda_gp': tk.DoubleVar(value=10.0),
            'ema_decay': tk.DoubleVar(value=0.999),
            'd_updates_per_g': tk.IntVar(value=1),  # D updates per G update
        }
        
        # Performance tracking
        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        
        # For storing generated images
        self.generated_images = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Enhanced DCGAN Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        tk.Label(left_frame, text="Image Size: 32x32", 
                font=("Arial", 10)).pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize GAN", 
                 command=self.initialize_gan, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="500")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display - SINGLE LARGE IMAGE
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Single image display (256x256)
        self.single_image_frame = tk.Frame(preview_frame, width=256, height=256, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar at bottom
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="Enhanced DCGAN Settings (32x32)", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar for many settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Image size display
        tk.Label(net_frame, text="Image Size: 32x32 (Fixed)", 
                font=("Arial", 10, "bold")).pack(pady=(0, 10))
        
        # Network parameters
        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 10, 500),
            ("Generator Features (ngf):", 'ngf', 32, 256),
            ("Discriminator Features (ndf):", 'ndf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 64),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Enhanced training settings
        enhanced_frame = tk.LabelFrame(scrollable_frame, text="Enhanced Features", padx=10, pady=10)
        enhanced_frame.pack(fill=tk.X, pady=(0, 10))
        
        enhanced_settings = [
            ("Use Attention:", 'use_attention', tk.BooleanVar),
            ("Use Residual Connections:", 'use_residual', tk.BooleanVar),
            ("Use Spectral Norm:", 'use_spectral_norm', tk.BooleanVar),
            ("Use Data Augmentation:", 'use_augmentation', tk.BooleanVar),
            ("Use EMA (Exponential Moving Average):", 'use_ema', tk.BooleanVar),
            ("Use Gradient Penalty (WGAN-GP):", 'use_gradient_penalty', tk.BooleanVar),
        ]
        
        for label_text, var_name, var_type in enhanced_settings:
            frame = tk.Frame(enhanced_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=40, anchor='w').pack(side=tk.LEFT)
            tk.Checkbutton(frame, variable=self.settings[var_name]).pack(side=tk.RIGHT)
        
        # Advanced parameters
        advanced_frame = tk.LabelFrame(scrollable_frame, text="Advanced Parameters", padx=10, pady=10)
        advanced_frame.pack(fill=tk.X, pady=(0, 10))
        
        advanced_settings = [
            ("D updates per G update:", 'd_updates_per_g', 1, 5),
            ("Gradient Penalty Lambda:", 'lambda_gp', 1.0, 100.0),
            ("EMA Decay:", 'ema_decay', 0.9, 0.9999),
        ]
        
        for label_text, var_name, min_val, max_val in advanced_settings:
            frame = tk.Frame(advanced_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                    orient=tk.HORIZONTAL, length=200, 
                    resolution=0.001 if var_name == 'ema_decay' else 1.0).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Enhanced Preset", 
                 command=self.reset_to_enhanced, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load Generator", 
                 command=self.load_generator, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                # Add to log
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                
                # Update status with first line
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                
                print(message)  # Also print to console
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_gan(self):
        """Initialize enhanced GAN with current settings"""
        try:
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            use_attention = self.settings['use_attention'].get()
            use_residual = self.settings['use_residual'].get()
            use_spectral_norm = self.settings['use_spectral_norm'].get()
            
            self.gan = SimpleDCGAN(
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf,
                use_attention=use_attention,
                use_residual=use_residual,
                use_spectral_norm=use_spectral_norm
            )
            
            self.log_message(f"Initialized Enhanced DCGAN for 32x32 images")
            self.log_message(f"Latent dim: {latent_dim}, G features: {ngf}, D features: {ndf}")
            self.log_message(f"Attention: {use_attention}, Residual: {use_residual}, Spectral Norm: {use_spectral_norm}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            
            # Update optimizers with new settings
            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            for param_group in self.gan.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, num_workers),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_gan(self, epochs, batch_size, num_workers):
        """Enhanced training loop with new features"""
        try:
            generate_interval = self.settings['generate_interval'].get()
            use_augmentation = self.settings['use_augmentation'].get()
            use_ema = self.settings['use_ema'].get()
            use_gradient_penalty = self.settings['use_gradient_penalty'].get()
            d_updates = self.settings['d_updates_per_g'].get()
            
            # Create dataset with augmentation for small datasets
            dataset = EnhancedImageDataset(
                self.image_paths, 
                augment=use_augmentation
            )
            
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                epoch_start = time.time()
                
                for real_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # Train Discriminator (multiple times per generator update)
                    for _ in range(d_updates):
                        self.gan.optimizerD.zero_grad()
                        
                        # Real images
                        real_labels = torch.ones(batch_size_actual, 1, device=self.gan.device)
                        output_real = self.gan.discriminator(real_images)
                        loss_real = self.gan.criterion(output_real, real_labels)
                        
                        # Fake images
                        noise = torch.randn(batch_size_actual, self.gan.latent_dim, device=self.gan.device)
                        fake_images = self.gan.generator(noise)
                        fake_labels = torch.zeros(batch_size_actual, 1, device=self.gan.device)
                        output_fake = self.gan.discriminator(fake_images.detach())
                        loss_fake = self.gan.criterion(output_fake, fake_labels)
                        
                        # Total discriminator loss
                        loss_d = (loss_real + loss_fake) / 2
                        
                        # Add gradient penalty if enabled
                        if use_gradient_penalty:
                            gp = self.gan.compute_gradient_penalty(real_images, fake_images.detach())
                            loss_d += self.settings['lambda_gp'].get() * gp
                        
                        loss_d.backward()
                        self.gan.optimizerD.step()
                    
                    # Train Generator
                    self.gan.optimizerG.zero_grad()
                    
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    output_fake = self.gan.discriminator(fake_images)
                    loss_g = self.gan.criterion(output_fake, real_labels)
                    
                    loss_g.backward()
                    self.gan.optimizerG.step()
                    
                    # Update EMA if enabled
                    if use_ema:
                        self.gan.update_ema()
                    
                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g.item()
                    batch_count += 1
                
                if batch_count > 0:
                    # Update learning rate schedulers
                    self.gan.schedulerG.step()
                    self.gan.schedulerD.step()
                    
                    avg_loss_d = total_loss_d / (batch_count * d_updates)
                    avg_loss_g = total_loss_g / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    # Get current learning rates
                    current_lr_g = self.gan.optimizerG.param_groups[0]['lr']
                    current_lr_d = self.gan.optimizerD.param_groups[0]['lr']
                    
                    # Log progress
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"D Loss: {avg_loss_d:.4f} | "
                                   f"G Loss: {avg_loss_g:.4f} | "
                                   f"LR G/D: {current_lr_g:.6f}/{current_lr_d:.6f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Total: {elapsed:.1f}s")
                    
                    # Generate samples at interval
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_training_samples(self):
    
        if not self.gan:
            return
    
        try:
            with torch.no_grad():
                # ALWAYS use regular generator for training display
                noise = torch.randn(1, self.gan.latent_dim).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()  # <-- Regular generator!
            
                # Convert to PIL...
            
                self.log_message(f"Generated training sample at epoch {self.current_epoch + 1}")
                #    REMOVE the EMA message!
                
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image with Lanczos when resizing"""
        img = (tensor + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        """Generate a single sample"""
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
                img = self.tensor_to_pil(generated[0])
                
                # Resize for display using Lanczos
                img_display = img.resize((256, 256), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                # Store
                self.generated_images.append(img)
                
                self.log_message("Generated single sample")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def save_model(self):
        """Save current model - MANUAL SAVE ONLY"""
        if not self.gan:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'discriminator_state_dict': self.gan.discriminator.state_dict(),
                    'optimizerG_state_dict': self.gan.optimizerG.state_dict(),
                    'optimizerD_state_dict': self.gan.optimizerD.state_dict(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                    'use_attention': self.settings['use_attention'].get(),
                    'use_residual': self.settings['use_residual'].get(),
                    'use_spectral_norm': self.settings['use_spectral_norm'].get(),
                }, filename)
                
                self.log_message(f"Model manually saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_generator(self):
        """Load generator from file"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                if 'latent_dim' in checkpoint:
                    self.settings['latent_dim'].set(checkpoint['latent_dim'])
                
                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])
                
                if 'ndf' in checkpoint:
                    self.settings['ndf'].set(checkpoint['ndf'])
                
                if 'use_attention' in checkpoint:
                    self.settings['use_attention'].set(checkpoint['use_attention'])
                
                if 'use_residual' in checkpoint:
                    self.settings['use_residual'].set(checkpoint['use_residual'])
                
                if 'use_spectral_norm' in checkpoint:
                    self.settings['use_spectral_norm'].set(checkpoint['use_spectral_norm'])
                
                # Initialize GAN with loaded settings
                self.initialize_gan()
                
                # Load state dicts
                self.gan.generator.load_state_dict(checkpoint['generator_state_dict'])
                if 'discriminator_state_dict' in checkpoint:
                    self.gan.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])
                
                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        """Generate a grid of images"""
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            
            with torch.no_grad():
                noise = torch.randn(num_images, self.gan.latent_dim).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
            
            # Clear previous images
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            # Create grid
            cols = 4
            rows = (num_images + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_tensor = generated[idx]
                        img = self.tensor_to_pil(img_tensor)
                        
                        # Resize for display using Lanczos
                        img_display = img.resize((128, 128), Image.Resampling.LANCZOS)
                        
                        photo = ImageTk.PhotoImage(img_display)
                        
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            
            self.log_message(f"Generated {num_images} images in grid")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            with open('dcgan_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            if os.path.exists('dcgan_defaults.json'):
                with open('dcgan_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_to_enhanced(self):
        """Reset to enhanced default settings for small datasets"""
        enhanced_settings = {
            'latent_dim': 128,
            'ngf': 64,
            'ndf': 64,
            'batch_size': 16,
            'learning_rate': 0.0002,
            'beta1': 0.5,
            'num_workers': min(4, multiprocessing.cpu_count()),
            'save_interval': 10,
            'generate_interval': 5,
            'use_attention': True,
            'use_residual': True,
            'use_spectral_norm': True,
            'use_augmentation': True,
            'use_ema': True,
            'use_gradient_penalty': True,
            'lambda_gp': 10.0,
            'ema_decay': 0.999,
            'd_updates_per_g': 1,
        }
        
        for key, value in enhanced_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        
        self.log_message("Reset to enhanced settings for small datasets")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Enhanced DCGAN Trainer (32x32 only)...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = DCGANApp(root)
    root.mainloop()