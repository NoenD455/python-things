import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path

# ==================== Neural Network ====================

class SimpleFastGAN:
    def __init__(self, image_size=32, latent_dim=128, ngf=64, ndf=64):
        self.image_size = image_size
        self.latent_dim = latent_dim
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Generator with SLE (Skip-Layer Excitation)
        class Generator(nn.Module):
            def __init__(self, image_size, latent_dim, ngf):
                super().__init__()
                self.image_size = image_size
                
                # Initial layer
                self.init = nn.Sequential(
                    nn.ConvTranspose2d(latent_dim, ngf * 8, 4, 1, 0, bias=False),
                    nn.BatchNorm2d(ngf * 8),
                    nn.ReLU(True)
                )  # ngf*8 x 4 x 4
                
                # Main upsampling blocks
                self.up1 = nn.Sequential(
                    nn.ConvTranspose2d(ngf * 8, ngf * 4, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf * 4),
                    nn.ReLU(True)
                )  # ngf*4 x 8 x 8
                
                self.up2 = nn.Sequential(
                    nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf * 2),
                    nn.ReLU(True)
                )  # ngf*2 x 16 x 16
                
                self.up3 = nn.Sequential(
                    nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf),
                    nn.ReLU(True)
                )  # ngf x 32 x 32
                
                # Output layer
                self.output = nn.Sequential(
                    nn.Conv2d(ngf, 3, 3, 1, 1, bias=False),
                    nn.Tanh()
                )  # 3 x 32 x 32
                
                # FastGAN SLE module - connects early layer to later layer
                self.sle = nn.Conv2d(ngf * 4, ngf, 1, bias=False)
                
            def forward(self, x):
                # Initial transformation
                x = self.init(x)  # [B, ngf*8, 4, 4]
                
                # First upsampling
                x = self.up1(x)   # [B, ngf*4, 8, 8]
                
                # Save for SLE connection
                sle_feat = x
                
                # Second upsampling
                x = self.up2(x)   # [B, ngf*2, 16, 16]
                x = self.up3(x)   # [B, ngf, 32, 32]
                
                # Apply SLE: connect early feature to final feature
                # Resize sle_feat to match x spatial dimensions
                sle_feat_resized = nn.functional.interpolate(
                    sle_feat, size=(32, 32), mode='bilinear', align_corners=False
                )
                sle_out = self.sle(sle_feat_resized)
                
                # Add the skip connection
                x = x + sle_out
                
                # Final output
                return self.output(x)
        
        # Discriminator with self-supervised rotation task
        class Discriminator(nn.Module):
            def __init__(self, image_size, ndf):
                super().__init__()
                
                # Main discriminator path (real/fake classification)
                self.main = nn.Sequential(
                    # Input: 3 x 32 x 32
                    nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf x 16 x 16
                    nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 2),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf*2 x 8 x 8
                    nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 4),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf*4 x 4 x 4
                )
                
                # Real/Fake classification head
                self.real_fake_head = nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False)
                
                # Self-supervised rotation classification head (4 rotations)
                self.rotation_head = nn.Sequential(
                    nn.Conv2d(ndf * 4, 128, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Flatten(),
                    nn.Linear(128 * 4 * 4, 4)  # 4 rotation classes
                )
                
            def forward(self, x):
                features = self.main(x)  # [B, ndf*4, 4, 4]
                
                # Real/fake prediction
                real_fake = self.real_fake_head(features).view(-1, 1)
                
                # Rotation prediction (only used during training with rotation augmentation)
                rotation = self.rotation_head(features)
                
                return real_fake, rotation
        
        self.generator = Generator(image_size, latent_dim, ngf)
        self.discriminator = Discriminator(image_size, ndf)
        
        # Loss functions
        self.criterion_gan = nn.BCEWithLogitsLoss()
        self.criterion_rotation = nn.CrossEntropyLoss()
        
        # Optimizers
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
        
        # FastGAN specific parameters
        self.use_self_supervision = True
        self.rotation_weight = 0.5  # Weight for rotation loss

# ==================== Dataset ====================

class FastGANDataset(Dataset):
    def __init__(self, image_paths, image_size=32, augment=False):
        self.image_paths = image_paths
        self.image_size = image_size
        self.augment = augment
        
        # Basic transform for all images
        self.base_transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
        
        # Augmentation transform (only used if augment=True)
        self.aug_transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomRotation(10),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            
            # Apply augmentation if enabled
            if self.augment:
                img_tensor = self.aug_transform(img)
            else:
                img_tensor = self.base_transform(img)
                
            return img_tensor
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            # Return a black image as fallback
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class FastGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("FastGAN Trainer - Optimized for 32x32")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings - Simplified for FastGAN
        self.settings = {
            'latent_dim': tk.IntVar(value=128),  # Increased for better representation
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=32),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'generate_interval': tk.IntVar(value=5),
            'use_augmentation': tk.BooleanVar(value=True),  # NEW: Augmentation toggle
            'use_self_supervision': tk.BooleanVar(value=True),  # NEW: Self-supervision toggle
            'rotation_weight': tk.DoubleVar(value=0.5)  # NEW: Rotation loss weight
        }
        
        # Performance tracking
        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        
        # For storing generated images
        self.generated_images = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="FastGAN Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size is fixed at 32x32
        tk.Label(left_frame, text="Image Size: 32x32 (Fixed)", 
                font=("Arial", 10)).pack(pady=(0, 10))
        
        # FastGAN features indicator
        tk.Label(left_frame, text="✓ SLE Connections\n✓ Self-Supervision\n✓ Style Learning", 
                font=("Arial", 9), justify=tk.LEFT, bg="lightyellow", 
                relief=tk.RIDGE, padx=10, pady=5).pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Dataset info label
        self.dataset_info = tk.Label(img_select_frame, text="No images loaded", fg="gray")
        self.dataset_info.pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize FastGAN", 
                 command=self.initialize_gan, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="50")  # Fewer epochs for FastGAN
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display - SINGLE LARGE IMAGE
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Single image display (256x256)
        self.single_image_frame = tk.Frame(preview_frame, width=256, height=256, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar at bottom
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="FastGAN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar for many settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Fixed image size display
        tk.Label(net_frame, text="Image Size: 32x32 (Fixed for FastGAN)", 
                font=("Arial", 10, "bold")).pack(pady=5)
        
        # Network parameters
        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 64, 256),
            ("Generator Features (ngf):", 'ngf', 32, 128),
            ("Discriminator Features (ndf):", 'ndf', 32, 128),
            ("Batch Size:", 'batch_size', 8, 64),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # FastGAN-specific settings
        fastgan_frame = tk.LabelFrame(scrollable_frame, text="FastGAN Features", padx=10, pady=10)
        fastgan_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Augmentation toggle
        aug_frame = tk.Frame(fastgan_frame)
        aug_frame.pack(fill=tk.X, pady=5)
        tk.Label(aug_frame, text="Use Data Augmentation:", width=30, anchor='w').pack(side=tk.LEFT)
        tk.Checkbutton(aug_frame, variable=self.settings['use_augmentation']).pack(side=tk.RIGHT)
        tk.Label(aug_frame, text="(Recommended for <1000 images)", fg="gray", 
                font=("Arial", 8)).pack(side=tk.RIGHT, padx=10)
        
        # Self-supervision toggle
        ss_frame = tk.Frame(fastgan_frame)
        ss_frame.pack(fill=tk.X, pady=5)
        tk.Label(ss_frame, text="Use Self-Supervision:", width=30, anchor='w').pack(side=tk.LEFT)
        tk.Checkbutton(ss_frame, variable=self.settings['use_self_supervision']).pack(side=tk.RIGHT)
        tk.Label(ss_frame, text="(Rotation task)", fg="gray", 
                font=("Arial", 8)).pack(side=tk.RIGHT, padx=10)
        
        # Rotation weight
        rot_frame = tk.Frame(fastgan_frame)
        rot_frame.pack(fill=tk.X, pady=5)
        tk.Label(rot_frame, text="Rotation Loss Weight:", width=30, anchor='w').pack(side=tk.LEFT)
        tk.Scale(rot_frame, from_=0.0, to=1.0, variable=self.settings['rotation_weight'],
                orient=tk.HORIZONTAL, length=200, resolution=0.1).pack(side=tk.RIGHT)
        tk.Label(rot_frame, textvariable=self.settings['rotation_weight'], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Generate Interval (epochs):", 'generate_interval', 1, 20),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text="Model: FastGAN (32x32 only)", anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="FastGAN Defaults", 
                 command=self.set_fastgan_defaults, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load FastGAN", 
                 command=self.load_generator, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def set_fastgan_defaults(self):
        """Set FastGAN optimized defaults"""
        fastgan_defaults = {
            'latent_dim': 128,
            'ngf': 64,
            'ndf': 64,
            'batch_size': 32,
            'learning_rate': 0.0002,
            'beta1': 0.5,
            'num_workers': min(4, multiprocessing.cpu_count()),
            'generate_interval': 5,
            'use_augmentation': True,
            'use_self_supervision': True,
            'rotation_weight': 0.5
        }
        
        for key, value in fastgan_defaults.items():
            if key in self.settings:
                if isinstance(value, bool):
                    self.settings[key].set(value)
                else:
                    self.settings[key].set(value)
        
        self.log_message("Set FastGAN optimized defaults")

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                # Add to log
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                
                # Update status with first line
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                
                print(message)  # Also print to console
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.dataset_info.config(
            text=f"{len(self.image_paths)} images", 
            fg="black" if len(self.image_paths) > 0 else "gray"
        )
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.dataset_info.config(text="No images loaded", fg="gray")
        self.log_message("Cleared all training images")

    def initialize_gan(self):
        """Initialize GAN with current settings"""
        try:
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            
            self.gan = SimpleFastGAN(
                image_size=32,  # Fixed at 32x32
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf
            )
            
            # Set FastGAN specific parameters
            self.gan.use_self_supervision = self.settings['use_self_supervision'].get()
            self.gan.rotation_weight = self.settings['rotation_weight'].get()
            
            self.log_message("Initialized FastGAN for 32x32 images")
            self.log_message(f"Latent dim: {latent_dim}, G features: {ngf}, D features: {ndf}")
            self.log_message(f"Self-supervision: {self.gan.use_self_supervision}, Rotation weight: {self.gan.rotation_weight}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing FastGAN: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: FastGAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            use_augmentation = self.settings['use_augmentation'].get()
            
            # Update optimizers with new settings
            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            for param_group in self.gan.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_fastgan,
                args=(epochs, batch_size, num_workers, use_augmentation),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started FastGAN training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}")
            self.log_message(f"Augmentation: {use_augmentation}")
            self.log_message(f"Self-supervision: {self.gan.use_self_supervision}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_fastgan(self, epochs, batch_size, num_workers, use_augmentation):
        """Training loop in separate thread"""
        try:
            generate_interval = self.settings['generate_interval'].get()
            
            # Create dataset with optional augmentation
            dataset = FastGANDataset(
                self.image_paths, 
                image_size=32, 
                augment=use_augmentation
            )
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                total_loss_rotation = 0
                batch_count = 0
                epoch_start = time.time()
                
                for real_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # ====== Train Discriminator ======
                    self.gan.optimizerD.zero_grad()
                    
                    # Real images
                    real_labels = torch.ones(batch_size_actual, 1, device=self.gan.device)
                    output_real, rotation_real = self.gan.discriminator(real_images)
                    loss_real = self.gan.criterion_gan(output_real, real_labels)
                    
                    # Fake images
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, 1, 1, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    fake_labels = torch.zeros(batch_size_actual, 1, device=self.gan.device)
                    output_fake, rotation_fake = self.gan.discriminator(fake_images.detach())
                    loss_fake = self.gan.criterion_gan(output_fake, fake_labels)
                    
                    # Self-supervised rotation loss (only on real images)
                    loss_rotation = 0
                    if self.gan.use_self_supervision and batch_size_actual >= 4:
                        # Create rotated versions and labels
                        rotations = []
                        rotation_labels = []
                        for i in range(batch_size_actual):
                            img = real_images[i]
                            for rot_idx in range(4):  # 0°, 90°, 180°, 270°
                                rotated = torch.rot90(img, rot_idx, [1, 2])
                                rotations.append(rotated)
                                rotation_labels.append(rot_idx)
                        
                        if len(rotations) > 0:
                            rotated_batch = torch.stack(rotations)
                            rotation_targets = torch.tensor(rotation_labels, device=self.gan.device)
                            
                            # Get rotation predictions
                            _, rotation_preds = self.gan.discriminator(rotated_batch)
                            loss_rotation = self.gan.criterion_rotation(rotation_preds, rotation_targets)
                    
                    # Total discriminator loss
                    loss_d = (loss_real + loss_fake) / 2
                    if self.gan.use_self_supervision:
                        loss_d = loss_d + self.gan.rotation_weight * loss_rotation
                    
                    loss_d.backward()
                    self.gan.optimizerD.step()
                    
                    # ====== Train Generator ======
                    self.gan.optimizerG.zero_grad()
                    
                    output_fake, _ = self.gan.discriminator(fake_images)
                    loss_g = self.gan.criterion_gan(output_fake, real_labels)
                    loss_g.backward()
                    self.gan.optimizerG.step()
                    
                    # Accumulate losses
                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g.item()
                    if self.gan.use_self_supervision:
                        total_loss_rotation += loss_rotation.item() if isinstance(loss_rotation, torch.Tensor) else 0
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    avg_loss_rotation = total_loss_rotation / batch_count if self.gan.use_self_supervision else 0
                    epoch_time = time.time() - epoch_start
                    
                    # Log progress
                    elapsed = time.time() - self.start_time
                    log_msg = f"Epoch {epoch+1}/{epochs} | "
                    log_msg += f"D Loss: {avg_loss_d:.4f} | "
                    log_msg += f"G Loss: {avg_loss_g:.4f} | "
                    if self.gan.use_self_supervision:
                        log_msg += f"Rot Loss: {avg_loss_rotation:.4f} | "
                    log_msg += f"Time: {epoch_time:.1f}s | "
                    log_msg += f"Total: {elapsed:.1f}s"
                    
                    self.log_message(log_msg)
                    
                    # Generate samples at interval
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("FastGAN training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_training_samples(self):
        """Generate sample images during training"""
        if not self.gan:
            return
        
        try:
            with torch.no_grad():
                # Generate 1 image
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
                
                # Convert to PIL
                img_tensor = generated[0]
                img = self.tensor_to_pil(img_tensor)
                
                # Resize to 256x256 for display
                img_display = img.resize((256, 256), Image.Resampling.LANCZOS)
                
                # Convert to PhotoImage
                photo = ImageTk.PhotoImage(img_display)
                
                # Update single image display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo  # Keep reference
                
                # Store for later
                self.generated_images.append(img)
                
                self.log_message(f"Generated training sample at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        img = (tensor + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        """Generate a single sample"""
        if not self.gan:
            self.log_message("Error: FastGAN not initialized!")
            return
        
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
                img = self.tensor_to_pil(generated[0])
                
                # Resize for display
                img_display = img.resize((256, 256), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                # Store
                self.generated_images.append(img)
                
                self.log_message("Generated single sample")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def save_model(self):
        """Save current model - MANUAL SAVE ONLY"""
        if not self.gan:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'discriminator_state_dict': self.gan.discriminator.state_dict(),
                    'optimizerG_state_dict': self.gan.optimizerG.state_dict(),
                    'optimizerD_state_dict': self.gan.optimizerD.state_dict(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                    'use_self_supervision': self.settings['use_self_supervision'].get(),
                    'rotation_weight': self.settings['rotation_weight'].get(),
                }, filename)
                
                self.log_message(f"FastGAN model manually saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_generator(self):
        """Load generator from file"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                if 'latent_dim' in checkpoint:
                    self.settings['latent_dim'].set(checkpoint['latent_dim'])
                
                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])
                
                if 'ndf' in checkpoint:
                    self.settings['ndf'].set(checkpoint['ndf'])
                
                if 'use_self_supervision' in checkpoint:
                    self.settings['use_self_supervision'].set(checkpoint['use_self_supervision'])
                
                if 'rotation_weight' in checkpoint:
                    self.settings['rotation_weight'].set(checkpoint['rotation_weight'])
                
                # Initialize GAN with loaded settings
                self.initialize_gan()
                
                # Load state dicts
                self.gan.generator.load_state_dict(checkpoint['generator_state_dict'])
                if 'discriminator_state_dict' in checkpoint:
                    self.gan.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])
                
                self.log_message(f"Loaded FastGAN model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        """Generate a grid of images"""
        if not self.gan:
            self.log_message("Error: FastGAN not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            
            with torch.no_grad():
                noise = torch.randn(num_images, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
            
            # Clear previous images
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            # Create grid
            cols = 4
            rows = (num_images + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_tensor = generated[idx]
                        img = self.tensor_to_pil(img_tensor)
                        
                        # Resize for display
                        img_display = img.resize((128, 128), Image.Resampling.LANCZOS)
                        
                        photo = ImageTk.PhotoImage(img_display)
                        
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            
            self.log_message(f"Generated {num_images} images in grid")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {}
            for k, v in self.settings.items():
                if isinstance(v.get(), bool):
                    defaults[k] = v.get()
                else:
                    defaults[k] = v.get()
            
            import json
            with open('fastgan_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("FastGAN settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            import json
            if os.path.exists('fastgan_defaults.json'):
                with open('fastgan_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.log_message("Loaded FastGAN defaults")
            else:
                self.log_message("No FastGAN defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting FastGAN Trainer...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = FastGANApp(root)
    root.mainloop()