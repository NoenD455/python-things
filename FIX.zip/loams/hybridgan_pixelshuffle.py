import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path

# =============================================================================
# HYBRID GAN – combines FastGAN's SLE + reconstruction loss with
#             PixelShuffle upsampling (clean, no checkerboard artefacts)
#             and larger capacity (ngf/ndf=64).
# =============================================================================

class SLE(nn.Module):
    """
    Skip‑Layer Excitation – reweights high‑resolution features using
    low‑resolution features. Improves gradient flow and speeds up convergence.
    """
    def __init__(self, low_ch, high_ch):
        super().__init__()
        self.avgpool = nn.AdaptiveAvgPool2d(4)
        self.conv1 = nn.Conv2d(low_ch, low_ch//2, 1, bias=False)
        self.relu = nn.LeakyReLU(0.1, inplace=True)
        self.conv2 = nn.Conv2d(low_ch//2, high_ch, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, low_feat, high_feat):
        x = self.avgpool(low_feat)
        x = self.conv1(x)
        x = self.relu(x)
        x = self.conv2(x)
        x = nn.functional.adaptive_avg_pool2d(x, 1)
        gate = self.sigmoid(x)
        return high_feat * gate


class Generator(nn.Module):
    """
    Generator with:
      - PixelShuffle upsampling (no checkerboard artefacts).
      - Two SLE connections (4→8 and 8→16) for better gradient flow.
      - ngf = 64 → enough capacity for diverse datasets.
    """
    def __init__(self, latent_dim=100, ngf=64):
        super().__init__()
        # 1x1 -> 4x4 (transposed conv is safe here, stride=1)
        self.init_conv = nn.Sequential(
            nn.ConvTranspose2d(latent_dim, ngf * 4, 4, 1, 0, bias=False),
            nn.BatchNorm2d(ngf * 4),
            nn.ReLU(True)
        )

        # 4x4 -> 8x8 (PixelShuffle)
        self.up1 = nn.Sequential(
            nn.Conv2d(ngf * 4, ngf * 8, 3, 1, 1, bias=False),
            nn.BatchNorm2d(ngf * 8),
            nn.ReLU(True),
            nn.PixelShuffle(2)        # (ngf*2, 8, 8)
        )

        # 8x8 -> 16x16
        self.up2 = nn.Sequential(
            nn.Conv2d(ngf * 2, ngf * 4, 3, 1, 1, bias=False),
            nn.BatchNorm2d(ngf * 4),
            nn.ReLU(True),
            nn.PixelShuffle(2)        # (ngf, 16, 16)
        )

        # 16x16 -> 32x32
        self.up3 = nn.Sequential(
            nn.Conv2d(ngf, 12, 3, 1, 1, bias=False),
            nn.PixelShuffle(2),       # (3, 32, 32)
            nn.Tanh()
        )

        # Two SLE connections
        self.sle1 = SLE(low_ch=ngf * 4, high_ch=ngf * 2)   # 4x4 -> 8x8
        self.sle2 = SLE(low_ch=ngf * 2, high_ch=ngf)      # 8x8 -> 16x16

    def forward(self, z):
        x0 = self.init_conv(z)        # (B, ngf*4, 4, 4)
        x1 = self.up1(x0)            # (B, ngf*2, 8, 8)
        x1 = self.sle1(x0, x1)       # excite 8x8 with 4x4 features
        x2 = self.up2(x1)            # (B, ngf, 16, 16)
        x2 = self.sle2(x1, x2)       # excite 16x16 with 8x8 features
        out = self.up3(x2)           # (B, 3, 32, 32)
        return out


class Discriminator(nn.Module):
    """
    Discriminator with:
      - Spectral normalisation on all conv layers (improves stability).
      - Self‑supervised decoder with PixelShuffle upsampling (clean reconstructions).
      - ndf = 64.
    """
    def __init__(self, ndf=64):
        super().__init__()
        # Downsampling path (spectral norm applied)
        self.conv1 = nn.Sequential(
            nn.utils.spectral_norm(nn.Conv2d(3, ndf, 4, 2, 1, bias=False)),
            nn.LeakyReLU(0.2, inplace=True)
        )
        self.conv2 = nn.Sequential(
            nn.utils.spectral_norm(nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False)),
            nn.BatchNorm2d(ndf * 2),
            nn.LeakyReLU(0.2, inplace=True)
        )
        self.conv3 = nn.Sequential(
            nn.utils.spectral_norm(nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False)),
            nn.BatchNorm2d(ndf * 4),
            nn.LeakyReLU(0.2, inplace=True)
        )

        # Adversarial output
        self.adv_layer = nn.utils.spectral_norm(
            nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False)
        )

        # Self‑supervised decoder (PixelShuffle – no checkerboard artefacts)
        self.decoder = nn.Sequential(
            nn.Conv2d(ndf * 4, ndf * 8, 3, 1, 1, bias=False),
            nn.BatchNorm2d(ndf * 8),
            nn.LeakyReLU(0.2, inplace=True),
            nn.PixelShuffle(2),               # (ndf*2, 8, 8)
            nn.Conv2d(ndf * 2, ndf * 4, 3, 1, 1, bias=False),
            nn.BatchNorm2d(ndf * 4),
            nn.LeakyReLU(0.2, inplace=True),
            nn.PixelShuffle(2),               # (ndf, 16, 16)
            nn.Conv2d(ndf, 12, 3, 1, 1, bias=False),
            nn.PixelShuffle(2),               # (3, 32, 32)
            nn.Tanh()
        )

    def forward(self, x, return_reconstruction=False):
        f1 = self.conv1(x)   # (B, ndf, 16, 16)
        f2 = self.conv2(f1)  # (B, ndf*2, 8, 8)
        f3 = self.conv3(f2)  # (B, ndf*4, 4, 4)

        adv_out = self.adv_layer(f3).view(-1, 1)

        if return_reconstruction:
            rec = self.decoder(f3)
            return adv_out, rec
        else:
            return adv_out


# =============================================================================
# HYBRID GAN WRAPPER
# =============================================================================
class HybridGAN:
    def __init__(self, latent_dim=100, ngf=64, ndf=64):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")

        self.latent_dim = latent_dim
        self.generator = Generator(latent_dim, ngf).to(self.device)
        self.discriminator = Discriminator(ndf).to(self.device)

        self.criterion = nn.BCEWithLogitsLoss()
        self.rec_loss_fn = nn.L1Loss()   # L1 gives sharper images

        self.optimizer_G = optim.Adam(self.generator.parameters(),
                                      lr=0.0002, betas=(0.5, 0.999))
        self.optimizer_D = optim.Adam(self.discriminator.parameters(),
                                      lr=0.0002, betas=(0.5, 0.999))

        self.rec_loss_weight = 10.0      # lambda as in FastGAN paper

    def train_step(self, real_images):
        batch_size = real_images.size(0)
        real_images = real_images.to(self.device)

        # ---------------------
        # 1. Train Discriminator
        # ---------------------
        self.optimizer_D.zero_grad()

        # Real images: adversarial + reconstruction
        real_out, rec = self.discriminator(real_images, return_reconstruction=True)
        real_labels = torch.ones(batch_size, 1, device=self.device)
        loss_D_real = self.criterion(real_out, real_labels)

        loss_rec = self.rec_loss_fn(rec, real_images) * self.rec_loss_weight

        # Fake images: adversarial only
        noise = torch.randn(batch_size, self.latent_dim, 1, 1, device=self.device)
        fake = self.generator(noise)
        fake_out = self.discriminator(fake.detach())
        fake_labels = torch.zeros(batch_size, 1, device=self.device)
        loss_D_fake = self.criterion(fake_out, fake_labels)

        loss_D = (loss_D_real + loss_D_fake) / 2 + loss_rec
        loss_D.backward()
        self.optimizer_D.step()

        # -----------------
        # 2. Train Generator
        # -----------------
        self.optimizer_G.zero_grad()

        noise = torch.randn(batch_size, self.latent_dim, 1, 1, device=self.device)
        fake = self.generator(noise)
        fake_out = self.discriminator(fake)
        loss_G = self.criterion(fake_out, real_labels)

        loss_G.backward()
        self.optimizer_G.step()

        return loss_D.item(), loss_G.item(), loss_rec.item()


# =============================================================================
# DATASET
# =============================================================================
class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except:
            return torch.zeros(3, 32, 32)


# =============================================================================
# GUI APPLICATION
# =============================================================================
class HybridGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("HybridGAN – PixelShuffle + SLE – 32x32 Training")
        self.root.geometry("1000x700")

        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        self.generated_images = []

        # Settings (defaults: ngf=64, ndf=64 for better quality)
        self.settings = {
            'latent_dim': tk.IntVar(value=100),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'rec_loss_weight': tk.DoubleVar(value=10.0),
            'generate_interval': tk.IntVar(value=5),
        }

        self.setup_gui()
        self.root.after(100, self.process_messages)

    # -------------------------------------------------------------------------
    # GUI Layout
    # -------------------------------------------------------------------------
    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))

        tk.Label(left_frame, text="HybridGAN Controls",
                font=("Arial", 12, "bold")).pack(pady=(0,10))

        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images,
                 width=20).pack(pady=5)
        tk.Button(img_frame, text="Clear All", command=self.clear_images,
                 width=20).pack(pady=5)

        self.image_listbox = tk.Listbox(img_frame, height=8)
        self.image_listbox.pack(fill=tk.BOTH, expand=True, pady=5)

        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0,10))

        tk.Button(train_frame, text="Initialize HybridGAN",
                 command=self.init_gan, width=20).pack(pady=5)

        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="START TRAINING",
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="STOP",
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)

        # Generation
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        tk.Button(gen_frame, text="Generate Sample",
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model",
                 command=self.save_model, width=20).pack(pady=5)

        # Right panel – preview & log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Preview", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,10))

        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        self.single_image_label = tk.Label(self.single_image_frame, text="No image", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)

        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

        self.status_label = tk.Label(self.training_tab, text="Ready",
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="HybridGAN Settings",
                font=("Arial", 14, "bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Network architecture
        net_frame = tk.LabelFrame(scrollable_frame, text="Network (ngf/ndf=64 recommended)", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0,10))

        sliders = [
            ("Latent Dimension:", 'latent_dim', 32, 256),
            ("Generator Filters (ngf):", 'ngf', 32, 128),
            ("Discriminator Filters (ndf):", 'ndf', 32, 128),
            ("Batch Size (CPU: 4-8):", 'batch_size', 1, 32),
        ]
        for label, key, low, high in sliders:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=low, to=high, variable=self.settings[key],
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT, padx=5)

        # Training hyperparameters
        train_frame = tk.LabelFrame(scrollable_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0,10))

        hp_sliders = [
            ("Learning Rate:", 'learning_rate', 1e-5, 1e-2),
            ("Beta1 (Adam):", 'beta1', 0.0, 0.999),
            ("Reconstruction Loss Weight:", 'rec_loss_weight', 1.0, 50.0),
            ("Generate Every N epochs:", 'generate_interval', 1, 20),
        ]
        for label, key, low, high in hp_sliders:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label, width=30, anchor='w').pack(side=tk.LEFT)
            if key in ['learning_rate', 'beta1']:
                res = 0.00001 if key == 'learning_rate' else 0.001
                tk.Scale(frame, from_=low, to=high, resolution=res,
                        variable=self.settings[key], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=low, to=high, variable=self.settings[key],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT, padx=5)

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X)
        tk.Label(sys_frame, text=f"CPU cores: {multiprocessing.cpu_count()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text="✓ PixelShuffle → artifact‑free upsampling", fg="green", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text="✓ Two SLE connections + spectral norm → fast, stable", fg="green", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text="✓ Reconstruction loss with clean PixelShuffle decoder → no mode collapse", fg="green", anchor='w').pack(fill=tk.X, pady=2)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Generate Images",
                font=("Arial", 14, "bold")).pack(pady=(0,20))

        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0,20))
        tk.Button(load_frame, text="Load Generator",
                 command=self.load_generator, width=20).pack(pady=5)

        gen_frame = tk.LabelFrame(main_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0,20))
        tk.Label(gen_frame, text="Number of images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var,
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        tk.Button(gen_frame, text="Generate Grid",
                 command=self.generate_grid, width=20).pack(pady=10)

        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        self.gen_scroll_frame.bind("<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all")))
        self.gen_canvas.create_window((0,0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # -------------------------------------------------------------------------
    # Event Handlers
    # -------------------------------------------------------------------------
    def log_message(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(msg)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images")

    def init_gan(self):
        try:
            self.gan = HybridGAN(
                latent_dim=self.settings['latent_dim'].get(),
                ngf=self.settings['ngf'].get(),
                ndf=self.settings['ndf'].get()
            )
            self.gan.rec_loss_weight = self.settings['rec_loss_weight'].get()
            self.log_message(f"HybridGAN initialized. Device: {self.gan.device}")
        except Exception as e:
            self.log_message(f"Init error: {str(e)}")

    def start_training(self):
        if not self.image_paths:
            self.log_message("No training images!")
            return
        if not self.gan:
            self.log_message("Initialize HybridGAN first!")
            return
        if self.training:
            self.log_message("Already training")
            return

        epochs = int(self.epoch_var.get())
        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()

        lr = self.settings['learning_rate'].get()
        beta1 = self.settings['beta1'].get()
        for param_group in self.gan.optimizer_G.param_groups:
            param_group['lr'] = lr
            param_group['betas'] = (beta1, 0.999)
        for param_group in self.gan.optimizer_D.param_groups:
            param_group['lr'] = lr
            param_group['betas'] = (beta1, 0.999)

        thread = threading.Thread(target=self.train_loop,
                                 args=(epochs,), daemon=True)
        thread.start()
        self.log_message(f"Training started for {epochs} epochs")

    def train_loop(self, epochs):
        try:
            batch_size = self.settings['batch_size'].get()
            generate_interval = self.settings['generate_interval'].get()

            dataset = ImageDataset(self.image_paths, image_size=32)
            dataloader = DataLoader(dataset, batch_size=batch_size,
                                   shuffle=True, num_workers=0, drop_last=True)

            for epoch in range(epochs):
                if not self.training:
                    break

                epoch_loss_D = 0.0
                epoch_loss_G = 0.0
                epoch_loss_rec = 0.0
                n_batches = 0
                epoch_start = time.time()

                for real_images in dataloader:
                    if not self.training:
                        break

                    loss_D, loss_G, loss_rec = self.gan.train_step(real_images)
                    epoch_loss_D += loss_D
                    epoch_loss_G += loss_G
                    epoch_loss_rec += loss_rec
                    n_batches += 1

                if n_batches > 0:
                    epoch_loss_D /= n_batches
                    epoch_loss_G /= n_batches
                    epoch_loss_rec /= n_batches
                    epoch_time = time.time() - epoch_start
                    self.current_epoch = epoch + 1
                    self.log_message(
                        f"Epoch {epoch+1}/{epochs} | "
                        f"D: {epoch_loss_D:.4f} | G: {epoch_loss_G:.4f} | "
                        f"Rec: {epoch_loss_rec:.4f} | Time: {epoch_time:.1f}s"
                    )

                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_sample()

            self.training = False
            self.log_message("Training finished!")
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()

    def generate_training_sample(self):
        if not self.gan:
            return
        with torch.no_grad():
            noise = torch.randn(1, self.gan.latent_dim, 1, 1, device=self.gan.device)
            fake = self.gan.generator(noise).cpu()
            img = self.tensor_to_pil(fake[0])
            img_display = img.resize((200, 200), Image.Resampling.NEAREST)
            photo = ImageTk.PhotoImage(img_display)
            self.single_image_label.config(image=photo, text="")
            self.single_image_label.image = photo
            self.generated_images.append(img)

    def generate_sample(self):
        self.generate_training_sample()
        self.log_message("Generated sample")

    def save_model(self):
        if not self.gan:
            return
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth")]
        )
        if filename:
            torch.save({
                'generator': self.gan.generator.state_dict(),
                'discriminator': self.gan.discriminator.state_dict(),
                'optimizer_G': self.gan.optimizer_G.state_dict(),
                'optimizer_D': self.gan.optimizer_D.state_dict(),
                'settings': {k: v.get() for k, v in self.settings.items()}
            }, filename)
            self.log_message(f"Model saved to {filename}")

    def load_generator(self):
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth")]
        )
        if filename:
            checkpoint = torch.load(filename, map_location='cpu')
            if 'settings' in checkpoint:
                for k, v in checkpoint['settings'].items():
                    if k in self.settings:
                        self.settings[k].set(v)
            self.init_gan()
            self.gan.generator.load_state_dict(checkpoint['generator'])
            if 'discriminator' in checkpoint:
                self.gan.discriminator.load_state_dict(checkpoint['discriminator'])
            self.log_message(f"Model loaded from {filename}")

    def generate_grid(self):
        if not self.gan:
            self.log_message("No model loaded!")
            return
        n = self.num_gen_var.get()
        with torch.no_grad():
            noise = torch.randn(n, self.gan.latent_dim, 1, 1, device=self.gan.device)
            fake = self.gan.generator(noise).cpu()

        for w in self.gen_scroll_frame.winfo_children():
            w.destroy()

        cols = 4
        for i in range(0, n, cols):
            row = tk.Frame(self.gen_scroll_frame)
            row.pack(pady=5)
            for j in range(cols):
                idx = i + j
                if idx < n:
                    img = self.tensor_to_pil(fake[idx])
                    img = img.resize((128,128), Image.Resampling.NEAREST)
                    photo = ImageTk.PhotoImage(img)
                    lbl = tk.Label(row, image=photo)
                    lbl.image = photo
                    lbl.pack(side=tk.LEFT, padx=5)
        self.log_message(f"Generated {n} images")

    @staticmethod
    def tensor_to_pil(tensor):
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        return transforms.ToPILImage()(img)

    def stop_training(self):
        self.training = False
        self.log_message("Stopping training...")


if __name__ == "__main__":
    multiprocessing.freeze_support()
    print("Starting HybridGAN – PixelShuffle upsampling, clean 32x32 images, fast training")
    print(f"PyTorch version: {torch.__version__}")
    root = tk.Tk()
    app = HybridGANApp(root)
    root.mainloop()