import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os
import threading
import queue
import librosa
import librosa.display
import soundfile as sf
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import traceback
import sys
import warnings
warnings.filterwarnings('ignore')

# ==================== AUDIO UTILITIES ====================

class AudioProcessor:
    @staticmethod
    def load_audio(filepath, target_sr=22050, duration=1.0):
        """Load audio file - use first 'duration' seconds"""
        try:
            audio, sr = librosa.load(filepath, sr=target_sr, duration=duration)
            
            if len(audio) > 0:
                audio = audio / (np.max(np.abs(audio)) + 1e-8) * 0.9
            
            target_samples = int(target_sr * duration)
            
            if len(audio) < target_samples:
                audio = np.pad(audio, (0, target_samples - len(audio)), mode='constant')
            
            return audio, sr
            
        except Exception as e:
            print(f"Error loading {filepath}: {e}")
            return np.zeros(int(target_sr * duration)), target_sr
    
    @staticmethod
    def audio_to_mel(audio, sr=22050, n_mels=128):
        """Convert audio to mel spectrogram - ensure 128x128 output"""
        target_length = int(sr * 1.0)
        if len(audio) > target_length:
            audio = audio[:target_length]
        elif len(audio) < target_length:
            audio = np.pad(audio, (0, target_length - len(audio)), mode='constant')
        
        # Use fixed hop_length to get exactly 128 time frames
        n_fft = 1024
        hop_length = target_length // 128  # Calculate to get 128 frames
        
        mel_spec = librosa.feature.melspectrogram(
            y=audio, 
            sr=sr,
            n_mels=n_mels,
            n_fft=n_fft,
            hop_length=hop_length
        )
        
        # Trim or pad to exactly 128x128
        if mel_spec.shape[1] > 128:
            mel_spec = mel_spec[:, :128]
        elif mel_spec.shape[1] < 128:
            pad_width = 128 - mel_spec.shape[1]
            mel_spec = np.pad(mel_spec, ((0, 0), (0, pad_width)), mode='constant')
        
        mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
        mel_spec_db = np.clip(mel_spec_db, -80, 0)
        mel_spec_db = (mel_spec_db + 80) / 80
        mel_spec_db = mel_spec_db * 2 - 1
        
        return mel_spec_db
    
    @staticmethod
    def mel_to_audio(mel_spec_db, sr=22050):
        """Convert mel spectrogram back to audio"""
        try:
            mel_spec_db = (mel_spec_db + 1) / 2 * 80 - 80
            mel_spec = librosa.db_to_power(mel_spec_db)
            
            # Use same hop_length as before
            target_length = sr * 1.0
            hop_length = int(target_length // 128)
            
            audio = librosa.feature.inverse.mel_to_audio(
                mel_spec,
                sr=sr,
                n_fft=1024,
                hop_length=hop_length,
                n_iter=32
            )
            
            if len(audio) > 0:
                audio = audio / (np.max(np.abs(audio)) + 1e-8)
            
            return audio
        except Exception as e:
            print(f"Error in mel_to_audio: {e}")
            return np.zeros(sr)
    
    @staticmethod
    def plot_spectrogram(mel_spec_db, title="Mel Spectrogram"):
        """Create a matplotlib plot of spectrogram"""
        fig, ax = plt.subplots(figsize=(6, 4))
        
        mel_display = (mel_spec_db + 1) / 2 * 80 - 80
        
        img = librosa.display.specshow(
            mel_display,
            sr=22050,
            hop_length=172,  # 22050/128 ≈ 172
            x_axis='time',
            y_axis='mel',
            ax=ax,
            cmap='magma'
        )
        
        ax.set_title(title)
        fig.colorbar(img, ax=ax, format='%+2.0f dB')
        plt.tight_layout()
        
        return fig
    
    @staticmethod
    def save_audio(audio, filename, sr=22050):
        """Save audio to file"""
        try:
            sf.write(filename, audio, sr)
            return True
        except Exception as e:
            print(f"Error saving audio: {e}")
            return False

# ==================== AUDIO DCGAN ====================

class AudioDCGAN:
    def __init__(self, mel_shape=(1, 128, 128), latent_dim=100):
        self.mel_shape = mel_shape
        self.latent_dim = latent_dim
        
        torch.set_num_threads(2)
        if torch.cuda.is_available():
            self.device = torch.device("cuda")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
            self.device = torch.device("cpu")
        
        # Generator for 128x128 output
        class Generator(nn.Module):
            def __init__(self, latent_dim, mel_shape):
                super().__init__()
                
                self.projection = nn.Sequential(
                    nn.Linear(latent_dim, 512 * 4 * 4),
                    nn.BatchNorm1d(512 * 4 * 4),
                    nn.ReLU(True)
                )
                
                # 4x4 → 8x8 → 16x16 → 32x32 → 64x64 → 128x128
                self.upsample = nn.Sequential(
                    # 4x4 → 8x8
                    nn.ConvTranspose2d(512, 256, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(256),
                    nn.ReLU(True),
                    
                    # 8x8 → 16x16
                    nn.ConvTranspose2d(256, 128, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(128),
                    nn.ReLU(True),
                    
                    # 16x16 → 32x32
                    nn.ConvTranspose2d(128, 64, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(64),
                    nn.ReLU(True),
                    
                    # 32x32 → 64x64
                    nn.ConvTranspose2d(64, 32, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(32),
                    nn.ReLU(True),
                    
                    # 64x64 → 128x128
                    nn.ConvTranspose2d(32, 16, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(16),
                    nn.ReLU(True),
                    
                    # Final convolution
                    nn.Conv2d(16, mel_shape[0], 3, 1, 1, bias=False),
                    nn.Tanh()
                )
            
            def forward(self, x):
                x = self.projection(x)
                x = x.view(-1, 512, 4, 4)
                x = self.upsample(x)
                return x
        
        # Discriminator for 128x128 input
        class Discriminator(nn.Module):
            def __init__(self, mel_shape):
                super().__init__()
                
                # 128x128 → 64x64 → 32x32 → 16x16 → 8x8 → 4x4 → 1x1
                self.main = nn.Sequential(
                    # 128x128 → 64x64
                    nn.Conv2d(mel_shape[0], 64, 4, 2, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    
                    # 64x64 → 32x32
                    nn.Conv2d(64, 128, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(128),
                    nn.LeakyReLU(0.2, inplace=True),
                    
                    # 32x32 → 16x16
                    nn.Conv2d(128, 256, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(256),
                    nn.LeakyReLU(0.2, inplace=True),
                    
                    # 16x16 → 8x8
                    nn.Conv2d(256, 512, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(512),
                    nn.LeakyReLU(0.2, inplace=True),
                    
                    # 8x8 → 4x4
                    nn.Conv2d(512, 1024, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(1024),
                    nn.LeakyReLU(0.2, inplace=True),
                    
                    # 4x4 → 1x1
                    nn.Conv2d(1024, 1, 4, 1, 0, bias=False),
                    nn.Sigmoid()
                )
            
            def forward(self, x):
                return self.main(x).view(-1)
        
        self.generator = Generator(latent_dim, mel_shape).to(self.device)
        self.discriminator = Discriminator(mel_shape).to(self.device)
        
        self._initialize_weights()
        
        self.criterion = nn.BCELoss()
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        
        self.audio_processor = AudioProcessor()
        
        print(f"Audio GAN initialized for {mel_shape} mel spectrograms")
    
    def _initialize_weights(self):
        for m in self.generator.modules():
            if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
                nn.init.normal_(m.weight.data, 0.0, 0.02)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.normal_(m.weight.data, 1.0, 0.02)
                nn.init.constant_(m.bias.data, 0)
        
        for m in self.discriminator.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight.data, 0.0, 0.02)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.normal_(m.weight.data, 1.0, 0.02)
                nn.init.constant_(m.bias.data, 0)
    
    def train_step(self, real_mels):
        batch_size = real_mels.size(0)
        
        # Train Discriminator
        self.optimizerD.zero_grad()
        
        real_labels = torch.ones(batch_size, device=self.device) * 0.9
        real_pred = self.discriminator(real_mels)
        d_loss_real = self.criterion(real_pred, real_labels)
        
        noise = torch.randn(batch_size, self.latent_dim, device=self.device)
        fake_mels = self.generator(noise)
        fake_labels = torch.zeros(batch_size, device=self.device) + 0.1
        fake_pred = self.discriminator(fake_mels.detach())
        d_loss_fake = self.criterion(fake_pred, fake_labels)
        
        d_loss = (d_loss_real + d_loss_fake) / 2
        d_loss.backward()
        self.optimizerD.step()
        
        # Train Generator
        self.optimizerG.zero_grad()
        
        fake_pred = self.discriminator(fake_mels)
        g_loss = self.criterion(fake_pred, real_labels)
        g_loss.backward()
        self.optimizerG.step()
        
        return {
            'd_loss': d_loss.item(),
            'g_loss': g_loss.item(),
            'fake_mels': fake_mels.detach().cpu()
        }
    
    def generate_audio(self, num_samples=1):
        """Generate audio from random noise"""
        with torch.no_grad():
            self.generator.eval()
            
            noise = torch.randn(num_samples, self.latent_dim, device=self.device)
            mels = self.generator(noise)
            
            self.generator.train()
            
            mels = mels.cpu()
            audios = []
            
            for i in range(num_samples):
                mel_spec = mels[i].squeeze().numpy()
                audio = self.audio_processor.mel_to_audio(mel_spec)
                audios.append(audio)
            
            return audios, mels

# ==================== AUDIO DATASET ====================

class AudioDataset(Dataset):
    def __init__(self, audio_paths, duration=1.0, sr=22050, n_mels=128):
        self.audio_paths = audio_paths
        self.duration = duration
        self.sr = sr
        self.n_mels = n_mels
        self.audio_processor = AudioProcessor()
        
        self.mel_spectrograms = []
        self.audio_files = []
        
        print(f"Loading {len(audio_paths)} audio files...")
        for i, path in enumerate(audio_paths):
            try:
                audio, sr = self.audio_processor.load_audio(path, sr, duration)
                mel_spec = self.audio_processor.audio_to_mel(audio, sr, n_mels)
                
                # Ensure it's exactly 128x128
                if mel_spec.shape != (n_mels, 128):
                    print(f"Warning: {path} has shape {mel_spec.shape}, expected ({n_mels}, 128)")
                    continue
                
                mel_tensor = torch.FloatTensor(mel_spec).unsqueeze(0)
                self.mel_spectrograms.append(mel_tensor)
                self.audio_files.append((audio, sr, os.path.basename(path)))
                
                if (i + 1) % 10 == 0:
                    print(f"  Loaded {i + 1}/{len(audio_paths)} files")
                    
            except Exception as e:
                print(f"Error loading {path}: {e}")
        
        print(f"Dataset loaded: {len(self.mel_spectrograms)} valid audio files (128x128)")
    
    def __len__(self):
        return len(self.mel_spectrograms)
    
    def __getitem__(self, idx):
        return self.mel_spectrograms[idx]
    
    def get_audio(self, idx):
        if idx < len(self.audio_files):
            return self.audio_files[idx]
        return None

# ==================== GUI APPLICATION ====================

class AudioGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Audio GAN Explorer")
        
        # Create scrollable main frame
        main_frame = tk.Frame(root)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create canvas and scrollbar
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Pack canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Bind mouse wheel for scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
        self.audio_processor = AudioProcessor()
        
        # Settings
        self.duration = 1.0
        self.sr = 22050
        self.n_mels = 128
        
        # State
        self.audio_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Generated audio storage
        self.generated_audios = []
        self.generated_mels = []
        
        # Current audio for playback
        self.current_audio = None
        self.current_audio_name = ""
        
        self.setup_gui(scrollable_frame)
        self.root.after(100, self.process_messages)
        
        # Set minimum window size
        self.root.minsize(1000, 700)
        
        print("Audio GAN Explorer Ready")
        print("Add audio files and click Initialize GAN to start")
    
    def setup_gui(self, parent):
        # Use parent (scrollable_frame) instead of creating new container
        main_container = tk.Frame(parent, padx=10, pady=10)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Left panel
        left_frame = tk.Frame(main_container, width=350)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        title_label = tk.Label(left_frame, text="Audio GAN Explorer", 
                              font=("Arial", 14, "bold"))
        title_label.pack(pady=(0, 10))
        
        # Audio selection
        tk.Label(left_frame, text="Audio Selection:", 
                font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 5))
        
        tk.Button(left_frame, text="Add Audio Files", 
                 command=self.add_audio, height=2).pack(fill=tk.X, pady=5)
        
        tk.Button(left_frame, text="Clear All Audio", 
                 command=self.clear_audio).pack(fill=tk.X, pady=5)
        
        # Audio list
        list_frame = tk.Frame(left_frame, height=100)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        list_scrollbar = tk.Scrollbar(list_frame)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.audio_listbox = tk.Listbox(list_frame, yscrollcommand=list_scrollbar.set, height=8)
        self.audio_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.audio_listbox.bind('<<ListboxSelect>>', self.on_audio_select)
        
        list_scrollbar.config(command=self.audio_listbox.yview)
        
        # Training controls
        tk.Label(left_frame, text="Training Controls:", 
                font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(10, 5))
        
        tk.Button(left_frame, text="Initialize GAN", 
                 command=self.initialize_gan, height=2).pack(fill=tk.X, pady=5)
        
        tk.Label(left_frame, text="Epochs:").pack(anchor=tk.W, pady=(10, 5))
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(left_frame, textvariable=self.epoch_var).pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(left_frame, text="Batch Size:").pack(anchor=tk.W, pady=(5, 5))
        self.batch_var = tk.StringVar(value="8")
        tk.Entry(left_frame, textvariable=self.batch_var).pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(left_frame, text="Start Training", 
                 command=self.start_training, height=2, bg="lightgreen").pack(fill=tk.X, pady=5)
        
        tk.Button(left_frame, text="Stop Training", 
                 command=self.stop_training, height=2, bg="salmon").pack(fill=tk.X, pady=5)
        
        # Generation controls
        tk.Label(left_frame, text="Generation:", 
                font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(10, 5))
        
        tk.Button(left_frame, text="Generate & Inspect", 
                 command=self.generate_and_inspect, height=2, bg="lightblue").pack(fill=tk.X, pady=5)
        
        tk.Button(left_frame, text="Play Generated", 
                 command=self.play_generated).pack(fill=tk.X, pady=5)
        
        tk.Button(left_frame, text="Save Generated", 
                 command=self.save_generated).pack(fill=tk.X, pady=5)
        
        # Status
        tk.Label(left_frame, text="Status:", 
                font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(10, 5))
        
        self.status_label = tk.Label(left_frame, text="Ready", 
                                    relief=tk.SUNKEN, height=2, anchor="w", padx=10)
        self.status_label.pack(fill=tk.X, pady=(0, 10))
        
        # Right panel
        right_frame = tk.Frame(main_container)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Notebook tabs
        notebook = ttk.Notebook(right_frame)
        notebook.pack(fill=tk.BOTH, expand=True)
        
        # Tab 1: Real Audio
        real_tab = ttk.Frame(notebook)
        notebook.add(real_tab, text="Real Audio")
        
        real_scroll_frame = tk.Frame(real_tab)
        real_scroll_frame.pack(fill=tk.BOTH, expand=True)
        
        real_canvas = tk.Canvas(real_scroll_frame)
        real_scrollbar = tk.Scrollbar(real_scroll_frame, orient="vertical", command=real_canvas.yview)
        self.real_audio_frame = tk.Frame(real_canvas)
        
        self.real_audio_frame.bind(
            "<Configure>",
            lambda e: real_canvas.configure(scrollregion=real_canvas.bbox("all"))
        )
        
        real_canvas.create_window((0, 0), window=self.real_audio_frame, anchor="nw")
        real_canvas.configure(yscrollcommand=real_scrollbar.set)
        
        real_canvas.pack(side="left", fill="both", expand=True)
        real_scrollbar.pack(side="right", fill="y")
        
        tk.Label(self.real_audio_frame, text="Select audio from list", 
                font=("Arial", 10)).pack(pady=10)
        
        self.real_spectrogram_canvas = None
        self.real_audio_info = tk.Label(self.real_audio_frame, text="No audio selected")
        self.real_audio_info.pack(pady=5)
        
        tk.Button(self.real_audio_frame, text="Play Audio", 
                 command=self.play_selected_audio).pack(pady=5)
        
        # Tab 2: Generated Audio
        gen_tab = ttk.Frame(notebook)
        notebook.add(gen_tab, text="Generated Audio")
        
        gen_scroll_frame = tk.Frame(gen_tab)
        gen_scroll_frame.pack(fill=tk.BOTH, expand=True)
        
        gen_canvas = tk.Canvas(gen_scroll_frame)
        gen_scrollbar = tk.Scrollbar(gen_scroll_frame, orient="vertical", command=gen_canvas.yview)
        self.gen_spectrogram_frame = tk.Frame(gen_canvas)
        
        self.gen_spectrogram_frame.bind(
            "<Configure>",
            lambda e: gen_canvas.configure(scrollregion=gen_canvas.bbox("all"))
        )
        
        gen_canvas.create_window((0, 0), window=self.gen_spectrogram_frame, anchor="nw")
        gen_canvas.configure(yscrollcommand=gen_scrollbar.set)
        
        gen_canvas.pack(side="left", fill="both", expand=True)
        gen_scrollbar.pack(side="right", fill="y")
        
        # Tab 3: Training Log
        log_tab = ttk.Frame(notebook)
        notebook.add(log_tab, text="Training Log")
        
        log_frame = tk.Frame(log_tab)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.log_text = tk.Text(log_frame, height=15, width=80, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        log_scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=log_scrollbar.set)
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
                status_text = message[:50] + "..." if len(message) > 50 else message
                self.status_label.config(text=status_text)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def add_audio(self):
        files = filedialog.askopenfilenames(
            title="Select Audio Files",
            filetypes=[("Audio files", "*.wav *.mp3 *.flac *.ogg *.m4a")]
        )
        
        new_files = 0
        for file in files:
            if file not in self.audio_paths:
                self.audio_paths.append(file)
                filename = os.path.basename(file)
                self.audio_listbox.insert(tk.END, filename)
                new_files += 1
        
        if new_files > 0:
            self.log_message(f"Added {new_files} audio files. Total: {len(self.audio_paths)}")
    
    def clear_audio(self):
        self.audio_paths = []
        self.audio_listbox.delete(0, tk.END)
        self.log_message("Cleared all audio files")
    
    def on_audio_select(self, event):
        selection = self.audio_listbox.curselection()
        if selection:
            idx = selection[0]
            if idx < len(self.audio_paths):
                self.display_real_audio(idx)
    
    def display_real_audio(self, idx):
        try:
            if self.real_spectrogram_canvas:
                self.real_spectrogram_canvas.get_tk_widget().destroy()
            
            audio_path = self.audio_paths[idx]
            audio, sr = self.audio_processor.load_audio(audio_path, self.sr, self.duration)
            mel_spec = self.audio_processor.audio_to_mel(audio, sr, self.n_mels)
            
            fig = self.audio_processor.plot_spectrogram(mel_spec, f"Spectrogram: {os.path.basename(audio_path)}")
            
            self.real_spectrogram_canvas = FigureCanvasTkAgg(fig, self.real_audio_frame)
            self.real_spectrogram_canvas.draw()
            self.real_spectrogram_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
            self.current_audio = audio
            self.current_audio_name = os.path.basename(audio_path)
            self.real_audio_info.config(text=f"Loaded: {self.current_audio_name}")
            
            self.log_message(f"Displaying {self.current_audio_name}")
            
        except Exception as e:
            self.log_message(f"Error displaying audio: {str(e)}")
            print(f"Error: {e}")
            traceback.print_exc()
    
    def play_selected_audio(self):
        if self.current_audio is not None:
            try:
                temp_file = "temp_playback.wav"
                self.audio_processor.save_audio(self.current_audio, temp_file, self.sr)
                
                if os.name == 'nt':
                    os.system(f"start wmplayer {temp_file}")
                else:
                    os.system(f"aplay {temp_file} 2>/dev/null || afplay {temp_file} 2>/dev/null")
                
                self.log_message(f"Playing: {self.current_audio_name}")
            except Exception as e:
                self.log_message(f"Error playing audio: {str(e)}")
        else:
            self.log_message("No audio selected to play")
    
    def initialize_gan(self):
        if len(self.audio_paths) < 4:
            self.log_message("Error: Need at least 4 audio files to train")
            return
        
        try:
            mel_shape = (1, self.n_mels, 128)
            self.gan = AudioDCGAN(mel_shape=mel_shape)
            self.log_message(f"Initialized GAN for {mel_shape} spectrograms")
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
            print(f"Error: {e}")
            traceback.print_exc()
    
    def start_training(self):
        if not self.audio_paths:
            self.log_message("Error: No audio files added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            batch_size = int(self.batch_var.get())
            
            self.training = True
            self.current_epoch = 0
            
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}")
            
        except ValueError:
            self.log_message("Error: Invalid parameters!")
    
    def train_gan(self, epochs, batch_size):
        try:
            dataset = AudioDataset(self.audio_paths, self.duration, self.sr, self.n_mels)
            dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=0)
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                
                for i, real_mels in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    real_mels = real_mels.to(self.gan.device)
                    info = self.gan.train_step(real_mels)
                    
                    total_loss_d += info['d_loss']
                    total_loss_g += info['g_loss']
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    
                    self.log_message(f"Epoch {epoch+1}/{epochs} | D Loss: {avg_loss_d:.4f} | G Loss: {avg_loss_g:.4f}")
                
                # Generate sample every 5 epochs
                if (epoch + 1) % 5 == 0:
                    self.root.after(0, self.display_generated_samples)
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            print(f"Training error: {e}")
            traceback.print_exc()
            self.training = False
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")
    
    def generate_and_inspect(self):
        """Generate new sounds and display them for inspection"""
        if not self.gan:
            self.log_message("Error: GAN not initialized! Train first or add audio files")
            return
        
        try:
            audios, mels = self.gan.generate_audio(num_samples=4)
            
            self.generated_audios = audios
            self.generated_mels = mels
            
            # Clear previous display
            for widget in self.gen_spectrogram_frame.winfo_children():
                widget.destroy()
            
            # Display in grid
            for i in range(min(4, len(audios))):
                sample_frame = tk.Frame(self.gen_spectrogram_frame)
                sample_frame.grid(row=i//2, column=i%2, padx=10, pady=10)
                
                mel_spec = mels[i].squeeze().numpy()
                fig = self.audio_processor.plot_spectrogram(mel_spec, f"Generated {i+1}")
                
                canvas = FigureCanvasTkAgg(fig, sample_frame)
                canvas.draw()
                canvas.get_tk_widget().pack()
                
                # Play and save buttons
                play_btn = tk.Button(sample_frame, text=f"Play {i+1}", 
                                   command=lambda idx=i: self.play_specific_generated(idx))
                play_btn.pack(side=tk.LEFT, padx=5)
                
                save_btn = tk.Button(sample_frame, text=f"Save {i+1}", 
                                   command=lambda idx=i: self.save_specific_generated(idx))
                save_btn.pack(side=tk.RIGHT, padx=5)
            
            self.log_message(f"Generated {len(audios)} new sounds (Epoch {self.current_epoch})")
            
        except Exception as e:
            self.log_message(f"Generation error: {str(e)}")
            print(f"Generation error: {e}")
            traceback.print_exc()
    
    def display_generated_samples(self):
        """Display samples during training"""
        if not self.gan:
            return
        
        try:
            audios, mels = self.gan.generate_audio(num_samples=4)
            
            self.generated_audios = audios
            self.generated_mels = mels
            
            self.root.after(0, self.update_generated_display, audios, mels)
            
        except Exception as e:
            print(f"Error in display_generated_samples: {e}")
    
    def update_generated_display(self, audios, mels):
        """Update the generated display from main thread"""
        try:
            for widget in self.gen_spectrogram_frame.winfo_children():
                widget.destroy()
            
            for i in range(min(4, len(audios))):
                sample_frame = tk.Frame(self.gen_spectrogram_frame)
                sample_frame.grid(row=i//2, column=i%2, padx=10, pady=10)
                
                mel_spec = mels[i].squeeze().numpy()
                fig = self.audio_processor.plot_spectrogram(mel_spec, f"Epoch {self.current_epoch+1} - {i+1}")
                
                canvas = FigureCanvasTkAgg(fig, sample_frame)
                canvas.draw()
                canvas.get_tk_widget().pack()
                
                play_btn = tk.Button(sample_frame, text=f"Play {i+1}", 
                                   command=lambda idx=i: self.play_specific_generated(idx))
                play_btn.pack(side=tk.LEFT, padx=5)
                
                save_btn = tk.Button(sample_frame, text=f"Save {i+1}", 
                                   command=lambda idx=i: self.save_specific_generated(idx))
                save_btn.pack(side=tk.RIGHT, padx=5)
            
            self.log_message(f"Auto-generated samples at epoch {self.current_epoch+1}")
            
        except Exception as e:
            print(f"Error updating display: {e}")
    
    def play_specific_generated(self, idx):
        """Play a specific generated sound"""
        if hasattr(self, 'generated_audios') and idx < len(self.generated_audios):
            try:
                audio = self.generated_audios[idx]
                temp_file = f"temp_generated_{idx}.wav"
                self.audio_processor.save_audio(audio, temp_file, self.sr)
                
                if os.name == 'nt':
                    os.system(f"start wmplayer {temp_file}")
                else:
                    os.system(f"aplay {temp_file} 2>/dev/null || afplay {temp_file} 2>/dev/null")
                
                self.log_message(f"Playing generated sound {idx+1}")
            except Exception as e:
                self.log_message(f"Error playing audio: {str(e)}")
        else:
            self.log_message("No generated sound available at that index")
    
    def play_generated(self):
        """Play the first generated sound"""
        self.play_specific_generated(0)
    
    def save_specific_generated(self, idx):
        """Save a specific generated sound"""
        if hasattr(self, 'generated_audios') and idx < len(self.generated_audios):
            try:
                filename = filedialog.asksaveasfilename(
                    defaultextension=".wav",
                    filetypes=[("WAV files", "*.wav"), ("All files", "*.*")],
                    initialfile=f"generated_epoch{self.current_epoch:04d}_{idx:02d}.wav"
                )
                
                if filename:
                    self.audio_processor.save_audio(self.generated_audios[idx], filename, self.sr)
                    self.log_message(f"Saved: {os.path.basename(filename)}")
            except Exception as e:
                self.log_message(f"Error saving audio: {str(e)}")
        else:
            self.log_message("No generated sound to save")
    
    def save_generated(self):
        """Save the first generated sound"""
        self.save_specific_generated(0)

# ==================== MAIN ====================

if __name__ == "__main__":
    print("Audio GAN Explorer")
    print("=" * 50)
    print("How to use:")
    print("1. Add audio files")
    print("2. Initialize GAN")
    print("3. Train")
    print("4. Use 'Generate & Inspect' during training")
    print("=" * 50)
    
    root = tk.Tk()
    app = AudioGANApp(root)
    root.mainloop()