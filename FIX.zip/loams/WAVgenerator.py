import tkinter as tk
from tkinter import filedialog, ttk
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import time
import librosa
import librosa.display
import soundfile as sf
import random
import warnings
import multiprocessing
warnings.filterwarnings('ignore')

# Audio processing
class AudioProcessor:
    def __init__(self, sr=22050, n_fft=2048, hop_length=512, n_mels=128, segment_duration=1.472):
        self.sr = sr
        self.n_fft = n_fft
        self.hop_length = hop_length
        self.n_mels = n_mels
        self.segment_duration = segment_duration  # 1472ms = 64 * 23ms
        self.segment_samples = int(sr * segment_duration)
        
    def audio_to_segments(self, audio_path, max_segments=None):
        """Split audio into segments and convert each to mel-spectrogram"""
        try:
            # Load entire audio file
            audio, sr = librosa.load(audio_path, sr=self.sr)
            
            # Calculate number of segments
            num_segments = len(audio) // self.segment_samples
            if num_segments == 0:  # Audio shorter than segment
                num_segments = 1
            
            if max_segments and num_segments > max_segments:
                num_segments = max_segments
            
            segments = []
            segment_audios = []
            
            for i in range(num_segments):
                start = i * self.segment_samples
                end = start + self.segment_samples
                segment_audio = audio[start:end]
                
                if len(segment_audio) < self.segment_samples:
                    segment_audio = np.pad(segment_audio, (0, self.segment_samples - len(segment_audio)), mode='constant')
                
                # Create mel-spectrogram for this segment
                mel_spec = librosa.feature.melspectrogram(
                    y=segment_audio, 
                    sr=sr,
                    n_fft=self.n_fft,
                    hop_length=self.hop_length,
                    n_mels=self.n_mels,
                    fmax=8000
                )
                
                mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
                mel_spec_norm = (mel_spec_db - mel_spec_db.min()) / (mel_spec_db.max() - mel_spec_db.min() + 1e-8)
                
                # Convert to PIL Image (grayscale)
                mel_spec_img = (mel_spec_norm * 255).astype(np.uint8)
                img = Image.fromarray(mel_spec_img)
                img = img.resize((64, 64), Image.Resampling.LANCZOS)
                
                segments.append(img)
                segment_audios.append(segment_audio)
            
            return segments, segment_audios, audio
            
        except Exception as e:
            print(f"Error processing {audio_path}: {e}")
            return [], [], np.zeros(self.segment_samples)
    
    def segment_to_mel(self, segment_audio):
        """Convert a single audio segment to mel-spectrogram image"""
        if len(segment_audio) < self.segment_samples:
            segment_audio = np.pad(segment_audio, (0, self.segment_samples - len(segment_audio)), mode='constant')
        
        mel_spec = librosa.feature.melspectrogram(
            y=segment_audio, 
            sr=self.sr,
            n_fft=self.n_fft,
            hop_length=self.hop_length,
            n_mels=self.n_mels,
            fmax=8000
        )
        
        mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
        mel_spec_norm = (mel_spec_db - mel_spec_db.min()) / (mel_spec_db.max() - mel_spec_db.min() + 1e-8)
        
        mel_spec_img = (mel_spec_norm * 255).astype(np.uint8)
        img = Image.fromarray(mel_spec_img)
        img = img.resize((64, 64), Image.Resampling.LANCZOS)
        
        return img, mel_spec_db
    
    def mel_to_audio(self, mel_image, use_griffin_lim=True):
        """Convert mel-spectrogram image back to audio"""
        try:
            mel_img = np.array(mel_image.convert('L')).astype(float)
            mel_img = mel_img / 255.0
            
            target_shape = (self.n_mels, int(self.segment_duration * self.sr / self.hop_length) + 1)
            if mel_img.shape != target_shape:
                img = Image.fromarray((mel_img * 255).astype(np.uint8))
                img = img.resize((target_shape[1], target_shape[0]), Image.Resampling.LANCZOS)
                mel_img = np.array(img).astype(float) / 255.0
            
            mel_img = np.clip(mel_img, 0, 1)
            mel_linear = librosa.db_to_power(mel_img * 80 - 80)
            
            if use_griffin_lim:
                audio = librosa.feature.inverse.mel_to_audio(
                    mel_linear,
                    sr=self.sr,
                    n_fft=self.n_fft,
                    hop_length=self.hop_length,
                    n_iter=32
                )
            else:
                audio = np.random.randn(self.segment_samples) * 0.01
            
            if np.max(np.abs(audio)) > 0:
                audio = audio / np.max(np.abs(audio)) * 0.9
            
            return audio[:self.segment_samples]
            
        except Exception as e:
            print(f"Error converting mel to audio: {e}")
            return np.zeros(self.segment_samples)
    
    def save_audio(self, audio, filename):
        sf.write(filename, audio, self.sr)
    
    def play_audio(self, audio):
        try:
            import simpleaudio as sa
            audio_int = (audio * 32767).astype(np.int16)
            play_obj = sa.play_buffer(audio_int, 1, 2, self.sr)
            return play_obj
        except ImportError:
            temp_file = "temp_generated.wav"
            self.save_audio(audio, temp_file)
            os.system(f"start {temp_file}" if os.name == 'nt' else f"afplay {temp_file}")

# Concatenative Synthesis Model
class ConcatenativeSynthesizer:
    def __init__(self, sr=22050, segment_duration=1.472):
        self.sr = sr
        self.segment_duration = segment_duration
        self.segment_samples = int(sr * segment_duration)
        self.audio_segments = []  # List of numpy arrays
        self.mel_segments = []    # List of PIL Images
        self.audio_processor = AudioProcessor(segment_duration=segment_duration)
        
        print(f"Initialized Concatenative Synthesizer")
        print(f"Segment duration: {segment_duration}s ({self.segment_samples} samples)")
    
    def load_segments_from_audio(self, audio_path, max_segments=None):
        """Load audio segments from a file"""
        mel_segments, audio_segments, full_audio = self.audio_processor.audio_to_segments(
            audio_path, 
            max_segments=max_segments
        )
        
        self.audio_segments.extend(audio_segments)
        self.mel_segments.extend(mel_segments)
        
        return len(audio_segments)
    
    def clear_segments(self):
        """Clear all loaded segments"""
        self.audio_segments = []
        self.mel_segments = []
    
    def get_segment_count(self):
        return len(self.audio_segments)
    
    def generate_random_sequence(self, num_segments=4, transition_smoothing=True):
        """Generate audio by randomly concatenating segments"""
        if not self.audio_segments:
            print("No segments loaded!")
            return None, []
        
        generated_audio = []
        generated_mels = []
        
        for i in range(num_segments):
            # Randomly select a segment
            idx = random.randint(0, len(self.audio_segments) - 1)
            segment_audio = self.audio_segments[idx].copy()
            segment_mel = self.mel_segments[idx]
            
            # Apply crossfade for smoother transitions (optional)
            if transition_smoothing and i > 0 and len(generated_audio[-1]) > 0:
                fade_length = min(512, len(generated_audio[-1]) // 4, len(segment_audio) // 4)
                if fade_length > 10:
                    # Apply crossfade between segments
                    fade_out = np.linspace(1, 0, fade_length)
                    fade_in = np.linspace(0, 1, fade_length)
                    
                    # Modify end of previous segment
                    generated_audio[-1][-fade_length:] *= fade_out
                    # Modify start of current segment
                    segment_audio[:fade_length] *= fade_in
            
            generated_audio.append(segment_audio)
            generated_mels.append(segment_mel)
        
        # Concatenate all segments
        if generated_audio:
            final_audio = np.concatenate(generated_audio)
            return final_audio, generated_mels
        else:
            return None, []
    
    def generate_similar_sequence(self, template_segment_idx, num_segments=4, similarity_threshold=0.3):
        """Generate audio by concatenating similar-sounding segments"""
        if not self.audio_segments or template_segment_idx >= len(self.audio_segments):
            return None, []
        
        template_segment = self.audio_segments[template_segment_idx]
        
        # Calculate RMS energy of template
        template_rms = np.sqrt(np.mean(template_segment**2))
        
        # Find similar segments
        similar_indices = []
        for i, segment in enumerate(self.audio_segments):
            if i == template_segment_idx:
                continue
                
            segment_rms = np.sqrt(np.mean(segment**2))
            rms_diff = abs(segment_rms - template_rms) / template_rms
            
            if rms_diff < similarity_threshold:
                similar_indices.append(i)
        
        if not similar_indices:
            similar_indices = list(range(len(self.audio_segments)))
        
        # Generate sequence
        generated_audio = []
        generated_mels = []
        
        # Start with template
        generated_audio.append(self.audio_segments[template_segment_idx].copy())
        generated_mels.append(self.mel_segments[template_segment_idx])
        
        # Add similar segments
        for i in range(1, num_segments):
            idx = random.choice(similar_indices)
            generated_audio.append(self.audio_segments[idx].copy())
            generated_mels.append(self.mel_segments[idx])
        
        final_audio = np.concatenate(generated_audio)
        return final_audio, generated_mels
    
    def generate_with_pattern(self, pattern=None, num_segments=4):
        """Generate audio following a repeating pattern"""
        if not self.audio_segments:
            return None, []
        
        if pattern is None:
            # Create a simple alternating pattern
            pattern = [0, 1, 0, 2] if len(self.audio_segments) >= 3 else [0, 1]
        
        generated_audio = []
        generated_mels = []
        
        for i in range(num_segments):
            pattern_idx = pattern[i % len(pattern)]
            if pattern_idx < len(self.audio_segments):
                idx = pattern_idx
            else:
                idx = random.randint(0, len(self.audio_segments) - 1)
            
            generated_audio.append(self.audio_segments[idx].copy())
            generated_mels.append(self.mel_segments[idx])
        
        final_audio = np.concatenate(generated_audio)
        return final_audio, generated_mels

# Audio dataset (now using ALL segments)
class AudioDataset:
    def __init__(self, audio_paths, audio_processor, max_segments_per_file=0):
        """
        Args:
            audio_paths: List of audio file paths
            audio_processor: AudioProcessor instance
            max_segments_per_file: 0 = all segments, >0 = limit per file
        """
        self.audio_paths = audio_paths
        self.audio_processor = audio_processor
        self.max_segments_per_file = max_segments_per_file  # 0 means all segments
        
        # Preprocess all audio files
        self.segments = []
        self.segment_audios = []
        self.total_segments = 0
        
        print(f"Loading segments from {len(audio_paths)} audio files...")
        
        for file_idx, audio_path in enumerate(audio_paths):
            try:
                # Get segments (max_segments_per_file = 0 means all segments)
                mel_segments, audio_segments, _ = self.audio_processor.audio_to_segments(
                    audio_path, 
                    max_segments=self.max_segments_per_file if self.max_segments_per_file > 0 else None
                )
                
                if mel_segments:
                    self.segments.extend(mel_segments)
                    self.segment_audios.extend(audio_segments)
                    self.total_segments += len(mel_segments)
                    print(f"  {os.path.basename(audio_path)}: {len(mel_segments)} segments")
                    
                    # Show progress for large files
                    if len(mel_segments) > 100:
                        print(f"    (Loaded {len(mel_segments)} segments)")
                else:
                    print(f"  Warning: No segments from {os.path.basename(audio_path)}")
                    
            except Exception as e:
                print(f"Error loading audio {audio_path}: {e}")
        
        print(f"Total loaded: {self.total_segments} audio segments from {len(audio_paths)} files")
    
    def __len__(self):
        return len(self.segments)
    
    def __getitem__(self, idx):
        return self.segments[idx], self.segment_audios[idx]

# Main application
class AudioConcatenativeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Audio Concatenative Synthesizer")
        self.root.geometry("1100x750")
        
        self.audio_paths = []
        self.training = False  # Not really training, but for consistency
        self.synthesizer = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        self.current_audio = None
        self.is_playing = False
        
        # Store audio segments for preview
        self.audio_segments = {}  # filename -> (mel_images, segment_audios, full_audio)
        self.current_preview_segment = 0
        
        self.settings = {
            'segment_duration': tk.DoubleVar(value=1.472),  # 1472ms segments
            'max_segments_per_file': tk.IntVar(value=0),  # 0 = ALL segments
            'use_crossfade': tk.BooleanVar(value=True),
            'crossfade_length': tk.IntVar(value=512),  # samples
            'generation_mode': tk.StringVar(value="random"),  # random, similar, pattern
            'similarity_threshold': tk.DoubleVar(value=0.3),
            'pattern_string': tk.StringVar(value="0,1,0,2"),
        }
        
        self.num_workers = min(2, multiprocessing.cpu_count())
        self.start_time = None
        self.generated_audio = []
        self.generated_mels = []
        
        self.setup_gui()
        self.root.after(100, self.process_messages)
        self.audio_processor = AudioProcessor(segment_duration=1.472)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.synthesis_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.synthesis_tab, text='Synthesis')
        self.setup_synthesis_tab()
        
        self.preview_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.preview_tab, text='Mel Preview')
        self.setup_preview_tab()
        
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()
        
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

    def setup_synthesis_tab(self):
        main_frame = tk.Frame(self.synthesis_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        tk.Label(left_frame, text="Concatenative Synthesizer", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        audio_frame = tk.LabelFrame(left_frame, text="Audio Library", padx=10, pady=10)
        audio_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(audio_frame, text="Add Audio Files", 
                 command=self.add_audio_files, width=20).pack(pady=5)
        tk.Button(audio_frame, text="Clear All", 
                 command=self.clear_audio, width=20).pack(pady=5)
        
        list_frame = tk.Frame(audio_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.audio_listbox = tk.Listbox(list_frame, height=8)
        self.audio_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.audio_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.audio_listbox.config(yscrollcommand=list_scrollbar.set)
        
        tk.Button(audio_frame, text="Preview Selected", 
                 command=self.preview_selected_audio, width=20).pack(pady=5)
        
        synthesis_frame = tk.LabelFrame(left_frame, text="Synthesis Controls", padx=10, pady=10)
        synthesis_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(synthesis_frame, text="Initialize Synthesizer", 
                 command=self.initialize_synthesizer, width=20).pack(pady=5)
        
        tk.Label(synthesis_frame, text="Segments to Generate:").pack(pady=5)
        self.segments_var = tk.StringVar(value="8")
        tk.Entry(synthesis_frame, textvariable=self.segments_var, width=10).pack(pady=5)
        
        mode_frame = tk.Frame(synthesis_frame)
        mode_frame.pack(pady=5)
        tk.Label(mode_frame, text="Mode:").pack(side=tk.LEFT)
        self.mode_combo = ttk.Combobox(mode_frame, values=["random", "similar", "pattern"], 
                                       state="readonly", width=15)
        self.mode_combo.pack(side=tk.LEFT, padx=5)
        self.mode_combo.set("random")
        
        tk.Button(synthesis_frame, text="Generate Audio", 
                 command=self.generate_audio, width=20, bg="lightgreen").pack(pady=5)
        
        # Segment stats display
        stats_frame = tk.LabelFrame(left_frame, text="Library Statistics", padx=10, pady=10)
        stats_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.segment_count_label = tk.Label(stats_frame, text="Segments loaded: 0")
        self.segment_count_label.pack(pady=2)
        
        self.file_count_label = tk.Label(stats_frame, text="Audio files: 0")
        self.file_count_label.pack(pady=2)
        
        self.segment_duration_label = tk.Label(stats_frame, text="Segment duration: 1.472s")
        self.segment_duration_label.pack(pady=2)
        
        gen_frame = tk.LabelFrame(left_frame, text="Audio Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Play Generated", 
                 command=self.play_generated_audio, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Audio", 
                 command=self.save_generated_audio, width=20).pack(pady=5)
        
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        preview_frame = tk.LabelFrame(right_frame, text="Generated Spectrogram", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.spec_frame = tk.Frame(preview_frame, width=256, height=256, bg='gray')
        self.spec_frame.pack(pady=10)
        self.spec_frame.pack_propagate(False)
        
        self.spec_label = tk.Label(self.spec_frame, text="No spectrogram generated", bg='gray')
        self.spec_label.pack(fill=tk.BOTH, expand=True)
        
        audio_controls = tk.Frame(preview_frame)
        audio_controls.pack(pady=5)
        
        tk.Button(audio_controls, text="Play", 
                 command=self.play_generated_audio, width=10).pack(side=tk.LEFT, padx=5)
        tk.Button(audio_controls, text="Stop", 
                 command=self.stop_audio, width=10).pack(side=tk.LEFT, padx=5)
        tk.Button(audio_controls, text="Save", 
                 command=self.save_generated_audio, width=10).pack(side=tk.LEFT, padx=5)
        
        log_frame = tk.LabelFrame(right_frame, text="Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        self.status_label = tk.Label(self.synthesis_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_preview_tab(self):
        """Setup mel-spectrogram preview tab"""
        main_frame = tk.Frame(self.preview_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Mel-Spectrogram Preview", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Audio selection
        select_frame = tk.LabelFrame(main_frame, text="Select Audio File", padx=10, pady=10)
        select_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(select_frame, text="Audio File:").pack(side=tk.LEFT, padx=5)
        
        self.preview_audio_var = tk.StringVar()
        self.preview_audio_combo = ttk.Combobox(select_frame, textvariable=self.preview_audio_var, 
                                               state="readonly", width=50)
        self.preview_audio_combo.pack(side=tk.LEFT, padx=5)
        self.preview_audio_combo.bind("<<ComboboxSelected>>", self.on_preview_audio_selected)
        
        tk.Button(select_frame, text="Load All Segments", 
                 command=self.load_audio_segments, width=20).pack(side=tk.LEFT, padx=5)
        
        # Segment navigation
        nav_frame = tk.LabelFrame(main_frame, text="Segment Navigation", padx=10, pady=10)
        nav_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(nav_frame, text="Segment:").pack(side=tk.LEFT, padx=5)
        
        self.segment_var = tk.IntVar(value=0)
        self.segment_spinbox = tk.Spinbox(nav_frame, from_=0, to=0, textvariable=self.segment_var,
                                         width=10, command=self.update_segment_preview)
        self.segment_spinbox.pack(side=tk.LEFT, padx=5)
        
        self.segment_total_label = tk.Label(nav_frame, text="of 0")
        self.segment_total_label.pack(side=tk.LEFT, padx=5)
        
        tk.Button(nav_frame, text="◀ Prev", 
                 command=self.prev_segment, width=10).pack(side=tk.LEFT, padx=5)
        tk.Button(nav_frame, text="Next ▶", 
                 command=self.next_segment, width=10).pack(side=tk.LEFT, padx=5)
        
        # Display area
        display_frame = tk.LabelFrame(main_frame, text="Segment Preview", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create frames for mel image and info
        top_frame = tk.Frame(display_frame)
        top_frame.pack(fill=tk.BOTH, expand=True)
        
        # Left: Mel image
        left_display = tk.Frame(top_frame, width=300)
        left_display.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        tk.Label(left_display, text="Mel-Spectrogram Image", 
                font=("Arial", 10, "bold")).pack(pady=(0, 5))
        
        self.mel_image_frame = tk.Frame(left_display, width=256, height=256, bg='gray')
        self.mel_image_frame.pack()
        self.mel_image_frame.pack_propagate(False)
        
        self.mel_image_label = tk.Label(self.mel_image_frame, text="No image", bg='gray')
        self.mel_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Right: Segment info
        right_display = tk.Frame(top_frame)
        right_display.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        tk.Label(right_display, text="Segment Information", 
                font=("Arial", 10, "bold")).pack(pady=(0, 5))
        
        info_frame = tk.Frame(right_display)
        info_frame.pack(fill=tk.BOTH, expand=True)
        
        self.segment_info_text = tk.Text(info_frame, height=10, font=("Courier", 9))
        self.segment_info_text.pack(fill=tk.BOTH, expand=True)
        
        # Audio controls
        controls_frame = tk.Frame(display_frame)
        controls_frame.pack(fill=tk.X, pady=(10, 0))
        
        tk.Button(controls_frame, text="Play Original Segment", 
                 command=self.play_preview_segment, width=20).pack(side=tk.LEFT, padx=5)
        tk.Button(controls_frame, text="Play Reconstructed", 
                 command=self.play_reconstructed_segment, width=20).pack(side=tk.LEFT, padx=5)
        tk.Button(controls_frame, text="Play Full Audio", 
                 command=self.play_full_preview_audio, width=20).pack(side=tk.LEFT, padx=5)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Audio Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Segments:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=32, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        mode_frame = tk.Frame(gen_frame)
        mode_frame.pack(pady=5)
        tk.Label(mode_frame, text="Generation Mode:").pack(side=tk.LEFT)
        self.gen_mode_combo = ttk.Combobox(mode_frame, values=["random", "similar", "pattern"], 
                                          state="readonly", width=15)
        self.gen_mode_combo.pack(side=tk.LEFT, padx=5)
        self.gen_mode_combo.set("random")
        
        tk.Button(gen_frame, text="Generate Sequence", 
                 command=self.generate_sequence, width=20).pack(pady=10)
        
        self.audio_display_frame = tk.LabelFrame(main_frame, text="Generated Segments", 
                                                padx=10, pady=10)
        self.audio_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.audio_canvas = tk.Canvas(self.audio_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.audio_display_frame, orient="vertical", 
                                command=self.audio_canvas.yview)
        self.audio_scroll_frame = tk.Frame(self.audio_canvas)
        
        self.audio_scroll_frame.bind(
            "<Configure>",
            lambda e: self.audio_canvas.configure(scrollregion=self.audio_canvas.bbox("all"))
        )
        
        self.audio_canvas.create_window((0, 0), window=self.audio_scroll_frame, anchor="nw")
        self.audio_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.audio_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        tk.Label(scrollable_frame, text="Synthesizer Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Segment settings
        segment_frame = tk.LabelFrame(scrollable_frame, text="Segment Settings", padx=10, pady=10)
        segment_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Segment duration
        duration_frame = tk.Frame(segment_frame)
        duration_frame.pack(fill=tk.X, pady=5)
        tk.Label(duration_frame, text="Segment Duration (seconds):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(duration_frame, from_=0.5, to=5.0, variable=self.settings['segment_duration'],
                orient=tk.HORIZONTAL, length=200, resolution=0.001).pack(side=tk.RIGHT)
        tk.Label(duration_frame, textvariable=self.settings['segment_duration'], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Max segments per file (0 = all)
        seg_frame = tk.Frame(segment_frame)
        seg_frame.pack(fill=tk.X, pady=5)
        tk.Label(seg_frame, text="Max Segments per File:", width=25, anchor='w').pack(side=tk.LEFT)
        
        # Create a frame for the entry and label
        seg_input_frame = tk.Frame(seg_frame)
        seg_input_frame.pack(side=tk.RIGHT)
        
        tk.Label(seg_input_frame, text="(0 = all):").pack(side=tk.LEFT, padx=(0, 5))
        
        # Use Entry for manual input
        self.max_segments_entry = tk.Entry(seg_input_frame, width=10)
        self.max_segments_entry.pack(side=tk.LEFT)
        self.max_segments_entry.insert(0, "0")  # Default to all segments
        
        # Add a button to apply the value
        tk.Button(seg_input_frame, text="Apply", 
                 command=self.apply_max_segments, width=8).pack(side=tk.LEFT, padx=5)
        
        tk.Label(segment_frame, text="Note: 1.472s = 64 time frames × 23ms each", 
                fg="gray", font=("Arial", 9)).pack(pady=(5, 0))
        
        # Generation settings
        gen_settings_frame = tk.LabelFrame(scrollable_frame, text="Generation Settings", padx=10, pady=10)
        gen_settings_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Use crossfade
        crossfade_frame = tk.Frame(gen_settings_frame)
        crossfade_frame.pack(fill=tk.X, pady=5)
        tk.Label(crossfade_frame, text="Use Crossfade:", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Checkbutton(crossfade_frame, variable=self.settings['use_crossfade']).pack(side=tk.LEFT)
        
        # Crossfade length
        fade_frame = tk.Frame(gen_settings_frame)
        fade_frame.pack(fill=tk.X, pady=5)
        tk.Label(fade_frame, text="Crossfade Length (samples):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(fade_frame, from_=64, to=2048, variable=self.settings['crossfade_length'],
                orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(fade_frame, textvariable=self.settings['crossfade_length'], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Similarity threshold
        sim_frame = tk.Frame(gen_settings_frame)
        sim_frame.pack(fill=tk.X, pady=5)
        tk.Label(sim_frame, text="Similarity Threshold:", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(sim_frame, from_=0.1, to=1.0, variable=self.settings['similarity_threshold'],
                orient=tk.HORIZONTAL, length=200, resolution=0.05).pack(side=tk.RIGHT)
        tk.Label(sim_frame, textvariable=self.settings['similarity_threshold'], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Pattern string
        pattern_frame = tk.Frame(gen_settings_frame)
        pattern_frame.pack(fill=tk.X, pady=5)
        tk.Label(pattern_frame, text="Pattern (comma-separated):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Entry(pattern_frame, textvariable=self.settings['pattern_string'], width=20).pack(side=tk.LEFT, padx=5)
        
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        import platform
        cpu_count = os.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Python: {platform.python_version()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Segment Duration: {self.settings['segment_duration'].get()}s", 
                anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Library Size: 0 segments", anchor='w').pack(fill=tk.X, pady=2)
        
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save Settings", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Settings", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Test Segment Processing", 
                 command=self.test_segment_processing, width=20).pack(side=tk.LEFT, padx=5)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def apply_max_segments(self):
        """Apply the max segments value from the entry field"""
        try:
            value = int(self.max_segments_entry.get())
            if value < 0:
                value = 0
            self.settings['max_segments_per_file'].set(value)
            self.log_message(f"Max segments per file set to: {value} (0 = all segments)")
        except ValueError:
            self.log_message("Error: Please enter a valid number for max segments")

    # Preview tab methods
    def update_preview_list(self):
        files = [os.path.basename(p) for p in self.audio_paths]
        self.preview_audio_combo['values'] = files
        if files:
            self.preview_audio_combo.current(0)

    def on_preview_audio_selected(self, event=None):
        self.load_audio_segments()

    def load_audio_segments(self):
        selection = self.preview_audio_combo.current()
        if selection < 0 or selection >= len(self.audio_paths):
            return
        
        audio_path = self.audio_paths[selection]
        filename = os.path.basename(audio_path)
        
        self.log_message(f"Loading segments from {filename}...")
        
        try:
            # Update audio processor with current settings
            segment_duration = self.settings['segment_duration'].get()
            self.audio_processor = AudioProcessor(segment_duration=segment_duration)
            
            # Get max segments setting
            max_segments = self.settings['max_segments_per_file'].get()
            if max_segments == 0:
                max_segments = None  # None = all segments
            
            # Load segments
            mel_images, segment_audios, full_audio = self.audio_processor.audio_to_segments(
                audio_path, 
                max_segments=max_segments
            )
            
            self.audio_segments[filename] = {
                'mel_images': mel_images,
                'segment_audios': segment_audios,
                'full_audio': full_audio,
                'num_segments': len(mel_images)
            }
            
            # Update UI
            max_segments_display = len(mel_images) - 1
            self.segment_var.set(0)
            self.segment_spinbox.config(from_=0, to=max_segments_display)
            self.segment_total_label.config(text=f"of {max_segments_display}")
            
            self.update_segment_preview()
            
            if max_segments is None:
                self.log_message(f"Loaded ALL {len(mel_images)} segments from {filename}")
            else:
                self.log_message(f"Loaded {len(mel_images)} segments from {filename} (limited to {max_segments} per file)")
            
        except Exception as e:
            self.log_message(f"Error loading segments: {str(e)}")

    def update_segment_preview(self):
        filename = self.preview_audio_var.get()
        if not filename or filename not in self.audio_segments:
            return
        
        segment_idx = self.segment_var.get()
        data = self.audio_segments[filename]
        
        if segment_idx >= len(data['mel_images']):
            return
        
        # Update mel image
        mel_img = data['mel_images'][segment_idx]
        mel_img_display = mel_img.resize((256, 256), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(mel_img_display)
        
        self.mel_image_label.config(image=photo, text="")
        self.mel_image_label.image = photo
        
        # Update segment info
        self.segment_info_text.delete(1.0, tk.END)
        
        segment_audio = data['segment_audios'][segment_idx]
        segment_duration = len(segment_audio) / self.audio_processor.sr
        
        self.segment_info_text.insert(tk.END, f"File: {filename}\n")
        self.segment_info_text.insert(tk.END, f"{'='*40}\n")
        self.segment_info_text.insert(tk.END, f"Segment: {segment_idx + 1}/{data['num_segments']}\n")
        self.segment_info_text.insert(tk.END, f"Duration: {segment_duration:.3f}s\n")
        self.segment_info_text.insert(tk.END, f"Time: {segment_idx * segment_duration:.2f}s - {(segment_idx + 1) * segment_duration:.2f}s\n")
        self.segment_info_text.insert(tk.END, f"Samples: {len(segment_audio)}\n")
        self.segment_info_text.insert(tk.END, f"Max Amplitude: {np.max(np.abs(segment_audio)):.3f}\n")
        
        # Calculate some audio features
        rms = np.sqrt(np.mean(segment_audio**2))
        zero_crossings = np.sum(np.abs(np.diff(np.sign(segment_audio)))) / len(segment_audio)
        
        self.segment_info_text.insert(tk.END, f"RMS Energy: {rms:.4f}\n")
        self.segment_info_text.insert(tk.END, f"Zero Crossings: {zero_crossings:.2f} per sample\n")
        
        # Store current segment for playback
        self.current_preview_segment = segment_idx

    def prev_segment(self):
        current = self.segment_var.get()
        if current > 0:
            self.segment_var.set(current - 1)
            self.update_segment_preview()

    def next_segment(self):
        filename = self.preview_audio_var.get()
        if filename in self.audio_segments:
            data = self.audio_segments[filename]
            current = self.segment_var.get()
            if current < data['num_segments'] - 1:
                self.segment_var.set(current + 1)
                self.update_segment_preview()

    def play_preview_segment(self):
        filename = self.preview_audio_var.get()
        if filename not in self.audio_segments:
            return
        
        segment_idx = self.current_preview_segment
        segment_audio = self.audio_segments[filename]['segment_audios'][segment_idx]
        
        self.play_audio_array(segment_audio, self.audio_processor.sr)
        self.log_message(f"Playing segment {segment_idx + 1} of {filename}")

    def play_reconstructed_segment(self):
        filename = self.preview_audio_var.get()
        if filename not in self.audio_segments:
            return
        
        segment_idx = self.current_preview_segment
        mel_img = self.audio_segments[filename]['mel_images'][segment_idx]
        
        reconstructed_audio = self.audio_processor.mel_to_audio(mel_img)
        self.play_audio_array(reconstructed_audio, self.audio_processor.sr)
        self.log_message(f"Playing reconstructed segment {segment_idx + 1}")

    def play_full_preview_audio(self):
        filename = self.preview_audio_var.get()
        if filename not in self.audio_segments:
            return
        
        full_audio = self.audio_segments[filename]['full_audio']
        self.play_audio_array(full_audio, self.audio_processor.sr)
        self.log_message(f"Playing full audio: {filename}")

    # Audio file management
    def add_audio_files(self):
        files = filedialog.askopenfilenames(
            title="Select audio files",
            filetypes=[
                ("Audio files", "*.wav *.mp3 *.ogg *.flac *.m4a"),
                ("WAV files", "*.wav"),
                ("MP3 files", "*.mp3"),
                ("All files", "*.*")
            ]
        )
        
        for file in files:
            if file not in self.audio_paths:
                self.audio_paths.append(file)
                filename = os.path.basename(file)
                self.audio_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} audio file{'s' if count != 1 else ''}. Total: {len(self.audio_paths)}")
        
        # Update preview list
        self.update_preview_list()
        
        # Update stats
        self.file_count_label.config(text=f"Audio files: {len(self.audio_paths)}")

    def clear_audio(self):
        self.audio_paths = []
        self.audio_listbox.delete(0, tk.END)
        self.audio_segments = {}
        if self.synthesizer:
            self.synthesizer.clear_segments()
        self.log_message("Cleared all audio files")
        
        # Update preview list
        self.update_preview_list()
        
        # Update stats
        self.file_count_label.config(text=f"Audio files: 0")
        self.segment_count_label.config(text=f"Segments loaded: 0")

    def preview_selected_audio(self):
        selection = self.audio_listbox.curselection()
        if not selection:
            self.log_message("No audio file selected!")
            return
        
        idx = selection[0]
        audio_path = self.audio_paths[idx]
        
        try:
            audio, sr = librosa.load(audio_path, sr=22050, duration=5.0)
            self.play_audio_array(audio, sr)
            self.log_message(f"Playing: {os.path.basename(audio_path)}")
        except Exception as e:
            self.log_message(f"Error playing audio: {str(e)}")

    # Audio playback
    def play_audio_array(self, audio, sr=22050):
        try:
            self.stop_audio()
            import simpleaudio as sa
            audio_int = (audio * 32767).astype(np.int16)
            self.current_audio = sa.play_buffer(audio_int, 1, 2, sr)
            self.is_playing = True
            threading.Thread(target=self.monitor_playback, daemon=True).start()
        except ImportError:
            self.log_message("Install simpleaudio: pip install simpleaudio")
            temp_file = "temp_preview.wav"
            sf.write(temp_file, audio, sr)
            os.system(f"start {temp_file}" if os.name == 'nt' else f"afplay {temp_file}")

    def monitor_playback(self):
        while self.is_playing and self.current_audio and self.current_audio.is_playing():
            time.sleep(0.1)
        self.is_playing = False

    def stop_audio(self):
        self.is_playing = False
        if self.current_audio:
            self.current_audio.stop()
            self.current_audio = None

    # Synthesizer methods
    def initialize_synthesizer(self):
        try:
            segment_duration = self.settings['segment_duration'].get()
            
            self.synthesizer = ConcatenativeSynthesizer(
                sr=22050,
                segment_duration=segment_duration
            )
            
            # Load all audio files into synthesizer
            total_segments = 0
            max_segments = self.settings['max_segments_per_file'].get()
            if max_segments == 0:
                max_segments = None
            
            for audio_path in self.audio_paths:
                segments_loaded = self.synthesizer.load_segments_from_audio(
                    audio_path,
                    max_segments=max_segments
                )
                total_segments += segments_loaded
            
            # Update stats display
            self.segment_count_label.config(text=f"Segments loaded: {total_segments}")
            self.segment_duration_label.config(text=f"Segment duration: {segment_duration}s")
            
            self.log_message(f"Initialized Concatenative Synthesizer")
            self.log_message(f"Loaded {total_segments} audio segments from {len(self.audio_paths)} files")
            self.log_message(f"Segment duration: {segment_duration}s")
            
        except Exception as e:
            self.log_message(f"Error initializing synthesizer: {str(e)}")
            import traceback
            traceback.print_exc()

    def generate_audio(self):
        if not self.synthesizer:
            self.log_message("Error: Synthesizer not initialized!")
            return
        
        if self.synthesizer.get_segment_count() == 0:
            self.log_message("Error: No audio segments loaded!")
            return
        
        try:
            num_segments = int(self.segments_var.get())
            mode = self.mode_combo.get()
            
            use_crossfade = self.settings['use_crossfade'].get()
            
            self.log_message(f"Generating audio with {num_segments} segments using {mode} mode...")
            
            if mode == "random":
                audio, mels = self.synthesizer.generate_random_sequence(
                    num_segments=num_segments,
                    transition_smoothing=use_crossfade
                )
            elif mode == "similar":
                # Use first segment as template
                template_idx = 0
                similarity_threshold = self.settings['similarity_threshold'].get()
                audio, mels = self.synthesizer.generate_similar_sequence(
                    template_segment_idx=template_idx,
                    num_segments=num_segments,
                    similarity_threshold=similarity_threshold
                )
            elif mode == "pattern":
                pattern_str = self.settings['pattern_string'].get()
                try:
                    pattern = [int(x.strip()) for x in pattern_str.split(',')]
                    audio, mels = self.synthesizer.generate_with_pattern(
                        pattern=pattern,
                        num_segments=num_segments
                    )
                except:
                    self.log_message("Error: Invalid pattern format. Using default.")
                    audio, mels = self.synthesizer.generate_random_sequence(
                        num_segments=num_segments,
                        transition_smoothing=use_crossfade
                    )
            else:
                audio, mels = self.synthesizer.generate_random_sequence(
                    num_segments=num_segments,
                    transition_smoothing=use_crossfade
                )
            
            if audio is not None:
                self.generated_audio = audio
                self.generated_mels = mels
                
                # Display first mel spectrogram
                if mels:
                    mel_img = mels[0]
                    mel_img_display = mel_img.resize((256, 256), Image.Resampling.LANCZOS)
                    photo = ImageTk.PhotoImage(mel_img_display)
                    
                    self.spec_label.config(image=photo, text="")
                    self.spec_label.image = photo
                
                duration = len(audio) / 22050
                self.log_message(f"Generated {duration:.2f}s of audio ({len(mels)} segments)")
                
            else:
                self.log_message("Error: Failed to generate audio!")
                
        except ValueError:
            self.log_message("Error: Invalid number of segments!")
        except Exception as e:
            self.log_message(f"Error generating audio: {str(e)}")

    def play_generated_audio(self):
        if self.generated_audio is not None and len(self.generated_audio) > 0:
            self.play_audio_array(self.generated_audio, 22050)
            duration = len(self.generated_audio) / 22050
            self.log_message(f"Playing generated audio ({duration:.2f}s)")
        else:
            self.log_message("No audio generated yet!")

    def save_generated_audio(self):
        if self.generated_audio is None or len(self.generated_audio) == 0:
            self.log_message("No audio to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".wav",
            filetypes=[("WAV files", "*.wav"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                sf.write(filename, self.generated_audio, 22050)
                self.log_message(f"Audio saved to {filename}")
            except Exception as e:
                self.log_message(f"Error saving audio: {str(e)}")

    def generate_sequence(self):
        if not self.synthesizer:
            self.log_message("Error: Synthesizer not initialized!")
            return
        
        try:
            num_segments = self.num_gen_var.get()
            mode = self.gen_mode_combo.get()
            use_crossfade = self.settings['use_crossfade'].get()
            
            self.log_message(f"Generating sequence of {num_segments} segments using {mode} mode...")
            
            if mode == "random":
                audio, mels = self.synthesizer.generate_random_sequence(
                    num_segments=num_segments,
                    transition_smoothing=use_crossfade
                )
            elif mode == "similar":
                template_idx = 0
                similarity_threshold = self.settings['similarity_threshold'].get()
                audio, mels = self.synthesizer.generate_similar_sequence(
                    template_segment_idx=template_idx,
                    num_segments=num_segments,
                    similarity_threshold=similarity_threshold
                )
            elif mode == "pattern":
                pattern_str = self.settings['pattern_string'].get()
                try:
                    pattern = [int(x.strip()) for x in pattern_str.split(',')]
                    audio, mels = self.synthesizer.generate_with_pattern(
                        pattern=pattern,
                        num_segments=num_segments
                    )
                except:
                    self.log_message("Error: Invalid pattern format. Using random.")
                    audio, mels = self.synthesizer.generate_random_sequence(
                        num_segments=num_segments,
                        transition_smoothing=use_crossfade
                    )
            
            if audio is None:
                self.log_message("Error: Failed to generate sequence!")
                return
            
            self.generated_audio = audio
            self.generated_mels = mels
            
            # Clear previous display
            for widget in self.audio_scroll_frame.winfo_children():
                widget.destroy()
            
            # Display each segment
            cols = 2
            rows = (len(mels) + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.audio_scroll_frame)
                row_frame.pack(pady=10)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < len(mels):
                        clip_frame = tk.LabelFrame(row_frame, text=f"Segment {idx+1}", padx=10, pady=10)
                        clip_frame.pack(side=tk.LEFT, padx=10)
                        
                        mel_img = mels[idx]
                        mel_img_display = mel_img.resize((128, 128), Image.Resampling.LANCZOS)
                        photo = ImageTk.PhotoImage(mel_img_display)
                        
                        img_label = tk.Label(clip_frame, image=photo)
                        img_label.image = photo
                        img_label.pack()
                        
                        # Extract this segment's audio from the concatenated result
                        segment_start = idx * self.synthesizer.segment_samples
                        segment_end = segment_start + self.synthesizer.segment_samples
                        if segment_end <= len(audio):
                            segment_audio = audio[segment_start:segment_end]
                        else:
                            segment_audio = audio[segment_start:]
                        
                        btn_frame = tk.Frame(clip_frame)
                        btn_frame.pack(pady=5)
                        
                        def make_play_callback(audio_clip, seg_num):
                            return lambda: (self.play_audio_array(audio_clip, 22050),
                                          self.log_message(f"Playing segment {seg_num}"))
                        
                        tk.Button(btn_frame, text="Play", 
                                 command=make_play_callback(segment_audio, idx+1), width=8).pack(side=tk.LEFT, padx=2)
                        
                        def make_save_callback(audio_clip, seg_num):
                            return lambda: self.save_single_audio(audio_clip, seg_num)
                        
                        tk.Button(btn_frame, text="Save", 
                                 command=make_save_callback(segment_audio, idx+1), width=8).pack(side=tk.LEFT, padx=2)
            
            duration = len(audio) / 22050
            self.log_message(f"Generated {len(mels)} segments ({duration:.2f}s total)")
            
        except Exception as e:
            self.log_message(f"Error generating sequence: {str(e)}")

    def save_single_audio(self, audio, clip_num):
        filename = filedialog.asksaveasfilename(
            defaultextension=".wav",
            filetypes=[("WAV files", "*.wav"), ("All files", "*.*")],
            initialfile=f"generated_segment_{clip_num}.wav"
        )
        
        if filename:
            try:
                sf.write(filename, audio, 22050)
                self.log_message(f"Segment {clip_num} saved to {filename}")
            except Exception as e:
                self.log_message(f"Error saving segment: {str(e)}")

    def save_defaults(self):
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('concatenative_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        try:
            import json
            if os.path.exists('concatenative_defaults.json'):
                with open('concatenative_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                # Update the entry field
                if 'max_segments_per_file' in defaults:
                    self.max_segments_entry.delete(0, tk.END)
                    self.max_segments_entry.insert(0, str(defaults['max_segments_per_file']))
                
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def test_segment_processing(self):
        if not self.audio_paths:
            self.log_message("No audio files to test!")
            return
        
        audio_path = self.audio_paths[0]
        
        try:
            self.log_message(f"Testing segment processing on: {os.path.basename(audio_path)}")
            
            segment_duration = self.settings['segment_duration'].get()
            self.audio_processor = AudioProcessor(segment_duration=segment_duration)
            
            # Test with 3 segments
            mel_images, segment_audios, _ = self.audio_processor.audio_to_segments(
                audio_path, 
                max_segments=3
            )
            
            self.log_message(f"Created {len(mel_images)} segments of {segment_duration}s each")
            
            # Play first segment original
            self.log_message("Playing original segment 1...")
            self.play_audio_array(segment_audios[0], self.audio_processor.sr)
            time.sleep(segment_duration + 0.5)
            
            # Play first segment reconstructed
            reconstructed_audio = self.audio_processor.mel_to_audio(mel_images[0])
            self.log_message("Playing reconstructed segment 1...")
            self.play_audio_array(reconstructed_audio, self.audio_processor.sr)
            
            self.log_message("Segment processing test complete!")
            
        except Exception as e:
            self.log_message(f"Error in segment processing test: {str(e)}")

    def log_message(self, message):
        self.message_queue.put(message)

    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

# Main
if __name__ == "__main__":
    print("Starting Audio Concatenative Synthesizer...")
    print("Install required packages: pip install librosa soundfile simpleaudio")
    
    root = tk.Tk()
    app = AudioConcatenativeApp(root)
    root.mainloop()