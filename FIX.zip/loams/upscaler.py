import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageFilter, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import random
import math

# ==================== Neural Network ====================

class SuperResUNet:
    def __init__(self, image_size=32, ngf=64):
        self.image_size = image_size
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # U-Net Architecture for Super Resolution
        class UNet(nn.Module):
            def __init__(self, in_channels=3, out_channels=3, features=64):
                super().__init__()
                
                # Encoder (downsampling)
                self.encoder1 = self._block(in_channels, features, "enc1")
                self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
                self.encoder2 = self._block(features, features * 2, "enc2")
                self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
                self.encoder3 = self._block(features * 2, features * 4, "enc3")
                self.pool3 = nn.MaxPool2d(kernel_size=2, stride=2)
                self.encoder4 = self._block(features * 4, features * 8, "enc4")
                self.pool4 = nn.MaxPool2d(kernel_size=2, stride=2)
                
                # Bottleneck
                self.bottleneck = self._block(features * 8, features * 16, "bottleneck")
                
                # Decoder (upsampling)
                self.upconv4 = nn.ConvTranspose2d(features * 16, features * 8, kernel_size=2, stride=2)
                self.decoder4 = self._block(features * 16, features * 8, "dec4")
                self.upconv3 = nn.ConvTranspose2d(features * 8, features * 4, kernel_size=2, stride=2)
                self.decoder3 = self._block(features * 8, features * 4, "dec3")
                self.upconv2 = nn.ConvTranspose2d(features * 4, features * 2, kernel_size=2, stride=2)
                self.decoder2 = self._block(features * 4, features * 2, "dec2")
                self.upconv1 = nn.ConvTranspose2d(features * 2, features, kernel_size=2, stride=2)
                self.decoder1 = self._block(features * 2, features, "dec1")
                
                # Final convolution
                self.final_conv = nn.Conv2d(features, out_channels, kernel_size=1)
                
            def _block(self, in_channels, out_channels, name):
                return nn.Sequential(
                    nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
                    nn.BatchNorm2d(out_channels),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
                    nn.BatchNorm2d(out_channels),
                    nn.ReLU(inplace=True),
                )
            
            def forward(self, x):
                # Encoder
                enc1 = self.encoder1(x)
                enc2 = self.encoder2(self.pool1(enc1))
                enc3 = self.encoder3(self.pool2(enc2))
                enc4 = self.encoder4(self.pool3(enc3))
                
                # Bottleneck
                bottleneck = self.bottleneck(self.pool4(enc4))
                
                # Decoder with skip connections
                dec4 = self.upconv4(bottleneck)
                dec4 = torch.cat((dec4, enc4), dim=1)
                dec4 = self.decoder4(dec4)
                
                dec3 = self.upconv3(dec4)
                dec3 = torch.cat((dec3, enc3), dim=1)
                dec3 = self.decoder3(dec3)
                
                dec2 = self.upconv2(dec3)
                dec2 = torch.cat((dec2, enc2), dim=1)
                dec2 = self.decoder2(dec2)
                
                dec1 = self.upconv1(dec2)
                dec1 = torch.cat((dec1, enc1), dim=1)
                dec1 = self.decoder1(dec1)
                
                return torch.tanh(self.final_conv(dec1))
        
        self.model = UNet(features=ngf)
        
        # Loss function - using L1 loss (better for super-resolution)
        self.criterion = nn.L1Loss()
        
        # Optimizer
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001, betas=(0.9, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.model.to(self.device)

# ==================== Dataset ====================

class SuperResDataset(Dataset):
    def __init__(self, image_paths, image_size=32, downscale_factor=4, augment=True):
        self.image_paths = image_paths
        self.image_size = image_size
        self.downscale_factor = downscale_factor
        self.augment = augment
        
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
        
        self.augment_transform = transforms.Compose([
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(10),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1),
        ])
        
        # For display only (not used in training)
        self.display_transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            # Load image
            img = Image.open(self.image_paths[idx]).convert('RGB')
            
            # Apply augmentations if enabled
            if self.augment:
                img = self.augment_transform(img)
            
            # Calculate small size (input)
            small_size = self.image_size // self.downscale_factor
            small_size = max(4, small_size)  # Minimum 4x4
            
            # Create pixelated/low-res input
            # Step 1: Downscale to very small size
            tiny_img = img.resize((small_size, small_size), Image.BILINEAR)
            
            # Step 2: Upscale back to target size using NEAREST (creates pixelated effect)
            # OR BILINEAR (creates blurry low-res effect)
            upscale_method = Image.NEAREST if random.random() > 0.5 else Image.BILINEAR
            pixelated_img = tiny_img.resize((self.image_size, self.image_size), upscale_method)
            
            # Target is the original image at full size
            target_img = img
            
            # Apply transforms
            pixelated_tensor = self.transform(pixelated_img)
            target_tensor = self.transform(target_img)
            
            return pixelated_tensor, target_tensor
            
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            # Return black images as fallback
            return (torch.zeros(3, self.image_size, self.image_size), 
                    torch.zeros(3, self.image_size, self.image_size))

# ==================== GUI Application ====================

class SuperResApp:
    def __init__(self, root):
        self.root = root
        self.root.title("UNet Super Resolution - Multi-Core")
        self.root.geometry("1200x800")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'ngf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=16),
            'learning_rate': tk.DoubleVar(value=0.001),
            'beta1': tk.DoubleVar(value=0.9),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'downscale_factor': tk.IntVar(value=4),  # How much to downscale
            'augment_data': tk.BooleanVar(value=True),
            'test_interval': tk.IntVar(value=5)
        }
        
        # Performance tracking
        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        
        # For storing test results
        self.test_results = []
        
        # Current images for upscaling tab
        self.current_lowres_image = None
        self.current_original_image = None
        self.current_upscaled_image = None
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Upscale
        self.upscale_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.upscale_tab, text='Upscale')
        self.setup_upscale_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="UNet Super Resolution", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Resolution info display
        self.res_display = tk.Label(left_frame, text="Upscale: 8x8 → 32x32")
        self.res_display.pack(pady=(0, 10))
        
        # Downscale factor display
        self.downscale_display = tk.Label(left_frame, 
                                         text=f"Downscale Factor: {self.settings['downscale_factor'].get()}")
        self.downscale_display.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize UNet", 
                 command=self.initialize_model, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Testing during training
        test_frame = tk.LabelFrame(left_frame, text="Testing", padx=10, pady=10)
        test_frame.pack(fill=tk.X)
        
        tk.Button(test_frame, text="Test on Sample", 
                 command=self.test_on_sample, width=20).pack(pady=5)
        tk.Button(test_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Results and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Triple image display
        preview_frame = tk.LabelFrame(right_frame, text="Super Resolution Results", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Three columns for low-res, upscaled, and original
        images_frame = tk.Frame(preview_frame)
        images_frame.pack(pady=10)
        
        # Low-res input
        lowres_frame = tk.LabelFrame(images_frame, text="Low-Res Input", padx=5, pady=5)
        lowres_frame.pack(side=tk.LEFT, padx=5)
        self.lowres_image_label = tk.Label(lowres_frame, text="No image", width=256, height=256, bg='gray')
        self.lowres_image_label.pack()
        
        # Upscaled output
        upscaled_frame = tk.LabelFrame(images_frame, text="Upscaled Output", padx=5, pady=5)
        upscaled_frame.pack(side=tk.LEFT, padx=5)
        self.upscaled_image_label = tk.Label(upscaled_frame, text="No image", width=256, height=256, bg='gray')
        self.upscaled_image_label.pack()
        
        # Original target
        original_frame = tk.LabelFrame(images_frame, text="Original Target", padx=5, pady=5)
        original_frame.pack(side=tk.LEFT, padx=5)
        self.original_image_label = tk.Label(original_frame, text="No image", width=256, height=256, bg='gray')
        self.original_image_label.pack()
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar at bottom
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="UNet Super Resolution Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar for many settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Super Resolution Parameters", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Fixed image size display
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Output Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed)", width=20).pack(side=tk.LEFT)
        
        # Downscale factor control
        downscale_frame = tk.Frame(net_frame)
        downscale_frame.pack(fill=tk.X, pady=5)
        tk.Label(downscale_frame, text="Downscale Factor:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(downscale_frame, from_=2, to=8, variable=self.settings['downscale_factor'], 
                orient=tk.HORIZONTAL, length=200, resolution=1,
                command=self.update_downscale_display).pack(side=tk.RIGHT)
        tk.Label(downscale_frame, textvariable=self.settings['downscale_factor'], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Calculate and display input size
        self.input_size_label = tk.Label(net_frame, text="", anchor='w')
        self.input_size_label.pack(fill=tk.X, pady=5)
        self.update_downscale_display()  # Initialize display
        
        # Other network parameters
        settings_list = [
            ("UNet Features (ngf):", 'ngf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 64),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.0001, 0.01),
            ("Beta1:", 'beta1', 0.5, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Test Interval (epochs):", 'test_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.0001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Data augmentation checkbox
        aug_frame = tk.Frame(train_frame)
        aug_frame.pack(fill=tk.X, pady=5)
        tk.Label(aug_frame, text="Data Augmentation:", width=30, anchor='w').pack(side=tk.LEFT)
        tk.Checkbutton(aug_frame, variable=self.settings['augment_data']).pack(side=tk.RIGHT)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_upscale_tab(self):
        main_frame = tk.Frame(self.upscale_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Super Resolution", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Top controls
        control_frame = tk.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Left side - Load and create low-res controls
        left_control = tk.Frame(control_frame)
        left_control.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 20))
        
        tk.Button(left_control, text="Load High-Res Image", 
                 command=self.load_highres_image, width=20).pack(pady=5)
        
        tk.Button(left_control, text="Create Low-Res Version", 
                 command=self.create_lowres_version, width=20).pack(pady=5)
        
        tk.Button(left_control, text="Load Low-Res Image", 
                 command=self.load_lowres_image, width=20).pack(pady=5)
        
        # Right side - Upscale controls
        right_control = tk.Frame(control_frame)
        right_control.pack(side=tk.LEFT, fill=tk.Y)
        
        tk.Button(right_control, text="Load UNet Model", 
                 command=self.load_model, width=20).pack(pady=5)
        
        tk.Button(right_control, text="Upscale Current", 
                 command=self.upscale_current, width=20, bg="lightblue").pack(pady=5)
        
        tk.Button(right_control, text="Batch Upscale", 
                 command=self.batch_upscale, width=20).pack(pady=5)
        
        # Downscale factor control
        factor_frame = tk.Frame(main_frame)
        factor_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(factor_frame, text="Downscale Factor:").pack(side=tk.LEFT, padx=(0, 10))
        
        # Create a dropdown with factor options
        self.current_factor_var = tk.StringVar(value="4")
        
        # Create the dropdown menu
        factor_options = ["2", "3", "4", "5", "6", "7", "8"]
        self.factor_dropdown = ttk.Combobox(factor_frame, textvariable=self.current_factor_var, 
                                           values=factor_options, state="readonly", width=10)
        self.factor_dropdown.pack(side=tk.LEFT, padx=5)
        
        # Method selection (how to downscale)
        tk.Label(factor_frame, text="Method:").pack(side=tk.LEFT, padx=(20, 5))
        self.method_var = tk.StringVar(value="pixelated")
        method_menu = ttk.Combobox(factor_frame, textvariable=self.method_var,
                                  values=["pixelated", "blurry"], state="readonly", width=10)
        method_menu.pack(side=tk.LEFT, padx=5)
        
        # Image display area
        display_frame = tk.LabelFrame(main_frame, text="Super Resolution Process", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        # Three columns
        columns_frame = tk.Frame(display_frame)
        columns_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Low-Res Input
        lowres_display_frame = tk.LabelFrame(columns_frame, text="Low-Res Input", padx=10, pady=10)
        lowres_display_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        self.lowres_display_label = tk.Label(lowres_display_frame, text="No low-res image", 
                                           width=200, height=200, bg='gray')
        self.lowres_display_label.pack(fill=tk.BOTH, expand=True)
        
        # Upscaled Output
        upscaled_display_frame = tk.LabelFrame(columns_frame, text="Upscaled Output", padx=10, pady=10)
        upscaled_display_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        self.upscaled_display_label = tk.Label(upscaled_display_frame, text="No upscaled image", 
                                             width=200, height=200, bg='gray')
        self.upscaled_display_label.pack(fill=tk.BOTH, expand=True)
        
        # Original/High-Res
        original_display_frame = tk.LabelFrame(columns_frame, text="Original/High-Res", padx=10, pady=10)
        original_display_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        self.original_display_label = tk.Label(original_display_frame, text="No high-res image", 
                                             width=200, height=200, bg='gray')
        self.original_display_label.pack(fill=tk.BOTH, expand=True)

    def update_downscale_display(self, *args):
        """Update downscale factor display"""
        factor = self.settings['downscale_factor'].get()
        output_size = 32
        input_size = output_size // factor
        input_size = max(4, input_size)
        
        self.downscale_display.config(text=f"Downscale Factor: {factor}")
        self.res_display.config(text=f"Upscale: {input_size}x{input_size} → {output_size}x{output_size}")
        self.input_size_label.config(text=f"Low-Res Input: {input_size}x{input_size} pixels")

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                # Add to log
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                
                # Update status with first line
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                
                print(message)  # Also print to console
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_model(self):
        """Initialize UNet with current settings"""
        try:
            image_size = 32  # Fixed at 32x32
            ngf = self.settings['ngf'].get()
            
            self.model = SuperResUNet(
                image_size=image_size,
                ngf=ngf
            )
            
            factor = self.settings['downscale_factor'].get()
            input_size = image_size // factor
            
            self.log_message(f"Initialized Super Resolution UNet")
            self.log_message(f"Input: {input_size}x{input_size} → Output: {image_size}x{image_size}")
            self.log_message(f"UNet features: {ngf}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing UNet: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.model:
            self.log_message("Error: UNet not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            downscale_factor = self.settings['downscale_factor'].get()
            augment = self.settings['augment_data'].get()
            
            # Update optimizer with new settings
            for param_group in self.model.optimizer.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_model,
                args=(epochs, batch_size, num_workers, downscale_factor, augment),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Downscale factor: {downscale_factor}")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}")
            self.log_message(f"Data augmentation: {augment}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_model(self, epochs, batch_size, num_workers, downscale_factor, augment):
        """Training loop in separate thread"""
        try:
            test_interval = self.settings['test_interval'].get()
            
            # Create dataset and dataloader
            dataset = SuperResDataset(self.image_paths, image_size=32, 
                                     downscale_factor=downscale_factor, augment=augment)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss = 0
                batch_count = 0
                epoch_start = time.time()
                
                for lowres_images, highres_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = lowres_images.size(0)
                    lowres_images = lowres_images.to(self.model.device)
                    highres_images = highres_images.to(self.model.device)
                    
                    # Train UNet
                    self.model.optimizer.zero_grad()
                    
                    # Forward pass
                    upscaled_images = self.model.model(lowres_images)
                    
                    # Calculate loss
                    loss = self.model.criterion(upscaled_images, highres_images)
                    
                    # Backward pass and optimize
                    loss.backward()
                    self.model.optimizer.step()
                    
                    total_loss += loss.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss = total_loss / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    # Log progress
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"Loss: {avg_loss:.6f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Total: {elapsed:.1f}s")
                    
                    # Test on sample at interval
                    if (epoch + 1) % test_interval == 0:
                        self.test_on_training_sample()
                        
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def test_on_training_sample(self):
        """Test the model on a sample from training set"""
        if not self.model or not self.image_paths:
            return
        
        try:
            with torch.no_grad():
                # Pick a random training image
                idx = random.randint(0, len(self.image_paths) - 1)
                
                # Create dataset for single image
                temp_dataset = SuperResDataset([self.image_paths[idx]], image_size=32,
                                             downscale_factor=self.settings['downscale_factor'].get(),
                                             augment=False)
                
                lowres_tensor, hq_tensor = temp_dataset[0]
                
                # Add batch dimension and move to device
                lowres_tensor = lowres_tensor.unsqueeze(0).to(self.model.device)
                hq_tensor = hq_tensor.unsqueeze(0)
                
                # Upscale
                upscaled_tensor = self.model.model(lowres_tensor).cpu()
                
                # Convert to PIL images
                lowres_img = self.tensor_to_pil(lowres_tensor.cpu()[0])
                upscaled_img = self.tensor_to_pil(upscaled_tensor[0])
                original_img = self.tensor_to_pil(hq_tensor[0])
                
                # Resize for display using NEAREST for low-res, BILINEAR for others
                display_size = (256, 256)
                
                # For low-res, show actual pixelation at display size
                lowres_display = lowres_img.resize(display_size, Image.NEAREST)
                upscaled_display = upscaled_img.resize(display_size, Image.BILINEAR)
                original_display = original_img.resize(display_size, Image.BILINEAR)
                
                # Convert to PhotoImage
                lowres_photo = ImageTk.PhotoImage(lowres_display)
                upscaled_photo = ImageTk.PhotoImage(upscaled_display)
                original_photo = ImageTk.PhotoImage(original_display)
                
                # Update displays
                self.lowres_image_label.config(image=lowres_photo, text="")
                self.lowres_image_label.image = lowres_photo
                
                self.upscaled_image_label.config(image=upscaled_photo, text="")
                self.upscaled_image_label.image = upscaled_photo
                
                self.original_image_label.config(image=original_photo, text="")
                self.original_image_label.image = original_photo
                
                # Store for later
                self.test_results.append((lowres_img, upscaled_img, original_img))
                
                self.log_message(f"Tested on training sample at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error testing on sample: {str(e)}")

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        img = (tensor + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def test_on_sample(self):
        """Test on a sample from training set (manual)"""
        if not self.model:
            self.log_message("Error: UNet not initialized!")
            return
        
        self.test_on_training_sample()

    def save_model(self):
        """Save current model"""
        if not self.model:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'model_state_dict': self.model.model.state_dict(),
                    'optimizer_state_dict': self.model.optimizer.state_dict(),
                    'criterion': self.model.criterion,
                    'image_size': 32,
                    'ngf': self.settings['ngf'].get(),
                    'downscale_factor': self.settings['downscale_factor'].get(),
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_model(self):
        """Load UNet model from file"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])
                
                if 'downscale_factor' in checkpoint:
                    self.settings['downscale_factor'].set(checkpoint['downscale_factor'])
                    self.update_downscale_display()
                    # Also update the upscale tab dropdown
                    self.current_factor_var.set(str(checkpoint['downscale_factor']))
                
                # Initialize model with loaded settings
                self.initialize_model()
                
                # Load state dict
                self.model.model.load_state_dict(checkpoint['model_state_dict'])
                
                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                self.log_message(f"Trained with downscale factor: {checkpoint.get('downscale_factor', 'unknown')}")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def load_highres_image(self):
        """Load a high-resolution image"""
        filename = filedialog.askopenfilename(
            title="Select high-resolution image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if filename:
            try:
                img = Image.open(filename).convert('RGB')
                # Store original at 32x32 for processing
                self.current_original_image = img.resize((32, 32), Image.BILINEAR)
                
                # Display at 200x200 for viewing
                display_img = img.resize((200, 200), Image.BILINEAR)
                photo = ImageTk.PhotoImage(display_img)
                self.original_display_label.config(image=photo, text="")
                self.original_display_label.image = photo
                
                self.log_message(f"Loaded high-res image: {os.path.basename(filename)}")
                
            except Exception as e:
                self.log_message(f"Error loading image: {str(e)}")

    def create_lowres_version(self):
        """Create a low-resolution version of current high-res image"""
        if self.current_original_image is None:
            self.log_message("Error: No high-res image loaded!")
            return
        
        try:
            factor = int(self.current_factor_var.get())
            method = self.method_var.get()
            
            # Calculate small size
            small_size = 32 // factor
            small_size = max(4, small_size)
            
            # Create low-res version
            tiny_img = self.current_original_image.resize((small_size, small_size), Image.BILINEAR)
            
            if method == "pixelated":
                # Upscale with nearest neighbor for blocky/pixelated look
                lowres_img = tiny_img.resize((32, 32), Image.NEAREST)
            else:  # "blurry"
                # Upscale with bilinear for smooth/blurry look
                lowres_img = tiny_img.resize((32, 32), Image.BILINEAR)
            
            self.current_lowres_image = lowres_img
            
            # Display at 200x200
            # For pixelated method, show actual pixels at display size
            if method == "pixelated":
                display_img = lowres_img.resize((200, 200), Image.NEAREST)
            else:
                display_img = lowres_img.resize((200, 200), Image.BILINEAR)
            
            photo = ImageTk.PhotoImage(display_img)
            self.lowres_display_label.config(image=photo, text="")
            self.lowres_display_label.image = photo
            
            self.log_message(f"Created {method} low-res image: {small_size}x{small_size} → 32x32")
            
        except Exception as e:
            self.log_message(f"Error creating low-res version: {str(e)}")

    def load_lowres_image(self):
        """Load a pre-existing low-resolution image"""
        filename = filedialog.askopenfilename(
            title="Select low-resolution image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if filename:
            try:
                img = Image.open(filename).convert('RGB')
                img = img.resize((32, 32), Image.NEAREST)  # Use NEAREST to preserve pixelation
                self.current_lowres_image = img
                
                # Display with NEAREST to show pixelation
                display_img = img.resize((200, 200), Image.NEAREST)
                photo = ImageTk.PhotoImage(display_img)
                self.lowres_display_label.config(image=photo, text="")
                self.lowres_display_label.image = photo
                
                self.log_message(f"Loaded low-res image: {os.path.basename(filename)}")
                
            except Exception as e:
                self.log_message(f"Error loading image: {str(e)}")

    def upscale_current(self):
        """Upscale current low-res image"""
        if not self.model:
            self.log_message("Error: UNet not loaded!")
            return
        
        if self.current_lowres_image is None:
            self.log_message("Error: No low-res image to upscale!")
            return
        
        try:
            # Convert PIL to tensor
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            lowres_tensor = transform(self.current_lowres_image).unsqueeze(0)
            lowres_tensor = lowres_tensor.to(self.model.device)
            
            with torch.no_grad():
                upscaled_tensor = self.model.model(lowres_tensor).cpu()
            
            # Convert back to PIL
            self.current_upscaled_image = self.tensor_to_pil(upscaled_tensor[0])
            
            # Display with BILINEAR for smooth view
            display_img = self.current_upscaled_image.resize((200, 200), Image.BILINEAR)
            photo = ImageTk.PhotoImage(display_img)
            self.upscaled_display_label.config(image=photo, text="")
            self.upscaled_display_label.image = photo
            
            self.log_message("Successfully upscaled image!")
            
        except Exception as e:
            self.log_message(f"Error upscaling image: {str(e)}")

    def batch_upscale(self):
        """Upscale multiple images"""
        if not self.model:
            self.log_message("Error: UNet not loaded!")
            return
        
        files = filedialog.askopenfilenames(
            title="Select low-res images to upscale",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if not files:
            return
        
        save_dir = filedialog.askdirectory(title="Select directory to save upscaled images")
        if not save_dir:
            return
        
        try:
            transform = transforms.Compose([
                transforms.Resize((32, 32)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            for i, file in enumerate(files):
                # Load and preprocess
                img = Image.open(file).convert('RGB')
                input_tensor = transform(img).unsqueeze(0).to(self.model.device)
                
                # Upscale
                with torch.no_grad():
                    output_tensor = self.model.model(input_tensor).cpu()
                
                # Convert back to PIL and save
                upscaled_img = self.tensor_to_pil(output_tensor[0])
                
                # Save with original name
                base_name = os.path.basename(file)
                name, ext = os.path.splitext(base_name)
                save_path = os.path.join(save_dir, f"{name}_upscaled{ext}")
                upscaled_img.save(save_path)
                
                self.log_message(f"Processed {i+1}/{len(files)}: {base_name}")
            
            self.log_message(f"Batch upscaling complete. Saved to {save_dir}")
            
        except Exception as e:
            self.log_message(f"Error in batch upscaling: {str(e)}")

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('superres_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            import json
            if os.path.exists('superres_defaults.json'):
                with open('superres_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.update_downscale_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting UNet Super Resolution Trainer...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = SuperResApp(root)
    root.mainloop()