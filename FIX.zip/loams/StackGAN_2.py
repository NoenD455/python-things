import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import traceback
from pathlib import Path

# ==================== StyleGAN Components ====================

class MappingNetwork(nn.Module):
    """Maps latent z to intermediate style code w."""
    def __init__(self, latent_dim=512, style_dim=512, num_layers=8):
        super().__init__()
        layers = []
        for i in range(num_layers):
            in_dim = latent_dim if i == 0 else style_dim
            out_dim = style_dim
            layers.append(nn.Linear(in_dim, out_dim))
            if i < num_layers - 1:
                layers.append(nn.LeakyReLU(0.2))
        self.net = nn.Sequential(*layers)

    def forward(self, z):
        # z: [batch, latent_dim] (flattened)
        return self.net(z)


class FiLMLayer(nn.Module):
    """Applies FiLM modulation: gamma * x + beta."""
    def __init__(self, channels, style_dim):
        super().__init__()
        self.channels = channels
        self.gamma_fc = nn.Linear(style_dim, channels)
        self.beta_fc = nn.Linear(style_dim, channels)

    def forward(self, x, w):
        # w: [batch, style_dim]
        gamma = self.gamma_fc(w).view(-1, self.channels, 1, 1)
        beta = self.beta_fc(w).view(-1, self.channels, 1, 1)
        return x * (1 + gamma) + beta


class NoiseInjection(nn.Module):
    """Adds per‑channel scaled random noise."""
    def __init__(self, channels):
        super().__init__()
        self.weight = nn.Parameter(torch.zeros(1, channels, 1, 1))

    def forward(self, x):
        noise = torch.randn(x.size(0), 1, x.size(2), x.size(3), device=x.device)
        return x + self.weight * noise


class StyleBlock(nn.Module):
    """A convolutional block with FiLM modulation and noise injection."""
    def __init__(self, in_channels, out_channels, style_dim, kernel_size=3, stride=1, padding=1):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.film = FiLMLayer(out_channels, style_dim)
        self.noise = NoiseInjection(out_channels)
        self.activation = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x, w):
        x = self.conv(x)
        x = self.bn(x)
        x = self.film(x, w)
        x = self.noise(x)
        x = self.activation(x)
        return x


# ---------- Style‑based 16x16 Generator (DCGAN‑style start) ----------
class StyleGenerator16(nn.Module):
    """Generates a 16x16 image starting from a transposed conv of latent."""
    def __init__(self, latent_dim=100, style_dim=512, ngf=64):
        super().__init__()
        self.style_dim = style_dim

        # Initial projection from latent to 4x4 feature map (DCGAN style)
        self.init_conv = nn.ConvTranspose2d(latent_dim, ngf * 8, 4, 1, 0, bias=False)
        self.init_bn = nn.BatchNorm2d(ngf * 8)
        self.init_act = nn.ReLU(True)

        # Style blocks for refinement (no upsampling yet)
        self.block1 = StyleBlock(ngf * 8, ngf * 8, style_dim)   # 4x4
        self.block2 = StyleBlock(ngf * 8, ngf * 8, style_dim)   # 4x4 (optional extra)

        # Upsample to 8x8
        self.up1 = nn.Upsample(scale_factor=2, mode='nearest')
        self.block3 = StyleBlock(ngf * 8, ngf * 4, style_dim)   # 8x8

        # Upsample to 16x16
        self.up2 = nn.Upsample(scale_factor=2, mode='nearest')
        self.block4 = StyleBlock(ngf * 4, ngf * 2, style_dim)   # 16x16

        # Final refinement and to RGB
        self.block5 = StyleBlock(ngf * 2, ngf, style_dim)       # 16x16
        self.to_rgb = nn.Conv2d(ngf, 3, 1)

    def forward(self, z, w):
        # z: [batch, latent_dim, 1, 1] (as from noise)
        x = self.init_conv(z)
        x = self.init_bn(x)
        x = self.init_act(x)

        x = self.block1(x, w)
        x = self.block2(x, w)

        x = self.up1(x)
        x = self.block3(x, w)

        x = self.up2(x)
        x = self.block4(x, w)

        x = self.block5(x, w)
        x = self.to_rgb(x)
        return torch.tanh(x)


# ---------- Style‑based 16x16 U‑Net (refiner) ----------
class StyleUNet16(nn.Module):
    """U‑Net with style modulation in every conv block."""
    def __init__(self, in_channels=3, out_channels=3, style_dim=512, features=64):
        super().__init__()
        # Encoder
        self.enc1 = StyleBlock(in_channels, features, style_dim)
        self.pool1 = nn.MaxPool2d(2)
        self.enc2 = StyleBlock(features, features * 2, style_dim)
        self.pool2 = nn.MaxPool2d(2)
        self.enc3 = StyleBlock(features * 2, features * 4, style_dim)

        # Decoder
        self.upconv2 = nn.ConvTranspose2d(features * 4, features * 2, 2, 2)
        self.dec2 = StyleBlock(features * 4, features * 2, style_dim)  # after skip
        self.upconv1 = nn.ConvTranspose2d(features * 2, features, 2, 2)
        self.dec1 = StyleBlock(features * 2, features, style_dim)       # after skip
        self.final = nn.Conv2d(features, out_channels, 1)

    def forward(self, x, w):
        # Encoder
        e1 = self.enc1(x, w)          # 16x16
        e2 = self.enc2(self.pool1(e1), w)  # 8x8
        e3 = self.enc3(self.pool2(e2), w)  # 4x4

        # Decoder
        d2 = self.upconv2(e3)          # 8x8
        d2 = torch.cat([d2, e2], dim=1)
        d2 = self.dec2(d2, w)

        d1 = self.upconv1(d2)          # 16x16
        d1 = torch.cat([d1, e1], dim=1)
        d1 = self.dec1(d1, w)

        return self.final(d1)


# ---------- SR Up‑scaler (unchanged) ----------
class SRUpScaler(nn.Module):
    def __init__(self, in_channels=3, out_channels=3, features=32):
        super().__init__()
        self.body = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(in_channels, features, 3, 1, 1),
            nn.BatchNorm2d(features),
            nn.ReLU(True),
            nn.Conv2d(features, out_channels, 3, 1, 1),
            nn.Tanh()
        )

    def forward(self, x):
        return self.body(x)


# ---------- Style‑based 32x32 U‑Net ----------
class StyleUNet32(nn.Module):
    """32x32 U‑Net with style modulation."""
    def __init__(self, in_channels=3, out_channels=3, style_dim=512, features=64):
        super().__init__()
        # Encoder
        self.enc1 = StyleBlock(in_channels, features, style_dim)
        self.pool1 = nn.MaxPool2d(2)
        self.enc2 = StyleBlock(features, features * 2, style_dim)
        self.pool2 = nn.MaxPool2d(2)
        self.enc3 = StyleBlock(features * 2, features * 4, style_dim)
        self.pool3 = nn.MaxPool2d(2)
        self.enc4 = StyleBlock(features * 4, features * 8, style_dim)

        # Decoder
        self.upconv3 = nn.ConvTranspose2d(features * 8, features * 4, 2, 2)
        self.dec3 = StyleBlock(features * 8, features * 4, style_dim)  # skip from enc3
        self.upconv2 = nn.ConvTranspose2d(features * 4, features * 2, 2, 2)
        self.dec2 = StyleBlock(features * 4, features * 2, style_dim)  # skip from enc2
        self.upconv1 = nn.ConvTranspose2d(features * 2, features, 2, 2)
        self.dec1 = StyleBlock(features * 2, features, style_dim)      # skip from enc1
        self.final = nn.Conv2d(features, out_channels, 1)

    def forward(self, x, w):
        # Encoder
        e1 = self.enc1(x, w)           # 32x32
        e2 = self.enc2(self.pool1(e1), w)  # 16x16
        e3 = self.enc3(self.pool2(e2), w)  # 8x8
        e4 = self.enc4(self.pool3(e3), w)  # 4x4

        # Decoder
        d3 = self.upconv3(e4)           # 8x8
        d3 = torch.cat([d3, e3], dim=1)
        d3 = self.dec3(d3, w)

        d2 = self.upconv2(d3)           # 16x16
        d2 = torch.cat([d2, e2], dim=1)
        d2 = self.dec2(d2, w)

        d1 = self.upconv1(d2)           # 32x32
        d1 = torch.cat([d1, e1], dim=1)
        d1 = self.dec1(d1, w)

        return self.final(d1)


# ---------- Fixed Discriminators ----------
class Discriminator16(nn.Module):
    def __init__(self, ndf=64):
        super().__init__()
        self.main = nn.Sequential(
            nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 2),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 4),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(ndf * 4, 1, 2, 1, 0, bias=False)   # changed from 4 to 2
        )

    def forward(self, x):
        return self.main(x).view(-1, 1)


class PatchGANDiscriminator32(nn.Module):
    def __init__(self, ndf=64):
        super().__init__()
        self.main = nn.Sequential(
            nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 2),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 4),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(ndf * 4, ndf * 8, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 8),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(ndf * 8, 1, 2, 1, 0, bias=False)
        )

    def forward(self, x):
        # Output shape: (batch, 1, 1, 1) -> squeeze to (batch, 1)
        return self.main(x).view(x.size(0), -1).mean(dim=1, keepdim=True)


# ---------- Full Stacked StyleGAN ----------
class StackedStyleGAN:
    def __init__(self, latent_dim=100, style_dim=512, ngf=64, ndf=64):
        self.latent_dim = latent_dim
        self.style_dim = style_dim
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        torch.set_num_threads(multiprocessing.cpu_count())

        # Mapping network
        self.mapping = MappingNetwork(latent_dim, style_dim, num_layers=8).to(self.device)

        # Generator stages
        self.gen16 = StyleGenerator16(latent_dim, style_dim, ngf).to(self.device)
        self.unet16 = StyleUNet16(3, 3, style_dim, ngf).to(self.device)
        self.sr = SRUpScaler(3, 3, 32).to(self.device)
        self.unet32 = StyleUNet32(3, 3, style_dim, ngf).to(self.device)

        # Discriminators
        self.disc16 = Discriminator16(ndf).to(self.device)
        self.disc32 = PatchGANDiscriminator32(ndf).to(self.device)

        # Loss
        self.criterion = nn.BCEWithLogitsLoss()

        # Optimizers (all generator parts + mapping)
        gen_params = list(self.mapping.parameters()) + list(self.gen16.parameters()) \
                     + list(self.unet16.parameters()) + list(self.sr.parameters()) \
                     + list(self.unet32.parameters())
        self.optimizerG = optim.Adam(gen_params, lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD16 = optim.Adam(self.disc16.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD32 = optim.Adam(self.disc32.parameters(), lr=0.0002, betas=(0.5, 0.999))

        print(f"StackedStyleGAN initialized. Device: {self.device}")

    def generate(self, z):
        """
        z: [batch, latent_dim, 1, 1]
        Returns: refined_16, refined_32
        """
        z_flat = z.view(z.size(0), -1)  # [batch, latent_dim]
        w = self.mapping(z_flat)         # [batch, style_dim]

        fake16_raw = self.gen16(z, w)    # note: generator also needs z (for initial projection)
        fake16_refined = self.unet16(fake16_raw, w)
        fake32_raw = self.sr(fake16_refined)
        fake32_refined = self.unet32(fake32_raw, w)
        return fake16_refined, fake32_refined

    def train_step(self, real32):
        batch_size = real32.size(0)
        real32 = real32.to(self.device)
        real16 = F.interpolate(real32, size=(16, 16), mode='bilinear', align_corners=False)

        real_label = torch.ones(batch_size, 1, device=self.device)
        fake_label = torch.zeros(batch_size, 1, device=self.device)

        # ---- Train Discriminators (freeze generators) ----
        for p in self.mapping.parameters():
            p.requires_grad = False
        for p in self.gen16.parameters():
            p.requires_grad = False
        for p in self.unet16.parameters():
            p.requires_grad = False
        for p in self.sr.parameters():
            p.requires_grad = False
        for p in self.unet32.parameters():
            p.requires_grad = False

        noise = torch.randn(batch_size, self.latent_dim, 1, 1, device=self.device)
        fake16, fake32 = self.generate(noise)

        # D16
        self.optimizerD16.zero_grad()
        out_real16 = self.disc16(real16)
        lossD16_real = self.criterion(out_real16, real_label)
        out_fake16 = self.disc16(fake16.detach())
        lossD16_fake = self.criterion(out_fake16, fake_label)
        lossD16 = (lossD16_real + lossD16_fake) / 2
        lossD16.backward()
        self.optimizerD16.step()

        # D32
        self.optimizerD32.zero_grad()
        out_real32 = self.disc32(real32)
        lossD32_real = self.criterion(out_real32, real_label)
        out_fake32 = self.disc32(fake32.detach())
        lossD32_fake = self.criterion(out_fake32, fake_label)
        lossD32 = (lossD32_real + lossD32_fake) / 2
        lossD32.backward()
        self.optimizerD32.step()

        # ---- Train Generators (unfreeze) ----
        for p in self.mapping.parameters():
            p.requires_grad = True
        for p in self.gen16.parameters():
            p.requires_grad = True
        for p in self.unet16.parameters():
            p.requires_grad = True
        for p in self.sr.parameters():
            p.requires_grad = True
        for p in self.unet32.parameters():
            p.requires_grad = True

        self.optimizerG.zero_grad()

        noise = torch.randn(batch_size, self.latent_dim, 1, 1, device=self.device)
        fake16, fake32 = self.generate(noise)

        lossG16 = self.criterion(self.disc16(fake16), real_label)
        lossG32 = self.criterion(self.disc32(fake32), real_label)
        lossG = lossG16 + lossG32
        lossG.backward()
        self.optimizerG.step()

        return {
            'D16': lossD16.item(),
            'D32': lossD32.item(),
            'G16': lossG16.item(),
            'G32': lossG32.item()
        }


# ==================== Dataset ====================
class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)


# ==================== GUI Application ====================
class StackedStyleGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Stacked StyleGAN (FiLM + Noise, DCGAN start)")
        self.root.geometry("1000x700")

        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()

        self.settings = {
            'latent_dim': tk.IntVar(value=100),
            'style_dim': tk.IntVar(value=512),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'generate_interval': tk.IntVar(value=5)
        }

        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        self.generated_images = []

        self.setup_gui()
        self.root.after(100, self.process_messages)

    # GUI setup methods (identical to previous, only names changed)
    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))

        tk.Label(left_frame, text="Stacked StyleGAN Controls", font=("Arial", 12, "bold")).pack(pady=(0, 10))
        self.size_display = tk.Label(left_frame, text="Architecture: StyleGAN (FiLM+Noise, DCGAN start)")
        self.size_display.pack(pady=(0, 10))

        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        tk.Button(img_select_frame, text="Add Images", command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=5)

        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        list_scrollbar = tk.Scrollbar(list_frame, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)

        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        tk.Button(train_frame, text="Initialize GAN", command=self.initialize_gan, width=20).pack(pady=5)

        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="Start Training", command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", command=self.stop_training, width=20, bg="salmon").pack(pady=5)

        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        tk.Button(gen_frame, text="Generate Sample", command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)

        # Right panel
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Image (32x32)", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)

        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

        self.status_label = tk.Label(self.training_tab, text="Ready", relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        tk.Label(main_frame, text="Stacked StyleGAN Settings", font=("Arial", 14, "bold")).pack(pady=(0, 20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))

        tk.Label(net_frame, text="Mapping Network (8 layers) + DCGAN initial projection", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(net_frame, text="FiLM modulation + noise injection in all conv layers", anchor='w').pack(fill=tk.X, pady=2)

        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 64, 1024),
            ("Style Dimension (w):", 'style_dim', 64, 1024),
            ("Base Channels (ngf):", 'ngf', 16, 256),
            ("Base Channels (ndf):", 'ndf', 16, 256),
            ("Batch Size:", 'batch_size', 1, 64),
        ]

        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)

        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))

        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count())),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]

        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)

        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", anchor='w').pack(fill=tk.X, pady=2)

        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        tk.Button(btn_frame, text="Save as Default", command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset", command=self.reset_settings, width=15).pack(side=tk.LEFT, padx=5)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        tk.Label(main_frame, text="Image Generation", font=("Arial", 14, "bold")).pack(pady=(0, 20))

        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        tk.Button(load_frame, text="Load Generator", command=self.load_generator, width=20).pack(pady=5)

        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var, orient=tk.HORIZONTAL, length=300).pack(pady=5)
        tk.Button(gen_frame, text="Generate Grid", command=self.generate_grid, width=20).pack(pady=10)

        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        self.gen_scroll_frame.bind("<Configure>", lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all")))
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ----- Utility methods (with full traceback logging) -----
    def log_message(self, message):
        self.message_queue.put(message)

    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=message[:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")])
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                self.image_listbox.insert(tk.END, os.path.basename(file))
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_gan(self):
        try:
            latent_dim = self.settings['latent_dim'].get()
            style_dim = self.settings['style_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            self.gan = StackedStyleGAN(latent_dim, style_dim, ngf, ndf)
            self.log_message(f"Initialized StackedStyleGAN: latent={latent_dim}, style={style_dim}, ngf={ngf}, ndf={ndf}")
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
            self.log_message(traceback.format_exc())

    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images!")
            return
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        if self.training:
            self.log_message("Training already in progress!")
            return

        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()

            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()

            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            for param_group in self.gan.optimizerD16.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            for param_group in self.gan.optimizerD32.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)

            thread = threading.Thread(target=self.train_gan, args=(epochs, batch_size, num_workers), daemon=True)
            thread.start()
            self.log_message(f"Started training for {epochs} epochs")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")
            self.log_message(traceback.format_exc())

    def train_gan(self, epochs, batch_size, num_workers):
        try:
            generate_interval = self.settings['generate_interval'].get()
            dataset = ImageDataset(self.image_paths, image_size=32)
            dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                    num_workers=min(num_workers, multiprocessing.cpu_count()),
                                    pin_memory=torch.cuda.is_available(),
                                    persistent_workers=(num_workers > 0))

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                epoch_start = time.time()
                total_losses = {'D16': 0, 'D32': 0, 'G16': 0, 'G32': 0}
                batch_count = 0

                for real32 in dataloader:
                    if not self.training:
                        break
                    losses = self.gan.train_step(real32)
                    for k, v in losses.items():
                        total_losses[k] += v
                    batch_count += 1

                if batch_count > 0:
                    avg_losses = {k: v / batch_count for k, v in total_losses.items()}
                    epoch_time = time.time() - epoch_start
                    elapsed = time.time() - self.start_time
                    self.log_message(
                        f"Epoch {epoch+1}/{epochs} | "
                        f"D16:{avg_losses['D16']:.4f} D32:{avg_losses['D32']:.4f} | "
                        f"G16:{avg_losses['G16']:.4f} G32:{avg_losses['G32']:.4f} | "
                        f"Time:{epoch_time:.1f}s | Total:{elapsed:.1f}s"
                    )

                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")

            self.training = False
            self.log_message("Training completed!")
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.log_message(traceback.format_exc())
            self.training = False

    def generate_training_samples(self):
        if not self.gan:
            return
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                _, fake32 = self.gan.generate(noise)
                img_tensor = fake32[0].cpu()
                img = self.tensor_to_pil(img_tensor)
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
                self.log_message(f"Generated sample at epoch {self.current_epoch+1}")
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")
            self.log_message(traceback.format_exc())

    def tensor_to_pil(self, tensor):
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        return transforms.ToPILImage()(img)

    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                _, fake32 = self.gan.generate(noise)
                img = self.tensor_to_pil(fake32[0].cpu())
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
                self.log_message("Generated single sample")
        except Exception as e:
            self.log_message(f"Error: {str(e)}")
            self.log_message(traceback.format_exc())

    def save_model(self):
        if not self.gan:
            self.log_message("Error: No model to save!")
            return
        filename = filedialog.asksaveasfilename(defaultextension=".pth",
                                                filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")])
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'mapping': self.gan.mapping.state_dict(),
                    'gen16': self.gan.gen16.state_dict(),
                    'unet16': self.gan.unet16.state_dict(),
                    'sr': self.gan.sr.state_dict(),
                    'unet32': self.gan.unet32.state_dict(),
                    'disc16': self.gan.disc16.state_dict(),
                    'disc32': self.gan.disc32.state_dict(),
                    'optimG': self.gan.optimizerG.state_dict(),
                    'optimD16': self.gan.optimizerD16.state_dict(),
                    'optimD32': self.gan.optimizerD32.state_dict(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'style_dim': self.settings['style_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                }, filename)
                self.log_message(f"Model saved to {filename}")
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")
                self.log_message(traceback.format_exc())

    def load_generator(self):
        filename = filedialog.askopenfilename(filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")])
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                for key in ['latent_dim', 'style_dim', 'ngf', 'ndf']:
                    if key in checkpoint:
                        self.settings[key].set(checkpoint[key])
                self.initialize_gan()
                self.gan.mapping.load_state_dict(checkpoint['mapping'])
                self.gan.gen16.load_state_dict(checkpoint['gen16'])
                self.gan.unet16.load_state_dict(checkpoint['unet16'])
                self.gan.sr.load_state_dict(checkpoint['sr'])
                self.gan.unet32.load_state_dict(checkpoint['unet32'])
                self.gan.disc16.load_state_dict(checkpoint['disc16'])
                self.gan.disc32.load_state_dict(checkpoint['disc32'])
                self.gan.optimizerG.load_state_dict(checkpoint['optimG'])
                self.gan.optimizerD16.load_state_dict(checkpoint['optimD16'])
                self.gan.optimizerD32.load_state_dict(checkpoint['optimD32'])
                self.log_message(f"Loaded model from {filename}")
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")
                self.log_message(traceback.format_exc())

    def generate_grid(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        try:
            num_images = self.num_gen_var.get()
            with torch.no_grad():
                noise = torch.randn(num_images, self.gan.latent_dim, 1, 1).to(self.gan.device)
                _, fake32 = self.gan.generate(noise)
                fake32 = fake32.cpu()

            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()

            cols = 4
            rows = (num_images + cols - 1) // cols
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img = self.tensor_to_pil(fake32[idx])
                        img_display = img.resize((128, 128), Image.Resampling.NEAREST)
                        photo = ImageTk.PhotoImage(img_display)
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            self.log_message(f"Generated {num_images} images")
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")
            self.log_message(traceback.format_exc())

    def save_defaults(self):
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('stackedstylegan_defaults.json', 'w') as f:
                json.dump(defaults, f)
            self.log_message("Settings saved")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")
            self.log_message(traceback.format_exc())

    def load_defaults(self):
        try:
            import json
            if os.path.exists('stackedstylegan_defaults.json'):
                with open('stackedstylegan_defaults.json', 'r') as f:
                    defaults = json.load(f)
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                self.log_message("Defaults loaded")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")
            self.log_message(traceback.format_exc())

    def reset_settings(self):
        self.settings['latent_dim'].set(100)
        self.settings['style_dim'].set(512)
        self.settings['ngf'].set(64)
        self.settings['ndf'].set(64)
        self.settings['batch_size'].set(8)
        self.settings['learning_rate'].set(0.0002)
        self.settings['beta1'].set(0.5)
        self.settings['num_workers'].set(min(4, multiprocessing.cpu_count()))
        self.settings['generate_interval'].set(5)
        self.log_message("Reset to default settings")


# ==================== Main ====================
if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = StackedStyleGANApp(root)
    root.mainloop()