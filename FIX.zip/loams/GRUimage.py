import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
from PIL import Image, ImageTk, ImageOps
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import random
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import threading
import queue
import time

# Set random seeds for reproducibility
torch.manual_seed(42)
np.random.seed(42)
random.seed(42)

# Device configuration
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# ==================== GRU Model ====================
class GRUPixelPredictor(nn.Module):
    def __init__(self, input_size=25, hidden_size=128, output_size=3, num_layers=2, 
                 use_coordinates=False, image_size=32):
        super(GRUPixelPredictor, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.use_coordinates = use_coordinates
        self.image_size = image_size
        
        # Calculate input size (5x5x3 = 75 + 2 if using coordinates)
        self.coord_features = 2 if use_coordinates else 0
        self.total_input_size = input_size * 3 + self.coord_features  # 5x5 RGB patches
        
        # GRU layer
        self.gru = nn.GRU(
            input_size=self.total_input_size, 
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=0.2
        )
        
        # Attention mechanism
        self.attention = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.ReLU(),
            nn.Linear(hidden_size // 2, 1)
        )
        
        # Fully connected layers
        self.fc1 = nn.Linear(hidden_size, hidden_size // 2)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_size // 2, output_size)
        self.sigmoid = nn.Sigmoid()
        
        # Layer normalization
        self.ln1 = nn.LayerNorm(hidden_size)
        self.ln2 = nn.LayerNorm(hidden_size // 2)
        
        # Coordinate embedding (if used)
        if use_coordinates:
            self.coord_fc = nn.Linear(2, hidden_size // 4)
        
    def forward(self, x, coordinates=None, hidden=None):
        batch_size = x.size(0)
        seq_len = x.size(1)
        
        # Add coordinate information if enabled
        if self.use_coordinates and coordinates is not None:
            # coordinates should be shape [batch_size, seq_len, 2]
            coord_embed = self.coord_fc(coordinates)
            # Repeat coord_embed to match x dimensions if needed
            if coord_embed.shape[1] < seq_len:
                coord_embed = coord_embed.repeat(1, seq_len, 1)
            # Concatenate coordinate information
            x = torch.cat([x, coord_embed], dim=-1)
        elif self.use_coordinates and coordinates is None:
            # If coordinates are not provided but expected, create zeros
            zeros_coords = torch.zeros(batch_size, seq_len, 2).to(x.device)
            coord_embed = self.coord_fc(zeros_coords)
            x = torch.cat([x, coord_embed], dim=-1)
        
        # Initialize hidden state if not provided
        if hidden is None:
            hidden = torch.zeros(self.num_layers, batch_size, self.hidden_size).to(x.device)
        
        # GRU forward pass
        out, hidden = self.gru(x, hidden)
        
        # Apply attention
        attention_weights = self.attention(out)
        attention_weights = torch.softmax(attention_weights, dim=1)
        context = torch.sum(attention_weights * out, dim=1)
        
        # Apply layer norm and fully connected layers
        out = self.ln1(context)
        out = self.fc1(out)
        out = self.relu(out)
        out = self.ln2(out)
        out = self.fc2(out)
        out = self.sigmoid(out)
        
        return out, hidden, attention_weights

# ==================== Dataset ====================
class PatchDataset(Dataset):
    def __init__(self, image_paths, patch_size=5, use_coordinates=False, image_size=32):
        self.image_paths = image_paths
        self.patch_size = patch_size
        self.use_coordinates = use_coordinates
        self.image_size = image_size
        self.patches = []
        self.labels = []
        self.coordinates = [] if use_coordinates else None
        
        # Load images and extract patches
        self._extract_patches()
        
    def _extract_patches(self):
        for img_path in self.image_paths:
            try:
                img = Image.open(img_path).convert('RGB')
                # Resize to standard size if needed
                if self.image_size:
                    img = img.resize((self.image_size, self.image_size))
                img_array = np.array(img) / 255.0  # Normalize to [0, 1]
                
                height, width, _ = img_array.shape
                
                # Extract 5x5 patches
                for i in range(2, height - 2):
                    for j in range(2, width - 2):
                        patch = img_array[i-2:i+3, j-2:j+3, :]  # 5x5 patch
                        center_pixel = img_array[i, j, :]  # Center pixel
                        
                        # Flatten the patch
                        patch_flat = patch.reshape(-1)
                        self.patches.append(patch_flat)
                        self.labels.append(center_pixel)
                        
                        # Store normalized coordinates if enabled
                        if self.use_coordinates:
                            # Normalize coordinates to [-1, 1] range
                            norm_i = (i / height) * 2 - 1  # -1 to 1
                            norm_j = (j / width) * 2 - 1   # -1 to 1
                            self.coordinates.append([norm_i, norm_j])
            except Exception as e:
                print(f"Error loading image {img_path}: {e}")
        
        self.patches = np.array(self.patches, dtype=np.float32)
        self.labels = np.array(self.labels, dtype=np.float32)
        
        if self.use_coordinates:
            self.coordinates = np.array(self.coordinates, dtype=np.float32)
        
        print(f"Extracted {len(self.patches)} patches")
        if self.use_coordinates:
            print(f"With coordinate information")
    
    def __len__(self):
        return len(self.patches)
    
    def __getitem__(self, idx):
        if self.use_coordinates:
            return (
                torch.tensor(self.patches[idx]), 
                torch.tensor(self.labels[idx]),
                torch.tensor(self.coordinates[idx])
            )
        else:
            return (
                torch.tensor(self.patches[idx]), 
                torch.tensor(self.labels[idx]),
                torch.zeros(2)  # Dummy coordinates
            )

# ==================== Image Generator ====================
class ImageGenerator:
    def __init__(self, model, patch_size=5, use_coordinates=False, image_size=32):
        self.model = model
        self.patch_size = patch_size
        self.use_coordinates = use_coordinates
        self.image_size = image_size
        self.half_size = patch_size // 2
        
    def _get_coordinates(self, i, j, height, width):
        """Get normalized coordinates for a pixel position"""
        norm_i = (i / height) * 2 - 1  # -1 to 1
        norm_j = (j / width) * 2 - 1   # -1 to 1
        return norm_i, norm_j
    
    def generate_image(self, initial_noise=None, size=32, steps=1, temperature=0.5):
        """Generate an image from noise"""
        with torch.no_grad():
            if initial_noise is None:
                # Generate random noise
                img = torch.rand(1, size, size, 3).to(device)
            else:
                img = initial_noise.clone().to(device)
            
            # Ensure image has batch dimension
            if len(img.shape) == 3:
                img = img.unsqueeze(0)
            
            batch_size, height, width, channels = img.shape
            
            # Generate image pixel by pixel
            for step in range(steps):
                # Create a copy to avoid in-place modifications
                new_img = img.clone()
                
                for i in range(self.half_size, height - self.half_size):
                    for j in range(self.half_size, width - self.half_size):
                        # Extract 5x5 patch
                        patch = img[:, i-self.half_size:i+self.half_size+1, 
                                     j-self.half_size:j+self.half_size+1, :]
                        
                        # Flatten patch
                        patch_flat = patch.reshape(batch_size, 1, -1)
                        
                        # Get coordinates if enabled
                        if self.use_coordinates:
                            norm_i, norm_j = self._get_coordinates(i, j, height, width)
                            coords = torch.tensor([[[norm_i, norm_j]]]).float().to(device)
                            coords = coords.repeat(batch_size, 1, 1)
                            # Predict center pixel with coordinates
                            pred, _, _ = self.model(patch_flat, coords)
                        else:
                            # Predict center pixel without coordinates
                            pred, _, _ = self.model(patch_flat)
                        
                        # Apply temperature scaling
                        pred = self._apply_temperature(pred, temperature)
                        
                        # Update pixel
                        new_img[:, i, j, :] = pred.reshape(batch_size, 3)
                
                img = new_img
            
            return img.squeeze(0).cpu().numpy()
    
    def _apply_temperature(self, pred, temperature):
        """Apply temperature scaling to predictions"""
        if temperature != 1.0:
            pred = torch.log(pred + 1e-8) / temperature
            pred = torch.softmax(pred * 10, dim=-1)  # Scale and softmax
        return pred
    
    def complete_image(self, partial_img, mask=None, steps=3, temperature=0.7):
        """Complete a partial image"""
        with torch.no_grad():
            img = torch.tensor(partial_img).float().to(device)
            if len(img.shape) == 3:
                img = img.unsqueeze(0)
            
            batch_size, height, width, channels = img.shape
            
            for step in range(steps):
                new_img = img.clone()
                
                for i in range(self.half_size, height - self.half_size):
                    for j in range(self.half_size, width - self.half_size):
                        # Only generate pixels in masked areas
                        if mask is None or mask[i, j] > 0.5:
                            patch = img[:, i-self.half_size:i+self.half_size+1, 
                                         j-self.half_size:j+self.half_size+1, :]
                            patch_flat = patch.reshape(batch_size, 1, -1)
                            
                            # Get coordinates if enabled
                            if self.use_coordinates:
                                norm_i, norm_j = self._get_coordinates(i, j, height, width)
                                coords = torch.tensor([[[norm_i, norm_j]]]).float().to(device)
                                coords = coords.repeat(batch_size, 1, 1)
                                pred, _, _ = self.model(patch_flat, coords)
                            else:
                                pred, _, _ = self.model(patch_flat)
                            
                            pred = self._apply_temperature(pred, temperature)
                            new_img[:, i, j, :] = pred.reshape(batch_size, 3)
                
                img = new_img
            
            return img.squeeze(0).cpu().numpy()

# ==================== GUI Application ====================
class ImageGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("GRU Image Generator with Spatial Coordinates")
        self.root.geometry("1200x850")
        
        # Initialize model and generator
        self.model = None
        self.generator = None
        self.train_dataset = None
        self.train_loader = None
        self.optimizer = None
        self.criterion = nn.MSELoss()
        
        # Training parameters
        self.epochs = 50
        self.batch_size = 64
        self.learning_rate = 0.001
        self.is_training = False
        self.current_epoch = 0
        
        # Image parameters
        self.generation_size = 32
        self.temperature = 0.7
        
        # Coordinate feature flag
        self.use_coordinates = tk.BooleanVar(value=False)
        
        # Queue for thread-safe GUI updates
        self.gui_queue = queue.Queue()
        
        # Setup GUI
        self.setup_gui()
        
        # Start queue processor
        self.process_queue()
    
    def setup_gui(self):
        # Create main frames
        control_frame = ttk.Frame(self.root, padding="10")
        control_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        image_frame = ttk.Frame(self.root, padding="10")
        image_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)
        image_frame.columnconfigure(0, weight=1)
        image_frame.columnconfigure(1, weight=1)
        image_frame.rowconfigure(0, weight=1)
        
        # ===== Control Frame =====
        # Training controls
        ttk.Label(control_frame, text="Training Controls", font=('Arial', 12, 'bold')).grid(row=0, column=0, columnspan=4, pady=(0, 10))
        
        ttk.Button(control_frame, text="Load Images", command=self.load_images).grid(row=1, column=0, padx=5, pady=5)
        ttk.Button(control_frame, text="Initialize Model", command=self.initialize_model).grid(row=1, column=1, padx=5, pady=5)
        ttk.Button(control_frame, text="Train Model", command=self.start_training).grid(row=1, column=2, padx=5, pady=5)
        ttk.Button(control_frame, text="Stop Training", command=self.stop_training).grid(row=1, column=3, padx=5, pady=5)
        
        # Coordinate feature checkbox
        ttk.Checkbutton(
            control_frame, 
            text="Use Spatial Coordinates", 
            variable=self.use_coordinates,
            command=self.on_coordinates_changed
        ).grid(row=1, column=4, padx=10, pady=5)
        
        # Training parameters
        ttk.Label(control_frame, text="Epochs:").grid(row=2, column=0, padx=5, pady=5)
        self.epochs_var = tk.StringVar(value="50")
        ttk.Entry(control_frame, textvariable=self.epochs_var, width=10).grid(row=2, column=1, padx=5, pady=5)
        
        ttk.Label(control_frame, text="Batch Size:").grid(row=2, column=2, padx=5, pady=5)
        self.batch_size_var = tk.StringVar(value="64")
        ttk.Entry(control_frame, textvariable=self.batch_size_var, width=10).grid(row=2, column=3, padx=5, pady=5)
        
        ttk.Label(control_frame, text="Learning Rate:").grid(row=2, column=4, padx=5, pady=5)
        self.lr_var = tk.StringVar(value="0.001")
        ttk.Entry(control_frame, textvariable=self.lr_var, width=10).grid(row=2, column=5, padx=5, pady=5)
        
        # Training progress
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(control_frame, variable=self.progress_var, maximum=100)
        self.progress_bar.grid(row=3, column=0, columnspan=6, sticky=(tk.W, tk.E), padx=5, pady=10)
        
        self.status_label = ttk.Label(control_frame, text="Ready")
        self.status_label.grid(row=4, column=0, columnspan=6, pady=5)
        
        # Coordinate info label
        self.coord_status = ttk.Label(control_frame, text="Spatial Coordinates: OFF", foreground="gray")
        self.coord_status.grid(row=5, column=0, columnspan=6, pady=2)
        
        # ===== Generation Controls =====
        ttk.Separator(control_frame, orient='horizontal').grid(row=6, column=0, columnspan=6, sticky=(tk.W, tk.E), pady=10)
        ttk.Label(control_frame, text="Generation Controls", font=('Arial', 12, 'bold')).grid(row=7, column=0, columnspan=3, pady=(0, 10))
        
        ttk.Button(control_frame, text="Generate Image", command=self.generate_image).grid(row=8, column=0, padx=5, pady=5)
        ttk.Button(control_frame, text="Generate from Noise", command=self.generate_from_noise).grid(row=8, column=1, padx=5, pady=5)
        ttk.Button(control_frame, text="Complete Image", command=self.complete_image).grid(row=8, column=2, padx=5, pady=5)
        
        ttk.Label(control_frame, text="Image Size:").grid(row=9, column=0, padx=5, pady=5)
        self.size_var = tk.StringVar(value="32")
        ttk.Entry(control_frame, textvariable=self.size_var, width=10).grid(row=9, column=1, padx=5, pady=5)
        
        ttk.Label(control_frame, text="Temperature:").grid(row=9, column=2, padx=5, pady=5)
        self.temp_var = tk.StringVar(value="0.7")
        ttk.Entry(control_frame, textvariable=self.temp_var, width=10).grid(row=9, column=3, padx=5, pady=5)
        
        ttk.Label(control_frame, text="Steps:").grid(row=9, column=4, padx=5, pady=5)
        self.steps_var = tk.StringVar(value="3")
        ttk.Entry(control_frame, textvariable=self.steps_var, width=10).grid(row=9, column=5, padx=5, pady=5)
        
        # Coordinate visualization checkbox
        self.show_coords = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            control_frame, 
            text="Visualize Coordinate Influence", 
            variable=self.show_coords
        ).grid(row=10, column=0, columnspan=2, padx=5, pady=5)
        
        # ===== Image Display Frame =====
        # Training image display
        train_frame = ttk.LabelFrame(image_frame, text="Training Images", padding="10")
        train_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5)
        
        self.train_canvas = tk.Canvas(train_frame, width=300, height=300, bg='white')
        self.train_canvas.grid(row=0, column=0, padx=5, pady=5)
        self.train_label = ttk.Label(train_frame, text="No training images loaded")
        self.train_label.grid(row=1, column=0)
        
        # Generated image display
        gen_frame = ttk.LabelFrame(image_frame, text="Generated Images", padding="10")
        gen_frame.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5)
        
        self.gen_canvas = tk.Canvas(gen_frame, width=300, height=300, bg='white')
        self.gen_canvas.grid(row=0, column=0, padx=5, pady=5)
        self.gen_label = ttk.Label(gen_frame, text="No generated images")
        self.gen_label.grid(row=1, column=0)
        
        # Loss plot
        loss_frame = ttk.LabelFrame(image_frame, text="Training Loss", padding="10")
        loss_frame.grid(row=0, column=2, sticky=(tk.W, tk.E, tk.N, tk.S), padx=5)
        
        self.figure, self.ax = plt.subplots(figsize=(4, 3))
        self.canvas = FigureCanvasTkAgg(self.figure, loss_frame)
        self.canvas.get_tk_widget().grid(row=0, column=0, padx=5, pady=5)
        self.ax.set_xlabel('Epoch')
        self.ax.set_ylabel('Loss')
        self.ax.set_title('Training Progress')
        self.losses = []
        
        # Configure weights for image frame
        image_frame.columnconfigure(0, weight=1)
        image_frame.columnconfigure(1, weight=1)
        image_frame.columnconfigure(2, weight=1)
        image_frame.rowconfigure(0, weight=1)
    
    def on_coordinates_changed(self):
        """Update coordinate status when checkbox is toggled"""
        if self.use_coordinates.get():
            self.coord_status.config(text="Spatial Coordinates: ON (Normalized -1 to 1)", foreground="green")
        else:
            self.coord_status.config(text="Spatial Coordinates: OFF", foreground="gray")
        
        # If model exists, reinitialize with new setting
        if self.model is not None:
            self.initialize_model()
    
    def process_queue(self):
        """Process messages from the queue for thread-safe GUI updates"""
        try:
            while True:
                msg = self.gui_queue.get_nowait()
                if msg[0] == 'update_status':
                    self.status_label.config(text=msg[1])
                elif msg[0] == 'update_progress':
                    self.progress_var.set(msg[1])
                elif msg[0] == 'update_loss':
                    self.losses.append(msg[1])
                    self.update_loss_plot()
                elif msg[0] == 'update_train_image':
                    self.update_train_image(msg[1])
                elif msg[0] == 'update_gen_image':
                    self.update_gen_image(msg[1])
                elif msg[0] == 'training_complete':
                    self.is_training = False
                    self.status_label.config(text=f"Training complete! Final loss: {msg[1]:.6f}")
                elif msg[0] == 'error':
                    messagebox.showerror("Error", msg[1])
        except queue.Empty:
            pass
        finally:
            self.root.after(100, self.process_queue)
    
    def update_loss_plot(self):
        """Update the loss plot"""
        self.ax.clear()
        self.ax.plot(self.losses, 'b-', linewidth=2)
        self.ax.set_xlabel('Epoch')
        self.ax.set_ylabel('Loss')
        self.ax.set_title('Training Progress')
        self.ax.grid(True, alpha=0.3)
        self.canvas.draw()
    
    def update_train_image(self, image_path):
        """Update the training image display"""
        try:
            img = Image.open(image_path)
            img.thumbnail((280, 280))
            photo = ImageTk.PhotoImage(img)
            self.train_canvas.create_image(150, 150, image=photo)
            self.train_canvas.image = photo
            self.train_label.config(text=os.path.basename(image_path))
            
            # If showing coordinate visualization, add coordinate grid
            if self.show_coords.get():
                self.visualize_coordinates_on_image(img)
        except Exception as e:
            print(f"Error loading training image: {e}")
    
    def visualize_coordinates_on_image(self, img):
        """Visualize coordinate grid on image"""
        try:
            # Create a copy to draw on
            img_copy = img.copy()
            draw = ImageDraw.Draw(img_copy)
            
            width, height = img_copy.size
            
            # Draw coordinate grid
            grid_size = 4
            for i in range(grid_size + 1):
                # Horizontal lines
                y = int(i * height / grid_size)
                draw.line([(0, y), (width, y)], fill='red', width=1)
                
                # Vertical lines
                x = int(i * width / grid_size)
                draw.line([(x, 0), (x, height)], fill='red', width=1)
            
            # Update display
            img_copy.thumbnail((280, 280))
            photo = ImageTk.PhotoImage(img_copy)
            self.train_canvas.create_image(150, 150, image=photo)
            self.train_canvas.image = photo
        except Exception as e:
            print(f"Error visualizing coordinates: {e}")
    
    def update_gen_image(self, img_array):
        """Update the generated image display"""
        try:
            # Convert numpy array to PIL Image
            img_array = (img_array * 255).astype(np.uint8)
            img = Image.fromarray(img_array)
            img.thumbnail((280, 280))
            photo = ImageTk.PhotoImage(img)
            self.gen_canvas.create_image(150, 150, image=photo)
            self.gen_canvas.image = photo
            
            # Add coordinate info to label
            coord_status = "with coordinates" if self.use_coordinates.get() else "without coordinates"
            self.gen_label.config(text=f"Generated {img_array.shape[0]}x{img_array.shape[1]} {coord_status}")
            
            # If showing coordinate visualization, add coordinate grid
            if self.show_coords.get():
                self.visualize_coordinates_on_generated(img_array)
        except Exception as e:
            print(f"Error displaying generated image: {e}")
    
    def visualize_coordinates_on_generated(self, img_array):
        """Visualize coordinate influence on generated image"""
        try:
            # Convert to PIL for drawing
            img = Image.fromarray(img_array)
            draw = ImageDraw.Draw(img)
            width, height = img.size
            
            # Draw coordinate grid
            grid_size = 4
            for i in range(grid_size + 1):
                # Normalized coordinate value (-1 to 1)
                norm_val = (i * 2 / grid_size) - 1
                
                # Horizontal lines
                y = int(i * height / grid_size)
                draw.line([(0, y), (width, y)], fill='yellow', width=2)
                draw.text((10, y-10), f"y={norm_val:.1f}", fill='yellow')
                
                # Vertical lines
                x = int(i * width / grid_size)
                draw.line([(x, 0), (x, height)], fill='yellow', width=2)
                draw.text((x+5, 10), f"x={norm_val:.1f}", fill='yellow')
            
            # Update display
            img.thumbnail((280, 280))
            photo = ImageTk.PhotoImage(img)
            self.gen_canvas.create_image(150, 150, image=photo)
            self.gen_canvas.image = photo
        except Exception as e:
            print(f"Error visualizing coordinate influence: {e}")
    
    def load_images(self):
        """Load training images"""
        file_paths = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.gif")]
        )
        
        if file_paths:
            try:
                self.gui_queue.put(('update_status', f"Loading {len(file_paths)} images..."))
                
                # Get image size for coordinate normalization
                img_size = int(self.size_var.get())
                
                # Create dataset with or without coordinates
                self.train_dataset = PatchDataset(
                    file_paths, 
                    use_coordinates=self.use_coordinates.get(),
                    image_size=img_size
                )
                self.train_loader = DataLoader(
                    self.train_dataset, 
                    batch_size=self.batch_size,
                    shuffle=True,
                    num_workers=0
                )
                
                # Show first image
                if file_paths:
                    self.gui_queue.put(('update_train_image', file_paths[0]))
                
                coord_text = "with coordinates" if self.use_coordinates.get() else "without coordinates"
                self.gui_queue.put(('update_status', f"Loaded {len(self.train_dataset)} patches {coord_text}"))
                
            except Exception as e:
                self.gui_queue.put(('error', f"Error loading images: {e}"))
    
    def initialize_model(self):
        """Initialize the GRU model"""
        try:
            use_coords = self.use_coordinates.get()
            img_size = int(self.size_var.get())
            
            self.model = GRUPixelPredictor(
                input_size=25,  # 5x5 patches
                hidden_size=128,
                output_size=3,
                num_layers=2,
                use_coordinates=use_coords,
                image_size=img_size
            ).to(device)
            
            self.generator = ImageGenerator(
                self.model, 
                use_coordinates=use_coords,
                image_size=img_size
            )
            self.optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
            
            coord_status = "with spatial coordinates" if use_coords else "without coordinates"
            self.gui_queue.put(('update_status', f"Model initialized {coord_status}"))
        except Exception as e:
            self.gui_queue.put(('error', f"Error initializing model: {e}"))
    
    def start_training(self):
        """Start training the model in a separate thread"""
        if self.model is None:
            messagebox.showwarning("Warning", "Please initialize the model first")
            return
        
        if self.train_loader is None:
            messagebox.showwarning("Warning", "Please load training images first")
            return
        
        if self.is_training:
            return
        
        # Get training parameters
        try:
            self.epochs = int(self.epochs_var.get())
            self.batch_size = int(self.batch_size_var.get())
            self.learning_rate = float(self.lr_var.get())
            
            # Update optimizer
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = self.learning_rate
        except ValueError:
            self.gui_queue.put(('error', "Invalid training parameters"))
            return
        
        # Start training thread
        self.is_training = True
        self.current_epoch = 0
        self.losses.clear()
        
        thread = threading.Thread(target=self.train_model)
        thread.daemon = True
        thread.start()
    
    def train_model(self):
        """Train the model"""
        try:
            use_coords = self.use_coordinates.get()
            coord_text = "with coordinates" if use_coords else "without coordinates"
            self.gui_queue.put(('update_status', f"Starting training {coord_text}..."))
            
            for epoch in range(self.epochs):
                if not self.is_training:
                    break
                
                self.current_epoch = epoch
                epoch_loss = 0.0
                batch_count = 0
                
                self.model.train()
                
                for batch_idx, batch_data in enumerate(self.train_loader):
                    if not self.is_training:
                        break
                    
                    # Unpack batch data
                    if use_coords:
                        patches, labels, coords = batch_data
                        patches = patches.to(device).unsqueeze(1)  # Add sequence dimension
                        labels = labels.to(device)
                        coords = coords.to(device).unsqueeze(1)  # Add sequence dimension
                        
                        # Forward pass with coordinates
                        outputs, _, _ = self.model(patches, coords)
                    else:
                        patches, labels, _ = batch_data
                        patches = patches.to(device).unsqueeze(1)
                        labels = labels.to(device)
                        
                        # Forward pass without coordinates
                        outputs, _, _ = self.model(patches)
                    
                    loss = self.criterion(outputs.squeeze(), labels)
                    
                    # Backward pass and optimize
                    self.optimizer.zero_grad()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                    self.optimizer.step()
                    
                    epoch_loss += loss.item()
                    batch_count += 1
                    
                    # Update progress
                    progress = ((epoch * len(self.train_loader) + batch_idx + 1) / 
                               (self.epochs * len(self.train_loader))) * 100
                    self.gui_queue.put(('update_progress', progress))
                
                avg_loss = epoch_loss / batch_count if batch_count > 0 else 0
                self.gui_queue.put(('update_loss', avg_loss))
                self.gui_queue.put(('update_status', f"Epoch [{epoch+1}/{self.epochs}], Loss: {avg_loss:.6f}"))
                
                # Generate a sample image every few epochs
                if (epoch + 1) % 5 == 0:
                    self.generate_sample_image()
            
            self.gui_queue.put(('training_complete', avg_loss if 'avg_loss' in locals() else 0))
            
        except Exception as e:
            self.gui_queue.put(('error', f"Training error: {e}"))
            self.is_training = False
    
    def stop_training(self):
        """Stop training"""
        self.is_training = False
        self.gui_queue.put(('update_status', "Training stopped"))
    
    def generate_sample_image(self):
        """Generate a sample image during training"""
        try:
            if self.generator is not None:
                # Generate from random noise
                size = int(self.size_var.get())
                noise = torch.rand(1, size, size, 3).to(device)
                generated = self.generator.generate_image(
                    initial_noise=noise,
                    size=size,
                    steps=1,
                    temperature=self.temperature
                )
                self.gui_queue.put(('update_gen_image', generated))
        except Exception as e:
            print(f"Error generating sample: {e}")
    
    def generate_image(self):
        """Generate an image using the trained model"""
        if self.generator is None:
            messagebox.showwarning("Warning", "Please initialize the model first")
            return
        
        try:
            self.gui_queue.put(('update_status', "Generating image..."))
            
            # Get generation parameters
            size = int(self.size_var.get())
            steps = int(self.steps_var.get())
            temperature = float(self.temp_var.get())
            
            # Generate from random noise
            noise = torch.rand(1, size, size, 3).to(device)
            generated = self.generator.generate_image(
                initial_noise=noise,
                size=size,
                steps=steps,
                temperature=temperature
            )
            
            self.gui_queue.put(('update_gen_image', generated))
            coord_text = "with coordinates" if self.use_coordinates.get() else "without coordinates"
            self.gui_queue.put(('update_status', f"Generated {size}x{size} image {coord_text}"))
            
        except Exception as e:
            self.gui_queue.put(('error', f"Error generating image: {e}"))
    
    def generate_from_noise(self):
        """Generate an image from pure noise"""
        if self.generator is None:
            messagebox.showwarning("Warning", "Please initialize the model first")
            return
        
        try:
            self.gui_queue.put(('update_status', "Generating from noise..."))
            
            size = int(self.size_var.get())
            steps = int(self.steps_var.get())
            temperature = float(self.temp_var.get())
            
            # Generate from noise (no initial image)
            generated = self.generator.generate_image(
                initial_noise=None,
                size=size,
                steps=steps,
                temperature=temperature
            )
            
            self.gui_queue.put(('update_gen_image', generated))
            coord_text = "with coordinates" if self.use_coordinates.get() else "without coordinates"
            self.gui_queue.put(('update_status', f"Generated from noise {coord_text}"))
            
        except Exception as e:
            self.gui_queue.put(('error', f"Error generating from noise: {e}"))
    
    def complete_image(self):
        """Complete a partial image"""
        if self.generator is None:
            messagebox.showwarning("Warning", "Please initialize the model first")
            return
        
        try:
            # Load an image to complete
            file_path = filedialog.askopenfilename(
                title="Select image to complete",
                filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.gif")]
            )
            
            if not file_path:
                return
            
            self.gui_queue.put(('update_status', "Completing image..."))
            
            # Get image size
            size = int(self.size_var.get())
            
            # Load and preprocess image
            img = Image.open(file_path).convert('RGB')
            img = img.resize((size, size))
            img_array = np.array(img) / 255.0
            
            # Create a mask (for example, mask out the center)
            mask = np.ones((size, size))
            center = size // 2
            mask_size = size // 4
            mask[center-mask_size:center+mask_size, center-mask_size:center+mask_size] = 0
            
            steps = int(self.steps_var.get())
            temperature = float(self.temp_var.get())
            
            # Complete the image
            completed = self.generator.complete_image(
                partial_img=img_array,
                mask=mask,
                steps=steps,
                temperature=temperature
            )
            
            self.gui_queue.put(('update_gen_image', completed))
            coord_text = "with coordinates" if self.use_coordinates.get() else "without coordinates"
            self.gui_queue.put(('update_status', f"Image completed {coord_text}"))
            
        except Exception as e:
            self.gui_queue.put(('error', f"Error completing image: {e}"))

# Import ImageDraw for coordinate visualization
from PIL import ImageDraw

# ==================== Main ====================
if __name__ == "__main__":
    root = tk.Tk()
    app = ImageGeneratorApp(root)
    
    # Set window icon and title
    root.title("GRU Image Generator with Spatial Coordinates")
    
    # Run the application
    root.mainloop()