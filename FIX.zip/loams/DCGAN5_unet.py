import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk, ImageDraw, ImageFont
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path

# ==================== Enhanced DCGAN with U-Net Refinement ====================

class EnhancedDCGAN:
    def __init__(self, image_size=32, latent_dim=100, ngf=64, ndf=64):
        self.image_size = image_size
        self.latent_dim = latent_dim
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # 1. Generator (same as before)
        class Generator(nn.Module):
            def __init__(self, latent_dim, ngf):
                super().__init__()
                self.main = nn.Sequential(
                    nn.ConvTranspose2d(latent_dim, ngf * 4, 4, 1, 0, bias=False),
                    nn.BatchNorm2d(ngf * 4),
                    nn.ReLU(True),
                    nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf * 2),
                    nn.ReLU(True),
                    nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf),
                    nn.ReLU(True),
                    nn.ConvTranspose2d(ngf, 3, 4, 2, 1, bias=False),
                    nn.Tanh()
                )
                
            def forward(self, x):
                return self.main(x)
        
        # 2. U-Net Refinement Network
        class UNetRefiner(nn.Module):
            def __init__(self, in_channels=3, out_channels=3, features=32):
                super().__init__()
                
                # Encoder (downsampling)
                self.enc1 = self.block(in_channels, features)
                self.enc2 = self.block(features, features * 2)
                self.enc3 = self.block(features * 2, features * 4)
                
                # Bottleneck
                self.bottleneck = self.block(features * 4, features * 8)
                
                # Decoder (upsampling)
                self.upconv3 = nn.ConvTranspose2d(features * 8, features * 4, 2, 2)
                self.dec3 = self.block(features * 8, features * 4)
                
                self.upconv2 = nn.ConvTranspose2d(features * 4, features * 2, 2, 2)
                self.dec2 = self.block(features * 4, features * 2)
                
                self.upconv1 = nn.ConvTranspose2d(features * 2, features, 2, 2)
                self.dec1 = self.block(features * 2, features)
                
                # Final output
                self.final = nn.Conv2d(features, out_channels, 1)
                
            def block(self, in_channels, out_channels):
                return nn.Sequential(
                    nn.Conv2d(in_channels, out_channels, 3, padding=1),
                    nn.BatchNorm2d(out_channels),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(out_channels, out_channels, 3, padding=1),
                    nn.BatchNorm2d(out_channels),
                    nn.LeakyReLU(0.2, inplace=True)
                )
            
            def forward(self, x):
                # Store input for residual connection
                x_input = x
                
                # Encoder
                enc1 = self.enc1(x)
                enc2 = self.enc2(nn.MaxPool2d(2)(enc1))
                enc3 = self.enc3(nn.MaxPool2d(2)(enc2))
                
                # Bottleneck
                bottleneck = self.bottleneck(nn.MaxPool2d(2)(enc3))
                
                # Decoder with skip connections
                dec3 = self.upconv3(bottleneck)
                dec3 = torch.cat((dec3, enc3), dim=1)
                dec3 = self.dec3(dec3)
                
                dec2 = self.upconv2(dec3)
                dec2 = torch.cat((dec2, enc2), dim=1)
                dec2 = self.dec2(dec2)
                
                dec1 = self.upconv1(dec2)
                dec1 = torch.cat((dec1, enc1), dim=1)
                dec1 = self.dec1(dec1)
                
                # Final output with residual connection
                refinement = self.final(dec1)
                return torch.tanh(refinement + x_input)
        
        # 3. Discriminator
        class Discriminator(nn.Module):
            def __init__(self, image_size, ndf):
                super().__init__()
                self.main = nn.Sequential(
                    nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 2),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 4),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False),
                )
                
            def forward(self, x):
                return self.main(x).view(-1, 1)
        
        self.generator = Generator(latent_dim, ngf)
        self.refiner = UNetRefiner()
        self.discriminator = Discriminator(image_size, ndf)
        
        # Loss functions
        self.criterion = nn.BCEWithLogitsLoss()
        self.refinement_criterion = nn.MSELoss()
        self.perceptual_weight = 0.1  # How much to preserve original content
        
        # Three optimizers
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerR = optim.Adam(self.refiner.parameters(), lr=0.0001, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.generator.to(self.device)
        self.refiner.to(self.device)
        self.discriminator.to(self.device)
    
    def generate(self, noise, refine=True):
        """Generate images, optionally refine them"""
        base_images = self.generator(noise)
        if refine:
            refined_images = self.refiner(base_images)
            return base_images, refined_images
        return base_images, base_images  # Return same for both

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class DCGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Enhanced DCGAN with U-Net Refiner")
        self.root.geometry("1200x800")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings - added refinement weight
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_dim': tk.IntVar(value=100),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
            'generate_interval': tk.IntVar(value=5),
            'refinement_weight': tk.DoubleVar(value=0.1)
        }
        
        # For storing generated images (base and refined)
        self.base_images = []
        self.refined_images = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training (enhanced with dual display)
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Enhanced Training')
        self.setup_enhanced_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate Grid
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate Grid')
        self.setup_generate_tab()
        
        # Tab 4: U-Net Refinement
        self.refine_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.refine_tab, text='U-Net Refinement')
        self.setup_refine_tab()

    def setup_enhanced_training_tab(self):
        # Main container
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Enhanced DCGAN with U-Net", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text="Image Size: 32x32")
        self.size_display.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize Enhanced GAN", 
                 command=self.initialize_enhanced_gan, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_enhanced_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Comparison", 
                 command=self.generate_comparison, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Enhanced Model", 
                 command=self.save_enhanced_model, width=20).pack(pady=5)
        
        # Right panel - Dual Preview
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Comparison display
        preview_frame = tk.LabelFrame(right_frame, text="Generator vs Refiner Comparison", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Two side-by-side image displays
        dual_frame = tk.Frame(preview_frame)
        dual_frame.pack(pady=10)
        
        # Base image (Generator output)
        base_frame = tk.LabelFrame(dual_frame, text="Base Image", padx=10, pady=10)
        base_frame.pack(side=tk.LEFT, padx=10)
        
        self.base_image_frame = tk.Frame(base_frame, width=200, height=200, bg='gray')
        self.base_image_frame.pack()
        self.base_image_frame.pack_propagate(False)
        
        self.base_image_label = tk.Label(self.base_image_frame, text="No base image", bg='gray')
        self.base_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Refined image (U-Net output)
        refined_frame = tk.LabelFrame(dual_frame, text="Refined Image", padx=10, pady=10)
        refined_frame.pack(side=tk.LEFT, padx=10)
        
        self.refined_image_frame = tk.Frame(refined_frame, width=200, height=200, bg='gray')
        self.refined_image_frame.pack()
        self.refined_image_frame.pack_propagate(False)
        
        self.refined_image_label = tk.Label(self.refined_image_frame, text="No refined image", bg='gray')
        self.refined_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="DCGAN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar for many settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Image size - Fixed to 32x32
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed)", width=20, anchor='w').pack(side=tk.LEFT, padx=5)
        
        # Other network parameters
        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 10, 500),
            ("Generator Features (ngf):", 'ngf', 32, 256),
            ("Discriminator Features (ndf):", 'ndf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 128),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Refinement Weight:", 'refinement_weight', 0.01, 1.0),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset to Paper", 
                 command=self.reset_to_paper, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        """Simple grid generation tab"""
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Grid Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Label(gen_frame, text="Use Refinement:").pack(pady=5)
        self.use_refinement = tk.BooleanVar(value=True)
        tk.Checkbutton(gen_frame, variable=self.use_refinement).pack()
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_refine_tab(self):
        """New tab for U-Net refinement operations"""
        main_frame = tk.Frame(self.refine_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="U-Net Image Refinement", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Input selection
        input_frame = tk.LabelFrame(main_frame, text="Input Source", padx=10, pady=10)
        input_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Radio buttons for input type
        self.refine_source = tk.StringVar(value="noise")
        
        tk.Radiobutton(input_frame, text="Generate from Noise", 
                      variable=self.refine_source, value="noise").pack(anchor='w', pady=5)
        tk.Radiobutton(input_frame, text="Load Custom Image", 
                      variable=self.refine_source, value="image").pack(anchor='w', pady=5)
        tk.Radiobutton(input_frame, text="Use Refined as Output", 
                      variable=self.refine_source, value="recursive").pack(anchor='w', pady=5)
        
        # Controls frame
        controls_frame = tk.Frame(input_frame)
        controls_frame.pack(fill=tk.X, pady=10)
        
        tk.Label(controls_frame, text="Number of images:").pack(side=tk.LEFT, padx=5)
        self.refine_num_var = tk.IntVar(value=4)
        tk.Scale(controls_frame, from_=1, to=16, variable=self.refine_num_var, 
                orient=tk.HORIZONTAL, length=150).pack(side=tk.LEFT, padx=5)
        
        tk.Label(controls_frame, text="Recursive steps:").pack(side=tk.LEFT, padx=5)
        self.recursive_steps = tk.IntVar(value=3)
        tk.Scale(controls_frame, from_=1, to=10, variable=self.recursive_steps, 
                orient=tk.HORIZONTAL, length=150).pack(side=tk.LEFT, padx=5)
        
        # Buttons
        btn_frame = tk.Frame(input_frame)
        btn_frame.pack(pady=10)
        
        tk.Button(btn_frame, text="Load Image", 
                 command=self.load_custom_image, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Generate & Refine", 
                 command=self.run_refinement, width=15, bg="lightblue").pack(side=tk.LEFT, padx=5)
        
        # Display area for refined images
        display_frame = tk.LabelFrame(main_frame, text="Refinement Results", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create canvas with scrollbar
        self.refine_canvas = tk.Canvas(display_frame, bg='white')
        scrollbar = tk.Scrollbar(display_frame, orient="vertical", command=self.refine_canvas.yview)
        self.refine_scroll_frame = tk.Frame(self.refine_canvas)
        
        self.refine_scroll_frame.bind(
            "<Configure>",
            lambda e: self.refine_canvas.configure(scrollregion=self.refine_canvas.bbox("all"))
        )
        
        self.refine_canvas.create_window((0, 0), window=self.refine_scroll_frame, anchor="nw")
        self.refine_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.refine_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Store loaded custom image
        self.custom_image = None

    def update_size_display(self):
        """Update image size display in training tab"""
        # Fixed to 32x32
        self.size_display.config(text="Image Size: 32x32")

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                # Add to log
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                
                # Update status with first line
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                
                print(message)  # Also print to console
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_enhanced_gan(self):
        """Initialize Enhanced DCGAN with U-Net"""
        try:
            image_size = self.settings['image_size'].get()
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            
            self.gan = EnhancedDCGAN(
                image_size=image_size,
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf
            )
            
            self.log_message("=== Enhanced DCGAN Initialized ===")
            self.log_message(f"Architecture: Generator -> U-Net Refiner -> Discriminator")
            self.log_message(f"Image Size: {image_size}x{image_size}")
            self.log_message(f"Latent dim: {latent_dim}, G features: {ngf}, D features: {ndf}")
            self.log_message(f"Refinement weight: {self.settings['refinement_weight'].get()}")
            
        except Exception as e:
            self.log_message(f"Error initializing Enhanced GAN: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_enhanced_training(self):
        """Start enhanced training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            refine_weight = self.settings['refinement_weight'].get()
            
            # Update optimizers
            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            for param_group in self.gan.optimizerR.param_groups:
                param_group['lr'] = lr * 0.5  # Lower LR for refiner
                param_group['betas'] = (beta1, 0.999)
            
            for param_group in self.gan.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Update refinement weight
            self.gan.perceptual_weight = refine_weight
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_enhanced_gan,
                args=(epochs, batch_size, num_workers),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"=== Started Enhanced Training ===")
            self.log_message(f"Epochs: {epochs}, Batch size: {batch_size}")
            self.log_message(f"Learning rates - G: {lr}, R: {lr*0.5}, D: {lr}")
            self.log_message(f"Refinement weight: {refine_weight}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_enhanced_gan(self, epochs, batch_size, num_workers):
        """Enhanced training loop with U-Net"""
        try:
            image_size = self.settings['image_size'].get()
            generate_interval = self.settings['generate_interval'].get()
            
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available()
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                total_loss_r = 0
                batch_count = 0
                
                for real_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # ===== Train Discriminator =====
                    self.gan.optimizerD.zero_grad()
                    
                    # Real images
                    real_labels = torch.ones(batch_size_actual, 1, device=self.gan.device)
                    output_real = self.gan.discriminator(real_images)
                    loss_real = self.gan.criterion(output_real, real_labels)
                    
                    # Fake images (generated + refined)
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, 1, 1, device=self.gan.device)
                    base_fakes, refined_fakes = self.gan.generate(noise, refine=True)
                    
                    fake_labels = torch.zeros(batch_size_actual, 1, device=self.gan.device)
                    output_fake = self.gan.discriminator(refined_fakes.detach())
                    loss_fake = self.gan.criterion(output_fake, fake_labels)
                    
                    loss_d = (loss_real + loss_fake) / 2
                    loss_d.backward()
                    self.gan.optimizerD.step()
                    
                    # ===== Train Generator & Refiner =====
                    self.gan.optimizerG.zero_grad()
                    self.gan.optimizerR.zero_grad()
                    
                    # Generate again
                    base_fakes = self.gan.generator(noise)
                    refined_fakes = self.gan.refiner(base_fakes)
                    
                    # Adversarial loss (fool discriminator)
                    output_fake = self.gan.discriminator(refined_fakes)
                    loss_g_adv = self.gan.criterion(output_fake, real_labels)
                    
                    # Refinement content loss (preserve base image)
                    loss_r_content = self.gan.refinement_criterion(refined_fakes, base_fakes)
                    
                    # Total loss
                    loss_g_total = loss_g_adv + (self.gan.perceptual_weight * loss_r_content)
                    loss_g_total.backward()
                    
                    self.gan.optimizerG.step()
                    self.gan.optimizerR.step()
                    
                    # Track losses
                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g_adv.item()
                    total_loss_r += loss_r_content.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    avg_loss_r = total_loss_r / batch_count
                    
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"D Loss: {avg_loss_d:.4f} | "
                                   f"G Adv Loss: {avg_loss_g:.4f} | "
                                   f"R Content Loss: {avg_loss_r:.4f} | "
                                   f"Time: {elapsed:.1f}s")
                    
                    # Generate comparison at interval
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_comparison()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("=== Enhanced Training Completed! ===")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_comparison(self):
        """Generate and display base vs refined images"""
        if not self.gan:
            return
        
        try:
            with torch.no_grad():
                # Generate 1 image pair
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                base_img, refined_img = self.gan.generate(noise, refine=True)
                
                # Convert to PIL
                base_pil = self.tensor_to_pil(base_img[0].cpu())
                refined_pil = self.tensor_to_pil(refined_img[0].cpu())
                
                # Resize for display
                base_display = base_pil.resize((200, 200), Image.Resampling.NEAREST)
                refined_display = refined_pil.resize((200, 200), Image.Resampling.NEAREST)
                
                # Convert to PhotoImage
                base_photo = ImageTk.PhotoImage(base_display)
                refined_photo = ImageTk.PhotoImage(refined_display)
                
                # Update displays
                self.base_image_label.config(image=base_photo, text="")
                self.base_image_label.image = base_photo
                
                self.refined_image_label.config(image=refined_photo, text="")
                self.refined_image_label.image = refined_photo
                
                # Store
                self.base_images.append(base_pil)
                self.refined_images.append(refined_pil)
                
                self.log_message(f"Generated comparison at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error generating comparison: {str(e)}")

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        img = (tensor + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def save_enhanced_model(self):
        """Save enhanced model with all three networks"""
        if not self.gan:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'refiner_state_dict': self.gan.refiner.state_dict(),
                    'discriminator_state_dict': self.gan.discriminator.state_dict(),
                    'optimizerG_state_dict': self.gan.optimizerG.state_dict(),
                    'optimizerR_state_dict': self.gan.optimizerR.state_dict(),
                    'optimizerD_state_dict': self.gan.optimizerD.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                    'refinement_weight': self.settings['refinement_weight'].get(),
                }, filename)
                
                self.log_message(f"Enhanced model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_custom_image(self):
        """Load custom image for refinement"""
        file = filedialog.askopenfilename(
            title="Select image to refine",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if file:
            try:
                img = Image.open(file).convert('RGB')
                # Resize to model size
                img_size = self.settings['image_size'].get()
                img = img.resize((img_size, img_size), Image.Resampling.LANCZOS)
                self.custom_image = img
                self.log_message(f"Loaded custom image: {os.path.basename(file)}")
                self.log_message(f"Image size: {img.size}")
            except Exception as e:
                self.log_message(f"Error loading image: {str(e)}")

    def run_refinement(self):
        """Run U-Net refinement based on selected source"""
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        source_type = self.refine_source.get()
        num_images = self.refine_num_var.get()
        
        try:
            with torch.no_grad():
                if source_type == "noise":
                    # Generate from random noise
                    noise = torch.randn(num_images, self.gan.latent_dim, 1, 1).to(self.gan.device)
                    base_imgs, refined_imgs = self.gan.generate(noise, refine=True)
                    title = "Generated from Noise"
                    
                elif source_type == "image" and self.custom_image:
                    # Refine custom image
                    transform = transforms.Compose([
                        transforms.ToTensor(),
                        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
                    ])
                    
                    img_tensor = transform(self.custom_image).unsqueeze(0).to(self.gan.device)
                    # Repeat for multiple images
                    img_tensor = img_tensor.repeat(num_images, 1, 1, 1)
                    
                    # Use refiner directly on the image
                    base_imgs = img_tensor
                    refined_imgs = self.gan.refiner(img_tensor)
                    title = f"Refined: {os.path.basename('custom_image.png')}"
                    
                elif source_type == "recursive":
                    # Recursive refinement
                    noise = torch.randn(num_images, self.gan.latent_dim, 1, 1).to(self.gan.device)
                    current_imgs = self.gan.generator(noise)
                    
                    steps = self.recursive_steps.get()
                    for step in range(steps):
                        current_imgs = self.gan.refiner(current_imgs)
                    
                    base_imgs = self.gan.generator(noise)
                    refined_imgs = current_imgs
                    title = f"Recursive Refinement ({steps} steps)"
                    
                else:
                    self.log_message("Error: No valid input source!")
                    return
                
                # Display results
                self.display_refinement_results(base_imgs.cpu(), refined_imgs.cpu(), title)
                self.log_message(f"Refinement completed: {title}")
                
        except Exception as e:
            self.log_message(f"Error during refinement: {str(e)}")
            import traceback
            traceback.print_exc()

    def display_refinement_results(self, base_tensors, refined_tensors, title):
        """Display base and refined images in a grid"""
        # Clear previous images
        for widget in self.refine_scroll_frame.winfo_children():
            widget.destroy()
        
        # Add title
        tk.Label(self.refine_scroll_frame, text=title, 
                font=("Arial", 12, "bold")).pack(pady=10)
        
        num_images = base_tensors.size(0)
        cols = 4
        rows = (num_images * 2 + cols - 1) // cols  # *2 for base+refined
        
        for i in range(0, rows, 2):
            row_frame_base = tk.Frame(self.refine_scroll_frame)
            row_frame_base.pack(pady=5)
            
            row_frame_refined = tk.Frame(self.refine_scroll_frame)
            row_frame_refined.pack(pady=5)
            
            # Base images row
            tk.Label(row_frame_base, text="Base:", font=("Arial", 10)).pack(side=tk.LEFT, padx=5)
            for j in range(cols):
                idx = (i//2) * cols + j
                if idx < num_images:
                    base_img = self.tensor_to_pil(base_tensors[idx])
                    base_display = base_img.resize((100, 100), Image.Resampling.NEAREST)
                    base_photo = ImageTk.PhotoImage(base_display)
                    
                    label = tk.Label(row_frame_base, image=base_photo)
                    label.image = base_photo
                    label.pack(side=tk.LEFT, padx=2)
            
            # Refined images row
            tk.Label(row_frame_refined, text="Refined:", font=("Arial", 10)).pack(side=tk.LEFT, padx=5)
            for j in range(cols):
                idx = (i//2) * cols + j
                if idx < num_images:
                    refined_img = self.tensor_to_pil(refined_tensors[idx])
                    refined_display = refined_img.resize((100, 100), Image.Resampling.NEAREST)
                    refined_photo = ImageTk.PhotoImage(refined_display)
                    
                    label = tk.Label(row_frame_refined, image=refined_photo)
                    label.image = refined_photo
                    label.pack(side=tk.LEFT, padx=2)

    def generate_grid(self):
        """Generate a grid of images"""
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            use_refine = self.use_refinement.get()
            
            with torch.no_grad():
                noise = torch.randn(num_images, self.gan.latent_dim, 1, 1).to(self.gan.device)
                if use_refine:
                    _, generated = self.gan.generate(noise, refine=True)
                else:
                    generated, _ = self.gan.generate(noise, refine=False)
            
            # Clear previous images
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            # Create grid
            cols = 4
            rows = (num_images + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_tensor = generated[idx]
                        img = self.tensor_to_pil(img_tensor)
                        
                        # Resize for display using NEAREST
                        img_display = img.resize((128, 128), Image.Resampling.NEAREST)
                        
                        photo = ImageTk.PhotoImage(img_display)
                        
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            
            self.log_message(f"Generated {num_images} images in grid (Refinement: {use_refine})")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('dcgan_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            import json
            if os.path.exists('dcgan_defaults.json'):
                with open('dcgan_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.update_size_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_to_paper(self):
        """Reset to DCGAN paper settings"""
        paper_settings = {
            'image_size': 32,
            'latent_dim': 100,
            'ngf': 64,
            'ndf': 64,
            'batch_size': 128,
            'learning_rate': 0.0002,
            'beta1': 0.5,
            'num_workers': min(4, multiprocessing.cpu_count()),
            'save_interval': 10,
            'generate_interval': 5,
            'refinement_weight': 0.1
        }
        
        for key, value in paper_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        
        self.update_size_display()
        self.log_message("Reset to DCGAN paper settings with refinement")

# ==================== Main ====================

if __name__ == "__main__":
    print("=== Enhanced DCGAN with U-Net Refiner ===")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = DCGANApp(root)
    root.mainloop()