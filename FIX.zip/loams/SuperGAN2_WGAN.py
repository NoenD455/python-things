import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import traceback
import random
import numpy as np
import math

# ==================== WGAN-GP (IMPROVED Architecture) ====================

class BigWGAN_GP:
    def __init__(self, image_size=64, latent_dim=350, use_skip=True, base_channels=128):
        self.image_size = image_size
        self.latent_dim = latent_dim
        self.use_skip = use_skip
        self.base_channels = base_channels
        self.gp_weight = 10.0  # Gradient penalty weight
        
        # CPU optimizations
        if torch.cuda.is_available():
            self.device = torch.device("cuda")
        else:
            self.device = torch.device("cpu")
            # CPU optimization settings
            torch.set_num_threads(4)
            os.environ['OMP_NUM_THREADS'] = '4'
            os.environ['MKL_NUM_THREADS'] = '4'
        
        # Generator (same as before)
        class Generator(nn.Module):
            def __init__(self, image_size, latent_dim, use_skip=True, base_channels=128):
                super().__init__()
                self.image_size = image_size
                self.use_skip = use_skip
                self.base_channels = base_channels
                
                if image_size == 64:
                    self.projection = nn.Sequential(
                        nn.Linear(latent_dim, base_channels * 8 * 4 * 4),
                        nn.ReLU(True),
                        nn.Dropout(0.1)
                    )
                    
                    self.block1 = UpsampleBlock(base_channels * 8, base_channels * 4, use_skip)
                    self.block2 = UpsampleBlock(base_channels * 4, base_channels * 2, use_skip)
                    self.block3 = UpsampleBlock(base_channels * 2, base_channels, use_skip)
                    self.block4 = UpsampleBlock(base_channels, base_channels // 2, use_skip)
                    
                    self.final = nn.Sequential(
                        nn.Conv2d(base_channels // 2, base_channels // 2, 3, padding=1, padding_mode='replicate'),
                        nn.BatchNorm2d(base_channels // 2),
                        nn.ReLU(True),
                        nn.Conv2d(base_channels // 2, base_channels // 4, 3, padding=1, padding_mode='replicate'),
                        nn.BatchNorm2d(base_channels // 4),
                        nn.ReLU(True),
                        nn.Conv2d(base_channels // 4, 3, 3, padding=1, padding_mode='replicate'),
                        nn.Tanh()
                    )
                    
                else:  # 32x32
                    self.projection = nn.Sequential(
                        nn.Linear(latent_dim, base_channels * 4 * 4 * 4),
                        nn.ReLU(True),
                        nn.Dropout(0.1)
                    )
                    
                    self.block1 = UpsampleBlock(base_channels * 4, base_channels * 2, use_skip)
                    self.block2 = UpsampleBlock(base_channels * 2, base_channels, use_skip)
                    self.block3 = UpsampleBlock(base_channels, base_channels // 2, use_skip)
                    
                    self.final = nn.Sequential(
                        nn.Conv2d(base_channels // 2, base_channels // 2, 3, padding=1, padding_mode='replicate'),
                        nn.BatchNorm2d(base_channels // 2),
                        nn.ReLU(True),
                        nn.Conv2d(base_channels // 2, 3, 3, padding=1, padding_mode='replicate'),
                        nn.Tanh()
                    )
                
            def forward(self, x):
                batch_size = x.size(0)
                x = self.projection(x)
                
                if self.image_size == 64:
                    x = x.view(-1, self.base_channels * 8, 4, 4)
                    x = self.block1(x)
                    x = self.block2(x)
                    x = self.block3(x)
                    x = self.block4(x)
                else:
                    x = x.view(-1, self.base_channels * 4, 4, 4)
                    x = self.block1(x)
                    x = self.block2(x)
                    x = self.block3(x)
                
                return self.final(x)
        
        # Upsample block
        class UpsampleBlock(nn.Module):
            def __init__(self, in_channels, out_channels, use_skip=True):
                super().__init__()
                self.use_skip = use_skip
                
                self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
                
                self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1, padding_mode='replicate')
                self.bn1 = nn.BatchNorm2d(out_channels)
                self.relu1 = nn.ReLU(True)
                
                self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1, padding_mode='replicate')
                self.bn2 = nn.BatchNorm2d(out_channels)
                
                if use_skip and in_channels != out_channels:
                    self.skip_conv = nn.Conv2d(in_channels, out_channels, 1)
                elif use_skip:
                    self.skip_conv = nn.Identity()
                else:
                    self.skip_conv = None
                
                self.relu2 = nn.ReLU(True)
                self.dropout = nn.Dropout2d(0.1)
            
            def forward(self, x):
                residual = x
                
                x = self.upsample(x)
                
                x = self.conv1(x)
                x = self.bn1(x)
                x = self.relu1(x)
                
                x = self.conv2(x)
                x = self.bn2(x)
                
                if self.use_skip and self.skip_conv is not None:
                    residual = self.upsample(residual)
                    if not isinstance(self.skip_conv, nn.Identity):
                        residual = self.skip_conv(residual)
                    x = x + residual
                
                x = self.relu2(x)
                x = self.dropout(x)
                return x
        
        # Critic (Discriminator for WGAN-GP) - NO SIGMOID
        class Critic(nn.Module):
            def __init__(self, image_size, base_channels=128):
                super().__init__()
                
                def conv_block(in_c, out_c, kernel=4, stride=2, padding=1, use_norm=True):
                    layers = [
                        nn.Conv2d(in_c, out_c, kernel, stride=stride, padding=padding, padding_mode='replicate')
                    ]
                    if use_norm:
                        layers.append(nn.BatchNorm2d(out_c))
                    layers.append(nn.LeakyReLU(0.2, inplace=True))
                    layers.append(nn.Dropout2d(0.2))
                    return nn.Sequential(*layers)
                
                if image_size == 64:
                    self.main = nn.Sequential(
                        nn.Conv2d(3, base_channels // 2, 4, stride=2, padding=1, padding_mode='replicate'),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        conv_block(base_channels // 2, base_channels),
                        conv_block(base_channels, base_channels * 2),
                        conv_block(base_channels * 2, base_channels * 4),
                        conv_block(base_channels * 4, base_channels * 8, kernel=3, stride=1, padding=0),
                        nn.Conv2d(base_channels * 8, 1, 2, stride=1, padding=0),
                    )
                else:  # 32x32
                    self.main = nn.Sequential(
                        nn.Conv2d(3, base_channels // 2, 4, stride=2, padding=1, padding_mode='replicate'),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        conv_block(base_channels // 2, base_channels),
                        conv_block(base_channels, base_channels * 2),
                        conv_block(base_channels * 2, base_channels * 4, kernel=3, stride=1, padding=0),
                        nn.Conv2d(base_channels * 4, 1, 2, stride=1, padding=0),
                    )
            
            def forward(self, x):
                if x.size(2) < 4 or x.size(3) < 4:
                    x = nn.functional.interpolate(x, size=(max(4, x.size(2)), max(4, x.size(3))), 
                                                  mode='bilinear', align_corners=False)
                
                output = self.main(x)
                return output.view(x.size(0), -1)
        
        self.generator = Generator(image_size, latent_dim, use_skip, base_channels)
        self.critic = Critic(image_size, base_channels)
        
        self._initialize_weights()
        
        # WGAN-GP uses different optimizer settings
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0001, betas=(0.0, 0.9))
        self.optimizerC = optim.Adam(self.critic.parameters(), lr=0.0004, betas=(0.0, 0.9))
        
        self.schedulerG = optim.lr_scheduler.StepLR(self.optimizerG, step_size=30, gamma=0.9)
        self.schedulerC = optim.lr_scheduler.StepLR(self.optimizerC, step_size=30, gamma=0.9)
        
        self.generator.to(self.device)
        self.critic.to(self.device)
        
        self._print_model_size()
    
    def compute_gradient_penalty(self, real_samples, fake_samples):
        """Calculates the gradient penalty loss for WGAN GP"""
        batch_size = real_samples.size(0)
        
        # Random weight term for interpolation between real and fake samples
        alpha = torch.rand(batch_size, 1, 1, 1, device=self.device)
        
        # Get random interpolation between real and fake samples
        interpolates = (alpha * real_samples + ((1 - alpha) * fake_samples)).requires_grad_(True)
        
        # Calculate critic scores
        d_interpolates = self.critic(interpolates)
        
        # Get gradients w.r.t. interpolates
        gradients = torch.autograd.grad(
            outputs=d_interpolates,
            inputs=interpolates,
            grad_outputs=torch.ones_like(d_interpolates, device=self.device),
            create_graph=True,
            retain_graph=True,
            only_inputs=True,
        )[0]
        
        gradients = gradients.view(gradients.size(0), -1)
        gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
        
        return gradient_penalty
    
    def _initialize_weights(self):
        for m in self.generator.modules():
            if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
                nn.init.normal_(m.weight, 0.0, 0.02)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.normal_(m.weight, 1.0, 0.02)
                nn.init.constant_(m.bias, 0)
        
        for m in self.critic.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight, 0.0, 0.02)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.normal_(m.weight, 1.0, 0.02)
                nn.init.constant_(m.bias, 0)
    
    def _print_model_size(self):
        g_params = sum(p.numel() for p in self.generator.parameters())
        c_params = sum(p.numel() for p in self.critic.parameters())
        total_params = g_params + c_params
        
        print(f"\n{'='*40}")
        print(f"Big WGAN-GP Model Size:")
        print(f"{'='*40}")
        print(f"Image Size: {self.image_size}x{self.image_size}")
        print(f"Latent Dim: {self.latent_dim}")
        print(f"Base Channels: {self.base_channels}")
        print(f"Generator: {g_params:,} params")
        print(f"Critic: {c_params:,} params")
        print(f"Total: {total_params:,} parameters")
        print(f"{'='*40}")

# ==================== Dataset ====================

class CleanImageDataset(Dataset):
    def __init__(self, image_paths, image_size=64, augment=True):
        self.image_paths = image_paths
        self.image_size = image_size
        self.augment = augment
        
        # Safe transforms for CPU
        if augment:
            self.transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.RandomHorizontalFlip(p=0.3),
                transforms.ColorJitter(brightness=0.1, contrast=0.1),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI ====================

class WGAN_GP_App:
    def __init__(self, root):
        self.root = root
        self.root.title("WGAN-GP Explorer with Vector Mixer")
        self.root.geometry("1200x800")
        
        self.root.minsize(1100, 700)
        
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        self.initializing = False
        
        # Vector mixer storage
        self.vector_a = None
        self.vector_b = None
        self.image_a = None
        self.image_b = None
        self.image_a_photo = None
        self.image_b_photo = None
        self.image_mixed_photo = None
        
        # Setup the GUI
        self.setup_gui()
        
        # Start message processing
        self.root.after(100, self.process_messages)
    
    def setup_gui(self):
        main_container = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, sashwidth=5, sashrelief=tk.RAISED)
        main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # LEFT PANEL
        left_panel = tk.Frame(main_container, width=360)
        main_container.add(left_panel, minsize=320, width=360)
        
        left_canvas = tk.Canvas(left_panel)
        left_scrollbar = tk.Scrollbar(left_panel, orient=tk.VERTICAL, command=left_canvas.yview)
        left_canvas.configure(yscrollcommand=left_scrollbar.set)
        
        left_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        left_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.left_content = tk.Frame(left_canvas)
        left_canvas.create_window((0, 0), window=self.left_content, anchor="nw")
        
        left_canvas.bind_all("<MouseWheel>", lambda e: left_canvas.yview_scroll(-1 * (e.delta // 120), "units"))
        self.left_content.bind("<Configure>", lambda e: left_canvas.configure(scrollregion=left_canvas.bbox("all")))
        
        tk.Label(self.left_content, text="WGAN-GP Explorer", font=("Arial", 16, "bold"), 
                fg="darkred").pack(pady=(5, 15))
        
        self.create_model_config()
        self.create_dataset_section()
        self.create_training_settings()
        self.create_display_settings()
        self.create_control_buttons()
        self.create_status_section()
        
        # RIGHT PANEL
        right_panel = tk.Frame(main_container)
        main_container.add(right_panel, minsize=700)
        
        self.notebook = ttk.Notebook(right_panel)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        
        single_tab = tk.Frame(self.notebook)
        self.notebook.add(single_tab, text="Single Image")
        self.setup_single_image_tab(single_tab)
        
        grid_tab = tk.Frame(self.notebook)
        self.notebook.add(grid_tab, text="Latent Grid")
        self.setup_grid_tab(grid_tab)
        
        mixer_tab = tk.Frame(self.notebook)
        self.notebook.add(mixer_tab, text="Vector Mixer")
        self.setup_vector_mixer_tab(mixer_tab)
        
        log_tab = tk.Frame(self.notebook)
        self.notebook.add(log_tab, text="Training Log")
        self.setup_log_tab(log_tab)
    
    def create_model_config(self):
        frame = tk.LabelFrame(self.left_content, text="Model Configuration", padx=10, pady=10)
        frame.pack(fill=tk.X, pady=(0, 10), padx=5)
        
        tk.Label(frame, text="Image Size:").grid(row=0, column=0, sticky="w", pady=5)
        self.size_var = tk.StringVar(value="32")
        size_frame = tk.Frame(frame)
        size_frame.grid(row=0, column=1, sticky="ew", pady=5, padx=(10, 0))
        tk.Radiobutton(size_frame, text="32x32", variable=self.size_var, value="32").pack(side=tk.LEFT, padx=(0, 10))
        tk.Radiobutton(size_frame, text="64x64", variable=self.size_var, value="64").pack(side=tk.LEFT)
        
        tk.Label(frame, text="Latent Dim:").grid(row=1, column=0, sticky="w", pady=5)
        self.latent_var = tk.StringVar(value="100")
        tk.Entry(frame, textvariable=self.latent_var, width=15).grid(row=1, column=1, sticky="ew", pady=5, padx=(10, 0))
        
        tk.Label(frame, text="Channels:").grid(row=2, column=0, sticky="w", pady=5)
        self.channels_var = tk.StringVar(value="64")
        channels_frame = tk.Frame(frame)
        channels_frame.grid(row=2, column=1, sticky="ew", pady=5, padx=(10, 0))
        tk.Radiobutton(channels_frame, text="64", variable=self.channels_var, value="64").pack(side=tk.LEFT, padx=(0, 5))
        tk.Radiobutton(channels_frame, text="128", variable=self.channels_var, value="128").pack(side=tk.LEFT, padx=(0, 5))
        tk.Radiobutton(channels_frame, text="256", variable=self.channels_var, value="256").pack(side=tk.LEFT)
        
        self.skip_var = tk.BooleanVar(value=False)
        tk.Checkbutton(frame, text="Skip Connections", variable=self.skip_var).grid(row=3, column=0, columnspan=2, sticky="w", pady=5)
        
        self.augment_var = tk.BooleanVar(value=False)
        tk.Checkbutton(frame, text="Mild Augmentation", variable=self.augment_var).grid(row=4, column=0, columnspan=2, sticky="w", pady=5)
        
        frame.columnconfigure(1, weight=1)
    
    def create_dataset_section(self):
        frame = tk.LabelFrame(self.left_content, text="Dataset", padx=10, pady=10)
        frame.pack(fill=tk.X, pady=(0, 10), padx=5)
        
        btn_frame = tk.Frame(frame)
        btn_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(btn_frame, text="Add Images", command=self.add_images, width=14).pack(side=tk.LEFT, padx=(0, 5))
        tk.Button(btn_frame, text="Clear All", command=self.clear_images, width=14, bg="salmon").pack(side=tk.LEFT)
        
        tk.Label(frame, text="Images:").pack(anchor="w")
        
        list_frame = tk.Frame(frame, height=120)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame)
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    def create_training_settings(self):
        frame = tk.LabelFrame(self.left_content, text="Training Settings", padx=10, pady=10)
        frame.pack(fill=tk.X, pady=(0, 10), padx=5)
        
        tk.Label(frame, text="Epochs:").grid(row=0, column=0, sticky="w", pady=5)
        self.epoch_var = tk.StringVar(value="500")
        tk.Entry(frame, textvariable=self.epoch_var, width=15).grid(row=0, column=1, sticky="ew", pady=5, padx=(10, 0))
        
        tk.Label(frame, text="Batch Size:").grid(row=1, column=0, sticky="w", pady=5)
        self.batch_var = tk.StringVar(value="8")
        tk.Entry(frame, textvariable=self.batch_var, width=15).grid(row=1, column=1, sticky="ew", pady=5, padx=(10, 0))
        
        tk.Label(frame, text="Critic Steps:").grid(row=2, column=0, sticky="w", pady=5)
        self.critic_steps_var = tk.StringVar(value="5")
        tk.Entry(frame, textvariable=self.critic_steps_var, width=15).grid(row=2, column=1, sticky="ew", pady=5, padx=(10, 0))
        
        frame.columnconfigure(1, weight=1)
    
    def create_display_settings(self):
        frame = tk.LabelFrame(self.left_content, text="Display Settings", padx=10, pady=10)
        frame.pack(fill=tk.X, pady=(0, 10), padx=5)
        
        tk.Label(frame, text="Display Scale:").grid(row=0, column=0, sticky="w", pady=5)
        self.scale_var = tk.StringVar(value="4")
        scale_frame = tk.Frame(frame)
        scale_frame.grid(row=0, column=1, sticky="ew", pady=5, padx=(10, 0))
        tk.Radiobutton(scale_frame, text="2x", variable=self.scale_var, value="2").pack(side=tk.LEFT, padx=(0, 5))
        tk.Radiobutton(scale_frame, text="4x", variable=self.scale_var, value="4").pack(side=tk.LEFT, padx=(0, 5))
        tk.Radiobutton(scale_frame, text="8x", variable=self.scale_var, value="8").pack(side=tk.LEFT)
        
        tk.Label(frame, text="Grid Size:").grid(row=1, column=0, sticky="w", pady=5)
        self.grid_var = tk.StringVar(value="5")
        tk.Entry(frame, textvariable=self.grid_var, width=15).grid(row=1, column=1, sticky="ew", pady=5, padx=(10, 0))
        
        frame.columnconfigure(1, weight=1)
    
    def create_control_buttons(self):
        frame = tk.LabelFrame(self.left_content, text="Controls", padx=10, pady=10)
        frame.pack(fill=tk.X, pady=(0, 10), padx=5)
        
        buttons = [
            ("Initialize Model", self.initialize_gan, "SystemButtonFace"),
            ("Start Training", self.start_training, "lightgreen"),
            ("Stop Training", self.stop_training, "salmon"),
            ("Generate Sample", self.generate_sample, "SystemButtonFace"),
            ("Generate Grid", self.generate_interpolation_grid, "lightblue"),
        ]
        
        for text, command, color in buttons:
            btn = tk.Button(frame, text=text, command=command, height=2)
            if color != "SystemButtonFace":
                btn.config(bg=color)
            btn.pack(fill=tk.X, pady=3)
    
    def create_status_section(self):
        frame = tk.LabelFrame(self.left_content, text="Status", padx=10, pady=10)
        frame.pack(fill=tk.X, pady=(0, 5), padx=5)
        
        self.status_label = tk.Label(frame, text="Ready", relief=tk.SUNKEN, 
                                    height=2, anchor="w", padx=5, bg="white")
        self.status_label.pack(fill=tk.X)
    
    def setup_single_image_tab(self, parent):
        canvas = tk.Canvas(parent, bg="gray90")
        v_scrollbar = tk.Scrollbar(parent, orient=tk.VERTICAL, command=canvas.yview)
        h_scrollbar = tk.Scrollbar(parent, orient=tk.HORIZONTAL, command=canvas.xview)
        
        canvas.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        image_frame = tk.Frame(canvas, bg="gray90")
        self.image_canvas_window = canvas.create_window((0, 0), window=image_frame, anchor="nw")
        
        self.image_label = tk.Label(image_frame, bg="gray90")
        self.image_label.pack(pady=20, padx=20)
        
        image_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(self.image_canvas_window, width=e.width))
    
    def setup_grid_tab(self, parent):
        self.grid_canvas = tk.Canvas(parent, bg="white")
        v_scrollbar = tk.Scrollbar(parent, orient=tk.VERTICAL, command=self.grid_canvas.yview)
        h_scrollbar = tk.Scrollbar(parent, orient=tk.HORIZONTAL, command=self.grid_canvas.xview)
        
        self.grid_canvas.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        self.grid_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.grid_frame = tk.Frame(self.grid_canvas, bg="white")
        self.grid_canvas_window = self.grid_canvas.create_window((0, 0), window=self.grid_frame, anchor="nw")
        
        self.grid_frame.bind("<Configure>", lambda e: self.grid_canvas.configure(scrollregion=self.grid_canvas.bbox("all")))
        self.grid_canvas.bind("<Configure>", lambda e: self.grid_canvas.itemconfig(self.grid_canvas_window, width=e.width))
    
    def setup_vector_mixer_tab(self, parent):
        mixer_container = tk.Frame(parent)
        mixer_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Top section: Vector previews
        top_frame = tk.LabelFrame(mixer_container, text="Vector Mixer", padx=10, pady=10)
        top_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Create a 3-column layout: Vector A | Mix Controls | Vector B
        vector_columns = tk.Frame(top_frame)
        vector_columns.pack(fill=tk.X, pady=5)
        
        # Column 1: Vector A
        col_a = tk.Frame(vector_columns)
        col_a.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        tk.Label(col_a, text="Vector A", font=("Arial", 12, "bold"), fg="blue").pack()
        
        self.vector_a_canvas = tk.Canvas(col_a, width=150, height=150, bg="gray90", 
                                        highlightthickness=2, highlightbackground="blue")
        self.vector_a_canvas.pack(pady=5)
        
        self.vector_a_label = tk.Label(col_a, text="Not generated", relief=tk.SUNKEN, 
                                      padx=5, pady=2, width=20)
        self.vector_a_label.pack()
        
        tk.Button(col_a, text="Generate Vector A", command=lambda: self.generate_vector('A'), 
                 width=18, bg="lightblue").pack(pady=5)
        
        # Column 2: Mix Controls (Middle)
        col_middle = tk.Frame(vector_columns)
        col_middle.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10)
        
        tk.Label(col_middle, text="→ Mix →", font=("Arial", 14, "bold"), fg="purple").pack(pady=10)
        
        # Mixing methods
        mix_methods_frame = tk.Frame(col_middle)
        mix_methods_frame.pack(pady=10)
        
        tk.Label(mix_methods_frame, text="Mixing Method:", font=("Arial", 10, "bold")).pack(anchor="w", pady=5)
        
        self.mix_method_var = tk.StringVar(value="linear")
        
        mix_options = [
            ("Linear Blend (50/50)", "linear"),
            ("Half Swap (A+B)", "half_swap_ab"),
            ("Half Swap (B+A)", "half_swap_ba"),
            ("Average", "average"),
            ("Max", "max"),
            ("Min", "min"),
            ("Checkboard", "checkerboard"),
            ("Inverse Checkboard", "inv_checkerboard"),
            ("Average + Difference", "avg_diff"),
            ("Difference × Average", "diff_avg"),
            ("Weighted (75% A)", "weighted_75a"),
            ("Weighted (75% B)", "weighted_75b"),
            ("Random Mix", "random_mix"),
            ("Sin Wave Mix", "sin_mix"),
            ("Abs Difference", "abs_diff"),
            ("Multiply", "multiply"),
        ]
        
        mix_method_menu = tk.OptionMenu(mix_methods_frame, self.mix_method_var, *[opt[0] for opt in mix_options])
        mix_method_menu.config(width=20)
        mix_method_menu.pack(pady=5)
        
        self.mix_method_mapping = {opt[0]: opt[1] for opt in mix_options}
        
        # Buttons
        button_frame = tk.Frame(col_middle)
        button_frame.pack(pady=10)
        
        tk.Button(button_frame, text="🔄 Swap Vectors", command=self.swap_vectors,
                 width=16, bg="yellow", font=("Arial", 10)).pack(side=tk.LEFT, padx=5)
        
        tk.Button(button_frame, text="MIX", command=self.mix_selected_method,
                 width=16, bg="lightgreen", font=("Arial", 11, "bold")).pack(side=tk.LEFT, padx=5)
        
        # Column 3: Vector B
        col_b = tk.Frame(vector_columns)
        col_b.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0))
        
        tk.Label(col_b, text="Vector B", font=("Arial", 12, "bold"), fg="green").pack()
        
        self.vector_b_canvas = tk.Canvas(col_b, width=150, height=150, bg="gray90",
                                        highlightthickness=2, highlightbackground="green")
        self.vector_b_canvas.pack(pady=5)
        
        self.vector_b_label = tk.Label(col_b, text="Not generated", relief=tk.SUNKEN,
                                      padx=5, pady=2, width=20)
        self.vector_b_label.pack()
        
        tk.Button(col_b, text="Generate Vector B", command=lambda: self.generate_vector('B'),
                 width=18, bg="lightgreen").pack(pady=5)
        
        # Bottom section: Mixed Result
        bottom_frame = tk.LabelFrame(mixer_container, text="Mixed Result", padx=10, pady=10)
        bottom_frame.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        mixed_display_frame = tk.Frame(bottom_frame)
        mixed_display_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.mixed_canvas = tk.Canvas(mixed_display_frame, width=256, height=256, bg="gray90",
                                     highlightthickness=2, highlightbackground="purple")
        self.mixed_canvas.pack()
        
        self.mixed_label = tk.Label(bottom_frame, text="No mixed result yet", 
                                   font=("Arial", 10), fg="gray")
        self.mixed_label.pack(pady=5)
    
    def setup_log_tab(self, parent):
        self.log_text = tk.Text(parent, height=20, font=("Consolas", 10), wrap=tk.WORD)
        log_scrollbar = tk.Scrollbar(parent, command=self.log_text.yview)
        
        self.log_text.configure(yscrollcommand=log_scrollbar.set)
        
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        clear_frame = tk.Frame(parent)
        clear_frame.pack(fill=tk.X, padx=5, pady=5)
        tk.Button(clear_frame, text="Clear Log", command=self.clear_log, width=15).pack(side=tk.RIGHT)
    
    # ==================== VECTOR MIXER METHODS ====================
    
    def generate_vector(self, which):
        if not self.gan:
            self.log_message("✗ No model initialized!")
            return
        
        noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
        
        with torch.no_grad():
            self.gan.generator.eval()
            generated = self.gan.generator(noise)
            img = generated[0].cpu()
            img = (img + 1) / 2
            img = torch.clamp(img, 0, 1)
            img_pil = transforms.ToPILImage()(img)
            
            scale_factor = int(self.scale_var.get())
            display_size = self.gan.image_size * scale_factor
            img_pil_display = img_pil.resize((display_size, display_size), Image.Resampling.LANCZOS)
            
            preview_size = 150
            img_pil_preview = img_pil.resize((preview_size, preview_size), Image.Resampling.LANCZOS)
        
        if which == 'A':
            self.vector_a = noise
            self.image_a = img_pil_display
            self.vector_a_label.config(text=f"Vector A: Generated ✓")
            
            self.image_a_photo = ImageTk.PhotoImage(img_pil_preview)
            self.vector_a_canvas.delete("all")
            self.vector_a_canvas.create_image(75, 75, image=self.image_a_photo)
            
        else:
            self.vector_b = noise
            self.image_b = img_pil_display
            self.vector_b_label.config(text=f"Vector B: Generated ✓")
            
            self.image_b_photo = ImageTk.PhotoImage(img_pil_preview)
            self.vector_b_canvas.delete("all")
            self.vector_b_canvas.create_image(75, 75, image=self.image_b_photo)
        
        self.log_message(f"✓ Generated vector {which}")
    
    def swap_vectors(self):
        if self.vector_a is not None and self.vector_b is not None:
            self.vector_a, self.vector_b = self.vector_b, self.vector_a
            self.image_a, self.image_b = self.image_b, self.image_a
            self.image_a_photo, self.image_b_photo = self.image_b_photo, self.image_a_photo
            
            self.log_message("✓ Swapped vectors A and B")
            
            self.vector_a_label.config(text="Vector A: Generated ✓")
            self.vector_b_label.config(text="Vector B: Generated ✓")
            
            self.vector_a_canvas.delete("all")
            self.vector_b_canvas.delete("all")
            
            if self.image_a_photo:
                self.vector_a_canvas.create_image(75, 75, image=self.image_a_photo)
            if self.image_b_photo:
                self.vector_b_canvas.create_image(75, 75, image=self.image_b_photo)
    
    def mix_selected_method(self):
        selected_display = self.mix_method_var.get()
        method = self.mix_method_mapping.get(selected_display, "linear")
        self.mix_vectors(method)
    
    def mix_vectors(self, method):
        if self.vector_a is None or self.vector_b is None:
            self.log_message("✗ Generate both vectors first!")
            return
        
        self.notebook.select(2)
        
        try:
            with torch.no_grad():
                self.gan.generator.eval()
                
                if method == 'linear':
                    mixed = 0.5 * self.vector_a + 0.5 * self.vector_b
                    method_name = "Linear Blend (50/50)"
                
                elif method == 'half_swap_ab':
                    half = self.gan.latent_dim // 2
                    mixed = torch.cat([self.vector_a[:, :half], self.vector_b[:, half:]], dim=1)
                    if self.gan.latent_dim % 2 == 1:
                        avg_middle = (self.vector_a[:, half] + self.vector_b[:, half]) / 2
                        mixed = torch.cat([mixed[:, :half], avg_middle.unsqueeze(1), mixed[:, half:]], dim=1)
                    method_name = "Half Swap (A+B)"
                
                elif method == 'half_swap_ba':
                    half = self.gan.latent_dim // 2
                    mixed = torch.cat([self.vector_b[:, :half], self.vector_a[:, half:]], dim=1)
                    if self.gan.latent_dim % 2 == 1:
                        avg_middle = (self.vector_a[:, half] + self.vector_b[:, half]) / 2
                        mixed = torch.cat([mixed[:, :half], avg_middle.unsqueeze(1), mixed[:, half:]], dim=1)
                    method_name = "Half Swap (B+A)"
                
                elif method == 'average':
                    mixed = (self.vector_a + self.vector_b) / 2
                    method_name = "Average"
                
                elif method == 'max':
                    mixed = torch.max(self.vector_a, self.vector_b)
                    method_name = "Max"
                
                elif method == 'min':
                    mixed = torch.min(self.vector_a, self.vector_b)
                    method_name = "Min"
                
                elif method == 'checkerboard':
                    mixed = self.vector_a.clone()
                    mixed[:, 1::2] = self.vector_b[:, 1::2]
                    method_name = "Checkboard"
                
                elif method == 'inv_checkerboard':
                    mixed = self.vector_b.clone()
                    mixed[:, 1::2] = self.vector_a[:, 1::2]
                    method_name = "Inverse Checkboard"
                
                elif method == 'avg_diff':
                    avg = (self.vector_a + self.vector_b) / 2
                    diff = self.vector_a - self.vector_b
                    mixed = avg + diff * 0.5
                    method_name = "Average + Difference"
                
                elif method == 'diff_avg':
                    diff = self.vector_a - self.vector_b
                    avg = (self.vector_a + self.vector_b) / 2
                    mixed = diff * avg
                    method_name = "Difference × Average"
                
                elif method == 'weighted_75a':
                    mixed = 0.75 * self.vector_a + 0.25 * self.vector_b
                    method_name = "Weighted (75% A)"
                
                elif method == 'weighted_75b':
                    mixed = 0.25 * self.vector_a + 0.75 * self.vector_b
                    method_name = "Weighted (75% B)"
                
                elif method == 'random_mix':
                    mask = torch.rand_like(self.vector_a)
                    mixed = mask * self.vector_a + (1 - mask) * self.vector_b
                    method_name = "Random Mix"
                
                elif method == 'sin_mix':
                    x = torch.linspace(0, 3.14159, self.gan.latent_dim, device=self.gan.device).unsqueeze(0)
                    weights = torch.sin(x)
                    mixed = weights * self.vector_a + (1 - weights) * self.vector_b
                    method_name = "Sin Wave Mix"
                
                elif method == 'abs_diff':
                    mixed = torch.abs(self.vector_a - self.vector_b)
                    method_name = "Abs Difference"
                
                elif method == 'multiply':
                    mixed = self.vector_a * self.vector_b
                    method_name = "Multiply"
                
                else:
                    mixed = (self.vector_a + self.vector_b) / 2
                    method_name = "Average"
                
                generated = self.gan.generator(mixed)
                img = generated[0].cpu()
                img = (img + 1) / 2
                img = torch.clamp(img, 0, 1)
                img_pil = transforms.ToPILImage()(img)
                
                scale_factor = int(self.scale_var.get())
                display_size = self.gan.image_size * scale_factor
                img_pil_display = img_pil.resize((display_size, display_size), Image.Resampling.LANCZOS)
                
                preview_size = 256
                img_pil_preview = img_pil.resize((preview_size, preview_size), Image.Resampling.LANCZOS)
                
                self.image_mixed_photo = ImageTk.PhotoImage(img_pil_preview)
                self.mixed_canvas.delete("all")
                self.mixed_canvas.create_image(128, 128, image=self.image_mixed_photo)
                self.mixed_label.config(text=f"Mixed: {method_name}", fg="purple")
                
                self.log_message(f"✓ Mixed vectors: {method_name}")
                
        except Exception as e:
            self.log_message(f"✗ Mixing error: {str(e)}")
    
    # ==================== OTHER METHODS ====================
    
    def clear_log(self):
        self.log_text.delete(1.0, tk.END)
        self.log_message("Log cleared")
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
                status_text = message[:50] + "..." if len(message) > 50 else message
                self.status_label.config(text=status_text)
                self.root.update_idletasks()
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def add_images(self):
        if self.initializing:
            self.log_message("Please wait for initialization to complete")
            return
            
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")
    
    def clear_images(self):
        if self.initializing:
            self.log_message("Please wait for initialization to complete")
            return
            
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images")
    
    def initialize_gan(self):
        if self.initializing:
            self.log_message("Already initializing...")
            return
            
        if self.training:
            self.log_message("Cannot initialize while training!")
            return
            
        try:
            image_size = int(self.size_var.get())
            latent_dim = int(self.latent_var.get())
            use_skip = self.skip_var.get()
            base_channels = int(self.channels_var.get())
            
            self.initializing = True
            self.status_label.config(text="Initializing model...", bg="yellow")
            
            thread = threading.Thread(
                target=self._initialize_gan_thread,
                args=(image_size, latent_dim, use_skip, base_channels),
                daemon=True
            )
            thread.start()
            
        except Exception as e:
            self.log_message(f"Error in parameters: {str(e)}")
            self.initializing = False
    
    def _initialize_gan_thread(self, image_size, latent_dim, use_skip, base_channels):
        try:
            self.gan = BigWGAN_GP(
                image_size=image_size,
                latent_dim=latent_dim,
                use_skip=use_skip,
                base_channels=base_channels
            )
            
            self.message_queue.put(f"✓ Initialized WGAN-GP")
            self.message_queue.put(f"  Size: {image_size}x{image_size}")
            self.message_queue.put(f"  Latent dim: {latent_dim}")
            self.message_queue.put(f"  Channels: {base_channels}")
            self.message_queue.put(f"  Gradient Penalty: {self.gan.gp_weight}")
            
        except Exception as e:
            self.message_queue.put(f"✗ Error initializing: {str(e)}")
            print(f"Error: {e}")
            traceback.print_exc()
        finally:
            self.initializing = False
            self.status_label.config(bg="white")
    
    def start_training(self):
        if self.initializing:
            self.log_message("Please wait for initialization to complete")
            return
            
        if not self.image_paths:
            self.log_message("✗ No images added!")
            return
        
        if not self.gan:
            self.log_message("✗ Initialize model first!")
            return
        
        if self.training:
            self.log_message("✗ Already training!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            batch_size = int(self.batch_var.get())
            image_size = int(self.size_var.get())
            augment = self.augment_var.get()
            critic_steps = int(self.critic_steps_var.get())
            
            self.training = True
            
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, image_size, augment, critic_steps),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"▶ Started WGAN-GP training for {epochs} epochs")
            self.log_message(f"  Batch size: {batch_size}")
            self.log_message(f"  Critic steps: {critic_steps}")
            self.log_message(f"  Augmentation: {'On' if augment else 'Off'}")
            
        except ValueError:
            self.log_message("✗ Invalid numbers!")
    
    def train_gan(self, epochs, batch_size, image_size, augment, critic_steps):
        try:
            dataset = CleanImageDataset(self.image_paths, image_size, augment=augment)
            
            # Dynamic batch size adjustment for CPU
            current_batch_size = batch_size
            while True:
                try:
                    dataloader = DataLoader(
                        dataset,
                        batch_size=current_batch_size,
                        shuffle=True,
                        num_workers=0,
                        pin_memory=False
                    )
                    # Test one batch
                    test_batch = next(iter(dataloader))
                    break
                except RuntimeError as e:
                    if "out of memory" in str(e).lower():
                        current_batch_size = max(1, current_batch_size // 2)
                        self.log_message(f"Reduced batch size to {current_batch_size}")
                    else:
                        raise
            
            if current_batch_size != batch_size:
                self.log_message(f"Using batch size {current_batch_size} due to memory constraints")
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                total_loss_c = 0
                total_loss_g = 0
                batch_count = 0
                
                for i, real_images in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    batch_size_current = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # Train Critic more times (WGAN-GP)
                    for _ in range(critic_steps):
                        self.gan.optimizerC.zero_grad()
                        
                        # Real images
                        d_real = self.gan.critic(real_images)
                        
                        # Fake images
                        noise = torch.randn(batch_size_current, self.gan.latent_dim, device=self.gan.device)
                        fake_images = self.gan.generator(noise)
                        d_fake = self.gan.critic(fake_images.detach())
                        
                        # Gradient penalty
                        gradient_penalty = self.gan.compute_gradient_penalty(real_images.data, fake_images.data)
                        
                        # Critic loss
                        loss_c = d_fake.mean() - d_real.mean() + self.gan.gp_weight * gradient_penalty
                        loss_c.backward()
                        self.gan.optimizerC.step()
                    
                    # Train Generator
                    self.gan.optimizerG.zero_grad()
                    
                    noise = torch.randn(batch_size_current, self.gan.latent_dim, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    d_fake = self.gan.critic(fake_images)
                    
                    # Generator loss
                    loss_g = -d_fake.mean()
                    loss_g.backward()
                    self.gan.optimizerG.step()
                    
                    total_loss_c += loss_c.item()
                    total_loss_g += loss_g.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_c = total_loss_c / (batch_count * critic_steps)
                    avg_loss_g = total_loss_g / batch_count
                    
                    self.log_message(f"E{epoch+1:03d}: C={avg_loss_c:.4f} G={avg_loss_g:.4f}")
                
                self.gan.schedulerG.step()
                self.gan.schedulerC.step()
                
                if (epoch + 1) % 5 == 0:
                    self.root.after(0, self.generate_sample_internal, False)
                
                # Save checkpoint every 50 epochs
                if (epoch + 1) % 50 == 0 and epoch > 0:
                    self.save_checkpoint(epoch)
            
            self.training = False
            self.log_message("✓ Training completed!")
            
        except Exception as e:
            self.log_message(f"✗ Training error: {str(e)}")
            print(f"Error: {e}")
            traceback.print_exc()
            self.training = False
    
    def save_checkpoint(self, epoch):
        """Save model checkpoint"""
        try:
            if not os.path.exists('checkpoints'):
                os.makedirs('checkpoints')
            
            checkpoint_path = f'checkpoints/wgangp_epoch_{epoch+1}.pth'
            torch.save({
                'epoch': epoch,
                'generator_state_dict': self.gan.generator.state_dict(),
                'critic_state_dict': self.gan.critic.state_dict(),
                'optimizerG_state_dict': self.gan.optimizerG.state_dict(),
                'optimizerC_state_dict': self.gan.optimizerC.state_dict(),
                'image_size': self.gan.image_size,
                'latent_dim': self.gan.latent_dim,
            }, checkpoint_path)
            
            self.log_message(f"✓ Checkpoint saved: {checkpoint_path}")
        except Exception as e:
            self.log_message(f"✗ Failed to save checkpoint: {str(e)}")
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("⏹ Training stopped")
    
    def generate_sample_internal(self, show=True, seed=None):
        if not self.gan:
            return None
        
        try:
            with torch.no_grad():
                self.gan.generator.eval()
                
                if seed is not None:
                    torch.manual_seed(seed)
                    noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                else:
                    noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                
                generated = self.gan.generator(noise)
                img = generated[0].cpu()
                img = (img + 1) / 2
                img = torch.clamp(img, 0, 1)
                img = transforms.ToPILImage()(img)
                
                scale_factor = int(self.scale_var.get())
                display_size = self.gan.image_size * scale_factor
                img = img.resize((display_size, display_size), Image.Resampling.LANCZOS)
                
                if show:
                    self.display_image(img)
                
                if self.training:
                    self.gan.generator.train()
                
                return img
                
        except Exception as e:
            self.log_message(f"✗ Generation error: {str(e)}")
            return None
    
    def generate_sample(self):
        if self.initializing:
            self.log_message("Please wait for initialization to complete")
            return
            
        if not self.gan:
            self.log_message("✗ No model initialized!")
            return
            
        self.notebook.select(0)
        
        img = self.generate_sample_internal(show=True, seed=random.randint(0, 10000))
        if img:
            self.log_message("✓ Generated sample")
    
    def generate_interpolation_grid(self):
        if self.initializing:
            self.log_message("Please wait for initialization to complete")
            return
            
        if not self.gan:
            self.log_message("✗ No model initialized!")
            return
        
        self.notebook.select(1)
        
        try:
            grid_size = int(self.grid_var.get())
            scale_factor = int(self.scale_var.get())
            
            for widget in self.grid_frame.winfo_children():
                widget.destroy()
            
            self.log_message(f"Generating {grid_size}x{grid_size} grid...")
            
            noise_start = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
            noise_end = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
            
            with torch.no_grad():
                self.gan.generator.eval()
                
                display_size = self.gan.image_size * scale_factor
                
                for i in range(grid_size):
                    for j in range(grid_size):
                        alpha = (i * grid_size + j) / max(grid_size * grid_size - 1, 1)
                        noise = (1 - alpha) * noise_start + alpha * noise_end
                        
                        generated = self.gan.generator(noise)
                        img = generated[0].cpu()
                        img = (img + 1) / 2
                        img = torch.clamp(img, 0, 1)
                        img = transforms.ToPILImage()(img)
                        
                        img = img.resize((display_size, display_size), Image.Resampling.LANCZOS)
                        
                        photo = ImageTk.PhotoImage(img)
                        label = tk.Label(self.grid_frame, image=photo, bg="white")
                        label.image = photo
                        label.grid(row=i, column=j, padx=1, pady=1)
                
                self.gan.generator.train()
            
            self.log_message(f"✓ Generated {grid_size}x{grid_size} grid (simple interpolation)")
            
        except Exception as e:
            self.log_message(f"✗ Grid error: {str(e)}")
            print(f"Error: {e}")
            traceback.print_exc()
    
    def display_image(self, img):
        photo = ImageTk.PhotoImage(img)
        self.image_label.config(image=photo)
        self.image_label.image = photo

# ==================== Main ====================

if __name__ == "__main__":
    print("WGAN-GP Explorer - Optimized for CPU Training!")
    print("-" * 50)
    print("Major Improvements:")
    print("• WGAN-GP loss (better stability & quality)")
    print("• Gradient penalty prevents mode collapse")
    print("• CPU optimizations (4 threads)")
    print("• Dynamic batch size adjustment")
    print("• Auto-checkpointing every 50 epochs")
    print("• Critic trained 5x more than generator")
    print("-" * 50)
    print("Default settings optimized for small datasets:")
    print("• 32x32 resolution")
    print("• 100 latent dimension")
    print("• 64 channels")
    print("• Skip connections OFF")
    print("• 500 epochs recommended")
    print("-" * 50)
    
    try:
        root = tk.Tk()
        app = WGAN_GP_App(root)
        root.mainloop()
    except Exception as e:
        print(f"Fatal error: {e}")
        traceback.print_exc()