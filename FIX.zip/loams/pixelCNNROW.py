import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import math

# ==================== Neural Network with Simple Positional Encoding ====================

class RowPixelCNNSimplePosition:
    def __init__(self, image_size=32, channels=3, hidden_dim=128, num_layers=8, num_filters=64):
        self.image_size = image_size
        self.channels = channels
        self.hidden_dim = hidden_dim
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Simple Positional Encoding - Just Y and X coordinates as grayscale layers
        class SimplePositionalEncoding(nn.Module):
            def __init__(self, image_size):
                super().__init__()
                self.image_size = image_size
                
                # Pre-compute Y coordinate map (0 to 1 from top to bottom)
                y_coords = torch.linspace(0, 1, image_size).view(1, 1, image_size, 1)
                y_coords = y_coords.expand(1, 1, image_size, image_size)
                
                # Pre-compute X coordinate map (0 to 1 from left to right)
                x_coords = torch.linspace(0, 1, image_size).view(1, 1, 1, image_size)
                x_coords = x_coords.expand(1, 1, image_size, image_size)
                
                # Register as buffers (not trainable parameters)
                self.register_buffer('y_coords', y_coords)
                self.register_buffer('x_coords', x_coords)
                
                # Learnable scaling parameters (optional)
                self.y_scale = nn.Parameter(torch.ones(1))
                self.x_scale = nn.Parameter(torch.ones(1))
                
                # Learnable bias parameters (optional)
                self.y_bias = nn.Parameter(torch.zeros(1))
                self.x_bias = nn.Parameter(torch.zeros(1))
            
            def forward(self, batch_size, height=1):
                """
                Generate simple positional encoding for a batch
                Returns: (batch_size, 2, height, image_size)
                """
                # Get Y coordinates for the current row(s)
                # For predicting a single row: height = 1
                y_pos = self.y_coords[:, :, :height, :] * self.y_scale + self.y_bias
                x_pos = self.x_coords[:, :, :height, :] * self.x_scale + self.x_bias
                
                # Expand to batch size
                pos_encoding = torch.cat([y_pos, x_pos], dim=1)  # (1, 2, height, width)
                pos_encoding = pos_encoding.expand(batch_size, -1, -1, -1)  # (batch_size, 2, height, width)
                
                return pos_encoding
        
        # Simple Row-Predicting CNN with Positional Layers
        class SimpleRowPredictor(nn.Module):
            def __init__(self, image_size, channels, hidden_dim, num_layers, num_filters):
                super().__init__()
                
                self.image_size = image_size
                self.channels = channels
                
                # Input: 5 previous rows * channels + 2 position layers (Y and X)
                self.input_channels = 5 * channels + 2  # +2 for Y and X position layers
                
                # Simple convolutional encoder
                self.initial_conv = nn.Sequential(
                    nn.Conv2d(self.input_channels, num_filters, kernel_size=1, stride=1, padding=0),
                    nn.BatchNorm2d(num_filters),
                    nn.ReLU(inplace=True)
                )
                
                # Simple convolutional blocks
                self.conv_blocks = nn.ModuleList()
                current_channels = num_filters
                
                for i in range(num_layers):
                    dilation = 1 + (i % 3)  # Simple dilation pattern
                    
                    block = nn.Sequential(
                        nn.Conv2d(current_channels, num_filters, 
                                 kernel_size=(1, 3), stride=1, 
                                 padding=(0, dilation), dilation=(1, dilation)),
                        nn.BatchNorm2d(num_filters),
                        nn.ReLU(inplace=True),
                        nn.Conv2d(num_filters, num_filters, 
                                 kernel_size=(1, 3), stride=1, 
                                 padding=(0, dilation), dilation=(1, dilation)),
                        nn.BatchNorm2d(num_filters),
                        nn.ReLU(inplace=True)
                    )
                    
                    self.conv_blocks.append(block)
                    current_channels = num_filters
                
                # Simple row predictor
                self.row_predictor = nn.Sequential(
                    nn.Conv2d(current_channels, hidden_dim, kernel_size=1),
                    nn.BatchNorm2d(hidden_dim),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(hidden_dim, hidden_dim, kernel_size=1),
                    nn.BatchNorm2d(hidden_dim),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(hidden_dim, channels, kernel_size=1)
                )
                
                # Position-specific modulation (simple)
                self.position_modulation = nn.Sequential(
                    nn.Conv2d(2, 16, kernel_size=1),  # Process Y and X coordinates
                    nn.ReLU(inplace=True),
                    nn.Conv2d(16, channels, kernel_size=1)
                )
            
            def forward(self, context, pos_encoding):
                """
                context shape: (batch_size, 5 * channels, 1, image_size) - previous rows
                pos_encoding shape: (batch_size, 2, 1, image_size) - Y and X position layers
                Returns: predicted row (batch_size, channels, 1, image_size)
                """
                # Combine context with positional encoding
                x = torch.cat([context, pos_encoding], dim=1)
                
                # Initial feature extraction
                h = self.initial_conv(x)
                
                # Process through convolutional blocks
                for conv_block in self.conv_blocks:
                    h_residual = h
                    h = conv_block(h)
                    h = h + h_residual  # Simple residual connection
                
                # Predict base row
                base_row = self.row_predictor(h)
                
                # Modulate with position information
                pos_mod = self.position_modulation(pos_encoding)
                
                # Combine base prediction with position modulation
                predicted_row = base_row + 0.1 * pos_mod  # Small modulation
                
                # Apply tanh for [-1, 1] range
                return torch.tanh(predicted_row)
        
        # Simple Image Generator
        class SimpleImageGenerator(nn.Module):
            def __init__(self, row_predictor, positional_encoding, image_size, channels):
                super().__init__()
                self.row_predictor = row_predictor
                self.positional_encoding = positional_encoding
                self.image_size = image_size
                self.channels = channels
                
            def forward(self, num_images=1, return_pos_maps=False):
                """
                Generate images auto-regressively row by row
                Returns: generated images (batch_size, channels, image_size, image_size)
                """
                batch_size = num_images
                device = next(self.row_predictor.parameters()).device
                
                # Initialize with zeros
                generated = torch.zeros(batch_size, self.channels, self.image_size, self.image_size).to(device)
                
                # Generate each row sequentially
                with torch.no_grad():
                    for row_idx in range(self.image_size):
                        # Get context rows (up to 5 previous rows)
                        context_rows = []
                        for offset in range(1, 6):  # Look at previous 5 rows
                            prev_row = row_idx - offset
                            if prev_row >= 0:
                                context_rows.append(generated[:, :, prev_row:prev_row+1, :])
                            else:
                                # Pad with zeros for first rows
                                context_rows.append(torch.zeros_like(generated[:, :, 0:1, :]))
                        
                        # Stack context rows along channel dimension
                        context = torch.cat(context_rows, dim=1)  # (batch_size, 5*channels, 1, width)
                        
                        # Get positional encoding for this row
                        pos_encoding = self.positional_encoding(batch_size, height=1)
                        
                        # Predict next row
                        predicted_row = self.row_predictor(context, pos_encoding)
                        
                        # Store the predicted row
                        generated[:, :, row_idx:row_idx+1, :] = predicted_row
                
                if return_pos_maps:
                    # Generate the position maps for visualization
                    y_map = self.positional_encoding.y_coords.expand(batch_size, 1, self.image_size, self.image_size)
                    x_map = self.positional_encoding.x_coords.expand(batch_size, 1, self.image_size, self.image_size)
                    pos_maps = torch.cat([y_map, x_map], dim=1)
                    return generated, pos_maps
                
                return generated
        
        # Create simple models
        self.positional_encoding = SimplePositionalEncoding(image_size)
        self.row_predictor = SimpleRowPredictor(
            image_size, channels, hidden_dim, num_layers, num_filters
        )
        self.generator = SimpleImageGenerator(
            self.row_predictor, self.positional_encoding, image_size, channels
        )
        
        # Simple MSE loss
        self.criterion = nn.MSELoss()
        
        # Optimizer
        self.optimizer = optim.Adam(
            self.row_predictor.parameters(), 
            lr=0.0003, 
            betas=(0.9, 0.999)
        )
        
        # Simple learning rate scheduler
        self.scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer, mode='min', factor=0.5, patience=5, verbose=False
        )
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.positional_encoding.to(self.device)
        self.row_predictor.to(self.device)
        self.generator.to(self.device)
        
        print(f"Using simple positional encoding: Y and X as grayscale layers (0-1 range)")
    
    def train_step(self, images):
        """
        Simple training step
        Returns: loss value
        """
        self.row_predictor.train()
        self.optimizer.zero_grad()
        
        batch_size, channels, height, width = images.shape
        
        # Prepare training data
        total_loss = 0
        rows_predicted = 0
        
        # Process rows in batches
        rows_per_step = min(8, height - 5)
        
        for start_row in range(5, height, rows_per_step):
            end_row = min(start_row + rows_per_step, height)
            
            contexts = []
            targets = []
            pos_encodings = []
            
            for row_idx in range(start_row, end_row):
                # Get context from previous 5 rows
                context_rows = []
                for offset in range(1, 6):
                    context_rows.append(images[:, :, row_idx-offset:row_idx-offset+1, :])
                
                context = torch.cat(context_rows, dim=1)
                target = images[:, :, row_idx:row_idx+1, :]
                
                # Get positional encoding for this row
                pos_encoding = self.positional_encoding(batch_size, height=1)
                
                contexts.append(context)
                targets.append(target)
                pos_encodings.append(pos_encoding)
            
            # Stack
            context_batch = torch.cat(contexts, dim=0)
            target_batch = torch.cat(targets, dim=0)
            pos_batch = torch.cat(pos_encodings, dim=0)
            
            # Forward pass
            predicted_rows = self.row_predictor(context_batch, pos_batch)
            
            # Calculate loss
            loss = self.criterion(predicted_rows, target_batch)
            
            # Backward pass
            loss.backward()
            total_loss += loss.item() * (end_row - start_row)
            rows_predicted += (end_row - start_row)
        
        # Update weights
        torch.nn.utils.clip_grad_norm_(self.row_predictor.parameters(), 1.0)
        self.optimizer.step()
        
        avg_loss = total_loss / rows_predicted if rows_predicted > 0 else 0
        self.scheduler.step(avg_loss)
        
        return avg_loss

# ==================== Dataset ====================

class SimpleImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        # Simple transformations
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class SimplePixelCNNApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Simple Row-Predicting PixelCNN with Position Layers")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Simple settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'hidden_dim': tk.IntVar(value=128),
            'num_layers': tk.IntVar(value=8),
            'num_filters': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=16),
            'learning_rate': tk.DoubleVar(value=0.0003),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'generate_interval': tk.IntVar(value=5),
            'context_rows': tk.IntVar(value=5),
        }
        
        # Performance tracking
        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        
        # For storing generated images
        self.generated_images = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Simple Position-Aware PixelCNN", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Model info display
        info_text = """Image Size: 32x32
Position Encoding: Y + X layers
(Y: 0=top, 1=bottom)
(X: 0=left, 1=right)
Generation: 32 forward passes"""
        self.model_info_label = tk.Label(left_frame, text=info_text, justify=tk.LEFT)
        self.model_info_label.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize Model", 
                 command=self.initialize_model, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Position visualization
        pos_frame = tk.LabelFrame(left_frame, text="Position Visualization", padx=10, pady=10)
        pos_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(pos_frame, text="Show Position Maps", 
                 command=self.show_position_maps, width=20).pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Single image display
        self.single_image_frame = tk.Frame(preview_frame, width=256, height=256, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar
        self.status_label = tk.Label(self.training_tab, text="Ready - Position layers: Y(vertical) + X(horizontal)", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="Simple Position-Aware PixelCNN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Position Encoding Info
        pos_frame = tk.LabelFrame(scrollable_frame, text="Position Encoding", padx=10, pady=10)
        pos_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Simple explanation
        explanation = """Position is encoded as 2 grayscale layers:
- Layer 1: Y position (0=top, 1=bottom)
- Layer 2: X position (0=left, 1=right)

The network sees these alongside the 5 previous rows.
This helps it understand spatial relationships."""
        tk.Label(pos_frame, text=explanation, justify=tk.LEFT, wraplength=500).pack(pady=5)
        
        # Position visualization
        tk.Button(pos_frame, text="Visualize Position Encoding", 
                 command=self.visualize_position_encoding, width=25).pack(pady=10)
        
        # Model Architecture
        net_frame = tk.LabelFrame(scrollable_frame, text="Model Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Fixed image size notice
        tk.Label(net_frame, text="Image Size: 32x32 (Fixed)", 
                fg="blue", font=("Arial", 10, "bold")).pack(pady=5)
        
        # Model parameters
        settings_list = [
            ("Hidden Dimension:", 'hidden_dim', 64, 256),
            ("Number of Layers:", 'num_layers', 4, 16),
            ("Number of Filters:", 'num_filters', 32, 128),
            ("Context Rows:", 'context_rows', 3, 10),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.0001, 0.001),
            ("Batch Size:", 'batch_size', 4, 32),
            ("Number of Workers:", 'num_workers', 1, min(4, multiprocessing.cpu_count())),
            ("Generate Interval:", 'generate_interval', 1, 20),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate']:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=0.0001).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text="Position encoding: 2 grayscale layers (Y=vertical, X=horizontal)", 
                anchor='w', fg="green").pack(fill=tk.X, pady=2)
        
        # Save/Load defaults
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset to Simple", 
                 command=self.reset_to_simple, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation with Position Awareness", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Model Management", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load Model", 
                 command=self.load_model, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=9)
        tk.Scale(gen_frame, from_=1, to=16, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        tk.Button(gen_frame, text="Generate with Position View", 
                 command=self.generate_with_position_view, width=25).pack(pady=5)
        
        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def visualize_position_encoding(self):
        """Visualize the Y and X position encoding layers"""
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        try:
            # Create visualization window
            vis_window = tk.Toplevel(self.root)
            vis_window.title("Position Encoding Visualization")
            vis_window.geometry("500x400")
            
            # Get position maps
            with torch.no_grad():
                y_map = self.model.positional_encoding.y_coords.cpu()
                x_map = self.model.positional_encoding.x_coords.cpu()
                
                # Convert to images
                y_img = (y_map[0, 0] * 255).numpy().astype(np.uint8)
                x_img = (x_map[0, 0] * 255).numpy().astype(np.uint8)
                
                # Create combined visualization
                y_pil = Image.fromarray(y_img, mode='L')
                x_pil = Image.fromarray(x_img, mode='L')
                
                # Resize for display
                y_pil = y_pil.resize((200, 200), Image.Resampling.NEAREST)
                x_pil = x_pil.resize((200, 200), Image.Resampling.NEAREST)
                
                # Convert to PhotoImage
                y_photo = ImageTk.PhotoImage(y_pil)
                x_photo = ImageTk.PhotoImage(x_pil)
                
                # Create labels
                tk.Label(vis_window, text="Y Position (Vertical)", font=("Arial", 10, "bold")).pack(pady=(10, 5))
                y_label = tk.Label(vis_window, image=y_photo)
                y_label.image = y_photo
                y_label.pack()
                
                tk.Label(vis_window, text="X Position (Horizontal)", font=("Arial", 10, "bold")).pack(pady=(10, 5))
                x_label = tk.Label(vis_window, image=x_photo)
                x_label.image = x_photo
                x_label.pack()
            
            self.log_message("Visualized position encoding layers")
            
        except Exception as e:
            self.log_message(f"Error visualizing position encoding: {str(e)}")

    def show_position_maps(self):
        """Show position maps for the current generated image"""
        self.visualize_position_encoding()

    def generate_with_position_view(self):
        """Generate an image and show position influence"""
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        try:
            with torch.no_grad():
                # Generate image with position maps
                generated, pos_maps = self.model.generator(num_images=1, return_pos_maps=True)
                img = self.tensor_to_pil(generated[0].cpu())
                
                # Get position maps
                y_map = pos_maps[0, 0].cpu().numpy()
                x_map = pos_maps[0, 1].cpu().numpy()
                
                # Create visualization window
                vis_window = tk.Toplevel(self.root)
                vis_window.title("Image with Position Influence")
                vis_window.geometry("700x500")
                
                # Main image
                tk.Label(vis_window, text="Generated Image", font=("Arial", 10, "bold")).pack(pady=(10, 5))
                img_display = img.resize((256, 256), Image.Resampling.LANCZOS)
                img_photo = ImageTk.PhotoImage(img_display)
                img_label = tk.Label(vis_window, image=img_photo)
                img_label.image = img_photo
                img_label.pack()
                
                # Position maps row
                pos_frame = tk.Frame(vis_window)
                pos_frame.pack(pady=10)
                
                # Y position
                y_frame = tk.Frame(pos_frame)
                y_frame.pack(side=tk.LEFT, padx=10)
                tk.Label(y_frame, text="Y Position", font=("Arial", 9)).pack()
                y_img = (y_map * 255).astype(np.uint8)
                y_pil = Image.fromarray(y_img, mode='L').resize((100, 100), Image.Resampling.NEAREST)
                y_photo = ImageTk.PhotoImage(y_pil)
                y_label = tk.Label(y_frame, image=y_photo)
                y_label.image = y_photo
                y_label.pack()
                
                # X position
                x_frame = tk.Frame(pos_frame)
                x_frame.pack(side=tk.LEFT, padx=10)
                tk.Label(x_frame, text="X Position", font=("Arial", 9)).pack()
                x_img = (x_map * 255).astype(np.uint8)
                x_pil = Image.fromarray(x_img, mode='L').resize((100, 100), Image.Resampling.NEAREST)
                x_photo = ImageTk.PhotoImage(x_pil)
                x_label = tk.Label(x_frame, image=x_photo)
                x_label.image = x_photo
                x_label.pack()
            
            self.log_message("Generated image with position visualization")
            
        except Exception as e:
            self.log_message(f"Error generating with position view: {str(e)}")

    # ==================== Core Methods ====================
    
    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:60])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_model(self):
        """Initialize simple Row-Predicting PixelCNN with position layers"""
        try:
            image_size = 32
            hidden_dim = self.settings['hidden_dim'].get()
            num_layers = self.settings['num_layers'].get()
            num_filters = self.settings['num_filters'].get()
            
            self.model = RowPixelCNNSimplePosition(
                image_size=image_size,
                channels=3,
                hidden_dim=hidden_dim,
                num_layers=num_layers,
                num_filters=num_filters
            )
            
            self.log_message(f"Initialized Simple Position-Aware PixelCNN")
            self.log_message(f"Position encoding: 2 grayscale layers (Y: vertical, X: horizontal)")
            self.log_message(f"Model predicts each row from {self.settings['context_rows'].get()} previous rows + position")
            self.log_message(f"Hidden dim: {hidden_dim}, Layers: {num_layers}, Filters: {num_filters}")
            
        except Exception as e:
            self.log_message(f"Error initializing model: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            
            # Update optimizer
            for param_group in self.model.optimizer.param_groups:
                param_group['lr'] = lr
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_model,
                args=(epochs, batch_size, num_workers),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Position encoding: Y (0=top,1=bottom) + X (0=left,1=right) layers")
            
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_model(self, epochs, batch_size, num_workers):
        try:
            image_size = 32
            
            # Create dataset
            dataset = SimpleImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available()
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss = 0
                batch_count = 0
                epoch_start = time.time()
                
                for batch_idx, images in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    images = images.to(self.model.device)
                    
                    # Train step
                    loss = self.model.train_step(images)
                    
                    total_loss += loss
                    batch_count += 1
                    
                    if batch_idx % 10 == 0:
                        self.log_message(f"Epoch {epoch+1}, Batch {batch_idx}: Loss = {loss:.4f}")
                
                if batch_count > 0:
                    avg_loss = total_loss / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.4f} | Time: {epoch_time:.1f}s")
                    
                    generate_interval = self.settings['generate_interval'].get()
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_training_samples(self):
        if not self.model:
            return
        
        try:
            with torch.no_grad():
                generated = self.model.generator(num_images=1).cpu()
                img = self.tensor_to_pil(generated[0])
                
                img_display = img.resize((256, 256), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img_display)
                
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                self.generated_images.append(img)
                
                self.log_message(f"Generated sample at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        try:
            with torch.no_grad():
                generated = self.model.generator(num_images=1).cpu()
                img = self.tensor_to_pil(generated[0])
                
                img_display = img.resize((256, 256), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img_display)
                
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                self.generated_images.append(img)
                
                self.log_message("Generated single sample with position awareness")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def save_model(self):
        if not self.model:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'row_predictor_state_dict': self.model.row_predictor.state_dict(),
                    'positional_encoding_state_dict': self.model.positional_encoding.state_dict(),
                    'optimizer_state_dict': self.model.optimizer.state_dict(),
                    'hidden_dim': self.settings['hidden_dim'].get(),
                    'num_layers': self.settings['num_layers'].get(),
                    'num_filters': self.settings['num_filters'].get(),
                }, filename)
                
                self.log_message(f"Simple model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_model(self):
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings
                for key in ['hidden_dim', 'num_layers', 'num_filters']:
                    if key in checkpoint and key in self.settings:
                        self.settings[key].set(checkpoint[key])
                
                # Initialize model
                self.initialize_model()
                
                # Load state dicts
                self.model.row_predictor.load_state_dict(checkpoint['row_predictor_state_dict'])
                self.model.positional_encoding.load_state_dict(checkpoint['positional_encoding_state_dict'])
                
                if 'optimizer_state_dict' in checkpoint:
                    self.model.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                
                self.log_message(f"Loaded simple model from {filename}")
                self.log_message(f"Trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            
            with torch.no_grad():
                generated = self.model.generator(num_images=num_images).cpu()
            
            # Clear previous
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            # Create grid
            cols = 3
            rows = (num_images + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img = self.tensor_to_pil(generated[idx])
                        img_display = img.resize((128, 128), Image.Resampling.LANCZOS)
                        photo = ImageTk.PhotoImage(img_display)
                        
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            
            self.log_message(f"Generated {num_images} images with Y+X position layers")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def save_defaults(self):
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('simple_pixelcnn_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Simple settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        try:
            import json
            if os.path.exists('simple_pixelcnn_defaults.json'):
                with open('simple_pixelcnn_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.log_message("Loaded simple defaults")
            else:
                self.log_message("No simple defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_to_simple(self):
        """Reset to simple defaults"""
        simple_settings = {
            'image_size': 32,
            'hidden_dim': 128,
            'num_layers': 8,
            'num_filters': 64,
            'batch_size': 16,
            'learning_rate': 0.0003,
            'num_workers': min(4, multiprocessing.cpu_count()),
            'generate_interval': 5,
            'context_rows': 5,
        }
        
        for key, value in simple_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        
        self.log_message("Reset to simple position-aware settings")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Simple Row-Predicting PixelCNN with Position Layers...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = SimplePixelCNNApp(root)
    root.mainloop()