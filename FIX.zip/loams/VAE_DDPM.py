# File: LatentDiffusion.py
import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import math
from pathlib import Path
import json

# ==================== VAE for Latent Compression ====================

class LatentVAE:
    def __init__(self, image_size=32, latent_size=16, latent_channels=1, hidden_dim=256):
        self.image_size = image_size
        self.latent_size = latent_size  # e.g., 16 for 16x16 latents
        self.latent_channels = latent_channels  # 1 for grayscale latents
        self.hidden_dim = hidden_dim
        
        # Set device
        torch.set_num_threads(multiprocessing.cpu_count())
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        
        # Encoder: Image (3x32x32) -> Latent (1x16x16)
        class Encoder(nn.Module):
            def __init__(self, image_size, latent_size, latent_channels, hidden_dim):
                super().__init__()
                self.latent_size = latent_size
                
                # Compression ratio calculation
                # From 32x32 to 16x16: 2^2 = 4x spatial compression
                # Plus going from 3 channels to 1: 3x channel compression
                # Total compression: 12x (actually more with downsampling)
                
                self.encoder = nn.Sequential(
                    # Input: 3 x 32 x 32
                    nn.Conv2d(3, 32, kernel_size=4, stride=2, padding=1),  # 32 x 16 x 16
                    nn.BatchNorm2d(32),
                    nn.ReLU(),
                    
                    nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),  # 64 x 16 x 16
                    nn.BatchNorm2d(64),
                    nn.ReLU(),
                    
                    nn.Conv2d(64, 32, kernel_size=3, stride=1, padding=1),  # 32 x 16 x 16
                    nn.BatchNorm2d(32),
                    nn.ReLU(),
                    
                    nn.Conv2d(32, latent_channels, kernel_size=1, stride=1, padding=0),  # 1 x 16 x 16
                    nn.Tanh()  # Output in [-1, 1]
                )
                
                # For KL divergence if needed (optional)
                self.fc_mu = nn.Linear(latent_size * latent_size * latent_channels, 
                                       latent_size * latent_size * latent_channels)
                self.fc_logvar = nn.Linear(latent_size * latent_size * latent_channels, 
                                          latent_size * latent_size * latent_channels)
                
            def forward(self, x):
                # Direct deterministic encoding (can add stochasticity later)
                z = self.encoder(x)
                
                # Flatten for KL if needed
                z_flat = z.view(z.size(0), -1)
                mu = self.fc_mu(z_flat)
                logvar = self.fc_logvar(z_flat)
                
                return z, mu, logvar
        
        # Decoder: Latent (1x16x16) -> Image (3x32x32)
        class Decoder(nn.Module):
            def __init__(self, image_size, latent_size, latent_channels, hidden_dim):
                super().__init__()
                
                self.decoder = nn.Sequential(
                    # Input: latent_channels x latent_size x latent_size
                    nn.Conv2d(latent_channels, 32, kernel_size=3, stride=1, padding=1),  # 32 x 16 x 16
                    nn.BatchNorm2d(32),
                    nn.ReLU(),
                    
                    nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),  # 64 x 16 x 16
                    nn.BatchNorm2d(64),
                    nn.ReLU(),
                    
                    # Upsample to 32x32
                    nn.Upsample(scale_factor=2, mode='nearest'),  # 64 x 32 x 32
                    nn.Conv2d(64, 32, kernel_size=3, stride=1, padding=1),  # 32 x 32 x 32
                    nn.BatchNorm2d(32),
                    nn.ReLU(),
                    
                    nn.Conv2d(32, 16, kernel_size=3, stride=1, padding=1),  # 16 x 32 x 32
                    nn.BatchNorm2d(16),
                    nn.ReLU(),
                    
                    nn.Conv2d(16, 3, kernel_size=3, stride=1, padding=1),  # 3 x 32 x 32
                    nn.Tanh()
                )
                
            def forward(self, z):
                return self.decoder(z)
        
        self.encoder_model = Encoder(image_size, latent_size, latent_channels, hidden_dim).to(self.device)
        self.decoder_model = Decoder(image_size, latent_size, latent_channels, hidden_dim).to(self.device)
        
        # Optimizer
        self.optimizer = optim.Adam(
            list(self.encoder_model.parameters()) + list(self.decoder_model.parameters()),
            lr=0.0005,
            betas=(0.9, 0.999)
        )
        
        # Simple reconstruction loss (MSE)
        self.criterion = nn.MSELoss()
    
    def encode(self, images):
        """Encode images to latents"""
        with torch.no_grad():
            z, mu, logvar = self.encoder_model(images)
        return z
    
    def decode(self, latents):
        """Decode latents to images"""
        with torch.no_grad():
            images = self.decoder_model(latents)
        return images
    
    def reparameterize(self, mu, logvar):
        """Reparameterization trick for VAE"""
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std
    
    def vae_loss(self, recon_x, x, mu, logvar, kl_weight=0.0001):
        """VAE loss = Reconstruction + KL"""
        recon_loss = self.criterion(recon_x, x)
        kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp()) / x.size(0)
        return recon_loss + kl_weight * kl_loss, recon_loss, kl_loss

# ==================== DDPM for Latent Denoising ====================

class LatentDDPM:
    def __init__(self, latent_size=16, latent_channels=1, nf=64, timesteps=100):
        self.latent_size = latent_size
        self.latent_channels = latent_channels
        self.timesteps = timesteps
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Pre-compute noise schedule (same as standard DDPM)
        self.betas = torch.linspace(1e-4, 0.02, timesteps).to(self.device)
        self.alphas = 1. - self.betas
        self.alpha_cumprod = torch.cumprod(self.alphas, dim=0)
        self.sqrt_alpha_cumprod = torch.sqrt(self.alpha_cumprod)
        self.sqrt_one_minus_alpha_cumprod = torch.sqrt(1. - self.alpha_cumprod)
        
        # Reverse process parameters
        self.sqrt_recip_alphas = torch.sqrt(1.0 / self.alphas)
        self.alphas_cumprod_prev = torch.cat([torch.tensor([1.0]).to(self.device), self.alpha_cumprod[:-1]])
        self.posterior_variance = self.betas * (1. - self.alphas_cumprod_prev) / (1. - self.alpha_cumprod)
        
        # U-Net for latent denoising (grayscale 16x16)
        class UNet(nn.Module):
            def __init__(self, in_channels=1, nf=64, timesteps=100):
                super().__init__()
                self.timesteps = timesteps
                
                # Timestep embedding
                self.time_embed = nn.Sequential(
                    nn.Linear(1, nf * 4),
                    nn.ReLU(),
                    nn.Linear(nf * 4, nf * 4)
                )
                
                # Encoder
                self.enc1 = nn.Sequential(
                    nn.Conv2d(in_channels, nf, 3, 1, 1),
                    nn.BatchNorm2d(nf),
                    nn.ReLU(),
                    nn.Conv2d(nf, nf, 3, 1, 1),
                    nn.BatchNorm2d(nf),
                    nn.ReLU()
                )
                
                self.pool1 = nn.MaxPool2d(2)  # 16x16 -> 8x8
                
                self.enc2 = nn.Sequential(
                    nn.Conv2d(nf, nf * 2, 3, 1, 1),
                    nn.BatchNorm2d(nf * 2),
                    nn.ReLU(),
                    nn.Conv2d(nf * 2, nf * 2, 3, 1, 1),
                    nn.BatchNorm2d(nf * 2),
                    nn.ReLU()
                )
                
                self.pool2 = nn.MaxPool2d(2)  # 8x8 -> 4x4
                
                # Bottleneck
                self.bottleneck = nn.Sequential(
                    nn.Conv2d(nf * 2, nf * 4, 3, 1, 1),
                    nn.BatchNorm2d(nf * 4),
                    nn.ReLU(),
                    nn.Conv2d(nf * 4, nf * 4, 3, 1, 1),
                    nn.BatchNorm2d(nf * 4),
                    nn.ReLU()
                )
                
                # Decoder
                self.up2 = nn.ConvTranspose2d(nf * 4, nf * 2, 2, 2)  # 4x4 -> 8x8
                self.dec2 = nn.Sequential(
                    nn.Conv2d(nf * 4, nf * 2, 3, 1, 1),
                    nn.BatchNorm2d(nf * 2),
                    nn.ReLU(),
                    nn.Conv2d(nf * 2, nf * 2, 3, 1, 1),
                    nn.BatchNorm2d(nf * 2),
                    nn.ReLU()
                )
                
                self.up1 = nn.ConvTranspose2d(nf * 2, nf, 2, 2)  # 8x8 -> 16x16
                self.dec1 = nn.Sequential(
                    nn.Conv2d(nf * 2, nf, 3, 1, 1),
                    nn.BatchNorm2d(nf),
                    nn.ReLU(),
                    nn.Conv2d(nf, in_channels, 3, 1, 1)  # Back to 1 channel
                )
                
            def forward(self, x, t):
                # Normalize timestep
                t_norm = t.float() / self.timesteps
                t_norm = t_norm.view(-1, 1)
                
                # Time embedding
                time_feat = self.time_embed(t_norm)
                time_feat = time_feat.view(-1, time_feat.size(1), 1, 1)
                
                # Encoder
                enc1_out = self.enc1(x)
                pool1_out = self.pool1(enc1_out)
                
                enc2_out = self.enc2(pool1_out)
                pool2_out = self.pool2(enc2_out)
                
                # Bottleneck with time conditioning
                bottleneck_out = self.bottleneck(pool2_out)
                
                # Expand and add time feature
                _, _, h, w = bottleneck_out.shape
                time_feat_expanded = nn.functional.interpolate(
                    time_feat, size=(h, w), mode='nearest'
                )
                bottleneck_out = bottleneck_out + time_feat_expanded[:, :bottleneck_out.size(1), :, :]
                
                # Decoder with skip connections
                up2_out = self.up2(bottleneck_out)
                up2_out = nn.functional.interpolate(up2_out, size=enc2_out.shape[2:], mode='nearest')
                dec2_in = torch.cat([up2_out, enc2_out], dim=1)
                dec2_out = self.dec2(dec2_in)
                
                up1_out = self.up1(dec2_out)
                up1_out = nn.functional.interpolate(up1_out, size=enc1_out.shape[2:], mode='nearest')
                dec1_in = torch.cat([up1_out, enc1_out], dim=1)
                output = self.dec1(dec1_in)
                
                return output
        
        self.unet = UNet(in_channels=latent_channels, nf=nf, timesteps=timesteps).to(self.device)
        
        # Loss and optimizer
        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(self.unet.parameters(), lr=0.0001, betas=(0.5, 0.999))
    
    def add_noise(self, x, t):
        """Add noise to latents at timestep t"""
        noise = torch.randn_like(x)
        sqrt_alpha_cumprod_t = self.sqrt_alpha_cumprod[t].view(-1, 1, 1, 1)
        sqrt_one_minus_alpha_cumprod_t = self.sqrt_one_minus_alpha_cumprod[t].view(-1, 1, 1, 1)
        
        noisy_x = sqrt_alpha_cumprod_t * x + sqrt_one_minus_alpha_cumprod_t * noise
        return noisy_x, noise
    
    def predict_noise(self, x, t):
        """Predict noise in noisy latents"""
        if t.dim() == 0:
            t = t.unsqueeze(0)
        return self.unet(x, t)

# ==================== Combined Latent Diffusion ====================

class LatentDiffusionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Latent Diffusion: VAE + DDPM")
        self.root.geometry("1200x800")
        
        # Models
        self.vae = None
        self.ddpm = None
        
        # Training parameters
        self.vae_images = []
        self.ddpm_images = []
        self.vae_training = False
        self.ddpm_training = False
        self.current_vae_epoch = 0
        self.current_ddpm_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'vae_latent_size': tk.IntVar(value=16),
            'vae_latent_channels': tk.IntVar(value=1),
            'vae_hidden_dim': tk.IntVar(value=256),
            'ddpm_nf': tk.IntVar(value=64),
            'ddpm_timesteps': tk.IntVar(value=100),
            'vae_batch_size': tk.IntVar(value=16),
            'ddpm_batch_size': tk.IntVar(value=8),
            'vae_learning_rate': tk.DoubleVar(value=0.0005),
            'ddpm_learning_rate': tk.DoubleVar(value=0.0001),
            'kl_weight': tk.DoubleVar(value=0.0001)
        }
        
        # Sampling settings
        self.sampling_settings = {
            'sampling_steps': tk.IntVar(value=50),
            'sampling_noise': tk.DoubleVar(value=0.05),
            'num_generated': tk.IntVar(value=4)
        }
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)
    
    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: VAE Training
        self.vae_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.vae_tab, text='VAE Training')
        self.setup_vae_tab()
        
        # Tab 2: DDPM Training
        self.ddpm_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.ddpm_tab, text='DDPM Training')
        self.setup_ddpm_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()
        
        # Tab 4: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
    
    def setup_vae_tab(self):
        main_frame = tk.Frame(self.vae_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        tk.Label(left_frame, text="VAE Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="VAE Training Images", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_frame, text="Add VAE Images", 
                 command=self.add_vae_images, width=20).pack(pady=5)
        tk.Button(img_frame, text="Clear VAE Images", 
                 command=self.clear_vae_images, width=20).pack(pady=5)
        
        self.vae_listbox = tk.Listbox(img_frame, height=6)
        self.vae_listbox.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="VAE Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize VAE", 
                 command=self.initialize_vae, width=20).pack(pady=5)
        
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.vae_epochs_var = tk.StringVar(value="50")
        tk.Entry(epoch_frame, textvariable=self.vae_epochs_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start VAE Training", 
                 command=self.start_vae_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop VAE Training", 
                 command=self.stop_vae_training, width=20, bg="salmon").pack(pady=5)
        
        # Test VAE
        test_frame = tk.LabelFrame(left_frame, text="Test VAE", padx=10, pady=10)
        test_frame.pack(fill=tk.X)
        
        tk.Button(test_frame, text="Load & Encode Test Image", 
                 command=self.test_vae_encode, width=20).pack(pady=5)
        tk.Button(test_frame, text="Save VAE", 
                 command=self.save_vae, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Original/Reconstruction display
        comp_frame = tk.LabelFrame(right_frame, text="VAE Reconstruction", padx=10, pady=10)
        comp_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Two side-by-side frames
        preview_frame = tk.Frame(comp_frame)
        preview_frame.pack(pady=10)
        
        self.orig_frame = tk.Frame(preview_frame, width=150, height=150, bg='gray')
        self.orig_frame.pack(side=tk.LEFT, padx=10)
        self.orig_frame.pack_propagate(False)
        self.orig_label = tk.Label(self.orig_frame, text="Original", bg='gray')
        self.orig_label.pack(fill=tk.BOTH, expand=True)
        
        self.recon_frame = tk.Frame(preview_frame, width=150, height=150, bg='gray')
        self.recon_frame.pack(side=tk.LEFT, padx=10)
        self.recon_frame.pack_propagate(False)
        self.recon_label = tk.Label(self.recon_frame, text="Reconstruction", bg='gray')
        self.recon_label.pack(fill=tk.BOTH, expand=True)
        
        # Latent display (grayscale)
        latent_frame = tk.LabelFrame(comp_frame, text="Latent Space (16x16 Grayscale)", padx=10, pady=10)
        latent_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.latent_frame = tk.Frame(latent_frame, width=160, height=160, bg='gray')
        self.latent_frame.pack(pady=5)
        self.latent_frame.pack_propagate(False)
        self.latent_label = tk.Label(self.latent_frame, text="Latent", bg='gray')
        self.latent_label.pack(fill=tk.BOTH, expand=True)
        
        # Log
        log_frame = tk.LabelFrame(right_frame, text="VAE Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.vae_log_text = tk.Text(log_frame, height=10, font=("Courier", 9))
        self.vae_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.vae_log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.vae_log_text.config(yscrollcommand=scrollbar.set)
        
        # Status
        self.vae_status = tk.Label(self.vae_tab, text="VAE: Ready", 
                                  relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.vae_status.pack(side=tk.BOTTOM, fill=tk.X)
    
    def setup_ddpm_tab(self):
        main_frame = tk.Frame(self.ddpm_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        tk.Label(left_frame, text="DDPM Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Note about needing trained VAE
        tk.Label(left_frame, text="Note: Train VAE first!", 
                fg="red", font=("Arial", 10, "bold")).pack(pady=(0, 10))
        
        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="DDPM Training Images", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_frame, text="Add DDPM Images", 
                 command=self.add_ddpm_images, width=20).pack(pady=5)
        tk.Button(img_frame, text="Clear DDPM Images", 
                 command=self.clear_ddpm_images, width=20).pack(pady=5)
        
        self.ddpm_listbox = tk.Listbox(img_frame, height=6)
        self.ddpm_listbox.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="DDPM Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize DDPM", 
                 command=self.initialize_ddpm, width=20).pack(pady=5)
        
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.ddpm_epochs_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.ddpm_epochs_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start DDPM Training", 
                 command=self.start_ddpm_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop DDPM Training", 
                 command=self.stop_ddpm_training, width=20, bg="salmon").pack(pady=5)
        
        # Save/Load
        save_frame = tk.LabelFrame(left_frame, text="Model Operations", padx=10, pady=10)
        save_frame.pack(fill=tk.X)
        
        tk.Button(save_frame, text="Load VAE", 
                 command=self.load_vae, width=20).pack(pady=5)
        tk.Button(save_frame, text="Save DDPM", 
                 command=self.save_ddpm, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Info display
        info_frame = tk.LabelFrame(right_frame, text="Latent Diffusion Info", padx=10, pady=10)
        info_frame.pack(fill=tk.X, pady=(0, 10))
        
        info_text = """Training Process:
1. VAE encodes images to 16x16 grayscale latents
2. DDPM learns to denoise these latents
3. Generation: Random latent → DDPM denoises → VAE decodes

Compression: 32x32x3 (3072 values) → 16x16x1 (256 values)
12x smaller! Faster training & generation."""
        
        tk.Label(info_frame, text=info_text, justify=tk.LEFT, 
                font=("Courier", 9)).pack(pady=10)
        
        # Training samples display
        sample_frame = tk.LabelFrame(right_frame, text="DDPM Training Samples", padx=10, pady=10)
        sample_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.ddpm_sample_frame = tk.Frame(sample_frame, width=200, height=200, bg='gray')
        self.ddpm_sample_frame.pack(pady=10)
        self.ddpm_sample_frame.pack_propagate(False)
        self.ddpm_sample_label = tk.Label(self.ddpm_sample_frame, text="Training samples appear here", bg='gray')
        self.ddpm_sample_label.pack(fill=tk.BOTH, expand=True)
        
        # Log
        log_frame = tk.LabelFrame(right_frame, text="DDPM Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.ddpm_log_text = tk.Text(log_frame, height=10, font=("Courier", 9))
        self.ddpm_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.ddpm_log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.ddpm_log_text.config(yscrollcommand=scrollbar.set)
        
        # Status
        self.ddpm_status = tk.Label(self.ddpm_tab, text="DDPM: Ready", 
                                   relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.ddpm_status.pack(side=tk.BOTTOM, fill=tk.X)
    
    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Latent Diffusion Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Info
        info_frame = tk.LabelFrame(main_frame, text="Generation Pipeline", padx=10, pady=10)
        info_frame.pack(fill=tk.X, pady=(0, 20))
        
        pipeline_text = """Generation Steps:
1. Generate random noise (16x16x1 grayscale tensor)
2. DDPM denoises the latent over multiple steps
3. VAE decoder converts clean latent to 32x32x3 image

This is 12x faster than pixel-space diffusion!"""
        
        tk.Label(info_frame, text=pipeline_text, justify=tk.LEFT).pack(pady=10)
        
        # Controls
        controls_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        controls_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Parameters
        params_frame = tk.Frame(controls_frame)
        params_frame.pack(pady=10)
        
        tk.Label(params_frame, text="Number of Images:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
        tk.Scale(params_frame, from_=1, to=16, variable=self.sampling_settings['num_generated'],
                orient=tk.HORIZONTAL, length=150).grid(row=0, column=1, padx=5, pady=5)
        tk.Label(params_frame, textvariable=self.sampling_settings['num_generated'], 
                width=5).grid(row=0, column=2, padx=5)
        
        tk.Label(params_frame, text="Denoising Steps:").grid(row=1, column=0, padx=5, pady=5, sticky='w')
        tk.Scale(params_frame, from_=10, to=200, variable=self.sampling_settings['sampling_steps'],
                orient=tk.HORIZONTAL, length=150).grid(row=1, column=1, padx=5, pady=5)
        tk.Label(params_frame, textvariable=self.sampling_settings['sampling_steps'], 
                width=5).grid(row=1, column=2, padx=5)
        
        # Buttons
        btn_frame = tk.Frame(controls_frame)
        btn_frame.pack(pady=10)
        
        tk.Button(btn_frame, text="Generate Images", 
                 command=self.generate_images, width=20, bg="lightblue").pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Both Models", 
                 command=self.load_both_models, width=20).pack(side=tk.LEFT, padx=5)
        
        # Results display
        results_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        results_frame.pack(fill=tk.BOTH, expand=True)
        
        # Canvas for scrolling
        self.gen_canvas = tk.Canvas(results_frame, bg='white')
        scrollbar = tk.Scrollbar(results_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Status
        self.gen_status = tk.Label(self.generate_tab, text="Ready to generate", 
                                  relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.gen_status.pack(side=tk.BOTTOM, fill=tk.X)
    
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="Latent Diffusion Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # VAE settings
        vae_frame = tk.LabelFrame(scrollable_frame, text="VAE Settings", padx=10, pady=10)
        vae_frame.pack(fill=tk.X, pady=(0, 10))
        
        vae_settings = [
            ("Image Size:", 'image_size', 32, 32, 0),  # Fixed at 32
            ("Latent Size:", 'vae_latent_size', 8, 32, 1),
            ("Latent Channels:", 'vae_latent_channels', 1, 4, 1),
            ("Hidden Dim:", 'vae_hidden_dim', 128, 512, 1),
            ("Batch Size:", 'vae_batch_size', 1, 32, 1),
            ("Learning Rate:", 'vae_learning_rate', 0.0001, 0.001, 5),
            ("KL Weight:", 'kl_weight', 0.0, 0.001, 5)
        ]
        
        for i, (label_text, var_name, min_val, max_val, res) in enumerate(vae_settings):
            frame = tk.Frame(vae_frame)
            frame.pack(fill=tk.X, pady=2)
            tk.Label(frame, text=label_text, width=20, anchor='w').pack(side=tk.LEFT)
            
            if res > 0:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=10**-res).pack(side=tk.RIGHT)
            else:
                tk.Label(frame, text=f"{min_val}x{min_val} (fixed)", width=10).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # DDPM settings
        ddpm_frame = tk.LabelFrame(scrollable_frame, text="DDPM Settings", padx=10, pady=10)
        ddpm_frame.pack(fill=tk.X, pady=(0, 10))
        
        ddpm_settings = [
            ("Network Features:", 'ddpm_nf', 32, 256, 1),
            ("Timesteps:", 'ddpm_timesteps', 10, 1000, 1),
            ("Batch Size:", 'ddpm_batch_size', 1, 16, 1),
            ("Learning Rate:", 'ddpm_learning_rate', 0.00001, 0.001, 5),
        ]
        
        for i, (label_text, var_name, min_val, max_val, res) in enumerate(ddpm_settings):
            frame = tk.Frame(ddpm_frame)
            frame.pack(fill=tk.X, pady=2)
            tk.Label(frame, text=label_text, width=20, anchor='w').pack(side=tk.LEFT)
            
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                    orient=tk.HORIZONTAL, length=200, resolution=10**-res).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Compression info
        comp_info = """Compression Stats:
Input: 32x32x3 RGB = 3072 values
Latent: 16x16x1 Grayscale = 256 values
Compression: 12x smaller
Memory: ~12x less, Speed: ~12x faster"""
        
        tk.Label(sys_frame, text=comp_info, anchor='w', justify=tk.LEFT, 
                font=("Courier", 8)).pack(fill=tk.X, pady=5)
        
        # Save/Load defaults
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save Defaults", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
    # ==================== Utility Methods ====================
    
    def log_message(self, message, tab="both"):
        """Thread-safe logging"""
        self.message_queue.put((message, tab))
    
    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message, tab = self.message_queue.get_nowait()
                
                # Add to appropriate log
                if tab in ["vae", "both"]:
                    self.vae_log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                    self.vae_log_text.see(tk.END)
                    self.vae_status.config(text=f"VAE: {message[:30]}...")
                
                if tab in ["ddpm", "both"]:
                    self.ddpm_log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                    self.ddpm_log_text.see(tk.END)
                    self.ddpm_status.config(text=f"DDPM: {message[:30]}...")
                
                if tab == "gen":
                    self.gen_status.config(text=message[:40])
                
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        img = (tensor + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img
    
    def tensor_to_grayscale_pil(self, tensor):
        """Convert grayscale tensor to PIL Image"""
        # Tensor shape: (1, H, W)
        img = (tensor.squeeze(0) + 1) / 2  # Denormalize
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img.unsqueeze(0) if img.dim() == 2 else img)
        return img
    
    # ==================== VAE Methods ====================
    
    def add_vae_images(self):
        """Add images for VAE training"""
        files = filedialog.askopenfilenames(
            title="Select VAE training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.vae_images:
                self.vae_images.append(file)
                self.vae_listbox.insert(tk.END, os.path.basename(file))
        
        self.log_message(f"Added {len(files)} images to VAE training set. Total: {len(self.vae_images)}", "vae")
    
    def clear_vae_images(self):
        """Clear VAE training images"""
        self.vae_images = []
        self.vae_listbox.delete(0, tk.END)
        self.log_message("Cleared all VAE training images", "vae")
    
    def initialize_vae(self):
        """Initialize VAE model"""
        try:
            self.vae = LatentVAE(
                image_size=self.settings['image_size'].get(),
                latent_size=self.settings['vae_latent_size'].get(),
                latent_channels=self.settings['vae_latent_channels'].get(),
                hidden_dim=self.settings['vae_hidden_dim'].get()
            )
            
            self.log_message(f"Initialized VAE: {self.settings['image_size'].get()}x{self.settings['image_size'].get()} -> "
                           f"{self.settings['vae_latent_size'].get()}x{self.settings['vae_latent_size'].get()}x{self.settings['vae_latent_channels'].get()}", "vae")
            self.log_message(f"Compression: 3072 values -> {self.settings['vae_latent_size'].get()**2 * self.settings['vae_latent_channels'].get()} values", "vae")
            
        except Exception as e:
            self.log_message(f"Error initializing VAE: {str(e)}", "vae")
    
    def start_vae_training(self):
        """Start VAE training"""
        if not self.vae_images:
            self.log_message("Error: No VAE training images!", "vae")
            return
        
        if not self.vae:
            self.log_message("Error: VAE not initialized!", "vae")
            return
        
        if self.vae_training:
            self.log_message("VAE training already in progress!", "vae")
            return
        
        try:
            epochs = int(self.vae_epochs_var.get())
            self.vae_training = True
            self.current_vae_epoch = 0
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_vae,
                args=(epochs,),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started VAE training for {epochs} epochs", "vae")
            
        except Exception as e:
            self.log_message(f"Error starting VAE training: {str(e)}", "vae")
    
    def train_vae(self, epochs):
        """VAE training loop"""
        try:
            batch_size = self.settings['vae_batch_size'].get()
            image_size = self.settings['image_size'].get()
            kl_weight = self.settings['kl_weight'].get()
            
            # Create transform
            transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            start_time = time.time()
            
            for epoch in range(epochs):
                if not self.vae_training:
                    break
                
                self.current_vae_epoch = epoch
                epoch_loss = 0
                num_batches = 0
                
                # Shuffle images
                shuffled_images = self.vae_images.copy()
                import random
                random.shuffle(shuffled_images)
                
                # Process in batches
                for i in range(0, len(shuffled_images), batch_size):
                    if not self.vae_training:
                        break
                    
                    batch_files = shuffled_images[i:i+batch_size]
                    batch_tensors = []
                    
                    # Load and transform batch
                    for file in batch_files:
                        try:
                            img = Image.open(file).convert('RGB')
                            batch_tensors.append(transform(img))
                        except:
                            continue
                    
                    if not batch_tensors:
                        continue
                    
                    # Stack batch
                    batch = torch.stack(batch_tensors).to(self.vae.device)
                    
                    # Forward pass
                    self.vae.optimizer.zero_grad()
                    z, mu, logvar = self.vae.encoder_model(batch)
                    recon = self.vae.decoder_model(z)
                    
                    # Compute loss
                    loss, recon_loss, kl_loss = self.vae.vae_loss(recon, batch, mu, logvar, kl_weight)
                    
                    # Backward pass
                    loss.backward()
                    self.vae.optimizer.step()
                    
                    epoch_loss += loss.item()
                    num_batches += 1
                
                # Log progress
                if num_batches > 0:
                    avg_loss = epoch_loss / num_batches
                    elapsed = time.time() - start_time
                    self.log_message(f"VAE Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s", "vae")
                    
                    # Show sample every 5 epochs
                    if (epoch + 1) % 5 == 0 and shuffled_images:
                        self.show_vae_sample(shuffled_images[0])
            
            self.vae_training = False
            self.log_message("VAE training completed!", "vae")
            
        except Exception as e:
            self.log_message(f"VAE training error: {str(e)}", "vae")
            self.vae_training = False
    
    def show_vae_sample(self, image_path):
        """Show VAE reconstruction sample"""
        if not self.vae:
            return
        
        try:
            transform = transforms.Compose([
                transforms.Resize((self.settings['image_size'].get(), 
                                 self.settings['image_size'].get())),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            # Load and encode image
            img = Image.open(image_path).convert('RGB')
            img_tensor = transform(img).unsqueeze(0).to(self.vae.device)
            
            with torch.no_grad():
                z, _, _ = self.vae.encoder_model(img_tensor)
                recon = self.vae.decoder_model(z)
            
            # Convert to PIL
            orig_img = self.tensor_to_pil(img_tensor[0].cpu())
            recon_img = self.tensor_to_pil(recon[0].cpu())
            latent_img = self.tensor_to_grayscale_pil(z[0].cpu())
            
            # Resize for display
            orig_display = orig_img.resize((150, 150), Image.Resampling.NEAREST)
            recon_display = recon_img.resize((150, 150), Image.Resampling.NEAREST)
            latent_display = latent_img.resize((160, 160), Image.Resampling.NEAREST)
            
            # Update display
            orig_photo = ImageTk.PhotoImage(orig_display)
            recon_photo = ImageTk.PhotoImage(recon_display)
            latent_photo = ImageTk.PhotoImage(latent_display)
            
            self.orig_label.config(image=orig_photo, text="")
            self.orig_label.image = orig_photo
            self.recon_label.config(image=recon_photo, text="")
            self.recon_label.image = recon_photo
            self.latent_label.config(image=latent_photo, text="")
            self.latent_label.image = latent_photo
            
        except Exception as e:
            self.log_message(f"Error showing VAE sample: {str(e)}", "vae")
    
    def stop_vae_training(self):
        """Stop VAE training"""
        if self.vae_training:
            self.vae_training = False
            self.log_message("VAE training stopped", "vae")
    
    def test_vae_encode(self):
        """Test VAE encoding/decoding"""
        if not self.vae:
            self.log_message("Error: VAE not initialized!", "vae")
            return
        
        filename = filedialog.askopenfilename(
            title="Select test image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if filename:
            try:
                transform = transforms.Compose([
                    transforms.Resize((self.settings['image_size'].get(), 
                                     self.settings['image_size'].get())),
                    transforms.ToTensor(),
                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
                ])
                
                img = Image.open(filename).convert('RGB')
                img_tensor = transform(img).unsqueeze(0).to(self.vae.device)
                
                with torch.no_grad():
                    z, _, _ = self.vae.encoder_model(img_tensor)
                    recon = self.vae.decoder_model(z)
                
                # Convert to PIL
                orig_img = self.tensor_to_pil(img_tensor[0].cpu())
                recon_img = self.tensor_to_pil(recon[0].cpu())
                latent_img = self.tensor_to_grayscale_pil(z[0].cpu())
                
                # Display
                orig_display = orig_img.resize((150, 150), Image.Resampling.NEAREST)
                recon_display = recon_img.resize((150, 150), Image.Resampling.NEAREST)
                latent_display = latent_img.resize((160, 160), Image.Resampling.NEAREST)
                
                orig_photo = ImageTk.PhotoImage(orig_display)
                recon_photo = ImageTk.PhotoImage(recon_display)
                latent_photo = ImageTk.PhotoImage(latent_display)
                
                self.orig_label.config(image=orig_photo, text="")
                self.orig_label.image = orig_photo
                self.recon_label.config(image=recon_photo, text="")
                self.recon_label.image = recon_photo
                self.latent_label.config(image=latent_photo, text="")
                self.latent_label.image = latent_photo
                
                self.log_message(f"Tested VAE on {os.path.basename(filename)}", "vae")
                
            except Exception as e:
                self.log_message(f"Error testing VAE: {str(e)}", "vae")
    
    def save_vae(self):
        """Save VAE model"""
        if not self.vae:
            self.log_message("Error: No VAE to save!", "vae")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_vae_epoch,
                    'encoder_state_dict': self.vae.encoder_model.state_dict(),
                    'decoder_state_dict': self.vae.decoder_model.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_size': self.settings['vae_latent_size'].get(),
                    'latent_channels': self.settings['vae_latent_channels'].get(),
                    'hidden_dim': self.settings['vae_hidden_dim'].get()
                }, filename)
                
                self.log_message(f"VAE saved to {filename}", "vae")
                
            except Exception as e:
                self.log_message(f"Error saving VAE: {str(e)}", "vae")
    
    # ==================== DDPM Methods ====================
    
    def add_ddpm_images(self):
        """Add images for DDPM training"""
        files = filedialog.askopenfilenames(
            title="Select DDPM training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.ddpm_images:
                self.ddpm_images.append(file)
                self.ddpm_listbox.insert(tk.END, os.path.basename(file))
        
        self.log_message(f"Added {len(files)} images to DDPM training set. Total: {len(self.ddpm_images)}", "ddpm")
    
    def clear_ddpm_images(self):
        """Clear DDPM training images"""
        self.ddpm_images = []
        self.ddpm_listbox.delete(0, tk.END)
        self.log_message("Cleared all DDPM training images", "ddpm")
    
    def initialize_ddpm(self):
        """Initialize DDPM model"""
        try:
            self.ddpm = LatentDDPM(
                latent_size=self.settings['vae_latent_size'].get(),
                latent_channels=self.settings['vae_latent_channels'].get(),
                nf=self.settings['ddpm_nf'].get(),
                timesteps=self.settings['ddpm_timesteps'].get()
            )
            
            self.log_message(f"Initialized DDPM for {self.settings['vae_latent_size'].get()}x{self.settings['vae_latent_size'].get()}x{self.settings['vae_latent_channels'].get()} latents", "ddpm")
            self.log_message(f"Denoising {self.settings['ddpm_timesteps'].get()} timesteps", "ddpm")
            
        except Exception as e:
            self.log_message(f"Error initializing DDPM: {str(e)}", "ddpm")
    
    def start_ddpm_training(self):
        """Start DDPM training"""
        if not self.ddpm_images:
            self.log_message("Error: No DDPM training images!", "ddpm")
            return
        
        if not self.ddpm:
            self.log_message("Error: DDPM not initialized!", "ddpm")
            return
        
        if not self.vae:
            self.log_message("Error: Need trained VAE first!", "ddpm")
            return
        
        if self.ddpm_training:
            self.log_message("DDPM training already in progress!", "ddpm")
            return
        
        try:
            epochs = int(self.ddpm_epochs_var.get())
            self.ddpm_training = True
            self.current_ddpm_epoch = 0
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_ddpm,
                args=(epochs,),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started DDPM training for {epochs} epochs", "ddpm")
            self.log_message(f"Training on {len(self.ddpm_images)} images (encoded by VAE)", "ddpm")
            
        except Exception as e:
            self.log_message(f"Error starting DDPM training: {str(e)}", "ddpm")
    
    def train_ddpm(self, epochs):
        """DDPM training loop"""
        try:
            batch_size = self.settings['ddpm_batch_size'].get()
            image_size = self.settings['image_size'].get()
            
            # Create transform
            transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            start_time = time.time()
            
            for epoch in range(epochs):
                if not self.ddpm_training:
                    break
                
                self.current_ddpm_epoch = epoch
                epoch_loss = 0
                num_batches = 0
                
                # Shuffle images
                shuffled_images = self.ddpm_images.copy()
                import random
                random.shuffle(shuffled_images)
                
                # Process in batches
                for i in range(0, len(shuffled_images), batch_size):
                    if not self.ddpm_training:
                        break
                    
                    batch_files = shuffled_images[i:i+batch_size]
                    batch_tensors = []
                    
                    # Load and transform batch
                    for file in batch_files:
                        try:
                            img = Image.open(file).convert('RGB')
                            batch_tensors.append(transform(img))
                        except:
                            continue
                    
                    if not batch_tensors:
                        continue
                    
                    # Stack batch and encode with VAE
                    batch = torch.stack(batch_tensors).to(self.vae.device)
                    
                    with torch.no_grad():
                        clean_latents, _, _ = self.vae.encoder_model(batch)
                    
                    # Move to DDPM device
                    clean_latents = clean_latents.to(self.ddpm.device)
                    batch_size_actual = clean_latents.size(0)
                    
                    # Train DDPM
                    self.ddpm.optimizer.zero_grad()
                    
                    # Sample random timesteps
                    t = torch.randint(0, self.ddpm.timesteps, (batch_size_actual,), 
                                     device=self.ddpm.device)
                    
                    # Add noise to latents
                    noisy_latents, noise = self.ddpm.add_noise(clean_latents, t)
                    
                    # Predict noise
                    predicted_noise = self.ddpm.predict_noise(noisy_latents, t)
                    
                    # MSE loss
                    loss = self.ddpm.criterion(predicted_noise, noise)
                    loss.backward()
                    self.ddpm.optimizer.step()
                    
                    epoch_loss += loss.item()
                    num_batches += 1
                
                # Log progress
                if num_batches > 0:
                    avg_loss = epoch_loss / num_batches
                    elapsed = time.time() - start_time
                    self.log_message(f"DDPM Epoch {epoch+1}/{epochs} | MSE Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s", "ddpm")
                    
                    # Show sample every 10 epochs
                    if (epoch + 1) % 10 == 0:
                        self.show_ddpm_sample()
            
            self.ddpm_training = False
            self.log_message("DDPM training completed!", "ddpm")
            
        except Exception as e:
            self.log_message(f"DDPM training error: {str(e)}", "ddpm")
            self.ddpm_training = False
    
    def show_ddpm_sample(self):
        """Show DDPM generated sample during training"""
        if not self.ddpm or not self.vae:
            return
        
        try:
            with torch.no_grad():
                # Generate random latent
                latent_size = self.settings['vae_latent_size'].get()
                latent_channels = self.settings['vae_latent_channels'].get()
                
                # Use fewer steps for training display
                steps = min(20, self.ddpm.timesteps)
                sampling_timesteps = torch.linspace(0, self.ddpm.timesteps-1, steps, 
                                                   dtype=torch.long, device=self.ddpm.device).flip(0)
                
                # Start from pure noise
                z = torch.randn(1, latent_channels, latent_size, latent_size).to(self.ddpm.device)
                
                # Reverse diffusion
                for t in sampling_timesteps:
                    t_tensor = torch.full((1,), t, device=self.ddpm.device, dtype=torch.long)
                    
                    predicted_noise = self.ddpm.predict_noise(z, t_tensor)
                    
                    alpha_t = self.ddpm.alphas[t]
                    sqrt_recip_alpha_t = self.ddpm.sqrt_recip_alphas[t]
                    beta_t = self.ddpm.betas[t]
                    sqrt_one_minus_alpha_cumprod_t = self.ddpm.sqrt_one_minus_alpha_cumprod[t]
                    
                    predicted_x0 = (z - sqrt_one_minus_alpha_cumprod_t * predicted_noise) / self.ddpm.sqrt_alpha_cumprod[t]
                    
                    if t > 0:
                        posterior_variance_t = self.ddpm.posterior_variance[t]
                        noise = torch.randn_like(z)
                        z = sqrt_recip_alpha_t * (z - beta_t / sqrt_one_minus_alpha_cumprod_t * predicted_noise) + \
                            torch.sqrt(posterior_variance_t) * noise * 0.05
                    else:
                        z = predicted_x0
                
                # Decode latent to image
                generated_image = self.vae.decode(z.to(self.vae.device))
                img = self.tensor_to_pil(generated_image[0].cpu())
                
                # Display
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                self.ddpm_sample_label.config(image=photo, text="")
                self.ddpm_sample_label.image = photo
                
                self.log_message(f"Generated training sample at epoch {self.current_ddpm_epoch + 1}", "ddpm")
                
        except Exception as e:
            self.log_message(f"Error showing DDPM sample: {str(e)}", "ddpm")
    
    def stop_ddpm_training(self):
        """Stop DDPM training"""
        if self.ddpm_training:
            self.ddpm_training = False
            self.log_message("DDPM training stopped", "ddpm")
    
    def save_ddpm(self):
        """Save DDPM model"""
        if not self.ddpm:
            self.log_message("Error: No DDPM to save!", "ddpm")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_ddpm_epoch,
                    'unet_state_dict': self.ddpm.unet.state_dict(),
                    'latent_size': self.settings['vae_latent_size'].get(),
                    'latent_channels': self.settings['vae_latent_channels'].get(),
                    'nf': self.settings['ddpm_nf'].get(),
                    'timesteps': self.settings['ddpm_timesteps'].get(),
                    'betas': self.ddpm.betas.cpu(),
                    'alphas': self.ddpm.alphas.cpu(),
                }, filename)
                
                self.log_message(f"DDPM saved to {filename}", "ddpm")
                
            except Exception as e:
                self.log_message(f"Error saving DDPM: {str(e)}", "ddpm")
    
    def load_vae(self):
        """Load VAE model"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Initialize VAE with loaded settings
                self.vae = LatentVAE(
                    image_size=checkpoint.get('image_size', 32),
                    latent_size=checkpoint.get('latent_size', 16),
                    latent_channels=checkpoint.get('latent_channels', 1),
                    hidden_dim=checkpoint.get('hidden_dim', 256)
                )
                
                # Load weights
                self.vae.encoder_model.load_state_dict(checkpoint['encoder_state_dict'])
                self.vae.decoder_model.load_state_dict(checkpoint['decoder_state_dict'])
                
                # Update settings
                if 'latent_size' in checkpoint:
                    self.settings['vae_latent_size'].set(checkpoint['latent_size'])
                if 'latent_channels' in checkpoint:
                    self.settings['vae_latent_channels'].set(checkpoint['latent_channels'])
                
                self.log_message(f"Loaded VAE from {filename}", "both")
                self.log_message(f"VAE latent size: {checkpoint.get('latent_size', 16)}", "both")
                
            except Exception as e:
                self.log_message(f"Error loading VAE: {str(e)}", "both")
    
    # ==================== Generation Methods ====================
    
    def load_both_models(self):
        """Load both VAE and DDPM"""
        self.load_vae()
        
        # Load DDPM separately
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Initialize DDPM
                self.ddpm = LatentDDPM(
                    latent_size=checkpoint.get('latent_size', 16),
                    latent_channels=checkpoint.get('latent_channels', 1),
                    nf=checkpoint.get('nf', 64),
                    timesteps=checkpoint.get('timesteps', 100)
                )
                
                # Load weights
                self.ddpm.unet.load_state_dict(checkpoint['unet_state_dict'])
                
                self.log_message(f"Loaded DDPM from {filename}", "gen")
                self.log_message("Both models loaded and ready for generation!", "gen")
                
            except Exception as e:
                self.log_message(f"Error loading DDPM: {str(e)}", "gen")
    
    def generate_images(self):
        """Generate images using the full pipeline"""
        if not self.vae or not self.ddpm:
            self.log_message("Error: Load both VAE and DDPM first!", "gen")
            return
        
        try:
            num_images = self.sampling_settings['num_generated'].get()
            steps = min(self.sampling_settings['sampling_steps'].get(), self.ddpm.timesteps)
            sampling_noise = self.sampling_settings['sampling_noise'].get()
            
            self.log_message(f"Generating {num_images} images with {steps} steps...", "gen")
            start_time = time.time()
            
            all_images = []
            
            # Pre-calculate timesteps
            sampling_timesteps = torch.linspace(0, self.ddpm.timesteps-1, steps, 
                                               dtype=torch.long, device=self.ddpm.device).flip(0)
            
            for img_idx in range(num_images):
                # Start from random latent noise
                latent_size = self.settings['vae_latent_size'].get()
                latent_channels = self.settings['vae_latent_channels'].get()
                
                z = torch.randn(1, latent_channels, latent_size, latent_size).to(self.ddpm.device)
                
                # Denoising loop
                for t in sampling_timesteps:
                    t_tensor = torch.full((1,), t, device=self.ddpm.device, dtype=torch.long)
                    
                    predicted_noise = self.ddpm.predict_noise(z, t_tensor)
                    
                    alpha_t = self.ddpm.alphas[t]
                    sqrt_recip_alpha_t = self.ddpm.sqrt_recip_alphas[t]
                    beta_t = self.ddpm.betas[t]
                    sqrt_one_minus_alpha_cumprod_t = self.ddpm.sqrt_one_minus_alpha_cumprod[t]
                    
                    predicted_x0 = (z - sqrt_one_minus_alpha_cumprod_t * predicted_noise) / self.ddpm.sqrt_alpha_cumprod[t]
                    
                    if t > 0:
                        posterior_variance_t = self.ddpm.posterior_variance[t]
                        noise = torch.randn_like(z)
                        z = sqrt_recip_alpha_t * (z - beta_t / sqrt_one_minus_alpha_cumprod_t * predicted_noise) + \
                            torch.sqrt(posterior_variance_t) * noise * sampling_noise
                    else:
                        z = predicted_x0
                
                # Decode latent to image
                generated_image = self.vae.decode(z.to(self.vae.device))
                img_tensor = generated_image[0].cpu()
                img = self.tensor_to_pil(img_tensor)
                all_images.append(img)
            
            # Clear previous images
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            # Create grid
            cols = 2 if num_images <= 4 else 4
            rows = (num_images + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_display = all_images[idx].resize((128, 128), Image.Resampling.NEAREST)
                        photo = ImageTk.PhotoImage(img_display)
                        
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            
            generation_time = time.time() - start_time
            self.log_message(f"Generated {num_images} images in {generation_time:.1f}s ({steps} steps each)", "gen")
            self.log_message(f"That's {generation_time/num_images:.1f}s per image! (Much faster than pixel diffusion)", "gen")
            
        except Exception as e:
            self.log_message(f"Error generating images: {str(e)}", "gen")
    
    # ==================== Settings Methods ====================
    
    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            defaults.update({k: v.get() for k, v in self.sampling_settings.items()})
            
            with open('latent_diffusion_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            
            self.log_message("Settings saved as defaults", "both")
            
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}", "both")
    
    def load_defaults(self):
        """Load saved defaults"""
        try:
            if os.path.exists('latent_diffusion_defaults.json'):
                with open('latent_diffusion_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                    elif key in self.sampling_settings:
                        self.sampling_settings[key].set(value)
                
                self.log_message("Loaded saved defaults", "both")
            else:
                self.log_message("No defaults file found", "both")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}", "both")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Latent Diffusion (VAE + DDPM)...")
    print(f"CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch threads: {torch.get_num_threads()}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = LatentDiffusionApp(root)
    root.mainloop()