import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import random
import math

# ==================== OPTIMIZED Neural Network ====================

class ContextPixelCNN:
    def __init__(self, image_size=32, channels=3, hidden_dim=128, context_size=5):
        """
        Optimized autoregressive model using context window.
        Uses parallel processing for training efficiency.
        """
        self.image_size = image_size
        self.channels = channels
        self.hidden_dim = hidden_dim
        self.context_size = context_size
        self.padding = context_size // 2
        
        # Set PyTorch for multi-core
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # OPTIMIZED Context processing network
        class ContextProcessor(nn.Module):
            def __init__(self, channels, hidden_dim, context_size):
                super().__init__()
                self.context_size = context_size
                self.center_idx = context_size // 2
                
                # Process context with spatial preservation
                self.context_net = nn.Sequential(
                    # Input: batch x channels x 5 x 5
                    nn.Conv2d(channels, hidden_dim, 3, padding=1),
                    nn.BatchNorm2d(hidden_dim),
                    nn.ReLU(True),
                    
                    nn.Conv2d(hidden_dim, hidden_dim * 2, 3, padding=1),
                    nn.BatchNorm2d(hidden_dim * 2),
                    nn.ReLU(True),
                    
                    # Preserve spatial dimensions
                    nn.Conv2d(hidden_dim * 2, hidden_dim, 3, padding=1),
                    nn.BatchNorm2d(hidden_dim),
                    nn.ReLU(True),
                    
                    # Final layer to predict channels
                    nn.Conv2d(hidden_dim, channels, 3, padding=1),
                )
                
            def forward(self, context):
                # Process context
                output = self.context_net(context)  # batch x channels x 5 x 5
                
                # Extract center pixel prediction only
                center_features = output[:, :, self.center_idx, self.center_idx]
                return torch.tanh(center_features)
        
        self.model = ContextProcessor(channels, hidden_dim, context_size)
        
        # Loss and optimizer
        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001)
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.model.to(self.device)
        
        # Generation parameters
        self.temperature = 0.0  # Sampling temperature
        self.generation_noise_intensity = 0.0
        self.noise_type = 'gaussian'  # 'gaussian', 'uniform', 'salt_pepper'
        self.training_top_rows = []

    def extract_context(self, images, i, j, out_of_bounds_value=0.0, training_mode=True):
        """
        Extract context window for pixel (i,j).
        OPTIMIZED: Vectorized where possible.
        """
        batch_size, channels, height, width = images.shape
        context = torch.zeros(batch_size, channels, self.context_size, self.context_size, 
                             device=images.device)
        context.fill_(out_of_bounds_value)
        
        # Calculate bounds
        start_i = i - self.padding
        end_i = i + self.padding + 1
        start_j = j - self.padding
        end_j = j + self.padding + 1
        
        # Vectorized approach for valid indices
        for ci in range(self.context_size):
            for cj in range(self.context_size):
                img_i = start_i + ci
                img_j = start_j + cj
                
                # Check if this is a valid past pixel (autoregressive constraint)
                if img_i < i or (img_i == i and img_j < j):
                    # Check bounds
                    if 0 <= img_i < height and 0 <= img_j < width:
                        context[:, :, ci, cj] = images[:, :, img_i, img_j]
                elif not training_mode and self.generation_noise_intensity > 0:
                    # Add noise for out-of-bounds during generation
                    self._add_noise_to_context(context, ci, cj, batch_size, channels)
        
        return context

    def _add_noise_to_context(self, context, ci, cj, batch_size, channels):
        """Add noise to context pixel based on noise type."""
        if self.noise_type == 'gaussian':
            noise = torch.randn(batch_size, channels, device=context.device) * self.generation_noise_intensity
        elif self.noise_type == 'uniform':
            noise = (torch.rand(batch_size, channels, device=context.device) * 2 - 1) * self.generation_noise_intensity
        elif self.noise_type == 'salt_pepper':
            noise = torch.rand(batch_size, channels, device=context.device)
            salt = noise > 0.95
            pepper = noise < 0.05
            noise = salt.float() - pepper.float()
            noise = noise * self.generation_noise_intensity
        else:
            noise = torch.zeros(batch_size, channels, device=context.device)
        
        context[:, :, ci, cj] = noise

    def predict_pixel(self, images, i, j, training_mode=True):
        """Predict pixel at (i,j) with temperature sampling."""
        context = self.extract_context(images, i, j, 
                                      out_of_bounds_value=0.0,
                                      training_mode=training_mode)
        prediction = self.model(context)
        
        # Apply temperature for sampling diversity
        if not training_mode and self.temperature > 0:
            noise = torch.randn_like(prediction) * self.temperature
            prediction = prediction + noise
            prediction = torch.clamp(prediction, -1, 1)
        
        return prediction

    # OPTIMIZED: Batch prediction for training
    def predict_all_pixels_batch(self, images, training_mode=True):
        """
        Predict all pixels in batch for efficient training.
        Returns predictions for ALL pixel positions.
        """
        batch_size, channels, height, width = images.shape
        predictions = torch.zeros_like(images)
        
        # We'll still loop but process in batches
        with torch.set_grad_enabled(training_mode):
            for i in range(height):
                for j in range(width):
                    predictions[:, :, i, j] = self.predict_pixel(
                        images, i, j, training_mode=training_mode
                    )
        
        return predictions

    def generate_top_row(self, batch_size):
        """Generate top row with diversity based on temperature."""
        if hasattr(self, 'training_top_rows') and len(self.training_top_rows) > 0:
            # Sample from training top rows
            idx = np.random.randint(0, len(self.training_top_rows), size=batch_size)
            top_rows = self.training_top_rows[idx]
            return top_rows.unsqueeze(2)  # Add height dimension (batch x channels x 1 x width)
        else:
            # Generate with temperature
            top_row = torch.randn(batch_size, self.channels, self.image_size, 
                                 device=self.device)
            if self.temperature > 0:
                top_row = top_row * (1 + self.temperature * 0.5)
            return top_row.unsqueeze(2)  # batch x channels x 1 x width

# ==================== OPTIMIZED Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        # Use augmentation for better generalization
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== IMPROVED GUI Application ====================

class PixelCNNApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Optimized Context PixelCNN Trainer")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # IMPROVED Settings with temperature and noise type
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'channels': tk.IntVar(value=3),
            'hidden_dim': tk.IntVar(value=128),
            'context_size': tk.IntVar(value=5),
            'batch_size': tk.IntVar(value=16),
            'learning_rate': tk.DoubleVar(value=0.001),
            'beta1': tk.DoubleVar(value=0.9),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
            'generate_interval': tk.IntVar(value=5),
            'noise_intensity': tk.DoubleVar(value=0.1),
            'temperature': tk.DoubleVar(value=0.1),  # NEW: Sampling temperature
            'noise_type': tk.StringVar(value='gaussian'),  # NEW: Noise type
        }
        
        # Performance tracking
        self.start_time = None
        
        # For storing generated images
        self.generated_images = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Optimized PixelCNN", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text="Image Size: 32x32")
        self.size_display.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize Model", 
                 command=self.initialize_model, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="50")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Quick generation
        gen_frame = tk.LabelFrame(left_frame, text="Quick Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container with scroll
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Optimized PixelCNN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create scrollable canvas
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Network parameters with better resolution
        settings_list = [
            ("Channels:", 'channels', 1, 3, 1),
            ("Hidden Dimension:", 'hidden_dim', 64, 512, 16),
            ("Context Size:", 'context_size', 3, 7, 2),
            ("Batch Size:", 'batch_size', 1, 64, 1),
        ]
        
        for label_text, var_name, min_val, max_val, resolution in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # NEW: Sampling parameters
        sampling_frame = tk.LabelFrame(scrollable_frame, text="Sampling Parameters", padx=10, pady=10)
        sampling_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Temperature slider (NEW)
        temp_frame = tk.Frame(sampling_frame)
        temp_frame.pack(fill=tk.X, pady=5)
        tk.Label(temp_frame, text="Temperature:", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(temp_frame, from_=0.0, to=1.0, variable=self.settings['temperature'],
                orient=tk.HORIZONTAL, length=200, resolution=0.01).pack(side=tk.RIGHT)
        tk.Label(temp_frame, textvariable=self.settings['temperature'], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Noise intensity with proper resolution
        noise_frame = tk.Frame(sampling_frame)
        noise_frame.pack(fill=tk.X, pady=5)
        tk.Label(noise_frame, text="Noise Intensity:", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(noise_frame, from_=0.0, to=1.0, variable=self.settings['noise_intensity'],
                orient=tk.HORIZONTAL, length=200, resolution=0.01).pack(side=tk.RIGHT)
        tk.Label(noise_frame, textvariable=self.settings['noise_intensity'], width=5).pack(side=tk.RIGHT, padx=5)
        
        # NEW: Noise type selector
        noise_type_frame = tk.Frame(sampling_frame)
        noise_type_frame.pack(fill=tk.X, pady=5)
        tk.Label(noise_type_frame, text="Noise Type:", width=25, anchor='w').pack(side=tk.LEFT)
        
        noise_type_menu = ttk.Combobox(noise_type_frame, textvariable=self.settings['noise_type'],
                                      values=['gaussian', 'uniform', 'salt_pepper'], width=18)
        noise_type_menu.pack(side=tk.RIGHT)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.0001, 0.01, 0.0001),
            ("Beta1:", 'beta1', 0.8, 0.999, 0.001),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2), 1),
            ("Generate Interval:", 'generate_interval', 1, 50, 1),
        ]
        
        for label_text, var_name, min_val, max_val, resolution in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                    orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset Defaults", 
                 command=self.reset_defaults, width=15).pack(side=tk.LEFT, padx=5)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load Model", 
                 command=self.load_model, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=4)
        tk.Scale(gen_frame, from_=1, to=16, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_model(self):
        """Initialize model with current settings"""
        try:
            image_size = self.settings['image_size'].get()
            channels = self.settings['channels'].get()
            hidden_dim = self.settings['hidden_dim'].get()
            context_size = self.settings['context_size'].get()
            
            self.model = ContextPixelCNN(
                image_size=image_size,
                channels=channels,
                hidden_dim=hidden_dim,
                context_size=context_size
            )
            
            self.log_message(f"Initialized Optimized PixelCNN for {image_size}x{image_size} images")
            self.log_message(f"Channels: {channels}, Hidden: {hidden_dim}, Context: {context_size}x{context_size}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing model: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = float(self.settings['learning_rate'].get())
            beta1 = float(self.settings['beta1'].get())
            temperature = float(self.settings['temperature'].get())
            noise_intensity = float(self.settings['noise_intensity'].get())
            noise_type = self.settings['noise_type'].get()
            
            # Update model parameters
            self.model.temperature = temperature
            self.model.generation_noise_intensity = noise_intensity
            self.model.noise_type = noise_type
            
            # Update optimizer
            for param_group in self.model.optimizer.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_model_optimized,
                args=(epochs, batch_size, num_workers),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr:.6f}, Temperature: {temperature:.3f}")
            self.log_message(f"Noise: {noise_type} with intensity {noise_intensity:.3f}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_model_optimized(self, epochs, batch_size, num_workers):
        """OPTIMIZED training loop"""
        try:
            image_size = self.settings['image_size'].get()
            generate_interval = self.settings['generate_interval'].get()
            
            # Create dataset with augmentation
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            # Store top rows from training data
            top_rows = []
            for batch in dataloader:
                if batch.size(0) > 0:
                    top_rows.append(batch[:, :, 0, :])
            if top_rows:
                self.model.training_top_rows = torch.cat(top_rows, dim=0)
                self.log_message(f"Stored {len(self.model.training_top_rows)} top rows from training data")
            
            # Training loop
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss = 0
                total_batches = 0
                epoch_start = time.time()
                
                for batch_idx, real_images in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    real_images = real_images.to(self.model.device)
                    
                    # OPTIMIZED: Predict all pixels at once
                    self.model.optimizer.zero_grad()
                    predictions = self.model.predict_all_pixels_batch(real_images, training_mode=True)
                    
                    # Compute loss
                    loss = self.model.criterion(predictions, real_images)
                    
                    # Backward pass and optimize
                    loss.backward()
                    self.model.optimizer.step()
                    
                    total_loss += loss.item()
                    total_batches += 1
                    
                    # Log batch progress
                    if (batch_idx + 1) % max(1, len(dataloader) // 5) == 0:
                        self.log_message(f"  Batch {batch_idx+1}/{len(dataloader)} | Loss: {loss.item():.6f}")
                
                if total_batches > 0:
                    avg_loss = total_loss / total_batches
                    epoch_time = time.time() - epoch_start
                    elapsed = time.time() - self.start_time
                    
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"Loss: {avg_loss:.6f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Total: {elapsed:.1f}s")
                    
                    # Generate samples at interval
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_image(self, batch_size=1):
        """Generate complete image autoregressively with temperature"""
        if not self.model:
            return None
        
        try:
            image_size = self.settings['image_size'].get()
            channels = self.settings['channels'].get()
            temperature = float(self.settings['temperature'].get())
            noise_intensity = float(self.settings['noise_intensity'].get())
            noise_type = self.settings['noise_type'].get()
            
            # Set generation parameters
            self.model.temperature = temperature
            self.model.generation_noise_intensity = noise_intensity
            self.model.noise_type = noise_type
            
            # Create empty image
            generated = torch.zeros(batch_size, channels, image_size, image_size, 
                                   device=self.model.device)
            
            # Generate top row
            top_row = self.model.generate_top_row(batch_size)
            generated[:, :, 0, :] = top_row.squeeze(2)
            
            # Generate rest pixel by pixel
            with torch.no_grad():
                for i in range(image_size):
                    for j in range(image_size):
                        if i == 0:  # Skip top row (already generated)
                            continue
                        
                        predicted_pixel = self.model.predict_pixel(generated, i, j, training_mode=False)
                        generated[:, :, i, j] = predicted_pixel
            
            return generated.cpu()
            
        except Exception as e:
            self.log_message(f"Error generating image: {str(e)}")
            return None

    def generate_training_samples(self):
        """Generate sample images during training"""
        if not self.model:
            return
        
        try:
            generated = self.generate_image(batch_size=1)
            
            if generated is not None:
                img_tensor = generated[0]
                img = self.tensor_to_pil(img_tensor)
                
                # Resize for display
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                # Store
                self.generated_images.append(img)
                
                # Log with current parameters
                temp = float(self.settings['temperature'].get())
                noise = float(self.settings['noise_intensity'].get())
                self.log_message(f"Generated sample (Epoch {self.current_epoch + 1})")
                self.log_message(f"  Temperature: {temp:.3f}, Noise: {noise:.3f}")
                
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        """Generate a single sample with current settings"""
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        try:
            generated = self.generate_image(batch_size=1)
            
            if generated is not None:
                img = self.tensor_to_pil(generated[0])
                
                # Resize for display
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                # Store
                self.generated_images.append(img)
                
                # Log parameters
                temp = float(self.settings['temperature'].get())
                noise = float(self.settings['noise_intensity'].get())
                noise_type = self.settings['noise_type'].get()
                self.log_message(f"Generated sample with:")
                self.log_message(f"  Temperature: {temp:.3f}")
                self.log_message(f"  Noise: {noise:.3f} ({noise_type})")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def save_model(self):
        """Save current model"""
        if not self.model:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'model_state_dict': self.model.model.state_dict(),
                    'optimizer_state_dict': self.model.optimizer.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'channels': self.settings['channels'].get(),
                    'hidden_dim': self.settings['hidden_dim'].get(),
                    'context_size': self.settings['context_size'].get(),
                    'temperature': float(self.settings['temperature'].get()),
                    'noise_intensity': float(self.settings['noise_intensity'].get()),
                    'noise_type': self.settings['noise_type'].get(),
                    'training_top_rows': self.model.training_top_rows if hasattr(self.model, 'training_top_rows') else [],
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_model(self):
        """Load model from file"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                settings_to_load = ['image_size', 'channels', 'hidden_dim', 'context_size']
                for setting in settings_to_load:
                    if setting in checkpoint:
                        self.settings[setting].set(checkpoint[setting])
                
                # Load temperature and noise settings
                if 'temperature' in checkpoint:
                    self.settings['temperature'].set(float(checkpoint['temperature']))
                if 'noise_intensity' in checkpoint:
                    self.settings['noise_intensity'].set(float(checkpoint['noise_intensity']))
                if 'noise_type' in checkpoint:
                    self.settings['noise_type'].set(checkpoint['noise_type'])
                
                self.update_size_display()
                
                # Initialize model
                self.initialize_model()
                
                # Load state dicts
                self.model.model.load_state_dict(checkpoint['model_state_dict'])
                if 'optimizer_state_dict' in checkpoint:
                    self.model.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                
                if 'training_top_rows' in checkpoint and len(checkpoint['training_top_rows']) > 0:
                    self.model.training_top_rows = checkpoint['training_top_rows']
                    self.log_message(f"Loaded {len(self.model.training_top_rows)} training top rows")
                
                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
                # Apply loaded temperature/noise to model
                self.model.temperature = float(self.settings['temperature'].get())
                self.model.generation_noise_intensity = float(self.settings['noise_intensity'].get())
                self.model.noise_type = self.settings['noise_type'].get()
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        """Generate a grid of images"""
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            
            # Generate images
            generated = self.generate_image(batch_size=num_images)
            
            if generated is None:
                self.log_message("Error: Failed to generate images")
                return
            
            # Clear previous images
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            # Create grid
            cols = 2
            rows = (num_images + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_tensor = generated[idx]
                        img = self.tensor_to_pil(img_tensor)
                        
                        # Resize for display
                        img_display = img.resize((192, 192), Image.Resampling.NEAREST)
                        photo = ImageTk.PhotoImage(img_display)
                        
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            
            # Log generation parameters
            temp = float(self.settings['temperature'].get())
            noise = float(self.settings['noise_intensity'].get())
            noise_type = self.settings['noise_type'].get()
            
            self.log_message(f"Generated {num_images} images")
            self.log_message(f"Temperature: {temp:.3f}, Noise: {noise:.3f} ({noise_type})")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {}
            for k, v in self.settings.items():
                if isinstance(v, tk.DoubleVar):
                    defaults[k] = float(v.get())
                elif isinstance(v, tk.IntVar):
                    defaults[k] = int(v.get())
                else:
                    defaults[k] = v.get()
            
            import json
            with open('pixelcnn_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            import json
            if os.path.exists('pixelcnn_defaults.json'):
                with open('pixelcnn_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        if isinstance(self.settings[key], tk.DoubleVar):
                            self.settings[key].set(float(value))
                        elif isinstance(self.settings[key], tk.IntVar):
                            self.settings[key].set(int(value))
                        else:
                            self.settings[key].set(value)
                
                self.update_size_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_defaults(self):
        """Reset to default settings"""
        default_settings = {
            'image_size': 32,
            'channels': 3,
            'hidden_dim': 128,
            'context_size': 5,
            'batch_size': 16,
            'learning_rate': 0.001,
            'beta1': 0.9,
            'num_workers': min(4, multiprocessing.cpu_count()),
            'save_interval': 10,
            'generate_interval': 5,
            'noise_intensity': 0.1,
            'temperature': 0.1,
            'noise_type': 'gaussian'
        }
        
        for key, value in default_settings.items():
            if key in self.settings:
                if isinstance(self.settings[key], tk.DoubleVar):
                    self.settings[key].set(float(value))
                elif isinstance(self.settings[key], tk.IntVar):
                    self.settings[key].set(int(value))
                else:
                    self.settings[key].set(value)
        
        self.update_size_display()
        self.log_message("Reset to default settings")

    def update_size_display(self):
        """Update image size display"""
        size = self.settings['image_size'].get()
        self.size_display.config(text=f"Image Size: {size}x{size}")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Optimized Context PixelCNN Trainer...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = PixelCNNApp(root)
    root.mainloop()