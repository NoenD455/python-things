import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageFilter, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import random

# ==================== Neural Network ====================

class DeblurUNet:
    def __init__(self, image_size=32, ngf=64):
        self.image_size = image_size
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # U-Net Architecture for Deblurring
        class UNet(nn.Module):
            def __init__(self, in_channels=3, out_channels=3, features=64):
                super().__init__()
                
                # Encoder (downsampling)
                self.encoder1 = self._block(in_channels, features, "enc1")
                self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
                self.encoder2 = self._block(features, features * 2, "enc2")
                self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
                self.encoder3 = self._block(features * 2, features * 4, "enc3")
                self.pool3 = nn.MaxPool2d(kernel_size=2, stride=2)
                self.encoder4 = self._block(features * 4, features * 8, "enc4")
                self.pool4 = nn.MaxPool2d(kernel_size=2, stride=2)
                
                # Bottleneck
                self.bottleneck = self._block(features * 8, features * 16, "bottleneck")
                
                # Decoder (upsampling)
                self.upconv4 = nn.ConvTranspose2d(features * 16, features * 8, kernel_size=2, stride=2)
                self.decoder4 = self._block(features * 16, features * 8, "dec4")
                self.upconv3 = nn.ConvTranspose2d(features * 8, features * 4, kernel_size=2, stride=2)
                self.decoder3 = self._block(features * 8, features * 4, "dec3")
                self.upconv2 = nn.ConvTranspose2d(features * 4, features * 2, kernel_size=2, stride=2)
                self.decoder2 = self._block(features * 4, features * 2, "dec2")
                self.upconv1 = nn.ConvTranspose2d(features * 2, features, kernel_size=2, stride=2)
                self.decoder1 = self._block(features * 2, features, "dec1")
                
                # Final convolution
                self.final_conv = nn.Conv2d(features, out_channels, kernel_size=1)
                
            def _block(self, in_channels, out_channels, name):
                return nn.Sequential(
                    nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
                    nn.BatchNorm2d(out_channels),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
                    nn.BatchNorm2d(out_channels),
                    nn.ReLU(inplace=True),
                )
            
            def forward(self, x):
                # Encoder
                enc1 = self.encoder1(x)
                enc2 = self.encoder2(self.pool1(enc1))
                enc3 = self.encoder3(self.pool2(enc2))
                enc4 = self.encoder4(self.pool3(enc3))
                
                # Bottleneck
                bottleneck = self.bottleneck(self.pool4(enc4))
                
                # Decoder with skip connections
                dec4 = self.upconv4(bottleneck)
                dec4 = torch.cat((dec4, enc4), dim=1)
                dec4 = self.decoder4(dec4)
                
                dec3 = self.upconv3(dec4)
                dec3 = torch.cat((dec3, enc3), dim=1)
                dec3 = self.decoder3(dec3)
                
                dec2 = self.upconv2(dec3)
                dec2 = torch.cat((dec2, enc2), dim=1)
                dec2 = self.decoder2(dec2)
                
                dec1 = self.upconv1(dec2)
                dec1 = torch.cat((dec1, enc1), dim=1)
                dec1 = self.decoder1(dec1)
                
                return torch.tanh(self.final_conv(dec1))
        
        self.model = UNet(features=ngf)
        
        # Loss function - using L1 loss (better for deblurring)
        self.criterion = nn.L1Loss()
        
        # Optimizer
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001, betas=(0.9, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.model.to(self.device)

# ==================== Dataset ====================

class BlurDataset(Dataset):
    def __init__(self, image_paths, image_size=32, blur_sigma=1.5, augment=True):
        self.image_paths = image_paths
        self.image_size = image_size
        self.blur_sigma = blur_sigma
        self.augment = augment
        
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
        
        self.augment_transform = transforms.Compose([
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(10),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1),
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            # Load and augment sharp image
            img = Image.open(self.image_paths[idx]).convert('RGB')
            
            if self.augment:
                img = self.augment_transform(img)
            
            sharp_img = self.transform(img)
            
            # Create blurred version
            blur_sigma = self.blur_sigma * (0.8 + 0.4 * random.random())  # Add randomness
            blurred_img = img.filter(ImageFilter.GaussianBlur(radius=blur_sigma))
            blurred_img = self.transform(blurred_img)
            
            return blurred_img, sharp_img
            
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            # Return black images as fallback
            return (torch.zeros(3, self.image_size, self.image_size), 
                    torch.zeros(3, self.image_size, self.image_size))

# ==================== GUI Application ====================

class DeblurApp:
    def __init__(self, root):
        self.root = root
        self.root.title("UNet Deblurring - Multi-Core")
        self.root.geometry("1200x800")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings - FIXED: removed save_interval since no auto-save
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'ngf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=16),
            'learning_rate': tk.DoubleVar(value=0.001),
            'beta1': tk.DoubleVar(value=0.9),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'blur_sigma': tk.DoubleVar(value=1.5),  # Controls blur amount
            'augment_data': tk.BooleanVar(value=True),
            'test_interval': tk.IntVar(value=5)
        }
        
        # Performance tracking
        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        
        # For storing test results
        self.test_results = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Deblur
        self.deblur_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.deblur_tab, text='Deblur')
        self.setup_deblur_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="UNet Deblurring Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text=f"Image Size: 32x32 (Fixed)")
        self.size_display.pack(pady=(0, 10))
        
        # Blur sigma display
        self.blur_display = tk.Label(left_frame, text=f"Blur Sigma: {self.settings['blur_sigma'].get()}")
        self.blur_display.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize UNet", 
                 command=self.initialize_model, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Testing during training
        test_frame = tk.LabelFrame(left_frame, text="Testing", padx=10, pady=10)
        test_frame.pack(fill=tk.X)
        
        tk.Button(test_frame, text="Test on Sample", 
                 command=self.test_on_sample, width=20).pack(pady=5)
        tk.Button(test_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Results and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Triple image display
        preview_frame = tk.LabelFrame(right_frame, text="Deblurring Results", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Three columns for blurred, deblurred, and sharp
        images_frame = tk.Frame(preview_frame)
        images_frame.pack(pady=10)
        
        # Blurred input
        blurred_frame = tk.LabelFrame(images_frame, text="Blurred Input", padx=5, pady=5)
        blurred_frame.pack(side=tk.LEFT, padx=5)
        self.blurred_image_label = tk.Label(blurred_frame, text="No image", width=256, height=256, bg='gray')
        self.blurred_image_label.pack()
        
        # Deblurred output
        deblurred_frame = tk.LabelFrame(images_frame, text="Deblurred Output", padx=5, pady=5)
        deblurred_frame.pack(side=tk.LEFT, padx=5)
        self.deblurred_image_label = tk.Label(deblurred_frame, text="No image", width=256, height=256, bg='gray')
        self.deblurred_image_label.pack()
        
        # Sharp target
        sharp_frame = tk.LabelFrame(images_frame, text="Sharp Target", padx=5, pady=5)
        sharp_frame.pack(side=tk.LEFT, padx=5)
        self.sharp_image_label = tk.Label(sharp_frame, text="No image", width=256, height=256, bg='gray')
        self.sharp_image_label.pack()
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar at bottom
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="UNet Deblurring Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar for many settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Fixed image size display
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed)", width=20).pack(side=tk.LEFT)
        
        # Blur settings - FIXED: better scale with resolution
        blur_frame = tk.Frame(net_frame)
        blur_frame.pack(fill=tk.X, pady=5)
        tk.Label(blur_frame, text="Blur Sigma:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(blur_frame, from_=0.5, to=3.0, variable=self.settings['blur_sigma'], 
                orient=tk.HORIZONTAL, length=200, resolution=0.1,
                command=self.update_blur_display).pack(side=tk.RIGHT)
        tk.Label(blur_frame, textvariable=self.settings['blur_sigma'], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Other network parameters
        settings_list = [
            ("UNet Features (ngf):", 'ngf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 64),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.0001, 0.01),
            ("Beta1:", 'beta1', 0.5, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Test Interval (epochs):", 'test_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.0001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Data augmentation checkbox
        aug_frame = tk.Frame(train_frame)
        aug_frame.pack(fill=tk.X, pady=5)
        tk.Label(aug_frame, text="Data Augmentation:", width=30, anchor='w').pack(side=tk.LEFT)
        tk.Checkbutton(aug_frame, variable=self.settings['augment_data']).pack(side=tk.RIGHT)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_deblur_tab(self):
        main_frame = tk.Frame(self.deblur_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Deblurring", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Top controls
        control_frame = tk.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Left side - Load and blur controls
        left_control = tk.Frame(control_frame)
        left_control.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 20))
        
        tk.Button(left_control, text="Load Sharp Image", 
                 command=self.load_sharp_image, width=20).pack(pady=5)
        
        tk.Button(left_control, text="Apply Blur", 
                 command=self.apply_blur_to_current, width=20).pack(pady=5)
        
        tk.Button(left_control, text="Load Blurred Image", 
                 command=self.load_blurred_image, width=20).pack(pady=5)
        
        # Right side - Deblur controls
        right_control = tk.Frame(control_frame)
        right_control.pack(side=tk.LEFT, fill=tk.Y)
        
        tk.Button(right_control, text="Load UNet Model", 
                 command=self.load_model, width=20).pack(pady=5)
        
        tk.Button(right_control, text="Deblur Current", 
                 command=self.deblur_current, width=20, bg="lightblue").pack(pady=5)
        
        tk.Button(right_control, text="Batch Deblur", 
                 command=self.batch_deblur, width=20).pack(pady=5)
        
        # Blur sigma control - FIXED: Use dropdown for predefined values
        sigma_frame = tk.Frame(main_frame)
        sigma_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(sigma_frame, text="Current Blur Sigma:").pack(side=tk.LEFT, padx=(0, 10))
        
        # Create a dropdown with specific values including the training default
        self.current_blur_var = tk.StringVar(value="1.5")  # Default matches training
        
        # Create the dropdown menu
        blur_options = ["0.5", "1.0", "1.5", "2.0", "2.5", "3.0"]
        self.blur_dropdown = ttk.Combobox(sigma_frame, textvariable=self.current_blur_var, 
                                         values=blur_options, state="readonly", width=10)
        self.blur_dropdown.pack(side=tk.LEFT, padx=5)
        
        # Also allow custom entry with validation
        tk.Label(sigma_frame, text="or Custom:").pack(side=tk.LEFT, padx=(20, 5))
        self.custom_blur_var = tk.StringVar(value="1.5")
        custom_blur_entry = tk.Entry(sigma_frame, textvariable=self.custom_blur_var, width=8)
        custom_blur_entry.pack(side=tk.LEFT, padx=5)
        
        # Apply custom button
        tk.Button(sigma_frame, text="Apply Custom", 
                 command=self.apply_custom_blur, width=12).pack(side=tk.LEFT, padx=5)
        
        # Image display area
        display_frame = tk.LabelFrame(main_frame, text="Image Processing", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        # Three columns
        columns_frame = tk.Frame(display_frame)
        columns_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Original/Sharp
        original_frame = tk.LabelFrame(columns_frame, text="Original/Sharp", padx=10, pady=10)
        original_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        self.original_image_label = tk.Label(original_frame, text="No image loaded", 
                                           width=200, height=200, bg='gray')
        self.original_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Blurred
        blurred_display_frame = tk.LabelFrame(columns_frame, text="Blurred", padx=10, pady=10)
        blurred_display_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        self.blurred_display_label = tk.Label(blurred_display_frame, text="No blurred image", 
                                            width=200, height=200, bg='gray')
        self.blurred_display_label.pack(fill=tk.BOTH, expand=True)
        
        # Deblurred
        deblurred_display_frame = tk.LabelFrame(columns_frame, text="Deblurred", padx=10, pady=10)
        deblurred_display_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        self.deblurred_display_label = tk.Label(deblurred_display_frame, text="No deblurred image", 
                                              width=200, height=200, bg='gray')
        self.deblurred_display_label.pack(fill=tk.BOTH, expand=True)
        
        # Store current images
        self.current_sharp_image = None
        self.current_blurred_image = None
        self.current_deblurred_image = None

    def update_blur_display(self, *args):
        """Update blur sigma display in training tab"""
        sigma = self.settings['blur_sigma'].get()
        self.blur_display.config(text=f"Blur Sigma: {sigma}")

    def apply_custom_blur(self):
        """Apply custom blur sigma value"""
        try:
            custom_value = float(self.custom_blur_var.get())
            if 0.1 <= custom_value <= 5.0:
                self.current_blur_var.set(str(custom_value))
                self.log_message(f"Set custom blur sigma to {custom_value}")
            else:
                self.log_message("Error: Blur sigma must be between 0.1 and 5.0")
        except ValueError:
            self.log_message("Error: Please enter a valid number for blur sigma")

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                # Add to log
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                
                # Update status with first line
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                
                print(message)  # Also print to console
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_model(self):
        """Initialize UNet with current settings"""
        try:
            image_size = 32  # Fixed at 32x32
            ngf = self.settings['ngf'].get()
            
            self.model = DeblurUNet(
                image_size=image_size,
                ngf=ngf
            )
            
            self.log_message(f"Initialized UNet for {image_size}x{image_size} deblurring")
            self.log_message(f"UNet features: {ngf}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            self.log_message(f"Blur sigma: {self.settings['blur_sigma'].get()}")
            
        except Exception as e:
            self.log_message(f"Error initializing UNet: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.model:
            self.log_message("Error: UNet not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            blur_sigma = self.settings['blur_sigma'].get()
            augment = self.settings['augment_data'].get()
            
            # Update optimizer with new settings
            for param_group in self.model.optimizer.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_model,
                args=(epochs, batch_size, num_workers, blur_sigma, augment),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}")
            self.log_message(f"Blur sigma: {blur_sigma}, Augmentation: {augment}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_model(self, epochs, batch_size, num_workers, blur_sigma, augment):
        """Training loop in separate thread - REMOVED auto-save"""
        try:
            test_interval = self.settings['test_interval'].get()
            
            # Create dataset and dataloader
            dataset = BlurDataset(self.image_paths, image_size=32, 
                                 blur_sigma=blur_sigma, augment=augment)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss = 0
                batch_count = 0
                epoch_start = time.time()
                
                for blurred_images, sharp_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = blurred_images.size(0)
                    blurred_images = blurred_images.to(self.model.device)
                    sharp_images = sharp_images.to(self.model.device)
                    
                    # Train UNet
                    self.model.optimizer.zero_grad()
                    
                    # Forward pass
                    deblurred_images = self.model.model(blurred_images)
                    
                    # Calculate loss
                    loss = self.model.criterion(deblurred_images, sharp_images)
                    
                    # Backward pass and optimize
                    loss.backward()
                    self.model.optimizer.step()
                    
                    total_loss += loss.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss = total_loss / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    # Log progress
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"Loss: {avg_loss:.6f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Total: {elapsed:.1f}s")
                    
                    # Test on sample at interval
                    if (epoch + 1) % test_interval == 0:
                        self.test_on_training_sample()
                        
                    # REMOVED auto-save functionality
                    
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def test_on_training_sample(self):
        """Test the model on a sample from training set"""
        if not self.model or not self.image_paths:
            return
        
        try:
            with torch.no_grad():
                # Pick a random training image
                idx = random.randint(0, len(self.image_paths) - 1)
                
                # Create dataset for single image (without augmentation for consistency)
                temp_dataset = BlurDataset([self.image_paths[idx]], image_size=32,
                                          blur_sigma=self.settings['blur_sigma'].get(),
                                          augment=False)
                
                blurred_tensor, sharp_tensor = temp_dataset[0]
                
                # Add batch dimension and move to device
                blurred_tensor = blurred_tensor.unsqueeze(0).to(self.model.device)
                sharp_tensor = sharp_tensor.unsqueeze(0)
                
                # Deblur
                deblurred_tensor = self.model.model(blurred_tensor).cpu()
                
                # Convert to PIL images
                blurred_img = self.tensor_to_pil(blurred_tensor.cpu()[0])
                deblurred_img = self.tensor_to_pil(deblurred_tensor[0])
                sharp_img = self.tensor_to_pil(sharp_tensor[0])
                
                # Resize for display using NEAREST NEIGHBOR
                display_size = (256, 256)
                blurred_display = blurred_img.resize(display_size, Image.NEAREST)
                deblurred_display = deblurred_img.resize(display_size, Image.NEAREST)
                sharp_display = sharp_img.resize(display_size, Image.NEAREST)
                
                # Convert to PhotoImage
                blurred_photo = ImageTk.PhotoImage(blurred_display)
                deblurred_photo = ImageTk.PhotoImage(deblurred_display)
                sharp_photo = ImageTk.PhotoImage(sharp_display)
                
                # Update displays
                self.blurred_image_label.config(image=blurred_photo, text="")
                self.blurred_image_label.image = blurred_photo
                
                self.deblurred_image_label.config(image=deblurred_photo, text="")
                self.deblurred_image_label.image = deblurred_photo
                
                self.sharp_image_label.config(image=sharp_photo, text="")
                self.sharp_image_label.image = sharp_photo
                
                # Store for later
                self.test_results.append((blurred_img, deblurred_img, sharp_img))
                
                self.log_message(f"Tested on training sample at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error testing on sample: {str(e)}")

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        img = (tensor + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def test_on_sample(self):
        """Test on a sample from training set (manual)"""
        if not self.model:
            self.log_message("Error: UNet not initialized!")
            return
        
        self.test_on_training_sample()

    def save_model(self):
        """Save current model"""
        if not self.model:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'model_state_dict': self.model.model.state_dict(),
                    'optimizer_state_dict': self.model.optimizer.state_dict(),
                    'criterion': self.model.criterion,
                    'image_size': 32,
                    'ngf': self.settings['ngf'].get(),
                    'blur_sigma': self.settings['blur_sigma'].get(),
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_model(self):
        """Load UNet model from file"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])
                
                if 'blur_sigma' in checkpoint:
                    self.settings['blur_sigma'].set(checkpoint['blur_sigma'])
                    self.update_blur_display()
                    # Also update the deblur tab dropdown
                    self.current_blur_var.set(str(checkpoint['blur_sigma']))
                
                # Initialize model with loaded settings
                self.initialize_model()
                
                # Load state dict
                self.model.model.load_state_dict(checkpoint['model_state_dict'])
                
                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                self.log_message(f"Trained with blur sigma: {checkpoint.get('blur_sigma', 'unknown')}")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def load_sharp_image(self):
        """Load a sharp image for deblurring"""
        filename = filedialog.askopenfilename(
            title="Select sharp image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if filename:
            try:
                img = Image.open(filename).convert('RGB')
                img = img.resize((32, 32), Image.NEAREST)  # Use NEAREST neighbor
                self.current_sharp_image = img
                
                # Display with NEAREST neighbor
                display_img = img.resize((200, 200), Image.NEAREST)
                photo = ImageTk.PhotoImage(display_img)
                self.original_image_label.config(image=photo, text="")
                self.original_image_label.image = photo
                
                self.log_message(f"Loaded sharp image: {os.path.basename(filename)}")
                
            except Exception as e:
                self.log_message(f"Error loading image: {str(e)}")

    def apply_blur_to_current(self):
        """Apply Gaussian blur to current sharp image"""
        if self.current_sharp_image is None:
            self.log_message("Error: No sharp image loaded!")
            return
        
        try:
            # Get blur sigma from dropdown or custom entry
            try:
                blur_sigma = float(self.current_blur_var.get())
            except ValueError:
                # Try custom entry
                blur_sigma = float(self.custom_blur_var.get())
            
            blurred_img = self.current_sharp_image.filter(
                ImageFilter.GaussianBlur(radius=blur_sigma)
            )
            self.current_blurred_image = blurred_img
            
            # Display with NEAREST neighbor
            display_img = blurred_img.resize((200, 200), Image.NEAREST)
            photo = ImageTk.PhotoImage(display_img)
            self.blurred_display_label.config(image=photo, text="")
            self.blurred_display_label.image = photo
            
            self.log_message(f"Applied blur with sigma={blur_sigma}")
            
        except Exception as e:
            self.log_message(f"Error applying blur: {str(e)}")

    def load_blurred_image(self):
        """Load a pre-blurred image"""
        filename = filedialog.askopenfilename(
            title="Select blurred image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if filename:
            try:
                img = Image.open(filename).convert('RGB')
                img = img.resize((32, 32), Image.NEAREST)  # Use NEAREST neighbor
                self.current_blurred_image = img
                
                # Display with NEAREST neighbor
                display_img = img.resize((200, 200), Image.NEAREST)
                photo = ImageTk.PhotoImage(display_img)
                self.blurred_display_label.config(image=photo, text="")
                self.blurred_display_label.image = photo
                
                self.log_message(f"Loaded blurred image: {os.path.basename(filename)}")
                
            except Exception as e:
                self.log_message(f"Error loading image: {str(e)}")

    def deblur_current(self):
        """Deblur current blurred image"""
        if not self.model:
            self.log_message("Error: UNet not loaded!")
            return
        
        if self.current_blurred_image is None:
            self.log_message("Error: No blurred image to deblur!")
            return
        
        try:
            # Convert PIL to tensor
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            blurred_tensor = transform(self.current_blurred_image).unsqueeze(0)
            blurred_tensor = blurred_tensor.to(self.model.device)
            
            with torch.no_grad():
                deblurred_tensor = self.model.model(blurred_tensor).cpu()
            
            # Convert back to PIL
            self.current_deblurred_image = self.tensor_to_pil(deblurred_tensor[0])
            
            # Display with NEAREST neighbor
            display_img = self.current_deblurred_image.resize((200, 200), Image.NEAREST)
            photo = ImageTk.PhotoImage(display_img)
            self.deblurred_display_label.config(image=photo, text="")
            self.deblurred_display_label.image = photo
            
            self.log_message("Successfully deblurred image")
            
        except Exception as e:
            self.log_message(f"Error deblurring image: {str(e)}")

    def batch_deblur(self):
        """Deblur multiple images"""
        if not self.model:
            self.log_message("Error: UNet not loaded!")
            return
        
        files = filedialog.askopenfilenames(
            title="Select images to deblur",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if not files:
            return
        
        save_dir = filedialog.askdirectory(title="Select directory to save deblurred images")
        if not save_dir:
            return
        
        try:
            transform = transforms.Compose([
                transforms.Resize((32, 32)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            for i, file in enumerate(files):
                # Load and preprocess
                img = Image.open(file).convert('RGB')
                input_tensor = transform(img).unsqueeze(0).to(self.model.device)
                
                # Deblur
                with torch.no_grad():
                    output_tensor = self.model.model(input_tensor).cpu()
                
                # Convert back to PIL and save
                deblurred_img = self.tensor_to_pil(output_tensor[0])
                
                # Save with original name
                base_name = os.path.basename(file)
                name, ext = os.path.splitext(base_name)
                save_path = os.path.join(save_dir, f"{name}_deblurred{ext}")
                deblurred_img.save(save_path)
                
                self.log_message(f"Processed {i+1}/{len(files)}: {base_name}")
            
            self.log_message(f"Batch deblurring complete. Saved to {save_dir}")
            
        except Exception as e:
            self.log_message(f"Error in batch deblurring: {str(e)}")

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('deblur_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            import json
            if os.path.exists('deblur_defaults.json'):
                with open('deblur_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.update_blur_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting UNet Deblurring Trainer...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = DeblurApp(root)
    root.mainloop()