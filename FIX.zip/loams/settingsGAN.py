import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk, ImageDraw, ImageFont
import os
import threading
import queue
import numpy as np
import traceback
import sys
import random

# ==================== BIG DCGAN (Fixed Kernel Issue) ====================

class BigDCGAN:
    def __init__(self, image_size=64, latent_dim=350, use_skip=True, base_channels=128):
        """
        BIG 32x32/64x64 GAN with fixed kernel issues
        """
        self.image_size = image_size
        self.latent_dim = latent_dim
        self.use_skip = use_skip
        self.base_channels = base_channels
        
        torch.set_num_threads(2)
        if torch.cuda.is_available():
            print("CUDA available")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # BIG Generator
        class Generator(nn.Module):
            def __init__(self, image_size, latent_dim, use_skip=True, base_channels=128):
                super().__init__()
                self.image_size = image_size
                self.use_skip = use_skip
                self.base_channels = base_channels
                
                if image_size == 64:
                    self.projection = nn.Sequential(
                        nn.Linear(latent_dim, base_channels * 8 * 4 * 4),
                        nn.ReLU(True),
                        nn.Dropout(0.1)
                    )
                    
                    self.block1 = UpsampleBlock(base_channels * 8, base_channels * 4, use_skip)
                    self.block2 = UpsampleBlock(base_channels * 4, base_channels * 2, use_skip)
                    self.block3 = UpsampleBlock(base_channels * 2, base_channels, use_skip)
                    self.block4 = UpsampleBlock(base_channels, base_channels // 2, use_skip)
                    
                    self.final = nn.Sequential(
                        nn.Conv2d(base_channels // 2, base_channels // 2, 3, padding=1, padding_mode='replicate'),
                        nn.BatchNorm2d(base_channels // 2),
                        nn.ReLU(True),
                        nn.Conv2d(base_channels // 2, base_channels // 4, 3, padding=1, padding_mode='replicate'),
                        nn.BatchNorm2d(base_channels // 4),
                        nn.ReLU(True),
                        nn.Conv2d(base_channels // 4, 3, 3, padding=1, padding_mode='replicate'),
                        nn.Tanh()
                    )
                    
                else:  # 32x32
                    self.projection = nn.Sequential(
                        nn.Linear(latent_dim, base_channels * 4 * 4 * 4),
                        nn.ReLU(True),
                        nn.Dropout(0.1)
                    )
                    
                    self.block1 = UpsampleBlock(base_channels * 4, base_channels * 2, use_skip)
                    self.block2 = UpsampleBlock(base_channels * 2, base_channels, use_skip)
                    self.block3 = UpsampleBlock(base_channels, base_channels // 2, use_skip)
                    
                    self.final = nn.Sequential(
                        nn.Conv2d(base_channels // 2, base_channels // 2, 3, padding=1, padding_mode='replicate'),
                        nn.BatchNorm2d(base_channels // 2),
                        nn.ReLU(True),
                        nn.Conv2d(base_channels // 2, 3, 3, padding=1, padding_mode='replicate'),
                        nn.Tanh()
                    )
                
            def forward(self, x):
                batch_size = x.size(0)
                x = self.projection(x)
                
                if self.image_size == 64:
                    x = x.view(-1, self.base_channels * 8, 4, 4)
                    x = self.block1(x)
                    x = self.block2(x)
                    x = self.block3(x)
                    x = self.block4(x)
                else:
                    x = x.view(-1, self.base_channels * 4, 4, 4)
                    x = self.block1(x)
                    x = self.block2(x)
                    x = self.block3(x)
                
                return self.final(x)
        
        # Upsample block
        class UpsampleBlock(nn.Module):
            def __init__(self, in_channels, out_channels, use_skip=True):
                super().__init__()
                self.use_skip = use_skip
                
                self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
                
                self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1, padding_mode='replicate')
                self.bn1 = nn.BatchNorm2d(out_channels)
                self.relu1 = nn.ReLU(True)
                
                self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1, padding_mode='replicate')
                self.bn2 = nn.BatchNorm2d(out_channels)
                
                if use_skip and in_channels != out_channels:
                    self.skip_conv = nn.Conv2d(in_channels, out_channels, 1)
                elif use_skip:
                    self.skip_conv = nn.Identity()
                else:
                    self.skip_conv = None
                
                self.relu2 = nn.ReLU(True)
                self.dropout = nn.Dropout2d(0.1)
            
            def forward(self, x):
                residual = x
                
                x = self.upsample(x)
                
                x = self.conv1(x)
                x = self.bn1(x)
                x = self.relu1(x)
                
                x = self.conv2(x)
                x = self.bn2(x)
                
                if self.use_skip and self.skip_conv is not None:
                    residual = self.upsample(residual)
                    if not isinstance(self.skip_conv, nn.Identity):
                        residual = self.skip_conv(residual)
                    x = x + residual
                
                x = self.relu2(x)
                x = self.dropout(x)
                return x
        
        # FIXED Discriminator
        class Discriminator(nn.Module):
            def __init__(self, image_size, base_channels=128):
                super().__init__()
                
                def safe_conv_block(in_c, out_c, kernel=4, stride=2, padding=1):
                    return nn.Sequential(
                        nn.Conv2d(in_c, out_c, kernel, stride=stride, padding=padding, padding_mode='replicate'),
                        nn.BatchNorm2d(out_c),
                        nn.LeakyReLU(0.2, inplace=True),
                        nn.Dropout2d(0.2)
                    )
                
                if image_size == 64:
                    self.main = nn.Sequential(
                        nn.Conv2d(3, base_channels // 2, 4, stride=2, padding=1, padding_mode='replicate'),
                        nn.LeakyReLU(0.2, inplace=True),
                        nn.Dropout2d(0.2),
                        
                        safe_conv_block(base_channels // 2, base_channels),
                        safe_conv_block(base_channels, base_channels * 2),
                        safe_conv_block(base_channels * 2, base_channels * 4),
                        safe_conv_block(base_channels * 4, base_channels * 8, kernel=3, stride=1, padding=0),
                        nn.Conv2d(base_channels * 8, 1, 2, stride=1, padding=0),
                    )
                else:  # 32x32
                    self.main = nn.Sequential(
                        nn.Conv2d(3, base_channels // 2, 4, stride=2, padding=1, padding_mode='replicate'),
                        nn.LeakyReLU(0.2, inplace=True),
                        nn.Dropout2d(0.2),
                        
                        safe_conv_block(base_channels // 2, base_channels),
                        safe_conv_block(base_channels, base_channels * 2),
                        safe_conv_block(base_channels * 2, base_channels * 4, kernel=3, stride=1, padding=0),
                        nn.Conv2d(base_channels * 4, 1, 2, stride=1, padding=0),
                    )
                
                self.sigmoid = nn.Sigmoid()
            
            def forward(self, x):
                if x.size(2) < 4 or x.size(3) < 4:
                    x = nn.functional.interpolate(x, size=(max(4, x.size(2)), max(4, x.size(3))), mode='bilinear', align_corners=False)
                
                features = self.main(x)
                return self.sigmoid(features.view(x.size(0), -1)).squeeze()
        
        self.generator = Generator(image_size, latent_dim, use_skip, base_channels)
        self.discriminator = Discriminator(image_size, base_channels)
        
        self._initialize_weights()
        
        self.criterion = nn.BCELoss()
        
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0001, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0004, betas=(0.5, 0.999))
        
        self.schedulerG = optim.lr_scheduler.StepLR(self.optimizerG, step_size=30, gamma=0.8)
        self.schedulerD = optim.lr_scheduler.StepLR(self.optimizerD, step_size=30, gamma=0.8)
        
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
        
        self._print_model_size()
    
    def _initialize_weights(self):
        for m in self.generator.modules():
            if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
                nn.init.normal_(m.weight, 0.0, 0.02)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.normal_(m.weight, 1.0, 0.02)
                nn.init.constant_(m.bias, 0)
        
        for m in self.discriminator.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight, 0.0, 0.02)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.normal_(m.weight, 1.0, 0.02)
                nn.init.constant_(m.bias, 0)
    
    def _print_model_size(self):
        g_params = sum(p.numel() for p in self.generator.parameters())
        d_params = sum(p.numel() for p in self.discriminator.parameters())
        total_params = g_params + d_params
        
        print(f"\n{'='*40}")
        print(f"Big DCGAN Model Size:")
        print(f"{'='*40}")
        print(f"Image Size: {self.image_size}x{self.image_size}")
        print(f"Latent Dim: {self.latent_dim}")
        print(f"Base Channels: {self.base_channels}")
        print(f"Generator: {g_params:,} params")
        print(f"Discriminator: {d_params:,} params")
        print(f"Total: {total_params:,} parameters")
        print(f"{'='*40}")

# ==================== Dataset ====================

class CleanImageDataset(Dataset):
    def __init__(self, image_paths, image_size=64, augment=True):
        self.image_paths = image_paths
        self.image_size = image_size
        self.augment = augment
        
        if augment:
            self.transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            if img.size[0] < self.image_size or img.size[1] < self.image_size:
                img = img.resize((self.image_size, self.image_size), Image.Resampling.LANCZOS)
            return self.transform(img)
        except:
            return torch.randn(3, self.image_size, self.image_size) * 0.3 + 0.5

# ==================== GUI ====================

class BigDCGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Big DCGAN Explorer")
        self.root.geometry("950x750")
        
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        self.setup_gui()
        self.root.after(100, self.process_messages)
    
    def setup_gui(self):
        main_container = tk.Frame(self.root, padx=5, pady=5)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Left panel
        left_frame = tk.Frame(main_container, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Big DCGAN", font=("Arial", 12, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 10), sticky="w")
        
        # Model config
        tk.Label(left_frame, text="Image Size:").grid(row=1, column=0, sticky="w", pady=(0, 5))
        self.size_var = tk.StringVar(value="64")
        size_frame = tk.Frame(left_frame)
        size_frame.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        tk.Radiobutton(size_frame, text="32x32", variable=self.size_var, value="32").pack(side=tk.LEFT, padx=(0, 10))
        tk.Radiobutton(size_frame, text="64x64", variable=self.size_var, value="64").pack(side=tk.LEFT)
        
        tk.Label(left_frame, text="Latent Dim:").grid(row=3, column=0, sticky="w", pady=(0, 5))
        self.latent_var = tk.StringVar(value="350")
        tk.Entry(left_frame, textvariable=self.latent_var).grid(row=4, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        tk.Label(left_frame, text="Channels:").grid(row=5, column=0, sticky="w", pady=(0, 5))
        self.channels_var = tk.StringVar(value="128")
        channels_frame = tk.Frame(left_frame)
        channels_frame.grid(row=6, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        tk.Radiobutton(channels_frame, text="64", variable=self.channels_var, value="64").pack(side=tk.LEFT, padx=(0, 5))
        tk.Radiobutton(channels_frame, text="128", variable=self.channels_var, value="128").pack(side=tk.LEFT, padx=(0, 5))
        tk.Radiobutton(channels_frame, text="256", variable=self.channels_var, value="256").pack(side=tk.LEFT)
        
        self.skip_var = tk.BooleanVar(value=True)
        tk.Checkbutton(left_frame, text="Skip Connections", variable=self.skip_var).grid(row=7, column=0, columnspan=2, sticky="w", pady=(0, 10))
        
        self.augment_var = tk.BooleanVar(value=False)
        tk.Checkbutton(left_frame, text="Data Augmentation", variable=self.augment_var).grid(row=8, column=0, columnspan=2, sticky="w", pady=(0, 10))
        
        # Dataset buttons
        tk.Button(left_frame, text="Add Images", command=self.add_images, height=2).grid(row=9, column=0, columnspan=2, sticky="ew", pady=5)
        tk.Button(left_frame, text="Clear All", command=self.clear_images, height=2, bg="salmon").grid(row=10, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        # Image list
        tk.Label(left_frame, text="Images:").grid(row=11, column=0, sticky="w", pady=(0, 5))
        
        list_frame = tk.Frame(left_frame)
        list_frame.grid(row=12, column=0, columnspan=2, sticky="nsew", pady=(0, 10))
        
        self.image_listbox = tk.Listbox(list_frame, height=6)
        self.image_listbox.grid(row=0, column=0, sticky="nsew")
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.grid(row=0, column=1, sticky="ns")
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training settings
        tk.Label(left_frame, text="Epochs:").grid(row=13, column=0, sticky="w")
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(left_frame, textvariable=self.epoch_var).grid(row=14, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        tk.Label(left_frame, text="Batch Size:").grid(row=15, column=0, sticky="w")
        self.batch_var = tk.StringVar(value="16")
        tk.Entry(left_frame, textvariable=self.batch_var).grid(row=16, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        # Display settings - NEW!
        tk.Label(left_frame, text="Display Scale:").grid(row=17, column=0, sticky="w", pady=(0, 5))
        self.scale_var = tk.StringVar(value="4")
        scale_frame = tk.Frame(left_frame)
        scale_frame.grid(row=18, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        tk.Radiobutton(scale_frame, text="2x", variable=self.scale_var, value="2").pack(side=tk.LEFT, padx=(0, 5))
        tk.Radiobutton(scale_frame, text="4x", variable=self.scale_var, value="4").pack(side=tk.LEFT, padx=(0, 5))
        tk.Radiobutton(scale_frame, text="8x", variable=self.scale_var, value="8").pack(side=tk.LEFT)
        
        tk.Label(left_frame, text="Grid Size:").grid(row=19, column=0, sticky="w", pady=(0, 5))
        self.grid_var = tk.StringVar(value="4")
        tk.Entry(left_frame, textvariable=self.grid_var, width=10).grid(row=20, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        # Control buttons
        tk.Button(left_frame, text="Initialize Model", command=self.initialize_gan, height=2).grid(row=21, column=0, columnspan=2, sticky="ew", pady=5)
        tk.Button(left_frame, text="Start Training", command=self.start_training, height=2, bg="lightgreen").grid(row=22, column=0, columnspan=2, sticky="ew", pady=5)
        tk.Button(left_frame, text="Stop Training", command=self.stop_training, height=2, bg="salmon").grid(row=23, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Generate Sample", command=self.generate_sample, height=2).grid(row=24, column=0, columnspan=2, sticky="ew", pady=5)
        tk.Button(left_frame, text="Generate Grid", command=self.generate_interpolation_grid, height=2, bg="lightblue").grid(row=25, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Status
        tk.Label(left_frame, text="Status:").grid(row=26, column=0, sticky="w", pady=(10, 5))
        self.status_label = tk.Label(left_frame, text="Ready", relief=tk.SUNKEN, height=2, anchor="w", padx=5)
        self.status_label.grid(row=27, column=0, columnspan=2, sticky="ew", pady=(0, 5))
        
        left_frame.grid_rowconfigure(12, weight=1)
        left_frame.grid_columnconfigure(0, weight=1)
        
        # Right panel
        right_frame = tk.Frame(main_container)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image
        single_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=5, pady=5)
        single_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.image_label = tk.Label(single_frame)
        self.image_label.pack(pady=5)
        
        # Grid
        grid_frame = tk.LabelFrame(right_frame, text="Latent Space Grid", padx=5, pady=5)
        grid_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.grid_canvas = tk.Canvas(grid_frame, bg="white")
        self.grid_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        grid_scrollbar = tk.Scrollbar(grid_frame, orient=tk.VERTICAL, command=self.grid_canvas.yview)
        grid_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.grid_canvas.configure(yscrollcommand=grid_scrollbar.set)
        
        self.grid_frame = tk.Frame(self.grid_canvas, bg="white")
        self.canvas_window = self.grid_canvas.create_window((0, 0), window=self.grid_frame, anchor="nw")
        
        self.grid_frame.bind("<Configure>", self._on_frame_configure)
        self.grid_canvas.bind("<Configure>", self._on_canvas_configure)
        
        # Log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=5, pady=5)
        log_frame.pack(fill=tk.X)
        
        self.log_text = tk.Text(log_frame, height=6, width=60, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        log_scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=log_scrollbar.set)
    
    def _on_frame_configure(self, event=None):
        self.grid_canvas.configure(scrollregion=self.grid_canvas.bbox("all"))
    
    def _on_canvas_configure(self, event):
        self.grid_canvas.itemconfig(self.canvas_window, width=event.width)
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
                status_text = message[:40] + "..." if len(message) > 40 else message
                self.status_label.config(text=status_text)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")
    
    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images")
    
    def initialize_gan(self):
        try:
            image_size = int(self.size_var.get())
            latent_dim = int(self.latent_var.get())
            use_skip = self.skip_var.get()
            base_channels = int(self.channels_var.get())
            
            self.gan = BigDCGAN(
                image_size=image_size,
                latent_dim=latent_dim,
                use_skip=use_skip,
                base_channels=base_channels
            )
            
            self.log_message(f"Initialized Big DCGAN")
            self.log_message(f"Size: {image_size}x{image_size}")
            self.log_message(f"Latent dim: {latent_dim}")
            self.log_message(f"Channels: {base_channels}")
            
        except Exception as e:
            self.log_message(f"Error: {str(e)}")
            print(f"Error: {e}")
            traceback.print_exc()
    
    def start_training(self):
        if not self.image_paths:
            self.log_message("No images!")
            return
        
        if not self.gan:
            self.log_message("Initialize first!")
            return
        
        if self.training:
            self.log_message("Already training!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            batch_size = int(self.batch_var.get())
            image_size = int(self.size_var.get())
            augment = self.augment_var.get()
            
            self.training = True
            
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, image_size, augment),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Training {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}")
            
        except ValueError:
            self.log_message("Invalid numbers!")
    
    def train_gan(self, epochs, batch_size, image_size, augment):
        try:
            dataset = CleanImageDataset(self.image_paths, image_size, augment=augment)
            dataloader = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=True,
                num_workers=0,
                pin_memory=False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                
                for i, real_images in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    batch_size_current = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # Train D
                    self.gan.optimizerD.zero_grad()
                    
                    real_labels = torch.rand(batch_size_current, device=self.gan.device) * 0.3 + 0.7
                    output_real = self.gan.discriminator(real_images)
                    loss_real = self.gan.criterion(output_real, real_labels)
                    
                    noise = torch.randn(batch_size_current, self.gan.latent_dim, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    
                    fake_labels = torch.rand(batch_size_current, device=self.gan.device) * 0.3
                    output_fake = self.gan.discriminator(fake_images.detach())
                    loss_fake = self.gan.criterion(output_fake, fake_labels)
                    
                    loss_d = (loss_real + loss_fake) / 2
                    loss_d.backward()
                    self.gan.optimizerD.step()
                    
                    # Train G
                    self.gan.optimizerG.zero_grad()
                    
                    output_fake = self.gan.discriminator(fake_images)
                    loss_g = self.gan.criterion(output_fake, real_labels)
                    loss_g.backward()
                    self.gan.optimizerG.step()
                    
                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    
                    self.log_message(f"E{epoch+1}: D={avg_loss_d:.4f} G={avg_loss_g:.4f}")
                
                self.gan.schedulerG.step()
                self.gan.schedulerD.step()
                
                if (epoch + 1) % 5 == 0:
                    self.generate_sample_internal(show=False)
            
            self.training = False
            self.log_message("Training done!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            print(f"Error: {e}")
            traceback.print_exc()
            self.training = False
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Stopped")
    
    def generate_sample_internal(self, show=True, seed=None):
        if not self.gan:
            return None
        
        try:
            with torch.no_grad():
                self.gan.generator.eval()
                
                if seed is not None:
                    torch.manual_seed(seed)
                    noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                else:
                    noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                
                generated = self.gan.generator(noise)
                img = generated[0].cpu()
                img = (img + 1) / 2
                img = transforms.ToPILImage()(img)
                
                # Apply display scale - FIXED!
                scale_factor = int(self.scale_var.get())
                display_size = self.gan.image_size * scale_factor
                img = img.resize((display_size, display_size), Image.Resampling.LANCZOS)
                
                if show:
                    self.display_image(img)
                
                if self.training:
                    self.gan.generator.train()
                
                return img
                
        except Exception as e:
            self.log_message(f"Gen error: {str(e)}")
            return None
    
    def generate_sample(self):
        img = self.generate_sample_internal(show=True)
        if img:
            self.current_image = img
            self.log_message("Generated sample")
    
    def generate_interpolation_grid(self):
        if not self.gan:
            self.log_message("No model!")
            return
        
        try:
            grid_size = int(self.grid_var.get())
            scale_factor = int(self.scale_var.get())
            
            for widget in self.grid_frame.winfo_children():
                widget.destroy()
            
            self.log_message(f"Generating {grid_size}x{grid_size} grid...")
            
            # Generate two random noise vectors
            noise1 = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
            noise2 = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
            noise3 = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
            
            with torch.no_grad():
                self.gan.generator.eval()
                
                for i in range(grid_size):
                    for j in range(grid_size):
                        # Interpolate in 2D
                        alpha_i = i / max(grid_size - 1, 1)
                        alpha_j = j / max(grid_size - 1, 1)
                        
                        # Bilinear interpolation between 3 noise vectors
                        noise_top = (1 - alpha_j) * noise1 + alpha_j * noise2
                        noise_bottom = (1 - alpha_j) * noise2 + alpha_j * noise3
                        noise = (1 - alpha_i) * noise_top + alpha_i * noise_bottom
                        
                        generated = self.gan.generator(noise)
                        img = generated[0].cpu()
                        img = (img + 1) / 2
                        img = transforms.ToPILImage()(img)
                        
                        # Apply scale
                        display_size = self.gan.image_size * scale_factor
                        img = img.resize((display_size, display_size), Image.Resampling.LANCZOS)
                        
                        photo = ImageTk.PhotoImage(img)
                        label = tk.Label(self.grid_frame, image=photo, bg="white")
                        label.image = photo
                        label.grid(row=i, column=j, padx=1, pady=1)
                
                self.gan.generator.train()
            
            self.log_message(f"Generated {grid_size}x{grid_size} grid")
            
        except Exception as e:
            self.log_message(f"Grid error: {str(e)}")
            print(f"Error: {e}")
            traceback.print_exc()
    
    def display_image(self, img):
        photo = ImageTk.PhotoImage(img)
        self.image_label.config(image=photo)
        self.image_label.image = photo

# ==================== Main ====================

if __name__ == "__main__":
    print("Big DCGAN Explorer")
    print("Now with display scaling and grid controls!")
    
    try:
        root = tk.Tk()
        app = BigDCGANApp(root)
        root.mainloop()
    except Exception as e:
        print(f"Error: {e}")
        traceback.print_exc()
        input("Press Enter to exit...")