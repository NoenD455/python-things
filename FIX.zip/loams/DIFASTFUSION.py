import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import time
import math
from pathlib import Path
import multiprocessing

# ==================== Diffusion DCNN ====================

class SimpleDiffusionDCNN:
    def __init__(self, image_size=32, channels=3, base_channels=32):
        self.image_size = image_size
        self.channels = channels
        self.base_channels = base_channels
        
        # Use all CPU cores
        torch.set_num_threads(multiprocessing.cpu_count())
        print(f"Using {torch.get_num_threads()} CPU threads")
        
        # Diffusion parameters - FEWER timesteps for faster training
        self.timesteps = 200  # Reduced from 1000 for CPU speed
        self.beta_start = 0.0001
        self.beta_end = 0.02
        
        # Precompute diffusion schedule
        self.betas = torch.linspace(self.beta_start, self.beta_end, self.timesteps)
        self.alphas = 1. - self.betas
        self.alphas_cumprod = torch.cumprod(self.alphas, dim=0)
        self.sqrt_alphas_cumprod = torch.sqrt(self.alphas_cumprod)
        self.sqrt_one_minus_alphas_cumprod = torch.sqrt(1. - self.alphas_cumprod)
        
        # Simple DCNN for diffusion
        class DiffusionModel(nn.Module):
            def __init__(self, channels, base_channels):
                super().__init__()
                
                # Time embedding - FIXED: expects float input
                self.time_embed = nn.Sequential(
                    nn.Linear(1, base_channels * 4),
                    nn.SiLU(),
                    nn.Linear(base_channels * 4, base_channels * 4),
                )
                
                # First conv
                self.conv1 = nn.Conv2d(channels + base_channels * 4, base_channels, 3, padding=1)
                
                # Downsample path
                self.down1 = nn.Sequential(
                    nn.Conv2d(base_channels, base_channels * 2, 3, padding=1),
                    nn.GroupNorm(8, base_channels * 2),
                    nn.SiLU(),
                    nn.Conv2d(base_channels * 2, base_channels * 2, 3, padding=1),
                    nn.GroupNorm(8, base_channels * 2),
                    nn.SiLU(),
                    nn.MaxPool2d(2)
                )
                
                self.down2 = nn.Sequential(
                    nn.Conv2d(base_channels * 2, base_channels * 4, 3, padding=1),
                    nn.GroupNorm(8, base_channels * 4),
                    nn.SiLU(),
                    nn.Conv2d(base_channels * 4, base_channels * 4, 3, padding=1),
                    nn.GroupNorm(8, base_channels * 4),
                    nn.SiLU(),
                    nn.MaxPool2d(2)
                )
                
                # Middle
                self.middle = nn.Sequential(
                    nn.Conv2d(base_channels * 4, base_channels * 4, 3, padding=1),
                    nn.GroupNorm(8, base_channels * 4),
                    nn.SiLU(),
                    nn.Conv2d(base_channels * 4, base_channels * 4, 3, padding=1),
                    nn.GroupNorm(8, base_channels * 4),
                    nn.SiLU(),
                )
                
                # Upsample path
                self.up2 = nn.Sequential(
                    nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                    nn.Conv2d(base_channels * 4, base_channels * 2, 3, padding=1),
                    nn.GroupNorm(8, base_channels * 2),
                    nn.SiLU(),
                    nn.Conv2d(base_channels * 2, base_channels * 2, 3, padding=1),
                    nn.GroupNorm(8, base_channels * 2),
                    nn.SiLU(),
                )
                
                self.up1 = nn.Sequential(
                    nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                    nn.Conv2d(base_channels * 2, base_channels, 3, padding=1),
                    nn.GroupNorm(8, base_channels),
                    nn.SiLU(),
                    nn.Conv2d(base_channels, base_channels, 3, padding=1),
                    nn.GroupNorm(8, base_channels),
                    nn.SiLU(),
                )
                
                # Final output
                self.final = nn.Conv2d(base_channels, channels, 3, padding=1)
                
            def forward(self, x, t):
                # FIX: Convert t to float
                # t is Long tensor of shape [batch_size], convert to float
                t_float = t.float().unsqueeze(-1)  # Convert to float and add dimension
                
                # Time embedding
                t_embed = self.time_embed(t_float)
                t_embed = t_embed.view(t_embed.shape[0], -1, 1, 1)
                t_embed = t_embed.expand(-1, -1, x.shape[2], x.shape[3])
                
                # Combine with input
                x = torch.cat([x, t_embed], dim=1)
                
                # Downsample
                x1 = self.conv1(x)
                x2 = self.down1(x1)
                x3 = self.down2(x2)
                
                # Middle
                x_mid = self.middle(x3)
                
                # Upsample with skip connections
                x_up2 = self.up2(x_mid + x3)
                x_up1 = self.up1(x_up2 + x2)
                
                # Final
                return self.final(x_up1 + x1)
        
        self.model = DiffusionModel(channels, base_channels)
        
        # Optimizer with lower memory footprint
        self.optimizer = optim.AdamW(self.model.parameters(), lr=1e-3, weight_decay=1e-4)
        
        # Device
        self.device = torch.device("cpu")  # Force CPU for compatibility
        self.model.to(self.device)
        
        # Move precomputed tensors to device
        self.betas = self.betas.to(self.device)
        self.alphas_cumprod = self.alphas_cumprod.to(self.device)
        self.sqrt_alphas_cumprod = self.sqrt_alphas_cumprod.to(self.device)
        self.sqrt_one_minus_alphas_cumprod = self.sqrt_one_minus_alphas_cumprod.to(self.device)
        
        # Count parameters
        total_params = sum(p.numel() for p in self.model.parameters())
        print(f"Diffusion DCNN parameters: {total_params:,}")
        print(f"Model size: {total_params * 4 / (1024*1024):.2f} MB")

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        # SIMPLER transform - no random crops/flips to speed up
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class DiffusionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Diffusion DCNN Trainer - CPU Optimized")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.diffusion = None
        self.current_epoch = 0
        self.current_step = 0
        self.message_queue = queue.Queue()
        
        # Settings optimized for CPU - ADDED MORE SETTINGS
        self.settings = {
            'image_size': tk.IntVar(value=32),  # Only 32x32 for speed
            'base_channels': tk.IntVar(value=32),  # Reduced from 64
            'timesteps': tk.IntVar(value=200),  # Reduced for faster training
            'batch_size': tk.IntVar(value=8),  # Smaller batch for CPU
            'learning_rate': tk.DoubleVar(value=1e-3),
            'num_workers': tk.IntVar(value=2),  # Reduced for stability
            'generate_interval': tk.IntVar(value=5),
            'sampling_steps': tk.IntVar(value=50),  # For generation
        }
        
        # For storing generated images
        self.generated_images = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings - ADDED BACK!
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Diffusion DCNN Trainer", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text=f"Image Size: {self.settings['image_size'].get()}x{self.settings['image_size'].get()}")
        self.size_display.pack(pady=(0, 10))
        
        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize Model", 
                 command=self.initialize_model, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="50")  # Fewer epochs needed
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Quick Actions", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.single_image_frame = tk.Frame(preview_frame, width=256, height=256, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar
        self.status_label = tk.Label(self.training_tab, text="Ready - Optimized for CPU", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="Diffusion DCNN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Image size
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed for CPU speed)", width=20).pack(side=tk.LEFT, padx=5)
        
        # Other parameters
        settings_list = [
            ("Base Channels:", 'base_channels', 16, 128),
            ("Timesteps (Training):", 'timesteps', 50, 500),
            ("Batch Size:", 'batch_size', 1, 32),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.0001, 0.01),
            ("Generate Interval (epochs):", 'generate_interval', 1, 20),
            ("Number of Workers:", 'num_workers', 1, min(4, multiprocessing.cpu_count())),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            
            if var_name == 'learning_rate':
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=0.0001).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Generation settings
        gen_frame = tk.LabelFrame(scrollable_frame, text="Generation Settings", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(gen_frame, text="Sampling Steps:", width=25, anchor='w').pack(anchor='w', pady=5)
        tk.Scale(gen_frame, from_=10, to=200, variable=self.settings['sampling_steps'],
                orient=tk.HORIZONTAL, length=200).pack(fill=tk.X, pady=5)
        tk.Label(gen_frame, textvariable=self.settings['sampling_steps'], width=5).pack(anchor='e', pady=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text="Device: CPU (Optimized)", anchor='w').pack(fill=tk.X, pady=2)
        
        # Preset buttons
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Fast Preset", 
                 command=self.set_fast_preset, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Quality Preset", 
                 command=self.set_quality_preset, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset Defaults", 
                 command=self.reset_defaults, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load Diffusion Model", 
                 command=self.load_model, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=4)  # Smaller default for CPU
        tk.Scale(gen_frame, from_=1, to=16, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=250).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def update_size_display(self):
        """Update image size display"""
        size = self.settings['image_size'].get()
        self.size_display.config(text=f"Image Size: {size}x{size}")

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_model(self):
        """Initialize diffusion model"""
        try:
            image_size = self.settings['image_size'].get()
            base_channels = self.settings['base_channels'].get()
            
            self.diffusion = SimpleDiffusionDCNN(
                image_size=image_size,
                base_channels=base_channels
            )
            
            # Update timesteps from settings
            self.diffusion.timesteps = self.settings['timesteps'].get()
            
            self.log_message(f"Initialized Diffusion DCNN for {image_size}x{image_size} images")
            self.log_message(f"Base channels: {base_channels}, Timesteps: {self.diffusion.timesteps}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing model: {str(e)}")
            import traceback
            traceback.print_exc()

    def forward_diffusion(self, x0, t):
        """Add noise to image at timestep t - FIXED dtype"""
        noise = torch.randn_like(x0)
        # Convert t to float for indexing
        t_float = t.float()
        sqrt_alpha_cumprod_t = self.diffusion.sqrt_alphas_cumprod[t_float.long()].view(-1, 1, 1, 1)
        sqrt_one_minus_alpha_cumprod_t = self.diffusion.sqrt_one_minus_alphas_cumprod[t_float.long()].view(-1, 1, 1, 1)
        noisy = sqrt_alpha_cumprod_t * x0 + sqrt_one_minus_alpha_cumprod_t * noise
        return noisy, noise

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.diffusion:
            self.log_message("Error: Model not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.current_step = 0
            start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            
            # Update optimizer
            for param_group in self.diffusion.optimizer.param_groups:
                param_group['lr'] = lr
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_model,
                args=(epochs, batch_size, num_workers),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}")
            self.log_message(f"Training on {len(self.image_paths)} images")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_model(self, epochs, batch_size, num_workers):
        """Training loop - FIXED dtype issues"""
        try:
            image_size = self.settings['image_size'].get()
            
            # Create dataset and dataloader
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, 2),  # Keep small for CPU
                pin_memory=False  # Disable for CPU
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss = 0
                batch_count = 0
                epoch_start = time.time()
                
                for x0 in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = x0.size(0)
                    x0 = x0.to(self.diffusion.device)
                    
                    # Sample random timesteps - ensure on correct device
                    t = torch.randint(0, self.diffusion.timesteps, (batch_size_actual,), 
                                    device=self.diffusion.device).long()
                    
                    # Forward diffusion
                    noisy, noise = self.forward_diffusion(x0, t)
                    
                    # Predict noise - FIX: ensure t is long tensor
                    self.diffusion.optimizer.zero_grad()
                    noise_pred = self.diffusion.model(noisy, t)
                    
                    # Simple MSE loss
                    loss = torch.nn.functional.mse_loss(noise_pred, noise)
                    loss.backward()
                    
                    # Gradient clipping for stability
                    torch.nn.utils.clip_grad_norm_(self.diffusion.model.parameters(), 1.0)
                    
                    self.diffusion.optimizer.step()
                    
                    total_loss += loss.item()
                    batch_count += 1
                    self.current_step += 1
                
                if batch_count > 0:
                    avg_loss = total_loss / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    # Log progress
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"Loss: {avg_loss:.4f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Step: {self.current_step}")
                    
                    # Generate sample every few epochs
                    generate_interval = self.settings['generate_interval'].get()
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_sample()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_training_sample(self):
        """Generate sample during training (DDIM fast sampling)"""
        if not self.diffusion:
            return
        
        try:
            with torch.no_grad():
                # Use DDIM for faster sampling
                img = self.sample_ddim(num_samples=1, steps=min(50, self.diffusion.timesteps//4))
                
                if img is not None:
                    # Convert to PIL
                    img = self.tensor_to_pil(img[0])
                    
                    # Resize for display
                    img_display = img.resize((256, 256), Image.Resampling.LANCZOS)
                    
                    # Convert to PhotoImage
                    photo = ImageTk.PhotoImage(img_display)
                    
                    # Update display
                    self.single_image_label.config(image=photo, text="")
                    self.single_image_label.image = photo
                    
                    # Store
                    self.generated_images.append(img)
                    
                    self.log_message(f"Generated training sample at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def sample_ddim(self, num_samples=1, steps=50):
        """DDIM sampling - much faster than DDPM - FIXED dtype issues"""
        if not self.diffusion:
            return None
        
        try:
            # Select subset of timesteps
            timesteps = self.diffusion.timesteps
            step_indices = torch.linspace(timesteps-1, 0, steps+1).long()
            step_indices = step_indices[:-1]  # Remove last step
            
            # Start from pure noise
            x = torch.randn(num_samples, 3, self.diffusion.image_size, 
                          self.diffusion.image_size, device=self.diffusion.device)
            
            alphas_cumprod = self.diffusion.alphas_cumprod
            
            for i, t in enumerate(step_indices):
                # Create tensor of timestep t
                t_tensor = torch.full((num_samples,), t, device=self.diffusion.device, dtype=torch.long)
                
                # Predict noise
                with torch.no_grad():
                    noise_pred = self.diffusion.model(x, t_tensor)
                
                # DDIM update
                alpha_t = alphas_cumprod[t]
                alpha_t_prev = alphas_cumprod[step_indices[i+1]] if i < len(step_indices)-1 else torch.tensor(1.0, device=self.diffusion.device)
                
                # Predicted x0
                pred_x0 = (x - math.sqrt(1 - alpha_t) * noise_pred) / math.sqrt(alpha_t)
                
                # Direction pointing to x_t
                dir_xt = math.sqrt(1 - alpha_t_prev) * noise_pred
                
                # Update x
                x = math.sqrt(alpha_t_prev) * pred_x0 + dir_xt
            
            return x.cpu()
            
        except Exception as e:
            self.log_message(f"Error in DDIM sampling: {str(e)}")
            import traceback
            traceback.print_exc()
            return None

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        img = (tensor + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        """Generate a single sample"""
        if not self.diffusion:
            self.log_message("Error: Model not initialized!")
            return
        
        try:
            steps = min(self.settings['sampling_steps'].get(), self.diffusion.timesteps)
            img = self.sample_ddim(num_samples=1, steps=steps)
            
            if img is not None:
                # Convert to PIL
                img_pil = self.tensor_to_pil(img[0])
                
                # Resize for display
                img_display = img_pil.resize((256, 256), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                # Store
                self.generated_images.append(img_pil)
                
                self.log_message(f"Generated sample with {steps} steps")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def save_model(self):
        """Save current model"""
        if not self.diffusion:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'step': self.current_step,
                    'model_state_dict': self.diffusion.model.state_dict(),
                    'optimizer_state_dict': self.diffusion.optimizer.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'base_channels': self.settings['base_channels'].get(),
                    'timesteps': self.settings['timesteps'].get(),
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_model(self):
        """Load model from file"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings
                if 'image_size' in checkpoint:
                    self.settings['image_size'].set(checkpoint['image_size'])
                    self.update_size_display()
                
                if 'base_channels' in checkpoint:
                    self.settings['base_channels'].set(checkpoint['base_channels'])
                
                if 'timesteps' in checkpoint:
                    self.settings['timesteps'].set(checkpoint['timesteps'])
                
                # Initialize model
                self.initialize_model()
                
                # Load state dict
                self.diffusion.model.load_state_dict(checkpoint['model_state_dict'])
                
                if 'optimizer_state_dict' in checkpoint:
                    self.diffusion.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                
                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        """Generate a grid of images"""
        if not self.diffusion:
            self.log_message("Error: Model not initialized!")
            return
        
        try:
            num_images = min(self.num_gen_var.get(), 9)  # Limit for CPU
            steps = min(self.settings['sampling_steps'].get(), self.diffusion.timesteps)
            
            # Clear previous images
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            # Create progress indicator
            progress_label = tk.Label(self.gen_scroll_frame, text="Generating...")
            progress_label.pack(pady=20)
            self.root.update()
            
            # Generate images
            imgs = self.sample_ddim(num_samples=num_images, steps=steps)
            
            if imgs is not None:
                progress_label.destroy()
                
                # Create grid
                cols = 3
                rows = (num_images + cols - 1) // cols
                
                for i in range(rows):
                    row_frame = tk.Frame(self.gen_scroll_frame)
                    row_frame.pack(pady=5)
                    
                    for j in range(cols):
                        idx = i * cols + j
                        if idx < num_images:
                            img_tensor = imgs[idx]
                            img = self.tensor_to_pil(img_tensor)
                            
                            # Resize for display
                            img_display = img.resize((96, 96), Image.Resampling.LANCZOS)
                            
                            photo = ImageTk.PhotoImage(img_display)
                            
                            label = tk.Label(row_frame, image=photo)
                            label.image = photo
                            label.pack(side=tk.LEFT, padx=5)
                
                self.log_message(f"Generated {num_images} images with {steps} steps")
            else:
                progress_label.config(text="Generation failed!")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def set_fast_preset(self):
        """Set settings for fast training"""
        fast_settings = {
            'base_channels': 24,
            'timesteps': 100,
            'batch_size': 8,
            'learning_rate': 2e-3,
            'num_workers': 1,
            'generate_interval': 10,
            'sampling_steps': 25,
        }
        
        for key, value in fast_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        
        self.log_message("Set Fast Preset - Fast training, lower quality")

    def set_quality_preset(self):
        """Set settings for quality training"""
        quality_settings = {
            'base_channels': 48,
            'timesteps': 400,
            'batch_size': 4,
            'learning_rate': 5e-4,
            'num_workers': 2,
            'generate_interval': 5,
            'sampling_steps': 100,
        }
        
        for key, value in quality_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        
        self.log_message("Set Quality Preset - Slower training, better quality")

    def reset_defaults(self):
        """Reset to defaults"""
        default_settings = {
            'image_size': 32,
            'base_channels': 32,
            'timesteps': 200,
            'batch_size': 8,
            'learning_rate': 1e-3,
            'num_workers': 2,
            'generate_interval': 5,
            'sampling_steps': 50,
        }
        
        for key, value in default_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        
        self.update_size_display()
        self.log_message("Reset to default settings")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Diffusion DCNN Trainer (CPU Optimized)...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Optimize for CPU
    torch.set_num_threads(multiprocessing.cpu_count())
    
    root = tk.Tk()
    app = DiffusionApp(root)
    root.mainloop()