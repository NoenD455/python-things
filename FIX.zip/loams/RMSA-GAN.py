import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path

# ==================== New RMSA-GAN Architecture ====================

class NoiseInjection(nn.Module):
    """Learnable noise injection for stochastic variation."""
    def __init__(self, channels):
        super().__init__()
        self.weight = nn.Parameter(torch.zeros(1, channels, 1, 1))
    def forward(self, x):
        noise = torch.randn(x.size(0), 1, x.size(2), x.size(3), device=x.device)
        return x + self.weight * noise

class ResUpBlock(nn.Module):
    """Upsampling residual block with noise injection."""
    def __init__(self, in_c, out_c):
        super().__init__()
        self.noise = NoiseInjection(in_c)
        self.conv1 = nn.Conv2d(in_c, out_c, 3, padding=1)
        self.norm1 = nn.GroupNorm(32, out_c)
        self.conv2 = nn.Conv2d(out_c, out_c, 3, padding=1)
        self.norm2 = nn.GroupNorm(32, out_c)
        self.skip = nn.Conv2d(in_c, out_c, 1) if in_c != out_c else nn.Identity()
    def forward(self, x):
        x_up = nn.functional.interpolate(x, scale_factor=2, mode='nearest')
        x = self.noise(x_up)
        x = nn.functional.relu(self.norm1(self.conv1(x)))
        x = self.norm2(self.conv2(x))
        skip = self.skip(x_up)
        return nn.functional.relu(x + skip)

class SelfAttention(nn.Module):
    """Self-attention module."""
    def __init__(self, in_c):
        super().__init__()
        self.query = nn.Conv2d(in_c, in_c // 8, 1)
        self.key   = nn.Conv2d(in_c, in_c // 8, 1)
        self.value = nn.Conv2d(in_c, in_c, 1)
        self.gamma = nn.Parameter(torch.zeros(1))
    def forward(self, x):
        B, C, H, W = x.shape
        Q = self.query(x).view(B, -1, H*W).permute(0, 2, 1)
        K = self.key(x).view(B, -1, H*W)
        V = self.value(x).view(B, -1, H*W)
        attn = nn.functional.softmax(Q @ K / (C//8)**0.5, dim=-1)
        out = (attn @ V.permute(0, 2, 1)).permute(0, 2, 1).view(B, C, H, W)
        return self.gamma * out + x

class Generator(nn.Module):
    """Generator for 32x32 images."""
    def __init__(self, latent_dim=100, ngf=64):
        super().__init__()
        self.latent_dim = latent_dim
        self.init = nn.Linear(latent_dim, 4*4*512)
        self.res1 = ResUpBlock(512, 256)   # 4x4 -> 8x8
        self.res2 = ResUpBlock(256, 128)   # 8x8 -> 16x16
        self.res3 = ResUpBlock(128, 64)    # 16x16 -> 32x32
        self.post1 = nn.Conv2d(64, 64, 3, padding=1)
        self.norm_post = nn.GroupNorm(32, 64)
        self.post2 = nn.Conv2d(64, 3, 3, padding=1)
    def forward(self, z):
        # z: (batch, latent_dim)
        x = self.init(z).view(-1, 512, 4, 4)
        x = self.res1(x)
        x = self.res2(x)
        x = self.res3(x)
        x = nn.functional.relu(self.norm_post(self.post1(x)))
        x = torch.tanh(self.post2(x))
        return x

class DiscriminatorBlock(nn.Module):
    """Downsampling residual block."""
    def __init__(self, in_c, out_c):
        super().__init__()
        self.conv1 = nn.Conv2d(in_c, out_c, 3, stride=2, padding=1)
        self.norm1 = nn.GroupNorm(32, out_c)
        self.conv2 = nn.Conv2d(out_c, out_c, 3, padding=1)
        self.norm2 = nn.GroupNorm(32, out_c)
        self.skip = nn.Conv2d(in_c, out_c, 1, stride=2) if in_c != out_c else nn.Identity()
    def forward(self, x):
        out = nn.functional.leaky_relu(self.norm1(self.conv1(x)), 0.2)
        out = self.norm2(self.conv2(out))
        skip = self.skip(x)
        return nn.functional.leaky_relu(out + skip, 0.2)

class DiscriminatorFull(nn.Module):
    """Full-scale discriminator (32x32 input)."""
    def __init__(self, ndf=64):
        super().__init__()
        self.conv_in = nn.Conv2d(3, ndf, 3, padding=1)
        self.block1 = DiscriminatorBlock(ndf, ndf*2)   # 32 -> 16
        self.block2 = DiscriminatorBlock(ndf*2, ndf*4) # 16 -> 8
        self.attn = SelfAttention(ndf*4)
        self.block3 = DiscriminatorBlock(ndf*4, ndf*8) # 8 -> 4
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(ndf*8, 1)
    def forward(self, x):
        x = nn.functional.leaky_relu(self.conv_in(x), 0.2)
        x = self.block1(x)
        x = self.block2(x)
        x = self.attn(x)
        x = self.block3(x)
        x = self.pool(x).view(x.size(0), -1)
        return self.fc(x)  # raw logit

class DiscriminatorHalf(nn.Module):
    """Half-scale discriminator (16x16 input)."""
    def __init__(self, ndf=64):
        super().__init__()
        self.conv_in = nn.Conv2d(3, ndf, 3, padding=1)
        self.block1 = DiscriminatorBlock(ndf, ndf*2)   # 16 -> 8
        self.block2 = DiscriminatorBlock(ndf*2, ndf*4) # 8 -> 4
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(ndf*4, 1)
    def forward(self, x):
        x = nn.functional.leaky_relu(self.conv_in(x), 0.2)
        x = self.block1(x)
        x = self.block2(x)
        x = self.pool(x).view(x.size(0), -1)
        return self.fc(x)

class RMSAGAN:
    """Wrapper for generator and two discriminators."""
    def __init__(self, image_size=32, latent_dim=100, ngf=64, ndf=64):
        self.image_size = image_size
        self.latent_dim = latent_dim
        
        # Set PyTorch threads
        torch.set_num_threads(multiprocessing.cpu_count())
        
        # Create networks
        self.generator = Generator(latent_dim, ngf)
        self.discriminator_full = DiscriminatorFull(ndf)
        self.discriminator_half = DiscriminatorHalf(ndf)
        
        # Loss function: Hinge loss (used in training loop)
        # We'll implement it manually in training loop.
        
        # Optimizers
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        # Combine both discriminators' parameters
        self.optimizerD = optim.Adam(
            list(self.discriminator_full.parameters()) + list(self.discriminator_half.parameters()),
            lr=0.0002, betas=(0.5, 0.999)
        )
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.generator.to(self.device)
        self.discriminator_full.to(self.device)
        self.discriminator_half.to(self.device)
        
    def train_discriminators(self, real_imgs, fake_imgs):
        """Compute hinge loss for both discriminators."""
        self.discriminator_full.zero_grad()
        self.discriminator_half.zero_grad()
        
        # Full discriminator
        real_out_full = self.discriminator_full(real_imgs)
        fake_out_full = self.discriminator_full(fake_imgs.detach())
        loss_D_full = torch.mean(torch.relu(1. - real_out_full)) + torch.mean(torch.relu(1. + fake_out_full))
        
        # Half discriminator (downsample real and fake to 16x16)
        real_half = nn.functional.avg_pool2d(real_imgs, 2)
        fake_half = nn.functional.avg_pool2d(fake_imgs.detach(), 2)
        real_out_half = self.discriminator_half(real_half)
        fake_out_half = self.discriminator_half(fake_half)
        loss_D_half = torch.mean(torch.relu(1. - real_out_half)) + torch.mean(torch.relu(1. + fake_out_half))
        
        loss_D = loss_D_full + loss_D_half
        loss_D.backward()
        self.optimizerD.step()
        return loss_D.item()
    
    def train_generator(self, fake_imgs):
        """Train generator to fool both discriminators."""
        self.generator.zero_grad()
        
        # Full discriminator
        fake_out_full = self.discriminator_full(fake_imgs)
        loss_G_full = -torch.mean(fake_out_full)
        
        # Half discriminator
        fake_half = nn.functional.avg_pool2d(fake_imgs, 2)
        fake_out_half = self.discriminator_half(fake_half)
        loss_G_half = -torch.mean(fake_out_half)
        
        loss_G = loss_G_full + loss_G_half
        loss_G.backward()
        self.optimizerG.step()
        return loss_G.item()

# ==================== Dataset (unchanged) ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application (modified training loop) ====================

class DCGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("RMSA-GAN Trainer - Multi-Core")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_dim': tk.IntVar(value=100),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
            'generate_interval': tk.IntVar(value=5)
        }
        
        # Performance tracking
        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        
        # For storing generated images
        self.generated_images = []
        
        # GUI Setup (unchanged)
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    # ========== GUI setup methods (unchanged, except we removed size display update) ==========
    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="RMSA-GAN Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text="Image Size: 32x32")
        self.size_display.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize GAN", 
                 command=self.initialize_gan, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display - SINGLE LARGE IMAGE
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Single image display (200x200)
        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar at bottom
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="RMSA-GAN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar for many settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Image size - Fixed to 32x32
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed)", width=20, anchor='w').pack(side=tk.LEFT, padx=5)
        
        # Other network parameters
        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 10, 500),
            ("Generator Features (ngf):", 'ngf', 32, 256),
            ("Discriminator Features (ndf):", 'ndf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 128),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset to Paper", 
                 command=self.reset_to_paper, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load Generator", 
                 command=self.load_generator, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ========== Helper methods (mostly unchanged) ==========
    def update_size_display(self):
        self.size_display.config(text="Image Size: 32x32")

    def log_message(self, message):
        self.message_queue.put(message)

    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_gan(self):
        try:
            image_size = self.settings['image_size'].get()
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            
            self.gan = RMSAGAN(
                image_size=image_size,
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf
            )
            
            self.log_message(f"Initialized RMSA-GAN for {image_size}x{image_size} images")
            self.log_message(f"Latent dim: {latent_dim}, G features: {ngf}, D features: {ndf}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            
            # Update optimizers with new settings
            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            for param_group in self.gan.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, num_workers),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_gan(self, epochs, batch_size, num_workers):
        """Modified training loop for RMSA-GAN (hinge loss, two discriminators)."""
        try:
            image_size = self.settings['image_size'].get()
            generate_interval = self.settings['generate_interval'].get()
            
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                epoch_start = time.time()
                
                for real_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # Generate fake images
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    
                    # Train discriminators (combined)
                    loss_d = self.gan.train_discriminators(real_images, fake_images)
                    
                    # Train generator (using updated discriminators)
                    # Note: we need fresh fake images because discriminator training changed them
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    loss_g = self.gan.train_generator(fake_images)
                    
                    total_loss_d += loss_d
                    total_loss_g += loss_g
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    epoch_time = time.time() - epoch_start
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"D Loss: {avg_loss_d:.4f} | "
                                   f"G Loss: {avg_loss_g:.4f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Total: {elapsed:.1f}s")
                    
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_training_samples(self):
        if not self.gan:
            return
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                generated = self.gan.generator(noise).cpu()
                img = self.tensor_to_pil(generated[0])
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
                self.log_message(f"Generated training sample at epoch {self.current_epoch + 1}")
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                generated = self.gan.generator(noise).cpu()
                img = self.tensor_to_pil(generated[0])
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
                self.log_message("Generated single sample")
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def save_model(self):
        if not self.gan:
            self.log_message("Error: No model to save!")
            return
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'discriminator_full_state_dict': self.gan.discriminator_full.state_dict(),
                    'discriminator_half_state_dict': self.gan.discriminator_half.state_dict(),
                    'optimizerG_state_dict': self.gan.optimizerG.state_dict(),
                    'optimizerD_state_dict': self.gan.optimizerD.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                }, filename)
                self.log_message(f"Model manually saved to {filename}")
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_generator(self):
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                # Update settings from checkpoint
                if 'image_size' in checkpoint:
                    self.settings['image_size'].set(checkpoint['image_size'])
                    self.update_size_display()
                if 'latent_dim' in checkpoint:
                    self.settings['latent_dim'].set(checkpoint['latent_dim'])
                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])
                if 'ndf' in checkpoint:
                    self.settings['ndf'].set(checkpoint['ndf'])
                
                self.initialize_gan()
                self.gan.generator.load_state_dict(checkpoint['generator_state_dict'])
                if 'discriminator_full_state_dict' in checkpoint:
                    self.gan.discriminator_full.load_state_dict(checkpoint['discriminator_full_state_dict'])
                if 'discriminator_half_state_dict' in checkpoint:
                    self.gan.discriminator_half.load_state_dict(checkpoint['discriminator_half_state_dict'])
                
                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        try:
            num_images = self.num_gen_var.get()
            with torch.no_grad():
                noise = torch.randn(num_images, self.gan.latent_dim, device=self.gan.device)
                generated = self.gan.generator(noise).cpu()
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            cols = 4
            rows = (num_images + cols - 1) // cols
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_tensor = generated[idx]
                        img = self.tensor_to_pil(img_tensor)
                        img_display = img.resize((128, 128), Image.Resampling.NEAREST)
                        photo = ImageTk.PhotoImage(img_display)
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            self.log_message(f"Generated {num_images} images in grid")
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def save_defaults(self):
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('dcgan_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        try:
            import json
            if os.path.exists('dcgan_defaults.json'):
                with open('dcgan_defaults.json', 'r') as f:
                    defaults = json.load(f)
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                self.update_size_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_to_paper(self):
        paper_settings = {
            'image_size': 32,
            'latent_dim': 100,
            'ngf': 64,
            'ndf': 64,
            'batch_size': 128,
            'learning_rate': 0.0002,
            'beta1': 0.5,
            'num_workers': min(4, multiprocessing.cpu_count()),
            'save_interval': 10,
            'generate_interval': 5
        }
        for key, value in paper_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        self.update_size_display()
        self.log_message("Reset to DCGAN paper settings")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting RMSA-GAN Trainer...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = DCGANApp(root)
    root.mainloop()