import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path

# =============================================================================
# FASTGAN – CORE NEURAL NETWORKS (designed for 32x32, CPU speed)
# =============================================================================

class SLE(nn.Module):
    """
    Skip-Layer Excitation (SLE) – the secret sauce of FastGAN.
    It takes a LOW-resolution feature map (e.g. 8x8) and uses it to
    "excite" (reweight) a HIGH-resolution feature map (e.g. 16x16).
    This helps gradients flow better and makes training MUCH faster.
    """
    def __init__(self, low_ch, high_ch):
        super().__init__()
        # Reduce low-res features to 4x4, then 1x1, then produce a gating vector
        self.avgpool = nn.AdaptiveAvgPool2d(4)
        self.conv1 = nn.Conv2d(low_ch, low_ch//2, 1, bias=False)
        self.relu = nn.LeakyReLU(0.1, inplace=True)
        self.conv2 = nn.Conv2d(low_ch//2, high_ch, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, low_feat, high_feat):
        x = self.avgpool(low_feat)          # [B, low_ch, 4, 4]
        x = self.conv1(x)                  # [B, low_ch//2, 4, 4]
        x = self.relu(x)
        x = self.conv2(x)                 # [B, high_ch, 4, 4]
        x = nn.functional.adaptive_avg_pool2d(x, 1)  # [B, high_ch, 1, 1]
        gate = self.sigmoid(x)            # values between 0 and 1
        return high_feat * gate           # element-wise multiplication


class Generator(nn.Module):
    """
    FastGAN Generator for 32x32 images.
    Architecture: latent (100) -> 4x4 -> 8x8 -> 16x16 -> 32x32.
    SLE connects the 8x8 feature map to the 16x16 feature map.
    No confusing "style" or "noise injection" – just clean deconvolutions.
    """
    def __init__(self, latent_dim=100, ngf=32):   # ngf = number of generator filters
        super().__init__()
        # 4x4
        self.init_conv = nn.Sequential(
            nn.ConvTranspose2d(latent_dim, ngf * 4, 4, 1, 0, bias=False),
            nn.BatchNorm2d(ngf * 4),
            nn.ReLU(True)
        )
        # 8x8
        self.conv1 = nn.Sequential(
            nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ngf * 2),
            nn.ReLU(True)
        )
        # 16x16
        self.conv2 = nn.Sequential(
            nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ngf),
            nn.ReLU(True)
        )
        # 32x32
        self.conv3 = nn.Sequential(
            nn.ConvTranspose2d(ngf, 3, 4, 2, 1, bias=False),
            nn.Tanh()   # output in range [-1,1]
        )

        # SLE: from 8x8 (ngf*2 channels) to 16x16 (ngf channels)
        self.sle = SLE(low_ch=ngf * 2, high_ch=ngf)

    def forward(self, z):
        # z shape: (batch, latent_dim, 1, 1)
        x0 = self.init_conv(z)   # (batch, ngf*4, 4, 4)
        x1 = self.conv1(x0)      # (batch, ngf*2, 8, 8)
        x2 = self.conv2(x1)      # (batch, ngf, 16, 16)

        # Apply SLE: the 8x8 features (x1) reweight the 16x16 features (x2)
        x2 = self.sle(x1, x2)

        out = self.conv3(x2)     # (batch, 3, 32, 32)
        return out


class Discriminator(nn.Module):
    """
    FastGAN Discriminator with a self‑supervised decoder.
    It does TWO jobs:
    1) Tells real from fake (adversarial loss)
    2) Reconstructs the input image from its deep features (L1 loss)
    The reconstruction task forces D to learn rich, diverse features,
    which prevents mode collapse and gives G much better feedback.
    """
    def __init__(self, ndf=32):   # ndf = number of discriminator filters
        super().__init__()
        # Downsampling path (standard DCGAN style)
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
            nn.LeakyReLU(0.2, inplace=True)
        )   # -> (ndf, 16, 16)
        self.conv2 = nn.Sequential(
            nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 2),
            nn.LeakyReLU(0.2, inplace=True)
        )   # -> (ndf*2, 8, 8)
        self.conv3 = nn.Sequential(
            nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 4),
            nn.LeakyReLU(0.2, inplace=True)
        )   # -> (ndf*4, 4, 4)

        # Adversarial output: 1 value per image (real/fake)
        self.adv_layer = nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False)

        # ---------- Self‑supervised decoder ----------
        # Takes the 4x4 feature map and upsamples it back to 32x32
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(ndf * 4, ndf * 2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 2),
            nn.LeakyReLU(0.2, inplace=True),
            nn.ConvTranspose2d(ndf * 2, ndf, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf),
            nn.LeakyReLU(0.2, inplace=True),
            nn.ConvTranspose2d(ndf, 3, 4, 2, 1, bias=False),
            nn.Tanh()   # reconstruct in same range as input
        )

    def forward(self, x, return_reconstruction=False):
        """
        If return_reconstruction=True, also output the reconstructed image.
        This is used when training D on REAL images.
        """
        f1 = self.conv1(x)   # (batch, ndf, 16, 16)
        f2 = self.conv2(f1)  # (batch, ndf*2, 8, 8)
        f3 = self.conv3(f2)  # (batch, ndf*4, 4, 4)

        # Adversarial score
        adv_out = self.adv_layer(f3).view(-1, 1)

        if return_reconstruction:
            rec = self.decoder(f3)   # (batch, 3, 32, 32)
            return adv_out, rec
        else:
            return adv_out


# =============================================================================
# DATASET (same as your DCGAN6.py)
# =============================================================================
class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except:
            return torch.zeros(3, 32, 32)


# =============================================================================
# FASTGAN WRAPPER – holds networks, optimizers, losses
# =============================================================================
class FastGAN:
    def __init__(self, latent_dim=100, ngf=32, ndf=32):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")

        self.latent_dim = latent_dim
        self.generator = Generator(latent_dim, ngf).to(self.device)
        self.discriminator = Discriminator(ndf).to(self.device)

        # Loss: we use BCEWithLogitsLoss (stable, works well)
        self.criterion = nn.BCEWithLogitsLoss()

        # Optimizers (Adam, same as DCGAN paper)
        self.optimizer_G = optim.Adam(self.generator.parameters(),
                                      lr=0.0002, betas=(0.5, 0.999))
        self.optimizer_D = optim.Adam(self.discriminator.parameters(),
                                      lr=0.0002, betas=(0.5, 0.999))

        # Weight for reconstruction loss (lambda_rec in paper, set to 10)
        self.rec_loss_weight = 10.0
        self.rec_loss_fn = nn.L1Loss()   # L1 gives sharper images

    def train_step(self, real_images):
        """
        One training iteration: update D, then update G.
        Returns: (loss_D, loss_G, loss_rec) for logging.
        """
        batch_size = real_images.size(0)
        real_images = real_images.to(self.device)

        # ---------------------
        # 1. Train Discriminator
        # ---------------------
        self.optimizer_D.zero_grad()

        # Real images: adversarial loss + reconstruction loss
        real_output, reconstructed = self.discriminator(real_images, return_reconstruction=True)
        real_labels = torch.ones(batch_size, 1, device=self.device)
        loss_D_real = self.criterion(real_output, real_labels)

        # Reconstruction loss (only on real images)
        loss_rec = self.rec_loss_fn(reconstructed, real_images) * self.rec_loss_weight

        # Fake images: adversarial loss only
        noise = torch.randn(batch_size, self.latent_dim, 1, 1, device=self.device)
        fake_images = self.generator(noise)
        fake_output = self.discriminator(fake_images.detach())
        fake_labels = torch.zeros(batch_size, 1, device=self.device)
        loss_D_fake = self.criterion(fake_output, fake_labels)

        # Total D loss
        loss_D = (loss_D_real + loss_D_fake) / 2 + loss_rec
        loss_D.backward()
        self.optimizer_D.step()

        # -----------------
        # 2. Train Generator
        # -----------------
        self.optimizer_G.zero_grad()

        # Generate new fake images
        noise = torch.randn(batch_size, self.latent_dim, 1, 1, device=self.device)
        fake_images = self.generator(noise)
        fake_output = self.discriminator(fake_images)
        # Generator wants D to think fakes are real
        loss_G = self.criterion(fake_output, real_labels)

        loss_G.backward()
        self.optimizer_G.step()

        return loss_D.item(), loss_G.item(), loss_rec.item()


# =============================================================================
# GUI APPLICATION (based on your DCGAN6.py, but with FastGAN engine)
# =============================================================================
class FastGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("FastGAN Trainer – 32x32, CPU Optimized")
        self.root.geometry("1000x700")

        # Training state
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        self.generated_images = []

        # Settings (simplified – only what matters)
        self.settings = {
            'latent_dim': tk.IntVar(value=100),
            'ngf': tk.IntVar(value=32),        # Generator filters
            'ndf': tk.IntVar(value=32),        # Discriminator filters
            'batch_size': tk.IntVar(value=8),  # CPU: keep small
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'rec_loss_weight': tk.DoubleVar(value=10.0),
            'generate_interval': tk.IntVar(value=5),
        }

        # Build GUI
        self.setup_gui()
        self.root.after(100, self.process_messages)

    # -------------------------------------------------------------------------
    # GUI Layout (identical to your DCGAN6.py, but with FastGAN labels)
    # -------------------------------------------------------------------------
    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left panel – controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))

        tk.Label(left_frame, text="FastGAN Controls",
                font=("Arial", 12, "bold")).pack(pady=(0,10))

        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images,
                 width=20).pack(pady=5)
        tk.Button(img_frame, text="Clear All", command=self.clear_images,
                 width=20).pack(pady=5)

        self.image_listbox = tk.Listbox(img_frame, height=8)
        self.image_listbox.pack(fill=tk.BOTH, expand=True, pady=5)

        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0,10))

        tk.Button(train_frame, text="Initialize FastGAN",
                 command=self.init_gan, width=20).pack(pady=5)

        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="START TRAINING",
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="STOP",
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)

        # Generation
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        tk.Button(gen_frame, text="Generate Sample",
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model",
                 command=self.save_model, width=20).pack(pady=5)

        # Right panel – preview & log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Preview", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,10))

        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        self.single_image_label = tk.Label(self.single_image_frame, text="No image", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)

        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

        self.status_label = tk.Label(self.training_tab, text="Ready",
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="FastGAN Settings",
                font=("Arial", 14, "bold")).pack(pady=(0,20))

        # Canvas for scrollable settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Network architecture
        net_frame = tk.LabelFrame(scrollable_frame, text="Network", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0,10))

        sliders = [
            ("Latent Dimension:", 'latent_dim', 32, 256),
            ("Generator Filters (ngf):", 'ngf', 16, 128),
            ("Discriminator Filters (ndf):", 'ndf', 16, 128),
            ("Batch Size (CPU: 4-8):", 'batch_size', 1, 32),
        ]
        for label, key, low, high in sliders:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=low, to=high, variable=self.settings[key],
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT, padx=5)

        # Training hyperparameters
        train_frame = tk.LabelFrame(scrollable_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0,10))

        hp_sliders = [
            ("Learning Rate:", 'learning_rate', 1e-5, 1e-2),
            ("Beta1 (Adam):", 'beta1', 0.0, 0.999),
            ("Reconstruction Loss Weight:", 'rec_loss_weight', 1.0, 50.0),
            ("Generate Every N epochs:", 'generate_interval', 1, 20),
        ]
        for label, key, low, high in hp_sliders:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label, width=30, anchor='w').pack(side=tk.LEFT)
            if key in ['learning_rate', 'beta1']:
                res = 0.00001 if key == 'learning_rate' else 0.001
                tk.Scale(frame, from_=low, to=high, resolution=res,
                        variable=self.settings[key], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=low, to=high, variable=self.settings[key],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT, padx=5)

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X)
        tk.Label(sys_frame, text=f"CPU cores: {multiprocessing.cpu_count()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text="Reconstruction loss forces D to learn diverse features → no mode collapse!",
                fg="blue", anchor='w').pack(fill=tk.X, pady=5)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Generate Images",
                font=("Arial", 14, "bold")).pack(pady=(0,20))

        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0,20))
        tk.Button(load_frame, text="Load Generator",
                 command=self.load_generator, width=20).pack(pady=5)

        gen_frame = tk.LabelFrame(main_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0,20))
        tk.Label(gen_frame, text="Number of images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var,
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        tk.Button(gen_frame, text="Generate Grid",
                 command=self.generate_grid, width=20).pack(pady=10)

        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        self.gen_scroll_frame.bind("<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all")))
        self.gen_canvas.create_window((0,0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # -------------------------------------------------------------------------
    # GUI Event Handlers
    # -------------------------------------------------------------------------
    def log_message(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(msg)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images")

    def init_gan(self):
        """Create FastGAN instance with current settings"""
        try:
            self.gan = FastGAN(
                latent_dim=self.settings['latent_dim'].get(),
                ngf=self.settings['ngf'].get(),
                ndf=self.settings['ndf'].get()
            )
            # Set reconstruction weight from GUI
            self.gan.rec_loss_weight = self.settings['rec_loss_weight'].get()
            self.log_message(f"FastGAN initialized. Device: {self.gan.device}")
        except Exception as e:
            self.log_message(f"Init error: {str(e)}")

    def start_training(self):
        if not self.image_paths:
            self.log_message("No training images!")
            return
        if not self.gan:
            self.log_message("Initialize FastGAN first!")
            return
        if self.training:
            self.log_message("Already training")
            return

        epochs = int(self.epoch_var.get())
        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()

        # Update optimizers with current LR/beta1
        lr = self.settings['learning_rate'].get()
        beta1 = self.settings['beta1'].get()
        for param_group in self.gan.optimizer_G.param_groups:
            param_group['lr'] = lr
            param_group['betas'] = (beta1, 0.999)
        for param_group in self.gan.optimizer_D.param_groups:
            param_group['lr'] = lr
            param_group['betas'] = (beta1, 0.999)

        # Launch training thread
        thread = threading.Thread(target=self.train_loop,
                                 args=(epochs,), daemon=True)
        thread.start()
        self.log_message(f"Training started for {epochs} epochs")

    def train_loop(self, epochs):
        """Main training loop (runs in background thread)"""
        try:
            batch_size = self.settings['batch_size'].get()
            generate_interval = self.settings['generate_interval'].get()

            dataset = ImageDataset(self.image_paths, image_size=32)
            # num_workers=0 is CRITICAL for CPU – multiprocessing overhead kills speed
            dataloader = DataLoader(dataset, batch_size=batch_size,
                                   shuffle=True, num_workers=0, drop_last=True)

            for epoch in range(epochs):
                if not self.training:
                    break

                epoch_loss_D = 0.0
                epoch_loss_G = 0.0
                epoch_loss_rec = 0.0
                n_batches = 0
                epoch_start = time.time()

                for real_images in dataloader:
                    if not self.training:
                        break

                    loss_D, loss_G, loss_rec = self.gan.train_step(real_images)
                    epoch_loss_D += loss_D
                    epoch_loss_G += loss_G
                    epoch_loss_rec += loss_rec
                    n_batches += 1

                if n_batches > 0:
                    epoch_loss_D /= n_batches
                    epoch_loss_G /= n_batches
                    epoch_loss_rec /= n_batches
                    epoch_time = time.time() - epoch_start
                    self.current_epoch = epoch + 1
                    self.log_message(
                        f"Epoch {epoch+1}/{epochs} | "
                        f"D: {epoch_loss_D:.4f} | G: {epoch_loss_G:.4f} | "
                        f"Rec: {epoch_loss_rec:.4f} | Time: {epoch_time:.1f}s"
                    )

                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_sample()

            self.training = False
            self.log_message("Training finished!")
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()

    def generate_training_sample(self):
        """Generate one image and display in preview"""
        if not self.gan:
            return
        with torch.no_grad():
            noise = torch.randn(1, self.gan.latent_dim, 1, 1, device=self.gan.device)
            fake = self.gan.generator(noise).cpu()
            img = self.tensor_to_pil(fake[0])
            # Resize for display (nearest neighbour preserves pixelation)
            img_display = img.resize((200, 200), Image.Resampling.NEAREST)
            photo = ImageTk.PhotoImage(img_display)
            self.single_image_label.config(image=photo, text="")
            self.single_image_label.image = photo
            self.generated_images.append(img)

    def generate_sample(self):
        """Manual generation button"""
        self.generate_training_sample()
        self.log_message("Generated sample")

    def save_model(self):
        if not self.gan:
            return
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth")]
        )
        if filename:
            torch.save({
                'generator': self.gan.generator.state_dict(),
                'discriminator': self.gan.discriminator.state_dict(),
                'optimizer_G': self.gan.optimizer_G.state_dict(),
                'optimizer_D': self.gan.optimizer_D.state_dict(),
                'settings': {k: v.get() for k, v in self.settings.items()}
            }, filename)
            self.log_message(f"Model saved to {filename}")

    def load_generator(self):
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth")]
        )
        if filename:
            checkpoint = torch.load(filename, map_location='cpu')
            # Restore settings
            if 'settings' in checkpoint:
                for k, v in checkpoint['settings'].items():
                    if k in self.settings:
                        self.settings[k].set(v)
            # Re-init GAN with loaded settings
            self.init_gan()
            self.gan.generator.load_state_dict(checkpoint['generator'])
            if 'discriminator' in checkpoint:
                self.gan.discriminator.load_state_dict(checkpoint['discriminator'])
            self.log_message(f"Model loaded from {filename}")

    def generate_grid(self):
        if not self.gan:
            self.log_message("No model loaded!")
            return
        n = self.num_gen_var.get()
        with torch.no_grad():
            noise = torch.randn(n, self.gan.latent_dim, 1, 1, device=self.gan.device)
            fake = self.gan.generator(noise).cpu()

        # Clear old images
        for w in self.gen_scroll_frame.winfo_children():
            w.destroy()

        cols = 4
        for i in range(0, n, cols):
            row = tk.Frame(self.gen_scroll_frame)
            row.pack(pady=5)
            for j in range(cols):
                idx = i + j
                if idx < n:
                    img = self.tensor_to_pil(fake[idx])
                    img = img.resize((128,128), Image.Resampling.NEAREST)
                    photo = ImageTk.PhotoImage(img)
                    lbl = tk.Label(row, image=photo)
                    lbl.image = photo
                    lbl.pack(side=tk.LEFT, padx=5)
        self.log_message(f"Generated {n} images")

    @staticmethod
    def tensor_to_pil(tensor):
        img = (tensor + 1) / 2   # [-1,1] -> [0,1]
        img = img.clamp(0, 1)
        return transforms.ToPILImage()(img)

    def stop_training(self):
        self.training = False
        self.log_message("Stopping training...")


# =============================================================================
# ENTRY POINT
# =============================================================================
if __name__ == "__main__":
    multiprocessing.freeze_support()
    print("Starting FastGAN GUI (CPU optimized, 32x32)")
    print(f"PyTorch version: {torch.__version__}")
    root = tk.Tk()
    app = FastGANApp(root)
    root.mainloop()