import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk, ImageDraw, ImageFont
import os
import threading
import queue
import numpy as np
import multiprocessing
import traceback
import sys

# ==================== Improved DCGAN with Reduced Gridding ====================

class ImprovedDCGAN:
    def __init__(self, image_size=64, latent_dim=100, use_skip=True):
        self.image_size = image_size
        self.latent_dim = latent_dim
        self.use_skip = use_skip
        
        torch.set_num_threads(2)
        if torch.cuda.is_available():
            print("CUDA available")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Generator with reduced gridding
        class Generator(nn.Module):
            def __init__(self, image_size, latent_dim, use_skip=True):
                super().__init__()
                self.image_size = image_size
                self.use_skip = use_skip
                
                if image_size == 64:
                    # Initial projection - NO BatchNorm1d here
                    self.projection = nn.Sequential(
                        nn.Linear(latent_dim, 1024 * 4 * 4),
                        nn.ReLU(True)
                    )
                    
                    self.block1 = UpsampleBlock(1024, 512, use_skip)  # 4x4 -> 8x8
                    self.block2 = UpsampleBlock(512, 256, use_skip)   # 8x8 -> 16x16
                    self.block3 = UpsampleBlock(256, 128, use_skip)   # 16x16 -> 32x32
                    self.block4 = UpsampleBlock(128, 64, use_skip)    # 32x32 -> 64x64
                    
                    self.final = nn.Sequential(
                        nn.Conv2d(64, 64, 3, padding=1),
                        nn.BatchNorm2d(64),
                        nn.ReLU(True),
                        nn.Conv2d(64, 3, 3, padding=1),
                        nn.Tanh()
                    )
                    
                else:  # 32x32
                    self.projection = nn.Sequential(
                        nn.Linear(latent_dim, 512 * 4 * 4),
                        nn.ReLU(True)
                    )
                    
                    self.block1 = UpsampleBlock(512, 256, use_skip)  # 4x4 -> 8x8
                    self.block2 = UpsampleBlock(256, 128, use_skip)  # 8x8 -> 16x16
                    self.block3 = UpsampleBlock(128, 64, use_skip)   # 16x16 -> 32x32
                    
                    self.final = nn.Sequential(
                        nn.Conv2d(64, 64, 3, padding=1),
                        nn.BatchNorm2d(64),
                        nn.ReLU(True),
                        nn.Conv2d(64, 3, 3, padding=1),
                        nn.Tanh()
                    )
                
            def forward(self, x):
                batch_size = x.size(0)
                x = self.projection(x)
                
                if self.image_size == 64:
                    x = x.view(-1, 1024, 4, 4)
                    x = self.block1(x)
                    x = self.block2(x)
                    x = self.block3(x)
                    x = self.block4(x)
                else:  # 32x32
                    x = x.view(-1, 512, 4, 4)
                    x = self.block1(x)
                    x = self.block2(x)
                    x = self.block3(x)
                
                return self.final(x)
        
        # Upsample block
        class UpsampleBlock(nn.Module):
            def __init__(self, in_channels, out_channels, use_skip=True):
                super().__init__()
                self.use_skip = use_skip
                
                self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
                
                self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1)
                self.bn1 = nn.BatchNorm2d(out_channels)
                self.relu1 = nn.ReLU(True)
                
                self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1)
                self.bn2 = nn.BatchNorm2d(out_channels)
                
                if use_skip and in_channels != out_channels:
                    self.skip_conv = nn.Conv2d(in_channels, out_channels, 1)
                elif use_skip:
                    self.skip_conv = nn.Identity()
                else:
                    self.skip_conv = None
                
                self.relu2 = nn.ReLU(True)
            
            def forward(self, x):
                residual = x
                
                x = self.upsample(x)
                
                x = self.conv1(x)
                x = self.bn1(x)
                x = self.relu1(x)
                
                x = self.conv2(x)
                x = self.bn2(x)
                
                if self.use_skip and self.skip_conv is not None:
                    residual = self.upsample(residual)
                    if not isinstance(self.skip_conv, nn.Identity):
                        residual = self.skip_conv(residual)
                    x = x + residual
                
                x = self.relu2(x)
                return x
        
        # Discriminator
        class Discriminator(nn.Module):
            def __init__(self, image_size):
                super().__init__()
                
                if image_size == 64:
                    self.main = nn.Sequential(
                        nn.Conv2d(3, 64, 4, stride=2, padding=1, bias=False),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(64, 128, 4, stride=2, padding=1, bias=False),
                        nn.BatchNorm2d(128),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(128, 256, 4, stride=2, padding=1, bias=False),
                        nn.BatchNorm2d(256),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(256, 512, 4, stride=2, padding=1, bias=False),
                        nn.BatchNorm2d(512),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(512, 1, 4, stride=1, padding=0, bias=False),
                    )
                else:  # 32x32
                    self.main = nn.Sequential(
                        nn.Conv2d(3, 64, 4, stride=2, padding=1, bias=False),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(64, 128, 4, stride=2, padding=1, bias=False),
                        nn.BatchNorm2d(128),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(128, 256, 4, stride=2, padding=1, bias=False),
                        nn.BatchNorm2d(256),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(256, 1, 4, stride=1, padding=0, bias=False),
                    )
                
                self.sigmoid = nn.Sigmoid()
            
            def forward(self, x):
                features = self.main(x)
                return self.sigmoid(features.view(x.size(0), -1)).squeeze()
        
        self.generator = Generator(image_size, latent_dim, use_skip)
        self.discriminator = Discriminator(image_size)
        
        self._initialize_weights()
        
        self.criterion = nn.BCELoss()
        
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0001, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0004, betas=(0.5, 0.999))
        
        self.schedulerG = optim.lr_scheduler.StepLR(self.optimizerG, step_size=50, gamma=0.5)
        self.schedulerD = optim.lr_scheduler.StepLR(self.optimizerD, step_size=50, gamma=0.5)
        
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
    
    def _initialize_weights(self):
        for m in self.generator.modules():
            if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                nn.init.constant_(m.bias, 0)
        
        for m in self.discriminator.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='leaky_relu', a=0.2)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=64):
        self.image_paths = image_paths
        self.image_size = image_size
        
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size), Image.NEAREST),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except:
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI ====================

class ImprovedDCGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("DCGAN Explorer - Improved")
        self.root.geometry("950x750")
        
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        self.interpolation_images = []
        
        self.setup_gui()
        self.root.after(100, self.process_messages)
    
    def setup_gui(self):
        main_container = tk.Frame(self.root, padx=5, pady=5)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        left_frame = tk.Frame(main_container, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        title_label = tk.Label(left_frame, text="DCGAN Explorer", 
                              font=("Arial", 12, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 10), sticky="w")
        
        tk.Label(left_frame, text="Image Size:").grid(row=1, column=0, sticky="w", pady=(0, 5))
        self.size_var = tk.StringVar(value="32")
        size_frame = tk.Frame(left_frame)
        size_frame.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        tk.Radiobutton(size_frame, text="32x32", variable=self.size_var, value="32").pack(side=tk.LEFT, padx=(0, 10))
        tk.Radiobutton(size_frame, text="64x64", variable=self.size_var, value="64").pack(side=tk.LEFT)
        
        self.skip_var = tk.BooleanVar(value=True)
        tk.Checkbutton(left_frame, text="Use Skip Connections", 
                      variable=self.skip_var).grid(row=3, column=0, columnspan=2, sticky="w", pady=(0, 10))
        
        tk.Button(left_frame, text="Add Training Images", 
                 command=self.add_images, height=2).grid(row=4, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Label(left_frame, text="Training Images:").grid(row=5, column=0, sticky="w", pady=(10, 5))
        
        list_frame = tk.Frame(left_frame)
        list_frame.grid(row=6, column=0, columnspan=2, sticky="nsew", pady=(0, 10))
        
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)
        
        self.image_listbox = tk.Listbox(list_frame, height=6)
        self.image_listbox.grid(row=0, column=0, sticky="nsew")
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.grid(row=0, column=1, sticky="ns")
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        tk.Button(left_frame, text="Clear All Images", 
                 command=self.clear_images).grid(row=7, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Label(left_frame, text="Training Controls:").grid(row=8, column=0, sticky="w", pady=(10, 5))
        
        tk.Button(left_frame, text="Initialize GAN", 
                 command=self.initialize_gan, height=2).grid(row=9, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Label(left_frame, text="Epochs:").grid(row=10, column=0, sticky="w")
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(left_frame, textvariable=self.epoch_var).grid(row=11, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        tk.Label(left_frame, text="Batch Size:").grid(row=12, column=0, sticky="w")
        self.batch_var = tk.StringVar(value="16")
        tk.Entry(left_frame, textvariable=self.batch_var).grid(row=13, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        tk.Button(left_frame, text="Start Training", 
                 command=self.start_training, height=2, bg="lightgreen").grid(row=14, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Stop Training", 
                 command=self.stop_training, height=2, bg="salmon").grid(row=15, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Label(left_frame, text="Generation:").grid(row=16, column=0, sticky="w", pady=(10, 5))
        
        tk.Button(left_frame, text="Generate Sample", 
                 command=self.generate_sample, height=2).grid(row=17, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Generate Interpolation Grid", 
                 command=self.generate_interpolation_grid, height=2, bg="lightblue").grid(row=18, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Label(left_frame, text="Interpolation Steps:").grid(row=19, column=0, sticky="w", pady=(10, 5))
        self.steps_var = tk.StringVar(value="14")
        tk.Entry(left_frame, textvariable=self.steps_var).grid(row=20, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        tk.Label(left_frame, text="Status:").grid(row=21, column=0, sticky="w", pady=(10, 5))
        self.status_label = tk.Label(left_frame, text="Ready", 
                                    relief=tk.SUNKEN, 
                                    height=2,
                                    anchor="w",
                                    padx=5)
        self.status_label.grid(row=22, column=0, columnspan=2, sticky="ew", pady=(0, 5))
        
        left_frame.grid_rowconfigure(6, weight=1)
        left_frame.grid_columnconfigure(0, weight=1)
        left_frame.grid_columnconfigure(1, weight=1)
        
        right_frame = tk.Frame(main_container)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        single_frame = tk.LabelFrame(right_frame, text="Single Generation", padx=5, pady=5)
        single_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.image_label = tk.Label(single_frame)
        self.image_label.pack(pady=5)
        
        grid_frame = tk.LabelFrame(right_frame, text="Latent Space Interpolation Grid", padx=5, pady=5)
        grid_frame.pack(fill=tk.BOTH, expand=True)
        
        self.grid_canvas = tk.Canvas(grid_frame, bg="white")
        self.grid_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        grid_scrollbar = tk.Scrollbar(grid_frame, orient=tk.VERTICAL, command=self.grid_canvas.yview)
        grid_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.grid_canvas.configure(yscrollcommand=grid_scrollbar.set)
        
        self.grid_frame = tk.Frame(self.grid_canvas, bg="white")
        self.canvas_window = self.grid_canvas.create_window((0, 0), window=self.grid_frame, anchor="nw")
        
        self.grid_frame.bind("<Configure>", self._on_frame_configure)
        self.grid_canvas.bind("<Configure>", self._on_canvas_configure)
        
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=5, pady=5)
        log_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.log_text = tk.Text(log_frame, height=6, width=60, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        log_scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=log_scrollbar.set)
    
    def _on_frame_configure(self, event=None):
        self.grid_canvas.configure(scrollregion=self.grid_canvas.bbox("all"))
    
    def _on_canvas_configure(self, event):
        self.grid_canvas.itemconfig(self.canvas_window, width=event.width)
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
                status_text = message[:40] + "..." if len(message) > 40 else message
                self.status_label.config(text=status_text)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")
    
    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")
    
    def initialize_gan(self):
        try:
            image_size = int(self.size_var.get())
            use_skip = self.skip_var.get()
            self.gan = ImprovedDCGAN(image_size=image_size, use_skip=use_skip)
            self.log_message(f"Initialized DCGAN for {image_size}x{image_size} images")
            self.log_message(f"Skip connections: {'Enabled' if use_skip else 'Disabled'}")
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
            print(f"Error initializing GAN: {e}")
            traceback.print_exc()
    
    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            batch_size = int(self.batch_var.get())
            image_size = int(self.size_var.get())
            
            self.training = True
            self.current_epoch = 0
            
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, image_size),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}")
        except ValueError:
            self.log_message("Error: Invalid parameters!")
    
    def train_gan(self, epochs, batch_size, image_size):
        try:
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=0,
                pin_memory=False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                
                for i, real_images in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    batch_size_current = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # Train Discriminator
                    self.gan.optimizerD.zero_grad()
                    
                    real_labels = torch.ones(batch_size_current).to(self.gan.device) * 0.9
                    output_real = self.gan.discriminator(real_images)
                    loss_real = self.gan.criterion(output_real, real_labels)
                    
                    noise = torch.randn(batch_size_current, self.gan.latent_dim, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    fake_labels = torch.zeros(batch_size_current).to(self.gan.device) + 0.1
                    output_fake = self.gan.discriminator(fake_images.detach())
                    loss_fake = self.gan.criterion(output_fake, fake_labels)
                    
                    loss_d = (loss_real + loss_fake) / 2
                    loss_d.backward()
                    self.gan.optimizerD.step()
                    
                    # Train Generator
                    self.gan.optimizerG.zero_grad()
                    
                    output_fake = self.gan.discriminator(fake_images)
                    loss_g = self.gan.criterion(output_fake, real_labels)
                    loss_g.backward()
                    self.gan.optimizerG.step()
                    
                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    
                    self.log_message(f"Epoch {epoch+1}/{epochs} | D Loss: {avg_loss_d:.4f} | G Loss: {avg_loss_g:.4f}")
                
                if (epoch + 1) % 5 == 0:
                    self.generate_sample_internal(show=False)
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            print(f"Training error: {e}")
            traceback.print_exc()
            self.training = False
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")
    
    def generate_sample_internal(self, show=True, noise=None):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            with torch.no_grad():
                # Set generator to eval mode for batch size 1
                self.gan.generator.eval()
                
                if noise is None:
                    noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                generated = self.gan.generator(noise)
                
                img = generated[0].cpu()
                img = (img + 1) / 2
                img = transforms.ToPILImage()(img)
                
                img = img.resize((256, 256), Image.NEAREST)
                
                if show:
                    self.display_image(img)
                
                # Set back to train mode if training
                if self.training:
                    self.gan.generator.train()
                
                return img
        except Exception as e:
            self.log_message(f"Generation error: {str(e)}")
            print(f"Generation error: {e}")
            traceback.print_exc()
    
    def generate_sample(self):
        img = self.generate_sample_internal(show=True)
        if img:
            self.log_message("Generated new sample image")
    
    def generate_interpolation_grid(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            steps = int(self.steps_var.get())
            
            for widget in self.grid_frame.winfo_children():
                widget.destroy()
            
            self.log_message(f"Generating interpolation grid with {steps} steps...")
            
            noise1 = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
            noise2 = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
            
            self.interpolation_images = []
            
            for i in range(steps + 2):
                alpha = i / (steps + 1)
                
                if alpha == 0:
                    noise = noise1
                elif alpha == 1:
                    noise = noise2
                else:
                    noise = (1 - alpha) * noise1 + alpha * noise2
                
                with torch.no_grad():
                    self.gan.generator.eval()
                    generated = self.gan.generator(noise)
                    img = generated[0].cpu()
                    img = (img + 1) / 2
                    img = transforms.ToPILImage()(img)
                    
                    display_size = 128
                    img = img.resize((display_size, display_size), Image.NEAREST)
                    
                    label_img = Image.new('RGB', (display_size, display_size + 20), color='white')
                    label_img.paste(img, (0, 0))
                    
                    draw = ImageDraw.Draw(label_img)
                    try:
                        font = ImageFont.truetype("arial.ttf", 12)
                    except:
                        font = ImageFont.load_default()
                    
                    if i == 0:
                        label = "Noise A"
                    elif i == steps + 1:
                        label = "Noise B"
                    else:
                        label = f"Step {i}"
                    
                    draw.text((5, display_size + 5), label, fill='black', font=font)
                    
                    self.interpolation_images.append(label_img)
            
            self.gan.generator.train()
            
            num_cols = min(8, len(self.interpolation_images))
            num_rows = (len(self.interpolation_images) + num_cols - 1) // num_cols
            
            for idx, img in enumerate(self.interpolation_images):
                row = idx // num_cols
                col = idx % num_cols
                
                photo = ImageTk.PhotoImage(img)
                label = tk.Label(self.grid_frame, image=photo, bg="white")
                label.image = photo
                label.grid(row=row, column=col, padx=5, pady=5)
            
            self.log_message(f"Generated {len(self.interpolation_images)} interpolation images")
            
        except Exception as e:
            self.log_message(f"Interpolation error: {str(e)}")
            print(f"Interpolation error: {e}")
            traceback.print_exc()
    
    def display_image(self, img):
        photo = ImageTk.PhotoImage(img)
        self.image_label.config(image=photo)
        self.image_label.image = photo

# ==================== Main ====================

if __name__ == "__main__":
    print("DCGAN Explorer - Improved Version")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = ImprovedDCGANApp(root)
    root.mainloop()