import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path

# ==================== Neural Network ====================

class SimpleRaLSGAN:
    def __init__(self, image_size=32, latent_dim=100, ngf=64, ndf=64):
        self.image_size = image_size
        self.latent_dim = latent_dim
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Generator (same architecture as DCGAN)
        class Generator(nn.Module):
            def __init__(self, image_size, latent_dim, ngf):
                super().__init__()
                
                # Only 32x32 architecture
                self.main = nn.Sequential(
                    nn.ConvTranspose2d(latent_dim, ngf * 4, 4, 1, 0, bias=False),
                    nn.BatchNorm2d(ngf * 4),
                    nn.ReLU(True),
                    # ngf*4 x 4 x 4
                    nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf * 2),
                    nn.ReLU(True),
                    # ngf*2 x 8 x 8
                    nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf),
                    nn.ReLU(True),
                    # ngf x 16 x 16
                    nn.ConvTranspose2d(ngf, 3, 4, 2, 1, bias=False),
                    nn.Tanh()
                    # 3 x 32 x 32
                )
                
            def forward(self, x):
                return self.main(x)
        
        # Discriminator (modified for relativistic loss)
        class Discriminator(nn.Module):
            def __init__(self, image_size, ndf):
                super().__init__()
                
                # Only 32x32 architecture
                self.main = nn.Sequential(
                    nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf x 16 x 16
                    nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 2),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf*2 x 8 x 8
                    nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 4),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf*4 x 4 x 4
                    nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False),
                    # Remove sigmoid for relativistic loss
                )
                
            def forward(self, x):
                # Output: batch_size x 1
                return self.main(x).view(-1)
        
        self.generator = Generator(image_size, latent_dim, ngf)
        self.discriminator = Discriminator(image_size, ndf)
        
        # Optimizers - using same as DCGAN but different loss
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
        
        # RaLSGAN specific parameters
        self.ra_lambda = 1.0  # Relativistic average lambda

    def relativistic_average_loss(self, real_preds, fake_preds, target_real):
        """Calculate relativistic average loss for RaLSGAN"""
        # For real images
        real_diff = real_preds - fake_preds.mean(dim=0, keepdim=True)
        if target_real:
            loss_real = torch.mean((real_diff - 1) ** 2)
        else:
            loss_real = torch.mean((real_diff + 1) ** 2)
        
        # For fake images
        fake_diff = fake_preds - real_preds.mean(dim=0, keepdim=True)
        if target_real:
            loss_fake = torch.mean((fake_diff + 1) ** 2)
        else:
            loss_fake = torch.mean((fake_diff - 1) ** 2)
        
        return (loss_real + loss_fake) / 2

    def train_step(self, real_images):
        """Single training step for RaLSGAN"""
        batch_size = real_images.size(0)
        
        # Move real images to device
        real_images = real_images.to(self.device)
        
        # ===== Train Discriminator =====
        self.optimizerD.zero_grad()
        
        # Sample noise for generator
        noise = torch.randn(batch_size, self.latent_dim, 1, 1, device=self.device)
        
        # Generate fake images
        fake_images = self.generator(noise).detach()
        
        # Get discriminator predictions
        real_preds = self.discriminator(real_images)
        fake_preds = self.discriminator(fake_images)
        
        # Calculate relativistic average loss for discriminator
        d_loss_real = torch.mean((real_preds - fake_preds.mean() - 1) ** 2)
        d_loss_fake = torch.mean((fake_preds - real_preds.mean() + 1) ** 2)
        d_loss = (d_loss_real + d_loss_fake) / 2
        
        # Backward and optimize discriminator
        d_loss.backward()
        self.optimizerD.step()
        
        # ===== Train Generator =====
        self.optimizerG.zero_grad()
        
        # Generate new fake images
        noise = torch.randn(batch_size, self.latent_dim, 1, 1, device=self.device)
        fake_images = self.generator(noise)
        
        # Get discriminator predictions
        real_preds = self.discriminator(real_images).detach()
        fake_preds = self.discriminator(fake_images)
        
        # Calculate relativistic average loss for generator
        g_loss_real = torch.mean((fake_preds - real_preds.mean() - 1) ** 2)
        g_loss_fake = torch.mean((real_preds - fake_preds.mean() + 1) ** 2)
        g_loss = (g_loss_real + g_loss_fake) / 2
        
        # Backward and optimize generator
        g_loss.backward()
        self.optimizerG.step()
        
        return d_loss.item(), g_loss.item()

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            # Return a black image as fallback
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class RaLSGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("RaLSGAN Trainer - Multi-Core")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_dim': tk.IntVar(value=100),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'beta2': tk.DoubleVar(value=0.999),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
            'generate_interval': tk.IntVar(value=5),
            'ra_lambda': tk.DoubleVar(value=1.0)  # RaLSGAN specific
        }
        
        # Performance tracking
        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        
        # For storing generated images
        self.generated_images = []
        
        # Loss tracking
        self.d_loss_history = []
        self.g_loss_history = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()
        
        # Tab 4: Loss Plot
        self.loss_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.loss_tab, text='Loss Plot')
        self.setup_loss_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="RaLSGAN Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text="Image Size: 32x32")
        self.size_display.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize GAN", 
                 command=self.initialize_gan, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        # Iterations input
        iter_frame = tk.Frame(train_frame)
        iter_frame.pack(pady=5)
        tk.Label(iter_frame, text="Iterations:").pack(side=tk.LEFT)
        self.iter_var = tk.StringVar(value="10000")
        tk.Entry(iter_frame, textvariable=self.iter_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display - SINGLE LARGE IMAGE
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Single image display (200x200)
        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar at bottom
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="RaLSGAN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar for many settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Image size - Fixed to 32x32
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed)", width=20, anchor='w').pack(side=tk.LEFT, padx=5)
        
        # Other network parameters
        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 10, 500),
            ("Generator Features (ngf):", 'ngf', 32, 256),
            ("Discriminator Features (ndf):", 'ndf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 128),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Beta2:", 'beta2', 0.9, 0.9999),
            ("RA Lambda:", 'ra_lambda', 0.1, 2.0),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1', 'beta2', 'ra_lambda']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset to Paper", 
                 command=self.reset_to_paper, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load Generator", 
                 command=self.load_generator, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_loss_tab(self):
        """Setup loss plotting tab"""
        main_frame = tk.Frame(self.loss_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Loss History", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Control frame
        control_frame = tk.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(control_frame, text="Update Plot", 
                 command=self.update_loss_plot, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(control_frame, text="Clear History", 
                 command=self.clear_loss_history, width=15).pack(side=tk.LEFT, padx=5)
        
        # Plot frame
        plot_frame = tk.LabelFrame(main_frame, text="Loss Curves", padx=10, pady=10)
        plot_frame.pack(fill=tk.BOTH, expand=True)
        
        # Canvas for plotting
        self.loss_canvas = tk.Canvas(plot_frame, bg='white', width=600, height=400)
        self.loss_canvas.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Info label
        self.loss_info_label = tk.Label(main_frame, text="No loss data yet. Start training to see plots.")
        self.loss_info_label.pack(pady=10)

    def update_size_display(self):
        """Update image size display in training tab"""
        # Fixed to 32x32
        self.size_display.config(text="Image Size: 32x32")

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                # Add to log
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                
                # Update status with first line
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                
                print(message)  # Also print to console
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_gan(self):
        """Initialize GAN with current settings"""
        try:
            image_size = self.settings['image_size'].get()
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            
            self.gan = SimpleRaLSGAN(
                image_size=image_size,
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf
            )
            
            # Update RA lambda if needed
            if hasattr(self.gan, 'ra_lambda'):
                self.gan.ra_lambda = self.settings['ra_lambda'].get()
            
            self.log_message(f"Initialized RaLSGAN for {image_size}x{image_size} images")
            self.log_message(f"Latent dim: {latent_dim}, G features: {ngf}, D features: {ndf}")
            self.log_message(f"RA Lambda: {self.gan.ra_lambda}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            beta2 = self.settings['beta2'].get()
            ra_lambda = self.settings['ra_lambda'].get()
            
            # Update optimizers with new settings
            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, beta2)
            
            for param_group in self.gan.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, beta2)
            
            # Update RA lambda
            if hasattr(self.gan, 'ra_lambda'):
                self.gan.ra_lambda = ra_lambda
            
            # Clear loss history
            self.d_loss_history = []
            self.g_loss_history = []
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, num_workers),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started RaLSGAN training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta: ({beta1}, {beta2})")
            self.log_message(f"RA Lambda: {ra_lambda}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_gan(self, epochs, batch_size, num_workers):
        """Training loop in separate thread"""
        try:
            image_size = self.settings['image_size'].get()
            generate_interval = self.settings['generate_interval'].get()
            
            # Create dataset and dataloader
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                epoch_start = time.time()
                
                for real_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = real_images.size(0)
                    
                    # Train step
                    d_loss, g_loss = self.gan.train_step(real_images)
                    
                    total_loss_d += d_loss
                    total_loss_g += g_loss
                    batch_count += 1
                    
                    # Store loss history
                    self.d_loss_history.append(d_loss)
                    self.g_loss_history.append(g_loss)
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    # Log progress
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"D Loss: {avg_loss_d:.4f} | "
                                   f"G Loss: {avg_loss_g:.4f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Total: {elapsed:.1f}s")
                    
                    # Generate samples at interval
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                        
                        # Update loss plot
                        if len(self.d_loss_history) > 0:
                            self.root.after(0, self.update_loss_plot)
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_training_samples(self):
        """Generate sample images during training"""
        if not self.gan:
            return
        
        try:
            with torch.no_grad():
                # Generate 1 image
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
                
                # Convert to PIL
                img_tensor = generated[0]
                img = self.tensor_to_pil(img_tensor)
                
                # Resize to 200x200 for display using NEAREST
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                
                # Convert to PhotoImage
                photo = ImageTk.PhotoImage(img_display)
                
                # Update single image display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo  # Keep reference
                
                # Store for later
                self.generated_images.append(img)
                
                self.log_message(f"Generated training sample at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        img = (tensor + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        """Generate a single sample"""
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
                img = self.tensor_to_pil(generated[0])
                
                # Resize for display using NEAREST
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                # Store
                self.generated_images.append(img)
                
                self.log_message("Generated single sample")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def save_model(self):
        """Save current model - MANUAL SAVE ONLY"""
        if not self.gan:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'discriminator_state_dict': self.gan.discriminator.state_dict(),
                    'optimizerG_state_dict': self.gan.optimizerG.state_dict(),
                    'optimizerD_state_dict': self.gan.optimizerD.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                    'ra_lambda': self.settings['ra_lambda'].get(),
                    'd_loss_history': self.d_loss_history,
                    'g_loss_history': self.g_loss_history,
                }, filename)
                
                self.log_message(f"Model manually saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_generator(self):
        """Load generator from file"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                if 'image_size' in checkpoint:
                    self.settings['image_size'].set(checkpoint['image_size'])
                    self.update_size_display()
                
                if 'latent_dim' in checkpoint:
                    self.settings['latent_dim'].set(checkpoint['latent_dim'])
                
                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])
                
                if 'ndf' in checkpoint:
                    self.settings['ndf'].set(checkpoint['ndf'])
                
                if 'ra_lambda' in checkpoint:
                    self.settings['ra_lambda'].set(checkpoint['ra_lambda'])
                
                # Initialize GAN with loaded settings
                self.initialize_gan()
                
                # Load state dicts
                self.gan.generator.load_state_dict(checkpoint['generator_state_dict'])
                if 'discriminator_state_dict' in checkpoint:
                    self.gan.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])
                
                # Load loss history if available
                if 'd_loss_history' in checkpoint:
                    self.d_loss_history = checkpoint['d_loss_history']
                if 'g_loss_history' in checkpoint:
                    self.g_loss_history = checkpoint['g_loss_history']
                
                self.log_message(f"Loaded RaLSGAN model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                self.log_message(f"RA Lambda: {checkpoint.get('ra_lambda', 'unknown')}")
                
                # Update loss plot
                if len(self.d_loss_history) > 0:
                    self.update_loss_plot()
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        """Generate a grid of images"""
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            
            with torch.no_grad():
                noise = torch.randn(num_images, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
            
            # Clear previous images
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            # Create grid
            cols = 4
            rows = (num_images + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_tensor = generated[idx]
                        img = self.tensor_to_pil(img_tensor)
                        
                        # Resize for display using NEAREST
                        img_display = img.resize((128, 128), Image.Resampling.NEAREST)
                        
                        photo = ImageTk.PhotoImage(img_display)
                        
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            
            self.log_message(f"Generated {num_images} images in grid")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def update_loss_plot(self):
        """Update the loss plot on the loss tab"""
        if len(self.d_loss_history) == 0:
            self.loss_info_label.config(text="No loss data yet. Start training to see plots.")
            return
        
        # Clear canvas
        self.loss_canvas.delete("all")
        
        # Get canvas dimensions
        width = self.loss_canvas.winfo_width() - 40
        height = self.loss_canvas.winfo_height() - 40
        
        if width <= 40 or height <= 40:
            return
        
        # Find min and max values
        all_losses = self.d_loss_history + self.g_loss_history
        if len(all_losses) == 0:
            return
            
        min_val = min(all_losses)
        max_val = max(all_losses)
        
        # Add some padding
        y_range = max_val - min_val
        if y_range == 0:
            y_range = 1
        min_val = min_val - y_range * 0.1
        max_val = max_val + y_range * 0.1
        
        # Draw axes
        self.loss_canvas.create_line(20, 20, 20, height, fill="black", width=2)
        self.loss_canvas.create_line(20, height, width, height, fill="black", width=2)
        
        # Draw labels
        self.loss_canvas.create_text(10, 10, text=f"Max: {max_val:.3f}", anchor="nw", font=("Arial", 8))
        self.loss_canvas.create_text(10, height, text=f"Min: {min_val:.3f}", anchor="sw", font=("Arial", 8))
        self.loss_canvas.create_text(width // 2, height + 20, text="Iterations", anchor="n", font=("Arial", 10))
        self.loss_canvas.create_text(5, height // 2, text="Loss", anchor="e", font=("Arial", 10), angle=90)
        
        # Plot D loss (blue)
        if len(self.d_loss_history) > 1:
            points = []
            for i, loss in enumerate(self.d_loss_history):
                if i >= 1000:  # Limit points for performance
                    break
                x = 20 + (i / min(len(self.d_loss_history), 1000)) * (width - 20)
                y = height - ((loss - min_val) / (max_val - min_val)) * (height - 20)
                points.append((x, y))
            
            if len(points) > 1:
                for i in range(1, len(points)):
                    self.loss_canvas.create_line(points[i-1][0], points[i-1][1], 
                                                 points[i][0], points[i][1], 
                                                 fill="blue", width=2)
        
        # Plot G loss (red)
        if len(self.g_loss_history) > 1:
            points = []
            for i, loss in enumerate(self.g_loss_history):
                if i >= 1000:  # Limit points for performance
                    break
                x = 20 + (i / min(len(self.g_loss_history), 1000)) * (width - 20)
                y = height - ((loss - min_val) / (max_val - min_val)) * (height - 20)
                points.append((x, y))
            
            if len(points) > 1:
                for i in range(1, len(points)):
                    self.loss_canvas.create_line(points[i-1][0], points[i-1][1], 
                                                 points[i][0], points[i][1], 
                                                 fill="red", width=2)
        
        # Draw legend
        self.loss_canvas.create_rectangle(width - 150, 20, width - 20, 70, fill="white", outline="black")
        self.loss_canvas.create_line(width - 140, 35, width - 110, 35, fill="blue", width=2)
        self.loss_canvas.create_text(width - 100, 35, text="D Loss", anchor="w", font=("Arial", 9))
        self.loss_canvas.create_line(width - 140, 55, width - 110, 55, fill="red", width=2)
        self.loss_canvas.create_text(width - 100, 55, text="G Loss", anchor="w", font=("Arial", 9))
        
        # Update info label
        avg_d_loss = np.mean(self.d_loss_history[-100:]) if len(self.d_loss_history) > 0 else 0
        avg_g_loss = np.mean(self.g_loss_history[-100:]) if len(self.g_loss_history) > 0 else 0
        self.loss_info_label.config(
            text=f"Latest losses - D: {avg_d_loss:.4f}, G: {avg_g_loss:.4f} | Total points: {len(self.d_loss_history)}"
        )

    def clear_loss_history(self):
        """Clear loss history"""
        self.d_loss_history = []
        self.g_loss_history = []
        self.loss_canvas.delete("all")
        self.loss_info_label.config(text="Loss history cleared.")
        self.log_message("Cleared loss history")

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('ralsgan_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            import json
            if os.path.exists('ralsgan_defaults.json'):
                with open('ralsgan_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.update_size_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_to_paper(self):
        """Reset to RaLSGAN paper settings"""
        paper_settings = {
            'image_size': 32,
            'latent_dim': 100,
            'ngf': 64,
            'ndf': 64,
            'batch_size': 48,  # RaLSGAN often uses larger batch
            'learning_rate': 0.0001,  # Lower LR for stability
            'beta1': 0.5,
            'beta2': 0.999,
            'num_workers': min(4, multiprocessing.cpu_count()),
            'save_interval': 10,
            'generate_interval': 5,
            'ra_lambda': 1.0  # Relativistic average lambda
        }
        
        for key, value in paper_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        
        self.update_size_display()
        self.log_message("Reset to RaLSGAN paper settings")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting RaLSGAN Trainer...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = RaLSGANApp(root)
    root.mainloop()