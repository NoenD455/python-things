import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from torchvision.utils import save_image
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk, ImageOps
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import os
import threading
import time
from datetime import datetime
import glob

# Set device to CPU for 2-core usage
device = torch.device("cpu")

# Configuration
IMAGE_SIZE = 64
LATENT_DIM = 128
BATCH_SIZE = 32
LEARNING_RATE = 0.0005
EPOCHS = 50

# Custom Dataset class
class ImageDataset(Dataset):
    def __init__(self, image_paths, transform=None):
        self.image_paths = image_paths
        self.transform = transform
        
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        image_path = self.image_paths[idx]
        image = Image.open(image_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        return image

# VAE Model
class VAE(nn.Module):
    def __init__(self, latent_dim=LATENT_DIM):
        super(VAE, self).__init__()
        
        # Encoder
        self.encoder = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=4, stride=2, padding=1),  # 64x64 -> 32x32
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=1), # 32x32 -> 16x16
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1), # 16x16 -> 8x8
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Conv2d(128, 256, kernel_size=4, stride=2, padding=1), # 8x8 -> 4x4
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Flatten(),
            nn.Linear(256 * 4 * 4, 1024),
            nn.ReLU()
        )
        
        # Latent space
        self.fc_mu = nn.Linear(1024, latent_dim)
        self.fc_logvar = nn.Linear(1024, latent_dim)
        
        # Decoder
        self.decoder_input = nn.Linear(latent_dim, 256 * 4 * 4)
        
        self.decoder = nn.Sequential(
            nn.Unflatten(1, (256, 4, 4)),
            nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2, padding=1), # 4x4 -> 8x8
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1), # 8x8 -> 16x16
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1), # 16x16 -> 32x32
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.ConvTranspose2d(32, 3, kernel_size=4, stride=2, padding=1), # 32x32 -> 64x64
            nn.Sigmoid()
        )
        
    def encode(self, x):
        h = self.encoder(x)
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        return mu, logvar
    
    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std
    
    def decode(self, z):
        h = self.decoder_input(z)
        return self.decoder(h)
    
    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        return self.decode(z), mu, logvar

# Loss function for VAE
def vae_loss(recon_x, x, mu, logvar):
    # Reconstruction loss (MSE)
    recon_loss = F.mse_loss(recon_x, x, reduction='sum')
    
    # KL divergence
    kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    
    return recon_loss + kl_loss

# Tkinter GUI Application
class VAEGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("VAE Image Generator")
        self.root.geometry("1200x800")
        
        # Initialize model
        self.model = VAE(LATENT_DIM).to(device)
        self.optimizer = optim.Adam(self.model.parameters(), lr=LEARNING_RATE)
        
        # Training variables
        self.training = False
        self.current_epoch = 0
        self.train_losses = []
        self.val_losses = []
        self.image_paths = []
        
        # Setup GUI
        self.setup_gui()
        
        # Create models directory if it doesn't exist
        if not os.path.exists('models'):
            os.makedirs('models')
        
        # Create generated images directory if it doesn't exist
        if not os.path.exists('generated'):
            os.makedirs('generated')
    
    def setup_gui(self):
        # Create main frames
        control_frame = ttk.Frame(self.root, padding="10")
        control_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        display_frame = ttk.Frame(self.root, padding="10")
        display_frame.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.columnconfigure(1, weight=2)
        self.root.rowconfigure(0, weight=1)
        
        # Control Panel
        ttk.Label(control_frame, text="VAE Image Generator", font=("Arial", 16, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # Dataset selection
        ttk.Label(control_frame, text="Dataset Folder:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.dataset_path = tk.StringVar()
        ttk.Entry(control_frame, textvariable=self.dataset_path, width=30).grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5)
        ttk.Button(control_frame, text="Browse", command=self.browse_dataset).grid(row=1, column=2, padx=(5, 0))
        
        # Training controls
        ttk.Separator(control_frame, orient='horizontal').grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        ttk.Label(control_frame, text="Training Parameters", font=("Arial", 12, "bold")).grid(row=3, column=0, columnspan=3, pady=(0, 10))
        
        ttk.Label(control_frame, text="Epochs:").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.epochs_var = tk.IntVar(value=EPOCHS)
        ttk.Entry(control_frame, textvariable=self.epochs_var, width=10).grid(row=4, column=1, sticky=tk.W, pady=5)
        
        ttk.Label(control_frame, text="Batch Size:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.batch_size_var = tk.IntVar(value=BATCH_SIZE)
        ttk.Entry(control_frame, textvariable=self.batch_size_var, width=10).grid(row=5, column=1, sticky=tk.W, pady=5)
        
        ttk.Label(control_frame, text="Latent Dim:").grid(row=6, column=0, sticky=tk.W, pady=5)
        self.latent_dim_var = tk.IntVar(value=LATENT_DIM)
        ttk.Entry(control_frame, textvariable=self.latent_dim_var, width=10).grid(row=6, column=1, sticky=tk.W, pady=5)
        
        ttk.Label(control_frame, text="Learning Rate:").grid(row=7, column=0, sticky=tk.W, pady=5)
        self.lr_var = tk.DoubleVar(value=LEARNING_RATE)
        ttk.Entry(control_frame, textvariable=self.lr_var, width=10).grid(row=7, column=1, sticky=tk.W, pady=5)
        
        # Training buttons
        button_frame = ttk.Frame(control_frame)
        button_frame.grid(row=8, column=0, columnspan=3, pady=20)
        
        self.train_button = ttk.Button(button_frame, text="Start Training", command=self.start_training)
        self.train_button.pack(side=tk.LEFT, padx=5)
        
        self.stop_button = ttk.Button(button_frame, text="Stop Training", command=self.stop_training, state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)
        
        # Training progress
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(control_frame, variable=self.progress_var, maximum=100)
        self.progress_bar.grid(row=9, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        self.status_label = ttk.Label(control_frame, text="Ready to train")
        self.status_label.grid(row=10, column=0, columnspan=3, pady=5)
        
        # Generation controls
        ttk.Separator(control_frame, orient='horizontal').grid(row=11, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        ttk.Label(control_frame, text="Image Generation", font=("Arial", 12, "bold")).grid(row=12, column=0, columnspan=3, pady=(0, 10))
        
        ttk.Label(control_frame, text="Number of Images:").grid(row=13, column=0, sticky=tk.W, pady=5)
        self.num_images_var = tk.IntVar(value=4)
        ttk.Entry(control_frame, textvariable=self.num_images_var, width=10).grid(row=13, column=1, sticky=tk.W, pady=5)
        
        generate_button_frame = ttk.Frame(control_frame)
        generate_button_frame.grid(row=14, column=0, columnspan=3, pady=10)
        
        ttk.Button(generate_button_frame, text="Generate Random", command=self.generate_random).pack(side=tk.LEFT, padx=5)
        ttk.Button(generate_button_frame, text="Generate from Noise", command=self.generate_from_noise).pack(side=tk.LEFT, padx=5)
        
        # Model management
        ttk.Separator(control_frame, orient='horizontal').grid(row=15, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        ttk.Label(control_frame, text="Model Management", font=("Arial", 12, "bold")).grid(row=16, column=0, columnspan=3, pady=(0, 10))
        
        model_button_frame = ttk.Frame(control_frame)
        model_button_frame.grid(row=17, column=0, columnspan=3, pady=5)
        
        ttk.Button(model_button_frame, text="Save Model", command=self.save_model).pack(side=tk.LEFT, padx=5)
        ttk.Button(model_button_frame, text="Load Model", command=self.load_model).pack(side=tk.LEFT, padx=5)
        
        # Display Panel
        self.setup_display_panel(display_frame)
    
    def setup_display_panel(self, parent):
        # Create notebook for different views
        notebook = ttk.Notebook(parent)
        notebook.pack(fill=tk.BOTH, expand=True)
        
        # Training visualization tab
        train_tab = ttk.Frame(notebook)
        notebook.add(train_tab, text="Training")
        
        # Create matplotlib figure for loss plot
        self.fig, self.ax = plt.subplots(figsize=(8, 4))
        self.ax.set_xlabel('Epoch')
        self.ax.set_ylabel('Loss')
        self.ax.set_title('Training and Validation Loss')
        self.ax.grid(True)
        self.loss_line_train, = self.ax.plot([], [], 'b-', label='Train Loss')
        self.loss_line_val, = self.ax.plot([], [], 'r-', label='Val Loss')
        self.ax.legend()
        
        self.canvas = FigureCanvasTkAgg(self.fig, train_tab)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Generation tab
        gen_tab = ttk.Frame(notebook)
        notebook.add(gen_tab, text="Generated Images")
        
        # Frame for generated images
        self.gen_images_frame = ttk.Frame(gen_tab)
        self.gen_images_frame.pack(fill=tk.BOTH, expand=True)
        
        # Label to display generated images
        self.gen_label = ttk.Label(self.gen_images_frame, text="No images generated yet")
        self.gen_label.pack(expand=True)
        
        # Original images tab
        orig_tab = ttk.Frame(notebook)
        notebook.add(orig_tab, text="Original Images")
        
        # Frame for original images
        self.orig_images_frame = ttk.Frame(orig_tab)
        self.orig_images_frame.pack(fill=tk.BOTH, expand=True)
        
        # Label to display original images
        self.orig_label = ttk.Label(self.orig_images_frame, text="No dataset loaded")
        self.orig_label.pack(expand=True)
    
    def browse_dataset(self):
        folder = filedialog.askdirectory(title="Select Dataset Folder")
        if folder:
            self.dataset_path.set(folder)
            # Load image paths
            self.image_paths = glob.glob(os.path.join(folder, "*.jpg")) + \
                              glob.glob(os.path.join(folder, "*.png")) + \
                              glob.glob(os.path.join(folder, "*.jpeg"))
            
            if self.image_paths:
                messagebox.showinfo("Dataset Loaded", f"Loaded {len(self.image_paths)} images")
                # Display some sample images
                self.display_sample_original_images()
            else:
                messagebox.showwarning("No Images", "No images found in the selected folder")
    
    def display_sample_original_images(self):
        if not self.image_paths:
            return
        
        # Load and display up to 4 sample images
        sample_paths = self.image_paths[:4]
        images = []
        
        for path in sample_paths:
            img = Image.open(path)
            # Resize using Lanczos for downscaling
            if img.width > IMAGE_SIZE or img.height > IMAGE_SIZE:
                img = img.resize((IMAGE_SIZE, IMAGE_SIZE), Image.Resampling.LANCZOS)
            else:
                # Use nearest neighbor for upscaling if needed
                img = img.resize((IMAGE_SIZE, IMAGE_SIZE), Image.Resampling.NEAREST)
            
            images.append(img)
        
        # Create a grid of images
        total_width = IMAGE_SIZE * 2
        total_height = IMAGE_SIZE * 2 if len(images) > 2 else IMAGE_SIZE
        
        grid_img = Image.new('RGB', (total_width, total_height))
        
        for i, img in enumerate(images):
            x = (i % 2) * IMAGE_SIZE
            y = (i // 2) * IMAGE_SIZE
            grid_img.paste(img, (x, y))
        
        # Display in GUI
        grid_img_tk = ImageTk.PhotoImage(grid_img)
        self.orig_label.configure(image=grid_img_tk, text="")
        self.orig_label.image = grid_img_tk
    
    def start_training(self):
        if not self.image_paths:
            messagebox.showerror("Error", "Please select a dataset folder first")
            return
        
        # Update model parameters if changed
        if self.latent_dim_var.get() != LATENT_DIM:
            self.model = VAE(self.latent_dim_var.get()).to(device)
            self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr_var.get())
        
        # Disable training button, enable stop button
        self.train_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        
        # Start training in a separate thread
        self.training = True
        self.current_epoch = 0
        self.train_losses = []
        self.val_losses = []
        
        training_thread = threading.Thread(target=self.train_model)
        training_thread.daemon = True
        training_thread.start()
    
    def stop_training(self):
        self.training = False
        self.status_label.config(text="Training stopped")
    
    def train_model(self):
        # Get parameters
        epochs = self.epochs_var.get()
        batch_size = self.batch_size_var.get()
        
        # Define transforms with downscaling using Lanczos and upscaling using Nearest Neighbor
        transform = transforms.Compose([
            transforms.Lambda(lambda img: self.resize_image(img, IMAGE_SIZE)),
            transforms.ToTensor()
        ])
        
        # Create dataset and dataloader
        dataset = ImageDataset(self.image_paths, transform=transform)
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=0)  # num_workers=0 for CPU
        
        # Training loop
        for epoch in range(epochs):
            if not self.training:
                break
                
            self.current_epoch = epoch
            self.model.train()
            train_loss = 0
            
            for batch_idx, data in enumerate(dataloader):
                if not self.training:
                    break
                    
                data = data.to(device)
                self.optimizer.zero_grad()
                
                recon_batch, mu, logvar = self.model(data)
                loss = vae_loss(recon_batch, data, mu, logvar)
                
                loss.backward()
                train_loss += loss.item()
                self.optimizer.step()
                
                # Update progress
                progress = ((batch_idx + 1) / len(dataloader)) * 100
                self.progress_var.set(progress)
                self.status_label.config(text=f"Epoch {epoch+1}/{epochs}, Batch {batch_idx+1}/{len(dataloader)}")
                self.root.update_idletasks()
            
            # Calculate average loss for this epoch
            avg_train_loss = train_loss / len(dataloader.dataset)
            self.train_losses.append(avg_train_loss)
            
            # Simple validation (using training data for simplicity)
            self.model.eval()
            with torch.no_grad():
                val_loss = 0
                for data in dataloader:
                    data = data.to(device)
                    recon_batch, mu, logvar = self.model(data)
                    val_loss += vae_loss(recon_batch, data, mu, logvar).item()
                
                avg_val_loss = val_loss / len(dataloader.dataset)
                self.val_losses.append(avg_val_loss)
            
            # Update loss plot
            self.update_loss_plot()
            
            # Generate sample images every 5 epochs
            if (epoch + 1) % 5 == 0:
                self.generate_and_display_samples(epoch + 1)
            
            # Update status
            self.status_label.config(text=f"Epoch {epoch+1}/{epochs} complete. Train Loss: {avg_train_loss:.4f}, Val Loss: {avg_val_loss:.4f}")
            
            # Reset progress bar
            self.progress_var.set(0)
        
        # Training complete
        self.training = False
        self.train_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.status_label.config(text="Training complete")
        
        # Save the model
        model_path = f"models/vae_model_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pth"
        torch.save(self.model.state_dict(), model_path)
        messagebox.showinfo("Model Saved", f"Model saved to {model_path}")
    
    def resize_image(self, img, target_size):
        """Resize image using Lanczos for downscaling and Nearest Neighbor for upscaling"""
        width, height = img.size
        
        if width > target_size or height > target_size:
            # Downscale using Lanczos
            return img.resize((target_size, target_size), Image.Resampling.LANCZOS)
        else:
            # Upscale using Nearest Neighbor
            return img.resize((target_size, target_size), Image.Resampling.NEAREST)
    
    def update_loss_plot(self):
        # Clear and update the plot
        self.ax.clear()
        
        if self.train_losses:
            epochs_range = range(1, len(self.train_losses) + 1)
            self.ax.plot(epochs_range, self.train_losses, 'b-', label='Train Loss')
        
        if self.val_losses:
            epochs_range = range(1, len(self.val_losses) + 1)
            self.ax.plot(epochs_range, self.val_losses, 'r-', label='Val Loss')
        
        self.ax.set_xlabel('Epoch')
        self.ax.set_ylabel('Loss')
        self.ax.set_title('Training and Validation Loss')
        self.ax.grid(True)
        self.ax.legend()
        
        self.canvas.draw()
    
    def generate_and_display_samples(self, epoch):
        self.model.eval()
        with torch.no_grad():
            # Generate random samples
            z = torch.randn(4, self.latent_dim_var.get()).to(device)
            samples = self.model.decode(z).cpu()
            
            # Create a grid of generated images
            grid_img = self.create_image_grid(samples)
            
            # Save the generated images
            save_path = f"generated/epoch_{epoch}.png"
            save_image(samples, save_path, nrow=2)
            
            # Display in GUI
            self.display_generated_images(grid_img)
    
    def generate_random(self):
        if not hasattr(self.model, 'decoder'):
            messagebox.showerror("Error", "Please train or load a model first")
            return
        
        num_images = self.num_images_var.get()
        
        self.model.eval()
        with torch.no_grad():
            # Generate random samples
            z = torch.randn(num_images, self.latent_dim_var.get()).to(device)
            samples = self.model.decode(z).cpu()
            
            # Create a grid of generated images
            grid_img = self.create_image_grid(samples)
            
            # Save the generated images
            save_path = f"generated/random_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            save_image(samples, save_path, nrow=int(np.sqrt(num_images)))
            
            # Display in GUI
            self.display_generated_images(grid_img)
            
            messagebox.showinfo("Images Generated", f"{num_images} images generated and saved to {save_path}")
    
    def generate_from_noise(self):
        if not hasattr(self.model, 'decoder'):
            messagebox.showerror("Error", "Please train or load a model first")
            return
        
        # Create a dialog for custom noise input
        noise_dialog = tk.Toplevel(self.root)
        noise_dialog.title("Generate from Noise")
        noise_dialog.geometry("400x300")
        
        ttk.Label(noise_dialog, text="Enter noise values (comma-separated):").pack(pady=10)
        
        noise_text = tk.Text(noise_dialog, height=10, width=40)
        noise_text.pack(pady=10)
        
        def generate_from_custom_noise():
            noise_str = noise_text.get("1.0", tk.END).strip()
            try:
                noise_values = [float(x) for x in noise_str.split(',')]
                latent_dim = self.latent_dim_var.get()
                
                if len(noise_values) != latent_dim:
                    messagebox.showerror("Error", f"Please enter exactly {latent_dim} values")
                    return
                
                # Convert to tensor
                z = torch.tensor(noise_values, dtype=torch.float32).unsqueeze(0).to(device)
                
                # Generate image
                self.model.eval()
                with torch.no_grad():
                    sample = self.model.decode(z).cpu()
                
                # Save and display
                save_path = f"generated/custom_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
                save_image(sample, save_path)
                
                # Convert tensor to PIL Image for display
                sample_img = transforms.ToPILImage()(sample.squeeze(0))
                
                # Resize for display using nearest neighbor
                display_size = IMAGE_SIZE * 2
                sample_img = sample_img.resize((display_size, display_size), Image.Resampling.NEAREST)
                
                # Display in GUI
                sample_img_tk = ImageTk.PhotoImage(sample_img)
                self.gen_label.configure(image=sample_img_tk, text="")
                self.gen_label.image = sample_img_tk
                
                messagebox.showinfo("Image Generated", f"Image generated and saved to {save_path}")
                noise_dialog.destroy()
                
            except ValueError:
                messagebox.showerror("Error", "Please enter valid numbers separated by commas")
        
        ttk.Button(noise_dialog, text="Generate", command=generate_from_custom_noise).pack(pady=10)
    
    def create_image_grid(self, tensor_images):
        """Convert a tensor of images to a PIL Image grid"""
        # Convert tensor to numpy and reshape
        images = tensor_images.numpy()
        images = np.transpose(images, (0, 2, 3, 1))  # (N, C, H, W) -> (N, H, W, C)
        
        # Determine grid size
        num_images = images.shape[0]
        grid_size = int(np.ceil(np.sqrt(num_images)))
        
        # Create empty grid image
        grid_img = Image.new('RGB', (grid_size * IMAGE_SIZE, grid_size * IMAGE_SIZE))
        
        # Paste images into grid
        for i in range(num_images):
            img_array = (images[i] * 255).astype(np.uint8)
            img = Image.fromarray(img_array)
            
            # Resize using nearest neighbor for display
            img = img.resize((IMAGE_SIZE, IMAGE_SIZE), Image.Resampling.NEAREST)
            
            x = (i % grid_size) * IMAGE_SIZE
            y = (i // grid_size) * IMAGE_SIZE
            grid_img.paste(img, (x, y))
        
        return grid_img
    
    def display_generated_images(self, grid_img):
        # Resize for display (optional)
        display_size = min(400, max(grid_img.width, grid_img.height))
        display_img = grid_img.resize((display_size, display_size), Image.Resampling.NEAREST)
        
        # Convert to PhotoImage
        grid_img_tk = ImageTk.PhotoImage(display_img)
        
        # Update label
        self.gen_label.configure(image=grid_img_tk, text="")
        self.gen_label.image = grid_img_tk
    
    def save_model(self):
        file_path = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch Model", "*.pth"), ("All Files", "*.*")],
            initialdir="models"
        )
        
        if file_path:
            torch.save(self.model.state_dict(), file_path)
            messagebox.showinfo("Model Saved", f"Model saved to {file_path}")
    
    def load_model(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("PyTorch Model", "*.pth"), ("All Files", "*.*")],
            initialdir="models"
        )
        
        if file_path:
            try:
                self.model.load_state_dict(torch.load(file_path, map_location=device))
                messagebox.showinfo("Model Loaded", f"Model loaded from {file_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load model: {str(e)}")

# Main function
def main():
    root = tk.Tk()
    app = VAEGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()