import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import multiprocessing
import time
import traceback
import json

# ==================== Neural Network ====================

class PixelShuffleUpsample(nn.Module):
    """Pixel shuffle upsampling block"""
    def __init__(self, in_channels, out_channels, upscale_factor=2):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels * (upscale_factor ** 2), 3, 1, 1, bias=False)
        self.pixel_shuffle = nn.PixelShuffle(upscale_factor)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(True)
    
    def forward(self, x):
        x = self.conv(x)
        x = self.pixel_shuffle(x)
        x = self.bn(x)
        x = self.relu(x)
        return x

class ResidualBlock(nn.Module):
    """Residual block with pixel shuffle option"""
    def __init__(self, channels, use_pixel_shuffle=False):
        super().__init__()
        self.use_pixel_shuffle = use_pixel_shuffle
        
        if use_pixel_shuffle:
            self.upsample = PixelShuffleUpsample(channels // 4, channels)
        
        self.conv1 = nn.Conv2d(channels, channels, 3, 1, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(channels)
        self.relu = nn.ReLU(True)
        self.conv2 = nn.Conv2d(channels, channels, 3, 1, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(channels)
    
    def forward(self, x):
        residual = x
        
        if self.use_pixel_shuffle:
            residual = self.upsample(residual)
        
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        out = out + residual
        out = self.relu(out)
        return out

class MultiScaleDCGAN:
    def __init__(self, image_size=32, latent_dim=100, ngf=64, ndf=64, use_pixel_shuffle=True):
        self.image_size = image_size
        self.latent_dim = latent_dim
        self.use_pixel_shuffle = use_pixel_shuffle
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # ==================== Generator ====================
        class Generator(nn.Module):
            def __init__(self, image_size, latent_dim, ngf, use_pixel_shuffle):
                super().__init__()
                self.image_size = image_size
                self.use_pixel_shuffle = use_pixel_shuffle
                
                # Base generator (produces 4x4 feature maps)
                self.base = nn.Sequential(
                    nn.ConvTranspose2d(latent_dim, ngf * 8, 4, 1, 0, bias=False),
                    nn.BatchNorm2d(ngf * 8),
                    nn.ReLU(True)
                )
                
                # Progressive upsampling blocks
                self.upsample_blocks = nn.ModuleList()
                
                if use_pixel_shuffle:
                    # 4x4 -> 8x8 using pixel shuffle
                    self.upsample_blocks.append(PixelShuffleUpsample(ngf * 8, ngf * 4))
                    # 8x8 -> 16x16 using pixel shuffle
                    self.upsample_blocks.append(PixelShuffleUpsample(ngf * 4, ngf * 2))
                    # 16x16 -> 32x32 using pixel shuffle
                    self.upsample_blocks.append(PixelShuffleUpsample(ngf * 2, ngf))
                else:
                    # 4x4 -> 8x8 using transposed conv
                    self.upsample_blocks.append(nn.Sequential(
                        nn.ConvTranspose2d(ngf * 8, ngf * 4, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(ngf * 4),
                        nn.ReLU(True)
                    ))
                    # 8x8 -> 16x16 using transposed conv
                    self.upsample_blocks.append(nn.Sequential(
                        nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(ngf * 2),
                        nn.ReLU(True)
                    ))
                    # 16x16 -> 32x32 using transposed conv
                    self.upsample_blocks.append(nn.Sequential(
                        nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(ngf),
                        nn.ReLU(True)
                    ))
                
                # Residual blocks for each scale
                self.residual_blocks = nn.ModuleList()
                self.residual_blocks.append(ResidualBlock(ngf * 4, use_pixel_shuffle=False))
                self.residual_blocks.append(ResidualBlock(ngf * 2, use_pixel_shuffle=False))
                self.residual_blocks.append(ResidualBlock(ngf, use_pixel_shuffle=False))
                
                # Output layers for each scale
                self.output_layers = nn.ModuleList()
                # 8x8 output
                self.output_layers.append(nn.Sequential(
                    nn.Conv2d(ngf * 4, 3, 3, 1, 1, bias=False),
                    nn.Tanh()
                ))
                # 16x16 output  
                self.output_layers.append(nn.Sequential(
                    nn.Conv2d(ngf * 2, 3, 3, 1, 1, bias=False),
                    nn.Tanh()
                ))
                # 32x32 output (final)
                self.output_layers.append(nn.Sequential(
                    nn.Conv2d(ngf, 3, 3, 1, 1, bias=False),
                    nn.Tanh()
                ))
            
            def forward(self, x):
                # Generate base features
                x = self.base(x)  # ngf*8 x 4 x 4
                
                outputs = []
                current_features = x
                
                for i, (upsample, residual) in enumerate(zip(self.upsample_blocks, self.residual_blocks)):
                    # Upsample
                    current_features = upsample(current_features)
                    
                    # Apply residual refinement
                    current_features = residual(current_features)
                    
                    # Get output at this scale
                    scale_output = self.output_layers[i](current_features)
                    outputs.append(scale_output)
                
                return outputs  # Returns [8x8, 16x16, 32x32] images
        
        # ==================== Multi-Scale Discriminators ====================
        class MultiScaleDiscriminator(nn.Module):
            def __init__(self, image_size, ndf):
                super().__init__()
                
                # Discriminator for 8x8 images
                self.discriminator_8x8 = nn.Sequential(
                    nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 2),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf * 2, 1, 2, 1, 0, bias=False),
                    nn.Flatten()
                )
                
                # Discriminator for 16x16 images
                self.discriminator_16x16 = nn.Sequential(
                    nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 2),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 4),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf * 4, 1, 2, 1, 0, bias=False),
                    nn.Flatten()
                )
                
                # Discriminator for 32x32 images
                self.discriminator_32x32 = nn.Sequential(
                    nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 2),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 4),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False),
                    nn.Flatten()
                )
            
            def forward(self, x, scale):
                if scale == 8:
                    return self.discriminator_8x8(x)
                elif scale == 16:
                    return self.discriminator_16x16(x)
                else:  # scale == 32
                    return self.discriminator_32x32(x)
        
        self.generator = Generator(image_size, latent_dim, ngf, use_pixel_shuffle)
        self.discriminator = MultiScaleDiscriminator(image_size, ndf)
        
        # Loss function - Using BCEWithLogitsLoss
        self.criterion = nn.BCEWithLogitsLoss()
        
        # Optimizers
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
        
        # Define the scales
        self.scales = [8, 16, 32]

# ==================== Dataset ====================

class MultiScaleImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        # Define transforms for each scale
        self.transforms = {
            32: transforms.Compose([
                transforms.Resize((32, 32)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ]),
            16: transforms.Compose([
                transforms.Resize((16, 16)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ]),
            8: transforms.Compose([
                transforms.Resize((8, 8)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        }
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return {
                32: self.transforms[32](img),
                16: self.transforms[16](img),
                8: self.transforms[8](img)
            }
        except Exception:
            return {
                32: torch.zeros(3, 32, 32),
                16: torch.zeros(3, 16, 16),
                8: torch.zeros(3, 8, 8)
            }

# ==================== GUI Application ====================

class MultiScaleDCGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Multi-Scale DCGAN Trainer")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings with label smoothing
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_dim': tk.IntVar(value=100),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
            'generate_interval': tk.IntVar(value=5),
            'label_smoothing': tk.DoubleVar(value=0.1),
            'use_pixel_shuffle': tk.BooleanVar(value=True)
        }
        
        # For storing generated images
        self.generated_images = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Multi-Scale DCGAN Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize GAN", 
                 command=self.initialize_gan, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Multi-Scale Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Multi-scale image display
        preview_frame = tk.LabelFrame(right_frame, text="Multi-Scale Generated Images", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create frame for 3 scales
        scales_frame = tk.Frame(preview_frame)
        scales_frame.pack(pady=10)
        
        self.scale_labels = {}
        scales = [("8x8", 100), ("16x16", 150), ("32x32", 200)]
        
        for scale_name, size in scales:
            scale_frame = tk.Frame(scales_frame)
            scale_frame.pack(side=tk.LEFT, padx=10)
            
            tk.Label(scale_frame, text=scale_name, font=("Arial", 10, "bold")).pack()
            
            img_frame = tk.Frame(scale_frame, width=size, height=size, bg='gray')
            img_frame.pack(pady=5)
            img_frame.pack_propagate(False)
            
            label = tk.Label(img_frame, text="No image", bg='gray')
            label.pack(fill=tk.BOTH, expand=True)
            
            self.scale_labels[scale_name] = label
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="Multi-Scale DCGAN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(net_frame, text="Multi-scale training at: 8x8, 16x16, 32x32", 
                font=("Arial", 10, "bold")).pack(pady=5)
        
        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 10, 500),
            ("Generator Features (ngf):", 'ngf', 32, 256),
            ("Discriminator Features (ndf):", 'ndf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 128),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Pixel Shuffle option
        frame = tk.Frame(net_frame)
        frame.pack(fill=tk.X, pady=5)
        tk.Label(frame, text="Use Pixel Shuffle:", width=30, anchor='w').pack(side=tk.LEFT)
        tk.Checkbutton(frame, variable=self.settings['use_pixel_shuffle']).pack(side=tk.RIGHT)
        
        # Training settings with label smoothing
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Label Smoothing:", 'label_smoothing', 0.0, 0.3),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1', 'label_smoothing']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset to Paper", 
                 command=self.reset_to_paper, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Multi-Scale Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load Generator", 
                 command=self.load_generator, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images (32x32)", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=message[:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                self.image_listbox.insert(tk.END, os.path.basename(file))
        
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_gan(self):
        """Initialize GAN with current settings"""
        try:
            image_size = self.settings['image_size'].get()
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            use_pixel_shuffle = self.settings['use_pixel_shuffle'].get()
            
            self.gan = MultiScaleDCGAN(
                image_size=image_size,
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf,
                use_pixel_shuffle=use_pixel_shuffle
            )
            
            self.log_message(f"Initialized Multi-Scale DCGAN")
            self.log_message(f"Latent dim: {latent_dim}, G features: {ngf}, D features: {ndf}")
            self.log_message(f"Pixel Shuffle: {use_pixel_shuffle}")
            self.log_message(f"Generating at 3 scales: 8x8, 16x16, 32x32")
            
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            label_smoothing = self.settings['label_smoothing'].get()
            
            # Update optimizers
            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            for param_group in self.gan.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, num_workers, label_smoothing),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Label smoothing: {label_smoothing}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_gan(self, epochs, batch_size, num_workers, label_smoothing):
        """Training loop with label smoothing"""
        try:
            dataset = MultiScaleImageDataset(self.image_paths)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available()
            )
            
            generate_interval = self.settings['generate_interval'].get()
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                epoch_start = time.time()
                
                for batch in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = None
                    
                    # Train Discriminator on all scales
                    self.gan.optimizerD.zero_grad()
                    loss_d_accum = 0
                    
                    for scale in self.gan.scales:
                        # Get real images
                        real_images = batch[scale].to(self.gan.device)
                        if batch_size_actual is None:
                            batch_size_actual = real_images.size(0)
                        
                        # Real images loss with label smoothing
                        real_labels = torch.ones(batch_size_actual, 1, device=self.gan.device) * (1 - label_smoothing)
                        output_real = self.gan.discriminator(real_images, scale)
                        loss_real = self.gan.criterion(output_real, real_labels)
                        
                        # Generate fake images
                        noise = torch.randn(batch_size_actual, self.gan.latent_dim, 1, 1, device=self.gan.device)
                        with torch.no_grad():
                            generated_images_all = self.gan.generator(noise)
                            scale_idx = self.gan.scales.index(scale)
                            fake_images = generated_images_all[scale_idx]
                        
                        # Fake images loss with label smoothing
                        fake_labels = torch.zeros(batch_size_actual, 1, device=self.gan.device) + label_smoothing
                        output_fake = self.gan.discriminator(fake_images.detach(), scale)
                        loss_fake = self.gan.criterion(output_fake, fake_labels)
                        
                        loss_d_scale = (loss_real + loss_fake) / 2
                        loss_d_accum += loss_d_scale
                    
                    loss_d = loss_d_accum / len(self.gan.scales)
                    loss_d.backward()
                    self.gan.optimizerD.step()
                    
                    # Train Generator on all scales
                    self.gan.optimizerG.zero_grad()
                    loss_g_accum = 0
                    
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, 1, 1, device=self.gan.device)
                    generated_images_all = self.gan.generator(noise)
                    
                    for scale_idx, scale in enumerate(self.gan.scales):
                        fake_images = generated_images_all[scale_idx]
                        real_labels = torch.ones(batch_size_actual, 1, device=self.gan.device) * (1 - label_smoothing)
                        output_fake = self.gan.discriminator(fake_images, scale)
                        loss_g_scale = self.gan.criterion(output_fake, real_labels)
                        loss_g_accum += loss_g_scale
                    
                    loss_g = loss_g_accum / len(self.gan.scales)
                    loss_g.backward()
                    self.gan.optimizerG.step()
                    
                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"D Loss: {avg_loss_d:.4f} | "
                                   f"G Loss: {avg_loss_g:.4f} | "
                                   f"Time: {epoch_time:.1f}s")
                    
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False

    def generate_training_samples(self):
        """Generate sample images during training"""
        if not self.gan:
            return
        
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated_images_list = self.gan.generator(noise)
                generated_images = [img.cpu().squeeze(0) for img in generated_images_list]
                
                scale_names = ["8x8", "16x16", "32x32"]
                display_sizes = [100, 150, 200]
                
                for scale_name, img_tensor, display_size in zip(scale_names, generated_images, display_sizes):
                    img = self.tensor_to_pil(img_tensor)
                    img_display = img.resize((display_size, display_size), Image.Resampling.NEAREST)
                    photo = ImageTk.PhotoImage(img_display)
                    
                    label = self.scale_labels[scale_name]
                    label.config(image=photo, text="")
                    label.image = photo
                
                self.generated_images.append(self.tensor_to_pil(generated_images[2]))
                
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        if tensor.dim() == 4:
            tensor = tensor.squeeze(0)
        
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        """Generate a single multi-scale sample"""
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated_images_list = self.gan.generator(noise)
                generated_images = [img.cpu().squeeze(0) for img in generated_images_list]
                
                scale_names = ["8x8", "16x16", "32x32"]
                display_sizes = [100, 150, 200]
                
                for scale_name, img_tensor, display_size in zip(scale_names, generated_images, display_sizes):
                    img = self.tensor_to_pil(img_tensor)
                    img_display = img.resize((display_size, display_size), Image.Resampling.NEAREST)
                    photo = ImageTk.PhotoImage(img_display)
                    
                    label = self.scale_labels[scale_name]
                    label.config(image=photo, text="")
                    label.image = photo
                
                self.generated_images.append(self.tensor_to_pil(generated_images[2]))
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def save_model(self):
        """Save current model"""
        if not self.gan:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'discriminator_state_dict': self.gan.discriminator.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                    'use_pixel_shuffle': self.settings['use_pixel_shuffle'].get(),
                    'architecture': 'MultiScaleDCGAN',
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_generator(self):
        """Load generator from file"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                if checkpoint.get('architecture') != 'MultiScaleDCGAN':
                    self.log_message("Warning: This doesn't appear to be a multi-scale model")
                
                if 'image_size' in checkpoint:
                    self.settings['image_size'].set(checkpoint['image_size'])
                if 'latent_dim' in checkpoint:
                    self.settings['latent_dim'].set(checkpoint['latent_dim'])
                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])
                if 'ndf' in checkpoint:
                    self.settings['ndf'].set(checkpoint['ndf'])
                if 'use_pixel_shuffle' in checkpoint:
                    self.settings['use_pixel_shuffle'].set(checkpoint['use_pixel_shuffle'])
                
                self.initialize_gan()
                self.gan.generator.load_state_dict(checkpoint['generator_state_dict'])
                
                if 'discriminator_state_dict' in checkpoint:
                    self.gan.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])
                
                self.log_message(f"Loaded model from {filename}")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        """Generate a grid of images (32x32 only)"""
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            
            with torch.no_grad():
                noise = torch.randn(num_images, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated_all = self.gan.generator(noise)
                generated = generated_all[2].cpu()
            
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            cols = 4
            rows = (num_images + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_tensor = generated[idx]
                        img = self.tensor_to_pil(img_tensor)
                        img_display = img.resize((128, 128), Image.Resampling.NEAREST)
                        photo = ImageTk.PhotoImage(img_display)
                        
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            
            self.log_message(f"Generated {num_images} 32x32 images")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            with open('multiscale_dcgan_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            if os.path.exists('multiscale_dcgan_defaults.json'):
                with open('multiscale_dcgan_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_to_paper(self):
        """Reset to enhanced DCGAN settings"""
        paper_settings = {
            'image_size': 32,
            'latent_dim': 100,
            'ngf': 64,
            'ndf': 64,
            'batch_size': 32,
            'learning_rate': 0.0002,
            'beta1': 0.5,
            'num_workers': min(4, multiprocessing.cpu_count()),
            'save_interval': 10,
            'generate_interval': 5,
            'label_smoothing': 0.1,
            'use_pixel_shuffle': True
        }
        
        for key, value in paper_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        
        self.log_message("Reset to paper settings")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Multi-Scale DCGAN Trainer...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = MultiScaleDCGANApp(root)
    root.mainloop()