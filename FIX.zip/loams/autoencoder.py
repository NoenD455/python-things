import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing

# ==================== Autoencoder Neural Network ====================

class ImageAutoencoder:
    def __init__(self, image_size=64, latent_dim=128):
        self.image_size = image_size
        self.latent_dim = latent_dim
        
        # Set PyTorch to use 2 cores
        torch.set_num_threads(2)
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Encoder: Compresses image to 128x1x1
        class Encoder(nn.Module):
            def __init__(self, image_size, latent_dim):
                super().__init__()
                self.image_size = image_size
                
                if image_size == 64:
                    # For 64x64 images
                    self.main = nn.Sequential(
                        # Input: 3 x 64 x 64
                        nn.Conv2d(3, 64, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(64),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 64 x 32 x 32
                        
                        nn.Conv2d(64, 128, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(128),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 128 x 16 x 16
                        
                        nn.Conv2d(128, 256, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(256),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 256 x 8 x 8
                        
                        nn.Conv2d(256, 512, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(512),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 512 x 4 x 4
                        
                        nn.Conv2d(512, latent_dim, 4, 1, 0, bias=False),
                        nn.Tanh()
                        # latent_dim x 1 x 1
                    )
                else:  # 32x32 images
                    self.main = nn.Sequential(
                        # Input: 3 x 32 x 32
                        nn.Conv2d(3, 64, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(64),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 64 x 16 x 16
                        
                        nn.Conv2d(64, 128, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(128),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 128 x 8 x 8
                        
                        nn.Conv2d(128, 256, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(256),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 256 x 4 x 4
                        
                        nn.Conv2d(256, latent_dim, 4, 1, 0, bias=False),
                        nn.Tanh()
                        # latent_dim x 1 x 1
                    )
            
            def forward(self, x):
                return self.main(x)
        
        # Decoder: Reconstructs image from 128x1x1
        class Decoder(nn.Module):
            def __init__(self, image_size, latent_dim):
                super().__init__()
                self.image_size = image_size
                
                if image_size == 64:
                    # For 64x64 images
                    self.main = nn.Sequential(
                        # Input: latent_dim x 1 x 1
                        nn.ConvTranspose2d(latent_dim, 512, 4, 1, 0, bias=False),
                        nn.BatchNorm2d(512),
                        nn.ReLU(True),
                        # 512 x 4 x 4
                        
                        nn.ConvTranspose2d(512, 256, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(256),
                        nn.ReLU(True),
                        # 256 x 8 x 8
                        
                        nn.ConvTranspose2d(256, 128, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(128),
                        nn.ReLU(True),
                        # 128 x 16 x 16
                        
                        nn.ConvTranspose2d(128, 64, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(64),
                        nn.ReLU(True),
                        # 64 x 32 x 32
                        
                        nn.ConvTranspose2d(64, 3, 4, 2, 1, bias=False),
                        nn.Tanh()
                        # 3 x 64 x 64
                    )
                else:  # 32x32 images
                    self.main = nn.Sequential(
                        # Input: latent_dim x 1 x 1
                        nn.ConvTranspose2d(latent_dim, 256, 4, 1, 0, bias=False),
                        nn.BatchNorm2d(256),
                        nn.ReLU(True),
                        # 256 x 4 x 4
                        
                        nn.ConvTranspose2d(256, 128, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(128),
                        nn.ReLU(True),
                        # 128 x 8 x 8
                        
                        nn.ConvTranspose2d(128, 64, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(64),
                        nn.ReLU(True),
                        # 64 x 16 x 16
                        
                        nn.ConvTranspose2d(64, 3, 4, 2, 1, bias=False),
                        nn.Tanh()
                        # 3 x 32 x 32
                    )
            
            def forward(self, x):
                return self.main(x)
        
        self.encoder = Encoder(image_size, latent_dim)
        self.decoder = Decoder(image_size, latent_dim)
        
        # Loss function (MSE for reconstruction)
        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(
            list(self.encoder.parameters()) + list(self.decoder.parameters()),
            lr=0.0002, betas=(0.5, 0.999)
        )
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.encoder.to(self.device)
        self.decoder.to(self.device)
    
    def encode(self, images):
        """Encode images to latent space"""
        with torch.no_grad():
            return self.encoder(images)
    
    def decode(self, latents):
        """Decode latents back to images"""
        with torch.no_grad():
            return self.decoder(latents)
    
    def reconstruct(self, images):
        """Full encode-decode cycle"""
        with torch.no_grad():
            latents = self.encoder(images)
            return self.decoder(latents)

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=64):
        self.image_paths = image_paths
        self.image_size = image_size
        
        # Only nearest neighbor resizing
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size), Image.NEAREST),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            # Return a black image as fallback
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class AutoencoderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Image Autoencoder - Compress to 128x1x1")
        self.root.geometry("900x700")  # Slightly larger window
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.autoencoder = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Performance tracking
        self.num_workers = 2  # Use 2 worker threads for data loading
        
        # Reference to original image for comparison
        self.original_image = None
        self.original_photo = None
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)
    
    def setup_gui(self):
        # Create main container with padding
        main_container = tk.Frame(self.root, padx=5, pady=5)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Left panel for controls
        left_frame = tk.Frame(main_container, width=280)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        title_label = tk.Label(left_frame, text="Autoencoder Trainer", 
                              font=("Arial", 12, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 10), sticky="w")
        
        # Image size selection
        tk.Label(left_frame, text="Image Size:").grid(row=1, column=0, sticky="w", pady=(0, 5))
        self.size_var = tk.StringVar(value="64")
        size_frame = tk.Frame(left_frame)
        size_frame.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        tk.Radiobutton(size_frame, text="32x32", variable=self.size_var, value="32").pack(side=tk.LEFT, padx=(0, 10))
        tk.Radiobutton(size_frame, text="64x64", variable=self.size_var, value="64").pack(side=tk.LEFT)
        
        # Add images button
        tk.Button(left_frame, text="Add Training Images", 
                 command=self.add_images, height=2).grid(row=3, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Load Test Image", 
                 command=self.load_test_image, height=2).grid(row=4, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Image list with scrollbar
        tk.Label(left_frame, text="Training Images:").grid(row=5, column=0, sticky="w", pady=(10, 5))
        
        # Create frame for listbox and scrollbar
        list_frame = tk.Frame(left_frame)
        list_frame.grid(row=6, column=0, columnspan=2, sticky="nsew", pady=(0, 10))
        
        # Configure grid weights for list_frame
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.grid(row=0, column=0, sticky="nsew")
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.grid(row=0, column=1, sticky="ns")
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Clear button
        tk.Button(left_frame, text="Clear All Images", 
                 command=self.clear_images).grid(row=7, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Training controls
        tk.Label(left_frame, text="Training Controls:").grid(row=8, column=0, sticky="w", pady=(10, 5))
        
        tk.Button(left_frame, text="Initialize Autoencoder", 
                 command=self.initialize_autoencoder, height=2).grid(row=9, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Label(left_frame, text="Epochs:").grid(row=10, column=0, sticky="w")
        self.epoch_var = tk.StringVar(value="50")
        epoch_entry = tk.Entry(left_frame, textvariable=self.epoch_var)
        epoch_entry.grid(row=11, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        tk.Button(left_frame, text="Start Training", 
                 command=self.start_training, height=2, bg="lightgreen").grid(row=12, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Stop Training", 
                 command=self.stop_training, height=2, bg="salmon").grid(row=13, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Test Reconstruction", 
                 command=self.test_reconstruction, height=2).grid(row=14, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Performance info
        perf_frame = tk.LabelFrame(left_frame, text="Autoencoder Info", padx=5, pady=2)
        perf_frame.grid(row=15, column=0, columnspan=2, sticky="ew", pady=(10, 5))
        
        self.perf_label = tk.Label(perf_frame, 
                                  text="Latent dim: 128x1x1\nCompression: 12288:128\nCPU Threads: 2", 
                                  font=("Arial", 9),
                                  justify=tk.LEFT)
        self.perf_label.pack()
        
        # Status
        tk.Label(left_frame, text="Status:").grid(row=16, column=0, sticky="w", pady=(10, 5))
        self.status_label = tk.Label(left_frame, text="Ready", 
                                    relief=tk.SUNKEN, 
                                    height=2,
                                    anchor="w",
                                    padx=5)
        self.status_label.grid(row=17, column=0, columnspan=2, sticky="ew", pady=(0, 5))
        
        # Configure grid weights for left_frame
        left_frame.grid_rowconfigure(6, weight=1)  # Listbox row expands
        left_frame.grid_columnconfigure(0, weight=1)
        left_frame.grid_columnconfigure(1, weight=1)
        
        # Right panel for preview
        right_frame = tk.Frame(main_container)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Image comparison frame
        comparison_frame = tk.Frame(right_frame)
        comparison_frame.pack(pady=10)
        
        # Original image
        orig_frame = tk.LabelFrame(comparison_frame, text="Original Image", padx=5, pady=5)
        orig_frame.grid(row=0, column=0, padx=5)
        
        self.original_label = tk.Label(orig_frame, width=128, height=128, bg="gray")
        self.original_label.pack(padx=5, pady=5)
        
        # Reconstructed image
        recon_frame = tk.LabelFrame(comparison_frame, text="Reconstructed Image", padx=5, pady=5)
        recon_frame.grid(row=0, column=1, padx=5)
        
        self.reconstructed_label = tk.Label(recon_frame, width=128, height=128, bg="gray")
        self.reconstructed_label.pack(padx=5, pady=5)
        
        # Latent space info
        latent_frame = tk.LabelFrame(right_frame, text="Latent Space (128x1x1)", padx=5, pady=5)
        latent_frame.pack(fill=tk.X, padx=10, pady=(10, 5))
        
        self.latent_label = tk.Label(latent_frame, 
                                    text="Latent values will appear here after encoding",
                                    font=("Courier", 8),
                                    justify=tk.LEFT,
                                    wraplength=400)
        self.latent_label.pack()
        
        # Training log with frame
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        # Configure log_frame grid
        log_frame.grid_rowconfigure(0, weight=1)
        log_frame.grid_columnconfigure(0, weight=1)
        
        self.log_text = tk.Text(log_frame, height=12, width=50, font=("Courier", 9))
        self.log_text.grid(row=0, column=0, sticky="nsew")
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.config(yscrollcommand=scrollbar.set)
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
                # Update status with first 40 chars
                status_text = message[:40] + "..." if len(message) > 40 else message
                self.status_label.config(text=status_text)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")
    
    def load_test_image(self):
        file = filedialog.askopenfilename(
            title="Select test image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        if file:
            try:
                image_size = int(self.size_var.get())
                img = Image.open(file).convert('RGB')
                img = img.resize((image_size, image_size), Image.NEAREST)
                
                # Store original PIL image
                self.original_image = img.copy()
                
                # Display original
                display_img = img.resize((128, 128), Image.NEAREST)
                photo = ImageTk.PhotoImage(display_img)
                self.original_label.config(image=photo)
                self.original_label.image = photo
                
                self.log_message(f"Loaded test image: {os.path.basename(file)}")
                
                # Clear reconstructed image
                self.reconstructed_label.config(image='', bg="gray")
                
            except Exception as e:
                self.log_message(f"Error loading test image: {str(e)}")
    
    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")
    
    def initialize_autoencoder(self):
        try:
            image_size = int(self.size_var.get())
            self.autoencoder = ImageAutoencoder(image_size=image_size, latent_dim=128)
            self.log_message(f"Initialized Autoencoder for {image_size}x{image_size} images")
            self.log_message(f"Latent dimension: 128x1x1")
            self.log_message(f"Compression ratio: {image_size*image_size*3}:128 = {image_size*image_size*3/128:.1f}:1")
            
            # Update performance label
            compression_ratio = (image_size * image_size * 3) / 128
            self.perf_label.config(
                text=f"Latent dim: 128x1x1\nCompression: {image_size*image_size*3}:128\nRatio: {compression_ratio:.1f}:1\nCPU Threads: {torch.get_num_threads()}"
            )
        except Exception as e:
            self.log_message(f"Error initializing autoencoder: {str(e)}")
    
    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.autoencoder:
            self.log_message("Error: Autoencoder not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            image_size = int(self.size_var.get())
            
            self.training = True
            self.current_epoch = 0
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_autoencoder,
                args=(epochs, image_size),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Compressing images to 128x1x1 latent space")
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
    
    def train_autoencoder(self, epochs, image_size):
        try:
            # Create dataset and dataloader
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=8, 
                shuffle=True,
                num_workers=self.num_workers,
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss = 0
                batch_count = 0
                
                for i, images in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    images = images.to(self.autoencoder.device)
                    
                    # Forward pass
                    self.autoencoder.optimizer.zero_grad()
                    
                    # Encode to latent space (128x1x1)
                    latents = self.autoencoder.encoder(images)
                    
                    # Decode back to image
                    reconstructions = self.autoencoder.decoder(latents)
                    
                    # Calculate reconstruction loss
                    loss = self.autoencoder.criterion(reconstructions, images)
                    
                    # Backward pass
                    loss.backward()
                    self.autoencoder.optimizer.step()
                    
                    total_loss += loss.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss = total_loss / batch_count
                    self.log_message(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f}")
                    
                    # Show latent space info every 5 epochs
                    if (epoch + 1) % 5 == 0 and batch_count > 0:
                        with torch.no_grad():
                            # Get sample latent vector
                            sample_latent = latents[0].cpu().numpy().flatten()
                            latent_info = f"Latent stats - Min: {sample_latent.min():.3f}, Max: {sample_latent.max():.3f}, Mean: {sample_latent.mean():.3f}"
                            self.log_message(latent_info)
                
                # Test reconstruction every 10 epochs
                if (epoch + 1) % 10 == 0 and self.original_image is not None:
                    self.test_reconstruction_internal()
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")
    
    def test_reconstruction_internal(self):
        if not self.autoencoder or self.original_image is None:
            return
        
        try:
            image_size = int(self.size_var.get())
            
            # Prepare test image
            test_image = self.original_image.resize((image_size, image_size), Image.NEAREST)
            
            # Convert to tensor
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            img_tensor = transform(test_image).unsqueeze(0).to(self.autoencoder.device)
            
            with torch.no_grad():
                # Encode to latent space
                latent = self.autoencoder.encoder(img_tensor)
                
                # Show latent space values
                latent_values = latent[0].cpu().numpy().flatten()
                latent_text = f"Latent[0:10]: {latent_values[:10].round(3)}..."
                self.latent_label.config(text=latent_text)
                
                # Decode back
                reconstructed = self.autoencoder.decoder(latent)
                
                # Convert to PIL Image
                recon_img = reconstructed[0].cpu()
                recon_img = (recon_img + 1) / 2  # Denormalize
                recon_img = transforms.ToPILImage()(recon_img)
                
                # Resize for display
                display_recon = recon_img.resize((128, 128), Image.NEAREST)
                
                # Display reconstructed
                recon_photo = ImageTk.PhotoImage(display_recon)
                self.reconstructed_label.config(image=recon_photo)
                self.reconstructed_label.image = recon_photo
                
                # Calculate and show PSNR
                mse = np.mean((np.array(test_image).astype(float) - np.array(recon_img.resize((image_size, image_size), Image.NEAREST)).astype(float))**2)
                if mse > 0:
                    psnr = 20 * np.log10(255.0 / np.sqrt(mse))
                    self.log_message(f"Reconstruction PSNR: {psnr:.2f} dB")
                else:
                    self.log_message("Perfect reconstruction!")
                
                return recon_img
        except Exception as e:
            self.log_message(f"Reconstruction error: {str(e)}")
    
    def test_reconstruction(self):
        if not self.autoencoder:
            self.log_message("Error: Autoencoder not initialized!")
            return
        
        if self.original_image is None:
            self.log_message("Error: No test image loaded!")
            return
        
        recon_img = self.test_reconstruction_internal()
        if recon_img:
            self.log_message("Tested reconstruction on loaded image")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Image Autoencoder Trainer")
    print("Compresses images to 128x1x1 latent representation")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    
    # Set multiprocessing start method for compatibility
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = AutoencoderApp(root)
    root.mainloop()