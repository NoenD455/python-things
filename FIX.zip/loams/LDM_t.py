import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import math
import traceback

# ==================== LDM Components ====================

class VAEEncoder(nn.Module):
    """Encoder to compress images to latent space"""
    def __init__(self, in_channels=3, latent_channels=4, nf=64):
        super().__init__()
        
        self.encoder = nn.Sequential(
            # Input: 32x32x3
            nn.Conv2d(in_channels, nf, 3, 1, 1),  # 32x32
            nn.BatchNorm2d(nf),
            nn.ReLU(),
            nn.Conv2d(nf, nf, 3, 1, 1),
            nn.BatchNorm2d(nf),
            nn.ReLU(),
            
            nn.Conv2d(nf, nf*2, 3, 2, 1),  # 16x16
            nn.BatchNorm2d(nf*2),
            nn.ReLU(),
            nn.Conv2d(nf*2, nf*2, 3, 1, 1),
            nn.BatchNorm2d(nf*2),
            nn.ReLU(),
            
            nn.Conv2d(nf*2, nf*4, 3, 2, 1),  # 8x8
            nn.BatchNorm2d(nf*4),
            nn.ReLU(),
            nn.Conv2d(nf*4, nf*4, 3, 1, 1),
            nn.BatchNorm2d(nf*4),
            nn.ReLU(),
            
            nn.Conv2d(nf*4, latent_channels, 3, 1, 1),  # 8x8
            nn.Tanh()  # Output in [-1, 1]
        )
        
    def forward(self, x):
        return self.encoder(x)

class VAEDecoder(nn.Module):
    """Decoder to reconstruct images from latent space"""
    def __init__(self, latent_channels=4, out_channels=3, nf=64):
        super().__init__()
        
        self.decoder = nn.Sequential(
            # Input: 8x8xlatent_channels
            nn.Conv2d(latent_channels, nf*4, 3, 1, 1),  # 8x8
            nn.BatchNorm2d(nf*4),
            nn.ReLU(),
            nn.Conv2d(nf*4, nf*4, 3, 1, 1),
            nn.BatchNorm2d(nf*4),
            nn.ReLU(),
            
            nn.ConvTranspose2d(nf*4, nf*2, 4, 2, 1),  # 16x16
            nn.BatchNorm2d(nf*2),
            nn.ReLU(),
            nn.Conv2d(nf*2, nf*2, 3, 1, 1),
            nn.BatchNorm2d(nf*2),
            nn.ReLU(),
            
            nn.ConvTranspose2d(nf*2, nf, 4, 2, 1),  # 32x32
            nn.BatchNorm2d(nf),
            nn.ReLU(),
            nn.Conv2d(nf, nf, 3, 1, 1),
            nn.BatchNorm2d(nf),
            nn.ReLU(),
            
            nn.Conv2d(nf, out_channels, 3, 1, 1),  # 32x32
            nn.Tanh()
        )
        
    def forward(self, z):
        return self.decoder(z)

class LDMUNet(nn.Module):
    """UNet for Latent Diffusion (operates on 8x8 latent space)"""
    def __init__(self, latent_channels=4, nf=64, timesteps=100):
        super().__init__()
        self.timesteps = timesteps
        
        # Timestep embedding
        self.time_embed = nn.Sequential(
            nn.Linear(1, nf * 4),
            nn.ReLU(),
            nn.Linear(nf * 4, nf * 4)
        )
        
        # Encoder (latent space is 8x8)
        self.enc1 = nn.Sequential(
            nn.Conv2d(latent_channels, nf, 3, 1, 1),
            nn.BatchNorm2d(nf),
            nn.ReLU(),
            nn.Conv2d(nf, nf, 3, 1, 1),
            nn.BatchNorm2d(nf),
            nn.ReLU()
        )
        
        self.pool1 = nn.MaxPool2d(2)  # 4x4
        
        # Bottleneck
        self.bottleneck = nn.Sequential(
            nn.Conv2d(nf, nf*2, 3, 1, 1),
            nn.BatchNorm2d(nf*2),
            nn.ReLU(),
            nn.Conv2d(nf*2, nf*2, 3, 1, 1),
            nn.BatchNorm2d(nf*2),
            nn.ReLU(),
            nn.Conv2d(nf*2, nf*2, 3, 1, 1),
            nn.BatchNorm2d(nf*2),
            nn.ReLU()
        )
        
        # Decoder
        self.up1 = nn.ConvTranspose2d(nf*2, nf, 2, 2)  # 8x8
        
        self.dec1 = nn.Sequential(
            nn.Conv2d(nf*2, nf, 3, 1, 1),
            nn.BatchNorm2d(nf),
            nn.ReLU(),
            nn.Conv2d(nf, nf, 3, 1, 1),
            nn.BatchNorm2d(nf),
            nn.ReLU(),
            nn.Conv2d(nf, latent_channels, 3, 1, 1)
        )
        
        # Time projection layers
        self.time_proj_enc1 = nn.Conv2d(nf*4, nf, 1, 1, 0)
        self.time_proj_bottleneck = nn.Conv2d(nf*4, nf*2, 1, 1, 0)
        
    def forward(self, x, t):
        # Normalize timestep to [0, 1]
        t_norm = t.float() / self.timesteps
        t_norm = t_norm.view(-1, 1)
        
        # Time embedding
        time_feat = self.time_embed(t_norm)
        time_feat = time_feat.view(-1, time_feat.size(1), 1, 1)
        
        # Encoder
        enc1_out = self.enc1(x)
        
        # Add time conditioning to encoder
        time_proj_enc1 = self.time_proj_enc1(time_feat)
        _, _, h1, w1 = enc1_out.shape
        time_proj_enc1 = nn.functional.interpolate(
            time_proj_enc1, size=(h1, w1), mode='nearest'
        )
        enc1_out = enc1_out + time_proj_enc1
        
        # Downsample
        pool1_out = self.pool1(enc1_out)
        
        # Bottleneck with time conditioning
        bottleneck_out = self.bottleneck(pool1_out)
        
        time_proj_bottleneck = self.time_proj_bottleneck(time_feat)
        _, _, hb, wb = bottleneck_out.shape
        time_proj_bottleneck = nn.functional.interpolate(
            time_proj_bottleneck, size=(hb, wb), mode='nearest'
        )
        bottleneck_out = bottleneck_out + time_proj_bottleneck
        
        # Decoder with skip connection
        up1_out = self.up1(bottleneck_out)
        
        # Ensure spatial dimensions match for concatenation
        if up1_out.shape[2:] != enc1_out.shape[2:]:
            up1_out = nn.functional.interpolate(
                up1_out, size=enc1_out.shape[2:], mode='nearest'
            )
        
        dec1_in = torch.cat([up1_out, enc1_out], dim=1)
        output = self.dec1(dec1_in)
        
        return output

# ==================== LDM Model ====================

class SimpleLDM:
    def __init__(self, image_size=32, latent_channels=4, nf=64, timesteps=100):
        self.image_size = image_size
        self.latent_channels = latent_channels
        self.latent_size = 8  # 32 / 4 (due to 2x downsampling twice)
        self.timesteps = timesteps
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Pre-compute noise schedule
        self.betas = torch.linspace(1e-4, 0.02, timesteps)
        self.alphas = 1. - self.betas
        self.alpha_cumprod = torch.cumprod(self.alphas, dim=0)
        self.sqrt_alpha_cumprod = torch.sqrt(self.alpha_cumprod)
        self.sqrt_one_minus_alpha_cumprod = torch.sqrt(1. - self.alpha_cumprod)
        
        # Compute reverse process parameters
        self.sqrt_recip_alphas = torch.sqrt(1.0 / self.alphas)
        self.alphas_cumprod_prev = torch.cat([torch.tensor([1.0]), self.alpha_cumprod[:-1]])
        
        # Calculate posterior variance
        self.posterior_variance = self.betas * (1. - self.alphas_cumprod_prev) / (1. - self.alpha_cumprod)
        
        # VAE components
        self.encoder = VAEEncoder(latent_channels=latent_channels, nf=nf)
        self.decoder = VAEDecoder(latent_channels=latent_channels, nf=nf)
        
        # UNet for latent diffusion
        self.unet = LDMUNet(latent_channels=latent_channels, nf=nf, timesteps=timesteps)
        
        # Losses
        self.recon_criterion = nn.MSELoss()
        self.diffusion_criterion = nn.MSELoss()
        
        # Optimizers
        self.vae_optimizer = optim.Adam(
            list(self.encoder.parameters()) + list(self.decoder.parameters()),
            lr=0.0001, betas=(0.5, 0.999)
        )
        self.diffusion_optimizer = optim.Adam(
            self.unet.parameters(),
            lr=0.0001, betas=(0.5, 0.999)
        )
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Move models to device
        self.encoder.to(self.device)
        self.decoder.to(self.device)
        self.unet.to(self.device)
        
        # Move schedules to device
        self.betas = self.betas.to(self.device)
        self.alphas = self.alphas.to(self.device)
        self.alpha_cumprod = self.alpha_cumprod.to(self.device)
        self.sqrt_alpha_cumprod = self.sqrt_alpha_cumprod.to(self.device)
        self.sqrt_one_minus_alpha_cumprod = self.sqrt_one_minus_alpha_cumprod.to(self.device)
        self.sqrt_recip_alphas = self.sqrt_recip_alphas.to(self.device)
        self.alphas_cumprod_prev = self.alphas_cumprod_prev.to(self.device)
        self.posterior_variance = self.posterior_variance.to(self.device)
    
    def encode(self, x):
        """Encode images to latent space"""
        return self.encoder(x)
    
    def decode(self, z):
        """Decode latent codes to images"""
        return self.decoder(z)
    
    def add_latent_noise(self, z, t):
        """Add noise to latents at timestep t"""
        noise = torch.randn_like(z)
        sqrt_alpha_cumprod_t = self.sqrt_alpha_cumprod[t]
        sqrt_one_minus_alpha_cumprod_t = self.sqrt_one_minus_alpha_cumprod[t]
        
        sqrt_alpha_cumprod_t = sqrt_alpha_cumprod_t.view(-1, 1, 1, 1)
        sqrt_one_minus_alpha_cumprod_t = sqrt_one_minus_alpha_cumprod_t.view(-1, 1, 1, 1)
        
        noisy_z = sqrt_alpha_cumprod_t * z + sqrt_one_minus_alpha_cumprod_t * noise
        return noisy_z, noise
    
    def predict_latent_noise(self, z, t):
        """Predict the noise in the noisy latent"""
        if t.dim() == 0:
            t = t.unsqueeze(0)
        
        predicted_noise = self.unet(z, t)
        return predicted_noise
    
    def train_vae_step(self, images):
        """Train VAE to compress and reconstruct images"""
        self.vae_optimizer.zero_grad()
        
        # Encode to latent
        latents = self.encode(images)
        
        # Decode back to images
        reconstructions = self.decode(latents)
        
        # Reconstruction loss
        recon_loss = self.recon_criterion(reconstructions, images)
        
        # KL loss (simplified, using L2 regularization on latents)
        kl_loss = torch.mean(latents ** 2) * 0.001
        
        total_loss = recon_loss + kl_loss
        total_loss.backward()
        self.vae_optimizer.step()
        
        return recon_loss.item(), kl_loss.item()
    
    def train_diffusion_step(self, latents):
        """Train diffusion model in latent space"""
        self.diffusion_optimizer.zero_grad()
        
        batch_size = latents.size(0)
        
        # Sample random timesteps
        t = torch.randint(0, self.timesteps, (batch_size,), device=self.device)
        
        # Add noise to latents
        noisy_latents, noise = self.add_latent_noise(latents, t)
        
        # Predict noise in latent space
        predicted_noise = self.predict_latent_noise(noisy_latents, t)
        
        # Diffusion loss
        diffusion_loss = self.diffusion_criterion(predicted_noise, noise)
        
        diffusion_loss.backward()
        self.diffusion_optimizer.step()
        
        return diffusion_loss.item()

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class LDMApp:
    def __init__(self, root):
        self.root = root
        self.root.title("LDM Trainer - Multi-Core (Latent Diffusion)")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.training_vae = False
        self.training_diffusion = False
        self.ldm = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_channels': tk.IntVar(value=4),
            'nf': tk.IntVar(value=64),
            'timesteps': tk.IntVar(value=100),
            'batch_size': tk.IntVar(value=4),
            'vae_lr': tk.DoubleVar(value=0.0001),
            'diffusion_lr': tk.DoubleVar(value=0.0001),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(2, multiprocessing.cpu_count())),
            'vae_epochs': tk.IntVar(value=50),
            'generate_interval': tk.IntVar(value=5)
        }
        
        # Sampling settings
        self.sampling_settings = {
            'sampling_steps': tk.IntVar(value=100),
            'sampling_noise': tk.DoubleVar(value=0.05)
        }
        
        # For storing generated images
        self.generated_images = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="LDM Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text="Image Size: 32x32, Latent: 8x8")
        self.size_display.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # VAE Training
        vae_frame = tk.LabelFrame(left_frame, text="VAE Training", padx=10, pady=10)
        vae_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(vae_frame, text="Initialize LDM", 
                 command=self.initialize_ldm, width=20).pack(pady=5)
        
        tk.Label(vae_frame, text="VAE Epochs:").pack(pady=2)
        self.vae_epoch_entry = tk.Entry(vae_frame, width=10)
        self.vae_epoch_entry.insert(0, "50")
        self.vae_epoch_entry.pack(pady=2)
        
        tk.Button(vae_frame, text="Train VAE", 
                 command=self.start_vae_training,
                 width=20, bg="lightblue").pack(pady=5)
        
        # Diffusion Training
        diff_frame = tk.LabelFrame(left_frame, text="Diffusion Training", padx=10, pady=10)
        diff_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(diff_frame, text="Diffusion Epochs:").pack(pady=2)
        self.diff_epoch_entry = tk.Entry(diff_frame, width=10)
        self.diff_epoch_entry.insert(0, "100")
        self.diff_epoch_entry.pack(pady=2)
        
        tk.Button(diff_frame, text="Train Diffusion", 
                 command=self.start_diffusion_training,
                 width=20, bg="lightgreen").pack(pady=5)
        
        tk.Button(diff_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="LDM Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="LDM Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Fixed settings display first
        fixed_settings = [
            ("Image Size:", "32x32"),
            ("Latent Size:", "8x8"),
        ]
        
        for label_text, value_text in fixed_settings:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Label(frame, text=value_text, width=20, anchor='w').pack(side=tk.LEFT, padx=5)
        
        # Adjustable settings
        settings_list = [
            ("Latent Channels:", 'latent_channels', 2, 16),
            ("Network Features:", 'nf', 32, 256),
            ("Timesteps:", 'timesteps', 10, 1000),
            ("Batch Size:", 'batch_size', 1, 32),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("VAE Learning Rate:", 'vae_lr', 0.00001, 0.01),
            ("Diffusion LR:", 'diffusion_lr', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(4, multiprocessing.cpu_count())),
            ("VAE Epochs:", 'vae_epochs', 10, 200),
            ("Generate Interval:", 'generate_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['vae_lr', 'diffusion_lr', 'beta1']:
                resolution = 0.00001 if 'lr' in var_name else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Sampling settings
        sampling_frame = tk.LabelFrame(scrollable_frame, text="Sampling Parameters", padx=10, pady=10)
        sampling_frame.pack(fill=tk.X, pady=(0, 10))
        
        sampling_settings = [
            ("Sampling Steps:", 'sampling_steps', 10, 1000),
            ("Sampling Noise:", 'sampling_noise', 0.0, 0.9),
        ]
        
        for label_text, var_name, min_val, max_val in sampling_settings:
            frame = tk.Frame(sampling_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.sampling_settings[var_name],
                    orient=tk.HORIZONTAL, length=200, resolution=0.01 if var_name == 'sampling_noise' else 1).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.sampling_settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load LDM", 
                 command=self.load_ldm, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=4)
        tk.Scale(gen_frame, from_=1, to=16, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def log_message(self, message):
        self.message_queue.put(message)

    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_ldm(self):
        try:
            image_size = self.settings['image_size'].get()
            latent_channels = self.settings['latent_channels'].get()
            nf = self.settings['nf'].get()
            timesteps = self.settings['timesteps'].get()
            
            self.ldm = SimpleLDM(
                image_size=image_size,
                latent_channels=latent_channels,
                nf=nf,
                timesteps=timesteps
            )
            
            self.log_message(f"Initialized LDM for {image_size}x{image_size} images")
            self.log_message(f"Latent space: 8x8x{latent_channels}, Features: {nf}, Timesteps: {timesteps}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing LDM: {str(e)}")
            self.log_message(f"Traceback: {traceback.format_exc()}")

    def start_vae_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.ldm:
            self.log_message("Error: LDM not initialized!")
            return
        
        if self.training_vae:
            self.log_message("VAE training already in progress!")
            return
        
        try:
            epochs = int(self.vae_epoch_entry.get())
            self.training_vae = True
            self.training = True
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['vae_lr'].get()
            beta1 = self.settings['beta1'].get()
            
            # Update VAE optimizer
            for param_group in self.ldm.vae_optimizer.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_vae,
                args=(epochs, batch_size, num_workers),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started VAE training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting VAE training: {str(e)}")

    def train_vae(self, epochs, batch_size, num_workers):
        try:
            image_size = self.settings['image_size'].get()
            
            # Create dataset and dataloader
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available()
            )
            
            for epoch in range(epochs):
                if not self.training_vae:
                    break
                
                total_recon_loss = 0
                total_kl_loss = 0
                batch_count = 0
                epoch_start = time.time()
                
                for images in dataloader:
                    if not self.training_vae:
                        break
                    
                    images = images.to(self.ldm.device)
                    
                    # Train VAE
                    recon_loss, kl_loss = self.ldm.train_vae_step(images)
                    
                    total_recon_loss += recon_loss
                    total_kl_loss += kl_loss
                    batch_count += 1
                
                if batch_count > 0:
                    avg_recon = total_recon_loss / batch_count
                    avg_kl = total_kl_loss / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    self.log_message(f"VAE Epoch {epoch+1}/{epochs} | "
                                   f"Recon: {avg_recon:.6f} | "
                                   f"KL: {avg_kl:.6f} | "
                                   f"Time: {epoch_time:.1f}s")
                    
                    if (epoch + 1) % 10 == 0:
                        # Test reconstruction
                        self.test_vae_reconstruction()
                else:
                    self.log_message(f"VAE Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training_vae = False
            if not self.training_diffusion:
                self.training = False
            self.log_message("VAE training completed!")
            
        except Exception as e:
            self.log_message(f"VAE training error: {str(e)}")
            self.log_message(f"Traceback: {traceback.format_exc()}")
            self.training_vae = False
            if not self.training_diffusion:
                self.training = False

    def test_vae_reconstruction(self):
        """Test VAE reconstruction on a sample image"""
        if not self.ldm or not self.image_paths:
            return
        
        try:
            # Load a sample image
            img_path = self.image_paths[0]
            img = Image.open(img_path).convert('RGB')
            transform = transforms.Compose([
                transforms.Resize((32, 32)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            img_tensor = transform(img).unsqueeze(0).to(self.ldm.device)
            
            with torch.no_grad():
                # Encode and decode
                latent = self.ldm.encode(img_tensor)
                reconstruction = self.ldm.decode(latent)
                
                # Convert to display
                recon_img = self.tensor_to_pil(reconstruction[0].cpu())
                recon_display = recon_img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(recon_display)
                
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
            
            self.log_message(f"VAE reconstruction test complete")
            
        except Exception as e:
            self.log_message(f"Error testing VAE: {str(e)}")

    def start_diffusion_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.ldm:
            self.log_message("Error: LDM not initialized!")
            return
        
        if self.training_diffusion:
            self.log_message("Diffusion training already in progress!")
            return
        
        try:
            epochs = int(self.diff_epoch_entry.get())
            self.training_diffusion = True
            self.training = True
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['diffusion_lr'].get()
            beta1 = self.settings['beta1'].get()
            generate_interval = self.settings['generate_interval'].get()
            
            # Update diffusion optimizer
            for param_group in self.ldm.diffusion_optimizer.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_diffusion,
                args=(epochs, batch_size, num_workers, generate_interval),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started diffusion training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting diffusion training: {str(e)}")

    def train_diffusion(self, epochs, batch_size, num_workers, generate_interval):
        try:
            image_size = self.settings['image_size'].get()
            
            # Create dataset and dataloader
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available()
            )
            
            for epoch in range(epochs):
                if not self.training_diffusion:
                    break
                
                self.current_epoch = epoch
                total_loss = 0
                batch_count = 0
                epoch_start = time.time()
                
                for images in dataloader:
                    if not self.training_diffusion:
                        break
                    
                    images = images.to(self.ldm.device)
                    
                    # Encode images to latent space
                    with torch.no_grad():
                        latents = self.ldm.encode(images)
                    
                    # Train diffusion model in latent space
                    loss = self.ldm.train_diffusion_step(latents)
                    
                    total_loss += loss
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss = total_loss / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    self.log_message(f"Diffusion Epoch {epoch+1}/{epochs} | "
                                   f"Loss: {avg_loss:.6f} | "
                                   f"Time: {epoch_time:.1f}s")
                    
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Diffusion Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training_diffusion = False
            if not self.training_vae:
                self.training = False
            self.log_message("Diffusion training completed!")
            
        except Exception as e:
            self.log_message(f"Diffusion training error: {str(e)}")
            self.log_message(f"Traceback: {traceback.format_exc()}")
            self.training_diffusion = False
            if not self.training_vae:
                self.training = False

    def generate_training_samples(self):
        """Generate samples during training"""
        if not self.ldm:
            return
        
        try:
            with torch.no_grad():
                # Use fewer steps during training for speed
                steps = min(30, self.ldm.timesteps)
                sampling_timesteps = torch.linspace(0, self.ldm.timesteps-1, steps, dtype=torch.long).flip(0)
                
                # Start from pure noise in latent space
                latent_shape = (1, self.ldm.latent_channels, self.ldm.latent_size, self.ldm.latent_size)
                z = torch.randn(latent_shape).to(self.ldm.device)
                
                # Reverse diffusion process in latent space
                for t in sampling_timesteps:
                    t_tensor = torch.full((1,), t, device=self.ldm.device, dtype=torch.long)
                    
                    # Predict noise in latent
                    predicted_noise = self.ldm.predict_latent_noise(z, t_tensor)
                    
                    # Get the parameters for this timestep
                    alpha_t = self.ldm.alphas[t]
                    sqrt_recip_alpha_t = self.ldm.sqrt_recip_alphas[t]
                    beta_t = self.ldm.betas[t]
                    sqrt_one_minus_alpha_cumprod_t = self.ldm.sqrt_one_minus_alpha_cumprod[t]
                    
                    # Predict latent x0
                    predicted_z0 = (z - sqrt_one_minus_alpha_cumprod_t * predicted_noise) / self.ldm.sqrt_alpha_cumprod[t]
                    
                    if t > 0:
                        # Get posterior variance
                        posterior_variance_t = self.ldm.posterior_variance[t]
                        
                        # Sample from the posterior
                        noise = torch.randn_like(z)
                        z = sqrt_recip_alpha_t * (z - beta_t / sqrt_one_minus_alpha_cumprod_t * predicted_noise) + \
                            torch.sqrt(posterior_variance_t) * noise
                    else:
                        z = predicted_z0
                
                # Decode to image space
                img_tensor = self.ldm.decode(z)
                img = self.tensor_to_pil(img_tensor[0].cpu())
                
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
                
                self.log_message(f"Generated training sample at epoch {self.current_epoch + 1} (using {steps} steps)")
                
        except Exception as e:
            self.log_message(f"Error generating training samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        if self.training_vae:
            self.training_vae = False
            self.log_message("VAE training stopped by user")
        
        if self.training_diffusion:
            self.training_diffusion = False
            self.log_message("Diffusion training stopped by user")
        
        self.training = False

    def generate_sample(self):
        if not self.ldm:
            self.log_message("Error: LDM not initialized!")
            return
        
        try:
            with torch.no_grad():
                # Get sampling settings
                requested_steps = self.sampling_settings['sampling_steps'].get()
                sampling_noise = self.sampling_settings['sampling_noise'].get()
                
                # Clamp steps to model's timesteps
                steps = min(requested_steps, self.ldm.timesteps)
                
                self.log_message(f"Generating sample with {steps} steps (requested: {requested_steps})...")
                
                sampling_timesteps = torch.linspace(0, self.ldm.timesteps-1, steps, dtype=torch.long).flip(0)
                
                # Start from pure noise in latent space
                latent_shape = (1, self.ldm.latent_channels, self.ldm.latent_size, self.ldm.latent_size)
                z = torch.randn(latent_shape).to(self.ldm.device)
                
                # Reverse diffusion process in latent space
                for t in sampling_timesteps:
                    t_tensor = torch.full((1,), t, device=self.ldm.device, dtype=torch.long)
                    
                    # Predict noise in latent
                    predicted_noise = self.ldm.predict_latent_noise(z, t_tensor)
                    
                    # Get the parameters for this timestep
                    alpha_t = self.ldm.alphas[t]
                    sqrt_recip_alpha_t = self.ldm.sqrt_recip_alphas[t]
                    beta_t = self.ldm.betas[t]
                    sqrt_one_minus_alpha_cumprod_t = self.ldm.sqrt_one_minus_alpha_cumprod[t]
                    
                    # Predict latent x0
                    predicted_z0 = (z - sqrt_one_minus_alpha_cumprod_t * predicted_noise) / self.ldm.sqrt_alpha_cumprod[t]
                    
                    if t > 0:
                        # Get posterior variance
                        posterior_variance_t = self.ldm.posterior_variance[t]
                        
                        # Sample from the posterior
                        noise = torch.randn_like(z)
                        z = sqrt_recip_alpha_t * (z - beta_t / sqrt_one_minus_alpha_cumprod_t * predicted_noise) + \
                            torch.sqrt(posterior_variance_t) * noise * sampling_noise
                    else:
                        z = predicted_z0
                
                # Decode to image space
                img_tensor = self.ldm.decode(z)
                img = self.tensor_to_pil(img_tensor[0].cpu())
                
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
                
                self.log_message(f"Generated sample with {steps} steps")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")
            self.log_message(f"Traceback: {traceback.format_exc()}")

    def save_model(self):
        if not self.ldm:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'encoder_state_dict': self.ldm.encoder.state_dict(),
                    'decoder_state_dict': self.ldm.decoder.state_dict(),
                    'unet_state_dict': self.ldm.unet.state_dict(),
                    'vae_optimizer_state_dict': self.ldm.vae_optimizer.state_dict(),
                    'diffusion_optimizer_state_dict': self.ldm.diffusion_optimizer.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_channels': self.settings['latent_channels'].get(),
                    'nf': self.settings['nf'].get(),
                    'timesteps': self.settings['timesteps'].get(),
                    'betas': self.ldm.betas.cpu(),
                    'alphas': self.ldm.alphas.cpu(),
                    'alpha_cumprod': self.ldm.alpha_cumprod.cpu(),
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_ldm(self):
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                if 'image_size' in checkpoint:
                    self.settings['image_size'].set(checkpoint['image_size'])
                
                if 'latent_channels' in checkpoint:
                    self.settings['latent_channels'].set(checkpoint['latent_channels'])
                
                if 'nf' in checkpoint:
                    self.settings['nf'].set(checkpoint['nf'])
                
                if 'timesteps' in checkpoint:
                    self.settings['timesteps'].set(checkpoint['timesteps'])
                
                # Initialize LDM with loaded settings
                self.initialize_ldm()
                
                # Load state dicts
                self.ldm.encoder.load_state_dict(checkpoint['encoder_state_dict'])
                self.ldm.decoder.load_state_dict(checkpoint['decoder_state_dict'])
                self.ldm.unet.load_state_dict(checkpoint['unet_state_dict'])
                
                if 'vae_optimizer_state_dict' in checkpoint:
                    self.ldm.vae_optimizer.load_state_dict(checkpoint['vae_optimizer_state_dict'])
                
                if 'diffusion_optimizer_state_dict' in checkpoint:
                    self.ldm.diffusion_optimizer.load_state_dict(checkpoint['diffusion_optimizer_state_dict'])
                
                # Load noise schedules
                if 'betas' in checkpoint:
                    self.ldm.betas = checkpoint['betas'].to(self.ldm.device)
                    self.ldm.alphas = checkpoint['alphas'].to(self.ldm.device)
                    self.ldm.alpha_cumprod = checkpoint['alpha_cumprod'].to(self.ldm.device)
                    self.ldm.sqrt_alpha_cumprod = torch.sqrt(self.ldm.alpha_cumprod)
                    self.ldm.sqrt_one_minus_alpha_cumprod = torch.sqrt(1. - self.ldm.alpha_cumprod)
                    self.ldm.sqrt_recip_alphas = torch.sqrt(1.0 / self.ldm.alphas)
                    self.ldm.alphas_cumprod_prev = torch.cat([
                        torch.tensor([1.0], device=self.ldm.device), 
                        self.ldm.alpha_cumprod[:-1]
                    ])
                    self.ldm.posterior_variance = self.ldm.betas * (1. - self.ldm.alphas_cumprod_prev) / (1. - self.ldm.alpha_cumprod)
                
                self.log_message(f"Loaded LDM from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        if not self.ldm:
            self.log_message("Error: LDM not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            requested_steps = self.sampling_settings['sampling_steps'].get()
            sampling_noise = self.sampling_settings['sampling_noise'].get()
            
            # Clamp steps to model's timesteps
            steps = min(requested_steps, self.ldm.timesteps)
            
            self.log_message(f"Generating {num_images} images with {steps} steps each (requested: {requested_steps})...")
            start_time = time.time()
            
            with torch.no_grad():
                all_images = []
                latent_shape = (1, self.ldm.latent_channels, self.ldm.latent_size, self.ldm.latent_size)
                
                for img_idx in range(num_images):
                    # Start from pure noise in latent space
                    z = torch.randn(latent_shape).to(self.ldm.device)
                    
                    sampling_timesteps = torch.linspace(0, self.ldm.timesteps-1, steps, dtype=torch.long).flip(0)
                    
                    # Reverse diffusion process in latent space
                    for t in sampling_timesteps:
                        t_tensor = torch.full((1,), t, device=self.ldm.device, dtype=torch.long)
                        
                        # Predict noise in latent
                        predicted_noise = self.ldm.predict_latent_noise(z, t_tensor)
                        
                        # Get the parameters for this timestep
                        alpha_t = self.ldm.alphas[t]
                        sqrt_recip_alpha_t = self.ldm.sqrt_recip_alphas[t]
                        beta_t = self.ldm.betas[t]
                        sqrt_one_minus_alpha_cumprod_t = self.ldm.sqrt_one_minus_alpha_cumprod[t]
                        
                        # Predict latent x0
                        predicted_z0 = (z - sqrt_one_minus_alpha_cumprod_t * predicted_noise) / self.ldm.sqrt_alpha_cumprod[t]
                        
                        if t > 0:
                            # Get posterior variance
                            posterior_variance_t = self.ldm.posterior_variance[t]
                            
                            # Sample from the posterior
                            noise = torch.randn_like(z)
                            z = sqrt_recip_alpha_t * (z - beta_t / sqrt_one_minus_alpha_cumprod_t * predicted_noise) + \
                                torch.sqrt(posterior_variance_t) * noise * sampling_noise
                        else:
                            z = predicted_z0
                    
                    # Decode to image space
                    img_tensor = self.ldm.decode(z)
                    all_images.append(img_tensor[0].cpu())
                
                # Clear previous images
                for widget in self.gen_scroll_frame.winfo_children():
                    widget.destroy()
                
                # Create grid
                cols = 2 if num_images <= 4 else 4
                rows = (num_images + cols - 1) // cols
                
                for i in range(rows):
                    row_frame = tk.Frame(self.gen_scroll_frame)
                    row_frame.pack(pady=5)
                    
                    for j in range(cols):
                        idx = i * cols + j
                        if idx < num_images:
                            img_tensor = all_images[idx]
                            img = self.tensor_to_pil(img_tensor)
                            img_display = img.resize((128, 128), Image.Resampling.NEAREST)
                            photo = ImageTk.PhotoImage(img_display)
                            
                            label = tk.Label(row_frame, image=photo)
                            label.image = photo
                            label.pack(side=tk.LEFT, padx=5)
            
            generation_time = time.time() - start_time
            self.log_message(f"Generated {num_images} images in {generation_time:.1f}s ({steps} steps each)")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")
            self.log_message(f"Traceback: {traceback.format_exc()}")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting LDM Trainer (Latent Diffusion Model)...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = LDMApp(root)
    root.mainloop()