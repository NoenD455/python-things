import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
from pathlib import Path

# ==================== Helper for transparency ====================

def load_image_as_rgb_with_black_bg(path):
    """
    Load an image from the given path.
    If the image has transparency (RGBA or palette with transparency),
    composite it onto a black background.
    Returns a PIL Image in RGB mode.
    """
    img = Image.open(path)

    # Convert palette images with transparency to RGBA first
    if img.mode == 'P' and 'transparency' in img.info:
        img = img.convert('RGBA')

    if img.mode == 'RGBA':
        # Create a black background image
        bg = Image.new('RGB', img.size, (0, 0, 0))
        # Use alpha channel as mask to paste the image onto the black background
        bg.paste(img, mask=img.split()[3])  # alpha channel
        return bg
    else:
        return img.convert('RGB')

# ==================== Neural Network (SRGAN) ====================

class ResidualBlock(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, 3, 1, 1),
            nn.BatchNorm2d(in_channels),
            nn.PReLU(),
            nn.Conv2d(in_channels, in_channels, 3, 1, 1),
            nn.BatchNorm2d(in_channels)
        )

    def forward(self, x):
        return x + self.block(x)


class UpsampleBlock(nn.Module):
    """Upscaling by factor 2 using pixel shuffle."""
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels * 4, 3, 1, 1)
        self.pixel_shuffle = nn.PixelShuffle(2)
        self.prelu = nn.PReLU()

    def forward(self, x):
        x = self.conv(x)
        x = self.pixel_shuffle(x)
        x = self.prelu(x)
        return x


class SRGANGenerator(nn.Module):
    """
    Generator for super‑resolution.
    Input: low‑res RGB image of size (low_res_size x low_res_size)
    Output: high‑res RGB image of size (32 x 32)
    The number of upsampling blocks is determined by the scale factor
    (32 // low_res_size), which must be a power of two.
    """
    def __init__(self, low_res_size=8, n_residual_blocks=8, base_channels=64):
        super().__init__()
        # Input convolution
        self.input_conv = nn.Sequential(
            nn.Conv2d(3, base_channels, 9, 1, 4),
            nn.PReLU()
        )

        # Residual blocks
        res_blocks = []
        for _ in range(n_residual_blocks):
            res_blocks.append(ResidualBlock(base_channels))
        self.res_blocks = nn.Sequential(*res_blocks)

        # Intermediate convolution
        self.mid_conv = nn.Sequential(
            nn.Conv2d(base_channels, base_channels, 3, 1, 1),
            nn.BatchNorm2d(base_channels)
        )

        # Upsampling blocks
        scale_factor = 32 // low_res_size
        # scale_factor must be a power of two (2, 4, 8)
        n_upsamples = int(np.log2(scale_factor))
        up_blocks = []
        in_ch = base_channels
        for i in range(n_upsamples):
            out_ch = base_channels // (2 ** i) if i < n_upsamples - 1 else base_channels
            up_blocks.append(UpsampleBlock(in_ch, out_ch))
            in_ch = out_ch
        self.upsample = nn.Sequential(*up_blocks)

        # Output convolution
        self.output_conv = nn.Sequential(
            nn.Conv2d(in_ch, 3, 9, 1, 4),
            nn.Tanh()
        )

    def forward(self, x):
        x = self.input_conv(x)
        residual = x
        x = self.res_blocks(x)
        x = self.mid_conv(x)
        x = x + residual
        x = self.upsample(x)
        x = self.output_conv(x)
        return x


class PatchGANDiscriminator(nn.Module):
    """PatchGAN discriminator for 32x32 input, outputs 8x8 patch scores."""
    def __init__(self, in_channels=3):
        super().__init__()
        self.model = nn.Sequential(
            # 32 -> 16
            nn.Conv2d(in_channels, 64, 4, 2, 1),
            nn.LeakyReLU(0.2, inplace=True),
            # 16 -> 8
            nn.Conv2d(64, 128, 4, 2, 1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
            # now 8x8, keep size with kernel=3, padding=1
            nn.Conv2d(128, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(256, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(512, 1, 3, 1, 1),
        )

    def forward(self, x):
        return self.model(x)


class SRGAN:
    def __init__(self, low_res_size=8, lambda_l1=100):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        torch.set_num_threads(multiprocessing.cpu_count())
        print(f"Using device: {self.device}")

        self.low_res_size = low_res_size
        self.generator = SRGANGenerator(low_res_size).to(self.device)
        self.discriminator = PatchGANDiscriminator().to(self.device)

        self.criterion_gan = nn.BCEWithLogitsLoss()
        self.criterion_l1 = nn.L1Loss()
        self.lambda_l1 = lambda_l1

        self.optimizer_G = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizer_D = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))

    def train_step(self, low_res_images, high_res_images):
        batch_size = low_res_images.size(0)
        low_res = low_res_images.to(self.device)
        high_res = high_res_images.to(self.device)

        # Labels for adversarial loss (patch GAN output 8x8)
        real_labels = torch.ones(batch_size, 1, 8, 8, device=self.device)
        fake_labels = torch.zeros(batch_size, 1, 8, 8, device=self.device)

        # ---------------------
        # Train Discriminator
        # ---------------------
        self.optimizer_D.zero_grad()

        # Real
        pred_real = self.discriminator(high_res)
        loss_D_real = self.criterion_gan(pred_real, real_labels)

        # Fake
        fake_high = self.generator(low_res)
        pred_fake = self.discriminator(fake_high.detach())
        loss_D_fake = self.criterion_gan(pred_fake, fake_labels)

        loss_D = (loss_D_real + loss_D_fake) * 0.5
        loss_D.backward()
        self.optimizer_D.step()

        # ---------------------
        # Train Generator
        # ---------------------
        self.optimizer_G.zero_grad()

        # Adversarial loss (try to fool D)
        pred_fake = self.discriminator(fake_high)
        loss_G_adv = self.criterion_gan(pred_fake, real_labels)

        # L1 loss
        loss_G_l1 = self.criterion_l1(fake_high, high_res) * self.lambda_l1

        loss_G = loss_G_adv + loss_G_l1
        loss_G.backward()
        self.optimizer_G.step()

        return loss_D.item(), loss_G_adv.item(), loss_G_l1.item()


# ==================== Augmented Dataset for SR ====================

class SRImageDataset(Dataset):
    def __init__(self, image_paths, low_res_size, target_size=32, aug_settings=None):
        self.image_paths = image_paths
        self.low_res_size = low_res_size
        self.target_size = target_size
        self.aug_settings = aug_settings or {}
        # Transform for high‑res target (resize to target_size, normalize to [-1,1])
        self.target_transform = transforms.Compose([
            transforms.Resize((target_size, target_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.image_paths)

    def apply_augmentations(self, pil_img):
        """Apply randomly selected augmentations to the PIL image."""
        img = pil_img.copy()
        # Each enabled augmentation has a 50% chance to be applied
        if self.aug_settings.get('stretch_height', False) and random.random() < 0.5:
            delta = random.randint(-8, 8)
            new_h = 32 + delta
            img = img.resize((32, new_h), Image.BICUBIC)
            img = img.resize((32, 32), Image.BICUBIC)

        if self.aug_settings.get('stretch_width', False) and random.random() < 0.5:
            delta = random.randint(-8, 8)
            new_w = 32 + delta
            img = img.resize((new_w, 32), Image.BICUBIC)
            img = img.resize((32, 32), Image.BICUBIC)

        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F.rotate(img, angle, interpolation=Image.BICUBIC)

        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F.hflip(img)

        if self.aug_settings.get('flip_vertical', False) and random.random() < 0.5:
            img = F.vflip(img)

        if self.aug_settings.get('affine_jitter', False) and random.random() < 0.5:
            translate_x = random.uniform(-0.1, 0.1) * 32
            translate_y = random.uniform(-0.1, 0.1) * 32
            scale = random.uniform(0.9, 1.1)
            shear = random.uniform(-10, 10)
            img = F.affine(img, angle=0, translate=(translate_x, translate_y),
                           scale=scale, shear=(shear, 0), interpolation=Image.BICUBIC)

        if self.aug_settings.get('brightness', False) and random.random() < 0.5:
            brightness_factor = random.uniform(0.8, 1.2)
            img = F.adjust_brightness(img, brightness_factor)

        if self.aug_settings.get('contrast', False) and random.random() < 0.5:
            contrast_factor = random.uniform(0.8, 1.2)
            img = F.adjust_contrast(img, contrast_factor)

        if self.aug_settings.get('saturation', False) and random.random() < 0.5:
            saturation_factor = random.uniform(0.8, 1.2)
            img = F.adjust_saturation(img, saturation_factor)

        if self.aug_settings.get('hue', False) and random.random() < 0.5:
            hue_factor = random.uniform(-0.1, 0.1)
            img = F.adjust_hue(img, hue_factor)

        if self.aug_settings.get('noise', False) and random.random() < 0.5:
            np_img = np.array(img).astype(np.float32)
            noise = np.random.normal(0, 10, np_img.shape)
            np_img = np.clip(np_img + noise, 0, 255).astype(np.uint8)
            img = Image.fromarray(np_img)

        # Ensure image is RGB
        if img.mode != 'RGB':
            img = img.convert('RGB')
        return img

    def __getitem__(self, idx):
        try:
            # Load image with transparency handling
            img_pil = load_image_as_rgb_with_black_bg(self.image_paths[idx])

            # Apply augmentations to the original image (before resizing)
            img_aug = self.apply_augmentations(img_pil)

            # Create low‑res version by resizing down
            low_res_pil = img_aug.resize((self.low_res_size, self.low_res_size), Image.BICUBIC)
            # Transform low‑res to tensor (also normalizes to [-1,1])
            low_res_tensor = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])(low_res_pil)

            # Create high‑res target (resize to target size)
            high_res_tensor = self.target_transform(img_aug)

            return low_res_tensor, high_res_tensor
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            dummy_low = torch.zeros(3, self.low_res_size, self.low_res_size)
            dummy_high = torch.zeros(3, self.target_size, self.target_size)
            return dummy_low, dummy_high


# ==================== GUI Application ====================

class SRGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SRGAN - Low-Res to 32x32")
        self.root.geometry("1000x700")

        self.image_paths = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()

        # Settings
        self.settings = {
            'low_res_size': tk.IntVar(value=8),          # 4,8,16 allowed (power of two)
            'lambda_l1': tk.IntVar(value=100),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
        }

        # Augmentation settings (same as before)
        self.aug_settings = {
            'stretch_height': tk.BooleanVar(value=False),
            'stretch_width': tk.BooleanVar(value=False),
            'rotation': tk.BooleanVar(value=False),
            'flip_horizontal': tk.BooleanVar(value=False),
            'flip_vertical': tk.BooleanVar(value=False),
            'affine_jitter': tk.BooleanVar(value=False),
            'brightness': tk.BooleanVar(value=False),
            'contrast': tk.BooleanVar(value=False),
            'saturation': tk.BooleanVar(value=False),
            'hue': tk.BooleanVar(value=False),
            'noise': tk.BooleanVar(value=False),
        }

        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None

        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.inference_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.inference_tab, text='Inference')
        self.setup_inference_tab()

    # ------------------------------------------------------------------
    # Training Tab (similar to before, but preview shows low‑res and generated)
    # ------------------------------------------------------------------
    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left panel
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="SRGAN Controls", font=("Arial", 12, "bold")).pack(pady=(0,10))

        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=5)

        list_frame = tk.Frame(img_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=scrollbar.set)

        # Model controls
        model_frame = tk.LabelFrame(left_frame, text="Model", padx=10, pady=10)
        model_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(model_frame, text="Initialize Model", command=self.initialize_model, width=20).pack(pady=5)

        # Training
        train_frame = tk.LabelFrame(left_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0,10))
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="Start Training", command=self.start_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", command=self.stop_training,
                  width=20, bg="salmon").pack(pady=5)

        # Save / Load
        save_frame = tk.LabelFrame(left_frame, text="Save/Load", padx=10, pady=10)
        save_frame.pack(fill=tk.X)
        tk.Button(save_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)
        tk.Button(save_frame, text="Load Model", command=self.load_model, width=20).pack(pady=5)

        # Right panel - preview and log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Preview frame (low‑res and generated)
        preview_frame = tk.LabelFrame(right_frame, text="Preview (Low‑Res → Generated)", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,10))

        preview_inner = tk.Frame(preview_frame)
        preview_inner.pack()

        self.preview_low_canvas = tk.Canvas(preview_inner, width=150, height=150, bg='gray')
        self.preview_low_canvas.pack(side=tk.LEFT, padx=5)
        self.preview_low_canvas.create_text(75, 75, text="Low‑Res")

        self.preview_gen_canvas = tk.Canvas(preview_inner, width=150, height=150, bg='gray')
        self.preview_gen_canvas.pack(side=tk.LEFT, padx=5)
        self.preview_gen_canvas.create_text(75, 75, text="Generated")

        # Log
        log_frame = tk.LabelFrame(right_frame, text="Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_log = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar_log.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar_log.set)

        self.status_label = tk.Label(self.training_tab, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    # ------------------------------------------------------------------
    # Settings Tab (with low_res_size and augmentations)
    # ------------------------------------------------------------------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Model Settings", font=("Arial",14,"bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Low‑res size
        size_frame = tk.LabelFrame(scrollable_frame, text="Input Size", padx=10, pady=10)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Low‑res size (4,8,16):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(size_frame, from_=4, to=16, variable=self.settings['low_res_size'],
                 orient=tk.HORIZONTAL, length=200, resolution=4).pack(side=tk.RIGHT)
        tk.Label(size_frame, textvariable=self.settings['low_res_size'], width=5).pack(side=tk.RIGHT)

        # Loss weight
        l1_frame = tk.LabelFrame(scrollable_frame, text="Loss Weight", padx=10, pady=10)
        l1_frame.pack(fill=tk.X, pady=5)
        tk.Label(l1_frame, text="L1 lambda:", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(l1_frame, from_=10, to=200, variable=self.settings['lambda_l1'],
                 orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(l1_frame, textvariable=self.settings['lambda_l1'], width=5).pack(side=tk.RIGHT)

        # Training parameters
        train_frame = tk.LabelFrame(scrollable_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=5)

        train_params = [
            ("Batch size:", 'batch_size', 1, 64),
            ("Learning rate:", 'learning_rate', 1e-5, 1e-2),
            ("Beta1 (Adam):", 'beta1', 0.0, 0.999),
            ("Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count()*2)),
        ]
        for label, key, low, high in train_params:
            f = tk.Frame(train_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            res = 0.00001 if key=='learning_rate' else (0.001 if key=='beta1' else 1)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Augmentations (same as before)
        aug_frame = tk.LabelFrame(scrollable_frame, text="Image Augmentations", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)

        augs = [
            ("Stretch Height (±8 px)", 'stretch_height'),
            ("Stretch Width (±8 px)", 'stretch_width'),
            ("Rotation (±30°)", 'rotation'),
            ("Flip Horizontal", 'flip_horizontal'),
            ("Flip Vertical", 'flip_vertical'),
            ("Affine Jitter (translate, scale, shear)", 'affine_jitter'),
            ("Brightness (±20%)", 'brightness'),
            ("Contrast (±20%)", 'contrast'),
            ("Saturation (±20%)", 'saturation'),
            ("Hue (±10%)", 'hue'),
            ("Gaussian Noise (σ=10)", 'noise'),
        ]
        for label, key in augs:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=5)
        cpu = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU cores: {cpu}").pack(anchor='w')
        tk.Label(sys_frame, text=f"PyTorch threads: {torch.get_num_threads()}").pack(anchor='w')
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}").pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ------------------------------------------------------------------
    # Inference Tab (load low‑res image and generate high‑res)
    # ------------------------------------------------------------------
    def setup_inference_tab(self):
        main_frame = tk.Frame(self.inference_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Inference: Low‑Res → 32x32", font=("Arial",14,"bold")).pack(pady=(0,20))

        # Controls
        ctrl_frame = tk.Frame(main_frame)
        ctrl_frame.pack(fill=tk.X, pady=5)

        tk.Button(ctrl_frame, text="Load Image (auto low‑res)", command=self.load_image_for_inference).pack(side=tk.LEFT, padx=5)
        tk.Button(ctrl_frame, text="Load Low‑Res Image", command=self.load_lowres_for_inference).pack(side=tk.LEFT, padx=5)
        tk.Button(ctrl_frame, text="Generate", command=self.run_inference).pack(side=tk.LEFT, padx=20)

        # Display area
        display_frame = tk.LabelFrame(main_frame, text="Input/Output", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True)

        inner = tk.Frame(display_frame)
        inner.pack(pady=10)

        # Input (low‑res) canvas 150x150 (we'll display the low‑res image enlarged)
        self.infer_input_canvas = tk.Canvas(inner, width=150, height=150, bg='lightgray')
        self.infer_input_canvas.pack(side=tk.LEFT, padx=10)
        self.infer_input_canvas.create_text(75, 75, text="Input (Low‑Res)")

        # Output (generated) canvas 150x150
        self.infer_output_canvas = tk.Canvas(inner, width=150, height=150, bg='lightgray')
        self.infer_output_canvas.pack(side=tk.LEFT, padx=10)
        self.infer_output_canvas.create_text(75, 75, text="Output (32x32)")

        self.infer_info = tk.Label(display_frame, text="", fg="blue")
        self.infer_info.pack(pady=5)

        # Storage
        self.current_low_tensor = None
        self.current_low_pil = None

    # ------------------------------------------------------------------
    # Core functions
    # ------------------------------------------------------------------
    def log_message(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(msg)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.webm *.bmp")]
        )
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images")

    def initialize_model(self):
        try:
            low_res = self.settings['low_res_size'].get()
            # Ensure low_res is a power of two and ≤16
            if low_res not in [4,8,16]:
                self.log_message("Low‑res size must be 4, 8, or 16. Using 8.")
                low_res = 8
                self.settings['low_res_size'].set(8)
            self.model = SRGAN(
                low_res_size=low_res,
                lambda_l1=self.settings['lambda_l1'].get()
            )
            self.log_message("Model initialized.")
        except Exception as e:
            self.log_message(f"Error: {e}")

    def start_training(self):
        if not self.image_paths:
            self.log_message("No images!")
            return
        if not self.model:
            self.log_message("Model not initialized!")
            return
        if self.training:
            self.log_message("Already training.")
            return

        try:
            epochs = int(self.epoch_var.get())
        except:
            self.log_message("Invalid epochs")
            return

        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()

        # Update optimizer hyperparameters
        for pg in self.model.optimizer_G.param_groups:
            pg['lr'] = self.settings['learning_rate'].get()
            pg['betas'] = (self.settings['beta1'].get(), 0.999)
        for pg in self.model.optimizer_D.param_groups:
            pg['lr'] = self.settings['learning_rate'].get()
            pg['betas'] = (self.settings['beta1'].get(), 0.999)

        thread = threading.Thread(target=self.train_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_message(f"Training started for {epochs} epochs.")

    def train_loop(self, epochs):
        try:
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            low_res = self.settings['low_res_size'].get()

            # Build augmentation settings dict from GUI variables
            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}

            dataset = SRImageDataset(self.image_paths, low_res, target_size=32, aug_settings=aug_dict)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=torch.cuda.is_available(),
                                persistent_workers=num_workers>0)

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                epoch_loss_D = 0.0
                epoch_loss_G_adv = 0.0
                epoch_loss_G_l1 = 0.0
                batches = 0

                for low_res_imgs, high_res_imgs in loader:
                    if not self.training:
                        break
                    loss_D, loss_G_adv, loss_G_l1 = self.model.train_step(low_res_imgs, high_res_imgs)

                    epoch_loss_D += loss_D
                    epoch_loss_G_adv += loss_G_adv
                    epoch_loss_G_l1 += loss_G_l1
                    batches += 1

                avg_D = epoch_loss_D / batches if batches else 0
                avg_G_adv = epoch_loss_G_adv / batches if batches else 0
                avg_G_l1 = epoch_loss_G_l1 / batches if batches else 0
                elapsed = time.time() - self.start_time
                self.log_message(f"Epoch {epoch+1}/{epochs} | D: {avg_D:.4f} | G_adv: {avg_G_adv:.4f} | G_l1: {avg_G_l1:.4f} | Time: {elapsed:.1f}s")

                # Show a preview every 5 epochs
                if (epoch+1) % 5 == 0:
                    self.show_preview(loader)

            self.training = False
            self.log_message("Training finished.")
        except Exception as e:
            self.log_message(f"Training error: {e}")
            import traceback
            traceback.print_exc()
            self.training = False

    def show_preview(self, loader):
        """Pick a random batch, show low‑res and generated image."""
        if not self.model:
            return
        try:
            data_iter = iter(loader)
            low_res, high_res = next(data_iter)
            # Take first item
            low = low_res[0:1].to(self.model.device)
            self.model.generator.eval()
            with torch.no_grad():
                fake = self.model.generator(low)
            self.model.generator.train()

            # Convert low‑res to display (upscale to 150x150 for visibility)
            low_np = low[0].cpu().numpy().transpose(1,2,0)
            low_np = ((low_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            low_pil = Image.fromarray(low_np).resize((150,150), Image.NEAREST)
            self.low_photo = ImageTk.PhotoImage(low_pil)
            self.preview_low_canvas.delete("all")
            self.preview_low_canvas.create_image(75, 75, image=self.low_photo)

            # Convert generated image
            fake_np = fake[0].cpu().numpy().transpose(1,2,0)
            fake_np = ((fake_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            fake_pil = Image.fromarray(fake_np).resize((150,150), Image.BICUBIC)
            self.fake_photo = ImageTk.PhotoImage(fake_pil)
            self.preview_gen_canvas.delete("all")
            self.preview_gen_canvas.create_image(75, 75, image=self.fake_photo)

        except Exception as e:
            self.log_message(f"Preview error: {e}")

    def stop_training(self):
        self.training = False
        self.log_message("Training stopped.")

    def save_model(self):
        if not self.model:
            self.log_message("No model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth",
                                              filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'generator': self.model.generator.state_dict(),
                'discriminator': self.model.discriminator.state_dict(),
                'optimizer_G': self.model.optimizer_G.state_dict(),
                'optimizer_D': self.model.optimizer_D.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items()},
                'aug_settings': {k:v.get() for k,v in self.aug_settings.items()}
            }, fname)
            self.log_message(f"Model saved to {fname}")

    def load_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            if 'settings' in ckpt:
                s = ckpt['settings']
                self.settings['low_res_size'].set(s.get('low_res_size',8))
                self.settings['lambda_l1'].set(s.get('lambda_l1',100))
            if 'aug_settings' in ckpt:
                for k, v in ckpt['aug_settings'].items():
                    if k in self.aug_settings:
                        self.aug_settings[k].set(v)
            self.initialize_model()
            self.model.generator.load_state_dict(ckpt['generator'])
            self.model.discriminator.load_state_dict(ckpt['discriminator'])
            self.model.generator.to(self.model.device)
            self.model.discriminator.to(self.model.device)
            self.model.optimizer_G.load_state_dict(ckpt['optimizer_G'])
            self.model.optimizer_D.load_state_dict(ckpt['optimizer_D'])
            self.log_message(f"Model loaded from {fname}")
        except Exception as e:
            self.log_message(f"Load error: {e}")

    # ------------------------------------------------------------------
    # Inference functions
    # ------------------------------------------------------------------
    def load_image_for_inference(self):
        """Load a normal image, downscale it to low‑res size automatically."""
        f = filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png *.jfif *.webp *.webm")])
        if not f:
            return
        try:
            pil_img = load_image_as_rgb_with_black_bg(f)
            low_res_size = self.settings['low_res_size'].get()
            # Create low‑res version
            low_res_pil = pil_img.resize((low_res_size, low_res_size), Image.BICUBIC)
            self.current_low_pil = low_res_pil

            # Convert to tensor for generation
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))
            ])
            self.current_low_tensor = transform(low_res_pil).unsqueeze(0)

            # Display low‑res image (enlarged)
            disp_img = low_res_pil.resize((150,150), Image.NEAREST)
            self.input_photo = ImageTk.PhotoImage(disp_img)
            self.infer_input_canvas.delete("all")
            self.infer_input_canvas.create_image(75, 75, image=self.input_photo)

            self.infer_info.config(text="Image downscaled to low‑res. Click Generate.")
        except Exception as e:
            self.log_message(f"Error loading image: {e}")

    def load_lowres_for_inference(self):
        """Load an image that is already low‑res (any size, will be resized to low_res_size)."""
        f = filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png *.jfif *.webp *.webm")])
        if not f:
            return
        try:
            pil_img = load_image_as_rgb_with_black_bg(f)
            low_res_size = self.settings['low_res_size'].get()
            low_res_pil = pil_img.resize((low_res_size, low_res_size), Image.BICUBIC)
            self.current_low_pil = low_res_pil

            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))
            ])
            self.current_low_tensor = transform(low_res_pil).unsqueeze(0)

            disp_img = low_res_pil.resize((150,150), Image.NEAREST)
            self.input_photo = ImageTk.PhotoImage(disp_img)
            self.infer_input_canvas.delete("all")
            self.infer_input_canvas.create_image(75, 75, image=self.input_photo)

            self.infer_info.config(text="Low‑res image loaded. Click Generate.")
        except Exception as e:
            self.log_message(f"Error loading low‑res image: {e}")

    def run_inference(self):
        if not self.model:
            self.infer_info.config(text="Model not loaded!")
            return
        if self.current_low_tensor is None:
            self.infer_info.config(text="No input image!")
            return

        try:
            self.model.generator.eval()
            with torch.no_grad():
                low = self.current_low_tensor.to(self.model.device)
                fake = self.model.generator(low)
            self.model.generator.train()

            fake_np = fake[0].cpu().numpy().transpose(1,2,0)
            fake_np = ((fake_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            fake_pil = Image.fromarray(fake_np).resize((150,150), Image.BICUBIC)
            self.fake_disp_photo = ImageTk.PhotoImage(fake_pil)
            self.infer_output_canvas.delete("all")
            self.infer_output_canvas.create_image(75, 75, image=self.fake_disp_photo)

            self.infer_info.config(text="Generated successfully.")
        except Exception as e:
            self.infer_info.config(text=f"Error: {e}")
            self.log_message(f"Inference error: {e}")

# ==================== Main ====================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = SRGANApp(root)
    root.mainloop()