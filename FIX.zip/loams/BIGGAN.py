import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torch.nn.utils import spectral_norm
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import math
from pathlib import Path

# ==================== Utility functions ====================

def snconv2d(in_channels, out_channels, kernel_size, stride=1, padding=0, bias=True):
    """Spectral norm Conv2d"""
    return spectral_norm(nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, bias=bias))

def snlinear(in_features, out_features, bias=True):
    """Spectral norm Linear"""
    return spectral_norm(nn.Linear(in_features, out_features, bias=bias))

def sn_embedding(num_embeddings, embedding_dim):
    """Spectral norm Embedding (not used in unconditional)"""
    return spectral_norm(nn.Embedding(num_embeddings, embedding_dim))

class SelfAttention(nn.Module):
    """Self-attention block (from BigGAN/SA-GAN)"""
    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels
        self.query = snconv2d(in_channels, in_channels // 8, 1)
        self.key   = snconv2d(in_channels, in_channels // 8, 1)
        self.value = snconv2d(in_channels, in_channels, 1)
        self.gamma = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        B, C, H, W = x.size()
        proj_query = self.query(x).view(B, -1, H*W).permute(0, 2, 1)  # B, N, C//8
        proj_key   = self.key(x).view(B, -1, H*W)                     # B, C//8, N
        energy     = torch.bmm(proj_query, proj_key)                  # B, N, N
        attention  = F.softmax(energy, dim=-1)
        proj_value = self.value(x).view(B, -1, H*W)                   # B, C, N
        out        = torch.bmm(proj_value, attention.permute(0, 2, 1)) # B, C, N
        out        = out.view(B, C, H, W)
        out        = self.gamma * out + x
        return out

# ==================== BigGAN Generator and Discriminator ====================

class GBlock(nn.Module):
    """Generator residual block with upsampling"""
    def __init__(self, in_channels, out_channels, use_sn=True, upsample=True):
        super().__init__()
        conv = snconv2d if use_sn else nn.Conv2d
        self.upsample = upsample
        self.conv1 = conv(in_channels, out_channels, 3, 1, 1)
        self.conv2 = conv(out_channels, out_channels, 3, 1, 1)
        self.bn1 = nn.BatchNorm2d(in_channels)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.skip = conv(in_channels, out_channels, 1, 1, 0) if in_channels != out_channels else nn.Identity()

    def forward(self, x):
        h = F.relu(self.bn1(x))
        if self.upsample:
            h = F.interpolate(h, scale_factor=2, mode='nearest')
        h = self.conv1(h)
        h = F.relu(self.bn2(h))
        h = self.conv2(h)

        if self.upsample:
            x_skip = F.interpolate(x, scale_factor=2, mode='nearest')
        else:
            x_skip = x
        x_skip = self.skip(x_skip)
        return h + x_skip

class DBlock(nn.Module):
    """Discriminator residual block with downsampling"""
    def __init__(self, in_channels, out_channels, use_sn=True, downsample=True):
        super().__init__()
        conv = snconv2d if use_sn else nn.Conv2d
        self.downsample = downsample
        self.conv1 = conv(in_channels, out_channels, 3, 1, 1)
        self.conv2 = conv(out_channels, out_channels, 3, 1, 1)
        self.skip = conv(in_channels, out_channels, 1, 1, 0) if in_channels != out_channels else nn.Identity()

    def forward(self, x):
        h = F.relu(x)
        h = self.conv1(h)
        h = F.relu(h)
        h = self.conv2(h)
        if self.downsample:
            h = F.avg_pool2d(h, 2)

        if self.downsample:
            x_skip = F.avg_pool2d(x, 2)
        else:
            x_skip = x
        x_skip = self.skip(x_skip)
        return h + x_skip

class BigGANGenerator(nn.Module):
    """
    BigGAN-style generator for 32x32 images.
    Skip-z: latent z is split and injected into each residual block.
    Self-attention placed at 16x16 resolution.
    """
    def __init__(self, latent_dim=120, base_channels=64, use_sn=True, use_attention=True):
        super().__init__()
        self.latent_dim = latent_dim
        self.ch = base_channels
        self.num_blocks = 4  # after initial projection

        # Split latent into chunks: one for initial linear, one per block
        num_chunks = self.num_blocks + 1
        base_chunk = latent_dim // num_chunks
        self.chunk_dims = [base_chunk] * num_chunks
        # Adjust last chunk to account for remainder (if any)
        remainder = latent_dim - base_chunk * num_chunks
        self.chunk_dims[-1] += remainder

        # Initial linear: takes first chunk and produces 4x4 feature map
        self.linear = nn.Linear(self.chunk_dims[0], 4 * 4 * 16 * self.ch)

        # Generator blocks (after initial)
        self.blocks = nn.ModuleList([
            GBlock(16 * self.ch, 16 * self.ch, use_sn, upsample=False),  # 4x4 -> 4x4
            GBlock(16 * self.ch,  8 * self.ch, use_sn, upsample=True),   # 4x4 -> 8x8
            GBlock( 8 * self.ch,  4 * self.ch, use_sn, upsample=True),   # 8x8 -> 16x16
            GBlock( 4 * self.ch,  2 * self.ch, use_sn, upsample=True),   # 16x16 -> 32x32
        ])

        # Self-attention at 16x16 (after third block)
        self.attention = SelfAttention(4 * self.ch) if use_attention else nn.Identity()

        # Final layers
        self.bn = nn.BatchNorm2d(2 * self.ch)
        self.conv_out = snconv2d(2 * self.ch, 3, 3, 1, 1) if use_sn else nn.Conv2d(2 * self.ch, 3, 3, 1, 1)
        self.tanh = nn.Tanh()

        # Embedders for each block (skip‑z conditioning)
        # Each embedder takes the corresponding chunk and outputs scale & shift for that block
        self.embedders = nn.ModuleList()
        for i, block in enumerate(self.blocks):
            out_ch = block.conv2.out_channels
            # Use chunk for this block (index i+1 because chunk 0 is for initial linear)
            self.embedders.append(nn.Linear(self.chunk_dims[i+1], 2 * out_ch))

    def forward(self, z):
        # Split z into chunks
        chunks = torch.split(z, self.chunk_dims, dim=1)

        # Initial projection from first chunk
        out = self.linear(chunks[0])
        out = out.view(out.size(0), 16 * self.ch, 4, 4)

        # Pass through blocks with conditioning from corresponding chunks
        for i, block in enumerate(self.blocks):
            # Get scale and shift from the chunk for this block
            embed = self.embedders[i](chunks[i+1])  # [B, 2*out_ch]
            scale, shift = embed.chunk(2, dim=1)
            scale = scale.unsqueeze(2).unsqueeze(3)
            shift = shift.unsqueeze(2).unsqueeze(3)

            out = block(out)
            # Apply scale and shift (simplified version of class-conditional BN)
            out = out * (1 + scale) + shift

            # Apply self-attention after the third block (16x16 resolution)
            if i == 2:
                out = self.attention(out)

        out = F.relu(self.bn(out))
        out = self.conv_out(out)
        out = self.tanh(out)
        return out

class BigGANDiscriminator(nn.Module):
    """BigGAN-style discriminator for 32x32 images."""
    def __init__(self, base_channels=64, use_sn=True, use_attention=True):
        super().__init__()
        self.ch = base_channels

        # Input block (no downsampling yet)
        self.input_conv = snconv2d(3, self.ch, 3, 1, 1) if use_sn else nn.Conv2d(3, self.ch, 3, 1, 1)

        # Downsampling blocks
        self.blocks = nn.ModuleList([
            DBlock(1 * self.ch, 2 * self.ch, use_sn, downsample=True),   # 32x32 -> 16x16
            DBlock(2 * self.ch, 4 * self.ch, use_sn, downsample=True),   # 16x16 -> 8x8
            DBlock(4 * self.ch, 8 * self.ch, use_sn, downsample=True),   # 8x8 -> 4x4
        ])

        # Self-attention at 16x16 (after first block)
        self.attention = SelfAttention(2 * self.ch) if use_attention else nn.Identity()

        # Final layers
        self.linear = snlinear(8 * self.ch * 4 * 4, 1, bias=True) if use_sn else nn.Linear(8 * self.ch * 4 * 4, 1)

    def forward(self, x):
        h = self.input_conv(x)
        for i, block in enumerate(self.blocks):
            h = block(h)
            if i == 0:
                h = self.attention(h)
        h = h.view(h.size(0), -1)
        out = self.linear(h)
        return out

# ==================== BigGAN wrapper ====================

class BigGAN:
    def __init__(self, latent_dim=120, base_channels=64, use_sn=True, use_attention=True, use_orthogonal=True, ortho_weight=1e-4):
        torch.set_num_threads(multiprocessing.cpu_count())
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")

        self.latent_dim = latent_dim
        self.generator = BigGANGenerator(latent_dim, base_channels, use_sn, use_attention).to(self.device)
        self.discriminator = BigGANDiscriminator(base_channels, use_sn, use_attention).to(self.device)

        # Losses: hinge loss by default
        self.hinge = True

        # Optimizers
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.0, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.0, 0.999))

        # Orthogonal regularization (optional)
        self.use_orthogonal = use_orthogonal
        self.ortho_weight = ortho_weight

    def set_hinge_loss(self, use_hinge):
        self.hinge = use_hinge

    def compute_orthogonal_regularization(self):
        """Compute orthogonal regularization loss for generator."""
        reg_loss = 0.0
        for name, param in self.generator.named_parameters():
            if 'weight' in name and param.dim() >= 2:
                w = param.view(param.size(0), -1)
                w_t_w = w.t().matmul(w)
                # Remove diagonal (cosine similarity without norm penalty)
                w_t_w = w_t_w * (1 - torch.eye(w_t_w.size(0), device=w_t_w.device))
                reg_loss += torch.norm(w_t_w, p='fro') ** 2
        return self.ortho_weight * reg_loss / 2

    def train_step(self, real_images):
        """Single training step (D then G). Returns losses dict."""
        batch_size = real_images.size(0)
        real_images = real_images.to(self.device)

        # Train Discriminator
        for _ in range(2):  # 2 D steps per G step (configurable)
            self.optimizerD.zero_grad()
            # Real
            real_logits = self.discriminator(real_images)
            # Fake
            noise = torch.randn(batch_size, self.latent_dim, device=self.device)
            fake_images = self.generator(noise)
            fake_logits = self.discriminator(fake_images.detach())

            if self.hinge:
                loss_d_real = torch.mean(F.relu(1.0 - real_logits))
                loss_d_fake = torch.mean(F.relu(1.0 + fake_logits))
                loss_d = loss_d_real + loss_d_fake
            else:
                loss_d = F.binary_cross_entropy_with_logits(real_logits, torch.ones_like(real_logits)) + \
                         F.binary_cross_entropy_with_logits(fake_logits, torch.zeros_like(fake_logits))
            loss_d.backward()
            self.optimizerD.step()

        # Train Generator
        self.optimizerG.zero_grad()
        noise = torch.randn(batch_size, self.latent_dim, device=self.device)
        fake_images = self.generator(noise)
        fake_logits = self.discriminator(fake_images)
        if self.hinge:
            loss_g = -torch.mean(fake_logits)
        else:
            loss_g = F.binary_cross_entropy_with_logits(fake_logits, torch.ones_like(fake_logits))

        # Orthogonal regularization
        if self.use_orthogonal:
            loss_g += self.compute_orthogonal_regularization()

        loss_g.backward()
        self.optimizerG.step()

        return {'loss_d': loss_d.item(), 'loss_g': loss_g.item()}

# ==================== Dataset (same as before) ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class BigGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BigGAN Trainer (32x32)")
        self.root.geometry("1100x750")

        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()

        # Settings
        self.settings = {
            'latent_dim': tk.IntVar(value=120),
            'base_channels': tk.IntVar(value=64),
            'use_sn': tk.BooleanVar(value=True),
            'use_attention': tk.BooleanVar(value=True),
            'use_orthogonal': tk.BooleanVar(value=True),
            'ortho_weight': tk.DoubleVar(value=1e-4),
            'hinge_loss': tk.BooleanVar(value=True),
            'd_steps': tk.IntVar(value=2),
            'batch_size': tk.IntVar(value=16),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.0),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'generate_interval': tk.IntVar(value=5),
            'truncation_threshold': tk.DoubleVar(value=1.0),  # for sampling
        }

        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        self.generated_images = []

        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))

        tk.Label(left_frame, text="BigGAN Controls", font=("Arial", 12, "bold")).pack(pady=(0, 10))
        tk.Label(left_frame, text="Image Size: 32x32").pack(pady=(0, 10))

        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=(0, 10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=5)

        list_frame = tk.Frame(img_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=scrollbar.set)

        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        tk.Button(train_frame, text="Initialize BigGAN", command=self.initialize_gan, width=20).pack(pady=5)

        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="Start Training", command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", command=self.stop_training, width=20, bg="salmon").pack(pady=5)

        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        tk.Button(gen_frame, text="Generate Sample", command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)

        # Right panel
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)

        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

        self.status_label = tk.Label(self.training_tab, text="Ready", relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="BigGAN Settings", font=("Arial", 14, "bold")).pack(pady=(0, 20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))

        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 10, 500),
            ("Base Channels:", 'base_channels', 16, 256),
        ]
        for label, var, minv, maxv in settings_list:
            f = tk.Frame(net_frame)
            f.pack(fill=tk.X, pady=5)
            tk.Label(f, text=label, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(f, from_=minv, to=maxv, variable=self.settings[var], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[var], width=5).pack(side=tk.RIGHT, padx=5)

        # Checkboxes
        f = tk.Frame(net_frame)
        f.pack(fill=tk.X, pady=5)
        tk.Checkbutton(f, text="Use Spectral Normalization", variable=self.settings['use_sn']).pack(anchor='w')
        f = tk.Frame(net_frame)
        f.pack(fill=tk.X, pady=5)
        tk.Checkbutton(f, text="Use Self-Attention", variable=self.settings['use_attention']).pack(anchor='w')

        # Orthogonal reg
        ortho_frame = tk.LabelFrame(scrollable_frame, text="Orthogonal Regularization", padx=10, pady=10)
        ortho_frame.pack(fill=tk.X, pady=(0, 10))
        tk.Checkbutton(ortho_frame, text="Enable", variable=self.settings['use_orthogonal']).pack(anchor='w')
        f = tk.Frame(ortho_frame)
        f.pack(fill=tk.X, pady=5)
        tk.Label(f, text="Weight:", width=30, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=1e-6, to=1e-2, resolution=1e-6, variable=self.settings['ortho_weight'], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['ortho_weight'], width=8).pack(side=tk.RIGHT, padx=5)

        # Training parameters
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))

        train_settings = [
            ("Learning Rate:", 'learning_rate', 1e-5, 1e-2),
            ("Beta1 (Adam):", 'beta1', 0.0, 0.999),
            ("Batch Size:", 'batch_size', 1, 128),
            ("D steps per G step:", 'd_steps', 1, 8),
            ("Number of Workers:", 'num_workers', 1, multiprocessing.cpu_count()),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]
        for label, var, minv, maxv in train_settings:
            f = tk.Frame(train_frame)
            f.pack(fill=tk.X, pady=5)
            tk.Label(f, text=label, width=30, anchor='w').pack(side=tk.LEFT)
            if var in ['learning_rate', 'beta1']:
                res = 1e-5 if var == 'learning_rate' else 0.001
                tk.Scale(f, from_=minv, to=maxv, variable=self.settings[var], orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            else:
                tk.Scale(f, from_=minv, to=maxv, variable=self.settings[var], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[var], width=5).pack(side=tk.RIGHT, padx=5)

        f = tk.Frame(train_frame)
        f.pack(fill=tk.X, pady=5)
        tk.Checkbutton(f, text="Use Hinge Loss", variable=self.settings['hinge_loss']).pack(anchor='w')

        # Truncation trick
        trunc_frame = tk.LabelFrame(scrollable_frame, text="Truncation Trick (sampling)", padx=10, pady=10)
        trunc_frame.pack(fill=tk.X, pady=(0, 10))
        f = tk.Frame(trunc_frame)
        f.pack(fill=tk.X, pady=5)
        tk.Label(f, text="Threshold (1.0 = no truncation):", width=30, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=0.1, to=2.0, resolution=0.1, variable=self.settings['truncation_threshold'], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['truncation_threshold'], width=5).pack(side=tk.RIGHT, padx=5)

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", anchor='w').pack(fill=tk.X, pady=2)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Image Generation", font=("Arial", 14, "bold")).pack(pady=(0, 20))

        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        tk.Button(load_frame, text="Load Generator", command=self.load_generator, width=20).pack(pady=5)

        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))

        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var, orient=tk.HORIZONTAL, length=300).pack(pady=5)

        tk.Label(gen_frame, text="Truncation Threshold:").pack(pady=5)
        self.gen_trunc_var = tk.DoubleVar(value=1.0)
        tk.Scale(gen_frame, from_=0.1, to=2.0, resolution=0.1, variable=self.gen_trunc_var, orient=tk.HORIZONTAL, length=300).pack(pady=5)

        tk.Button(gen_frame, text="Generate Grid", command=self.generate_grid, width=20).pack(pady=10)

        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)

        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        self.gen_scroll_frame.bind("<Configure>", lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all")))
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ========== Helper methods ==========
    def log_message(self, message):
        self.message_queue.put(message)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(msg)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")])
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images")

    def initialize_gan(self):
        try:
            latent_dim = self.settings['latent_dim'].get()
            base_channels = self.settings['base_channels'].get()
            use_sn = self.settings['use_sn'].get()
            use_attention = self.settings['use_attention'].get()
            use_orthogonal = self.settings['use_orthogonal'].get()
            ortho_weight = self.settings['ortho_weight'].get()

            self.gan = BigGAN(latent_dim, base_channels, use_sn, use_attention, use_orthogonal, ortho_weight)
            self.gan.set_hinge_loss(self.settings['hinge_loss'].get())
            self.log_message(f"Initialized BigGAN: latent={latent_dim}, base_ch={base_channels}")
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")

    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images!")
            return
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        if self.training:
            self.log_message("Training already in progress!")
            return

        epochs = int(self.epoch_var.get())
        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()

        batch_size = self.settings['batch_size'].get()
        num_workers = self.settings['num_workers'].get()
        lr = self.settings['learning_rate'].get()
        beta1 = self.settings['beta1'].get()
        d_steps = self.settings['d_steps'].get()

        # Update optimizers
        for pg in self.gan.optimizerG.param_groups:
            pg['lr'] = lr
            pg['betas'] = (beta1, 0.999)
        for pg in self.gan.optimizerD.param_groups:
            pg['lr'] = lr
            pg['betas'] = (beta1, 0.999)

        self.gan.set_hinge_loss(self.settings['hinge_loss'].get())

        thread = threading.Thread(target=self.train_gan, args=(epochs, batch_size, num_workers, d_steps), daemon=True)
        thread.start()
        self.log_message(f"Started training for {epochs} epochs, batch {batch_size}, D steps {d_steps}")

    def train_gan(self, epochs, batch_size, num_workers, d_steps):
        try:
            dataset = ImageDataset(self.image_paths, image_size=32)
            dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                    num_workers=min(num_workers, multiprocessing.cpu_count()),
                                    pin_memory=torch.cuda.is_available(),
                                    persistent_workers=(num_workers > 0))
            generate_interval = self.settings['generate_interval'].get()

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                total_loss_d = 0.0
                total_loss_g = 0.0
                batch_count = 0
                epoch_start = time.time()

                for real_images in dataloader:
                    if not self.training:
                        break
                    losses = self.gan.train_step(real_images)
                    total_loss_d += losses['loss_d']
                    total_loss_g += losses['loss_g']
                    batch_count += 1

                if batch_count > 0:
                    avg_d = total_loss_d / batch_count
                    avg_g = total_loss_g / batch_count
                    epoch_time = time.time() - epoch_start
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | D loss: {avg_d:.4f} | G loss: {avg_g:.4f} | Time: {epoch_time:.1f}s | Total: {elapsed:.1f}s")

                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1} - no batches")

            self.training = False
            self.log_message("Training completed!")
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False

    def generate_training_samples(self):
        if not self.gan:
            return
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                # Apply truncation if desired
                thresh = self.settings['truncation_threshold'].get()
                if thresh < 2.0:
                    noise = torch.clamp(noise, -thresh, thresh)
                generated = self.gan.generator(noise).cpu()
                img = self.tensor_to_pil(generated[0])
                img_disp = img.resize((200,200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_disp)
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def tensor_to_pil(self, tensor):
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        return transforms.ToPILImage()(img)

    def stop_training(self):
        self.training = False
        self.log_message("Training stopped by user")

    def generate_sample(self):
        if not self.gan:
            self.log_message("GAN not initialized!")
            return
        self.generate_training_samples()  # reuse

    def save_model(self):
        if not self.gan:
            self.log_message("No model to save")
            return
        filename = filedialog.asksaveasfilename(defaultextension=".pth", filetypes=[("PyTorch models", "*.pth")])
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'discriminator_state_dict': self.gan.discriminator.state_dict(),
                    'optimizerG': self.gan.optimizerG.state_dict(),
                    'optimizerD': self.gan.optimizerD.state_dict(),
                    'settings': {k: v.get() for k, v in self.settings.items()},
                }, filename)
                self.log_message(f"Model saved to {filename}")
            except Exception as e:
                self.log_message(f"Save error: {str(e)}")

    def load_generator(self):
        filename = filedialog.askopenfilename(filetypes=[("PyTorch models", "*.pth *.pt")])
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                # Load settings from checkpoint
                if 'settings' in checkpoint:
                    for k, v in checkpoint['settings'].items():
                        if k in self.settings:
                            self.settings[k].set(v)
                self.initialize_gan()  # re-init with loaded settings
                self.gan.generator.load_state_dict(checkpoint['generator_state_dict'])
                if 'discriminator_state_dict' in checkpoint:
                    self.gan.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])
                self.log_message(f"Loaded model from {filename}")
            except Exception as e:
                self.log_message(f"Load error: {str(e)}")

    def generate_grid(self):
        if not self.gan:
            self.log_message("GAN not initialized!")
            return
        try:
            num = self.num_gen_var.get()
            thresh = self.gen_trunc_var.get()
            with torch.no_grad():
                noise = torch.randn(num, self.gan.latent_dim, device=self.gan.device)
                if thresh < 2.0:
                    noise = torch.clamp(noise, -thresh, thresh)
                generated = self.gan.generator(noise).cpu()

            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()

            cols = 4
            rows = (num + cols - 1) // cols
            for i in range(rows):
                row = tk.Frame(self.gen_scroll_frame)
                row.pack(pady=5)
                for j in range(cols):
                    idx = i*cols + j
                    if idx < num:
                        img = self.tensor_to_pil(generated[idx])
                        img_disp = img.resize((128,128), Image.Resampling.NEAREST)
                        photo = ImageTk.PhotoImage(img_disp)
                        lbl = tk.Label(row, image=photo)
                        lbl.image = photo
                        lbl.pack(side=tk.LEFT, padx=5)
            self.log_message(f"Generated {num} images (trunc={thresh})")
        except Exception as e:
            self.log_message(f"Grid error: {str(e)}")

# ==================== Main ====================
if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = BigGANApp(root)
    root.mainloop()