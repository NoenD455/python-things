import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import random
import multiprocessing
from itertools import cycle, islice

# ==================== Autoencoder Network ====================

class ConvAutoencoder(nn.Module):
    def __init__(self, latent_dim=128, image_size=64):
        super().__init__()
        self.latent_dim = latent_dim
        self.image_size = image_size
        
        # Calculate the size after convolutions
        # For 64x64: 64 -> 32 -> 16 -> 8 -> 4 (4x4 spatial size)
        # For 32x32: 32 -> 16 -> 8 -> 4 -> 2 (2x2 spatial size)
        if image_size == 64:
            conv_output_size = 256 * 4 * 4  # 256 channels, 4x4 spatial
        else:  # 32x32
            conv_output_size = 256 * 2 * 2  # 256 channels, 2x2 spatial
        
        # Encoder
        self.encoder = nn.Sequential(
            # Input: 3 x image_size x image_size
            nn.Conv2d(3, 32, 4, 2, 1),  # image_size -> image_size/2
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.Conv2d(32, 64, 4, 2, 1),  # image_size/2 -> image_size/4
            nn.BatchNorm2d(64),
            nn.ReLU(True),
            nn.Conv2d(64, 128, 4, 2, 1),  # image_size/4 -> image_size/8
            nn.BatchNorm2d(128),
            nn.ReLU(True),
            nn.Conv2d(128, 256, 4, 2, 1),  # image_size/8 -> image_size/16
            nn.BatchNorm2d(256),
            nn.ReLU(True),
            nn.Flatten(),
            nn.Linear(conv_output_size, 512),
            nn.ReLU(True),
            nn.Linear(512, latent_dim)
        )
        
        # Decoder
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 512),
            nn.ReLU(True),
            nn.Linear(512, conv_output_size),
            nn.ReLU(True),
            nn.Unflatten(1, (256, image_size//16, image_size//16)),
            nn.ConvTranspose2d(256, 128, 4, 2, 1),  # image_size/16 -> image_size/8
            nn.BatchNorm2d(128),
            nn.ReLU(True),
            nn.ConvTranspose2d(128, 64, 4, 2, 1),  # image_size/8 -> image_size/4
            nn.BatchNorm2d(64),
            nn.ReLU(True),
            nn.ConvTranspose2d(64, 32, 4, 2, 1),  # image_size/4 -> image_size/2
            nn.BatchNorm2d(32),
            nn.ReLU(True),
            nn.ConvTranspose2d(32, 3, 4, 2, 1),  # image_size/2 -> image_size
            nn.Tanh()
        )
        
    def encode(self, x):
        return self.encoder(x)
    
    def decode(self, z):
        return self.decoder(z)
    
    def forward(self, x):
        z = self.encode(x)
        return self.decode(z)

class DualAutoencoderSystem:
    def __init__(self, latent_dim=128, image_size=64):
        self.image_size = image_size
        self.latent_dim = latent_dim
        
        # Set PyTorch to use 2 cores
        torch.set_num_threads(2)
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Two autoencoders
        self.ae1 = ConvAutoencoder(latent_dim, image_size)  # Class1 -> Class2
        self.ae2 = ConvAutoencoder(latent_dim, image_size)  # Class2 -> Class1
        
        # Optimizers
        self.optimizer1 = optim.Adam(self.ae1.parameters(), lr=0.0002)
        self.optimizer2 = optim.Adam(self.ae2.parameters(), lr=0.0002)
        
        # Loss function
        self.criterion = nn.L1Loss()  # Using L1 loss for reconstruction
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.ae1.to(self.device)
        self.ae2.to(self.device)
        
    def train_step(self, class1_batch, class2_batch):
        """Train both autoencoders using the double bottleneck approach"""
        # Move data to device
        class1_batch = class1_batch.to(self.device)
        class2_batch = class2_batch.to(self.device)
        
        # ===== Train AE1 (Class1 -> Class2 -> Class1) =====
        self.optimizer1.zero_grad()
        
        # Class1 -> AE1 -> Class2 style
        class1_to_2 = self.ae1(class1_batch)
        
        # Class2 style -> AE2 -> should reconstruct original Class1
        class2_to_1 = self.ae2(class1_to_2)
        
        # Reconstruction loss
        loss1 = self.criterion(class2_to_1, class1_batch)
        
        # ===== Train AE2 (Class2 -> Class1 -> Class2) =====
        self.optimizer2.zero_grad()
        
        # Class2 -> AE2 -> Class1 style
        class2_to_1_direct = self.ae2(class2_batch)
        
        # Class1 style -> AE1 -> should reconstruct original Class2
        class1_to_2_recon = self.ae1(class2_to_1_direct)
        
        # Reconstruction loss
        loss2 = self.criterion(class1_to_2_recon, class2_batch)
        
        # Total loss
        total_loss = loss1 + loss2
        
        # Backpropagate
        loss1.backward()
        loss2.backward()
        self.optimizer1.step()
        self.optimizer2.step()
        
        return loss1.item(), loss2.item(), total_loss.item()
    
    def transform_image(self, image, pipeline):
        """Transform image through a pipeline of autoencoders"""
        if not pipeline:
            return image
        
        result = image.clone().to(self.device)
        
        for ae_name in pipeline:
            if ae_name == 'ae1':
                result = self.ae1(result)
            elif ae_name == 'ae2':
                result = self.ae2(result)
        
        return result.cpu()

# ==================== Dataset ====================

class PairedImageDataset(Dataset):
    def __init__(self, class1_paths, class2_paths, image_size=64, transform=None):
        self.class1_paths = class1_paths
        self.class2_paths = class2_paths
        self.image_size = image_size
        
        if transform is None:
            self.transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transform
            
        # Create pairs by cycling the shorter list
        self.pairs = self._create_pairs()
    
    def _create_pairs(self):
        """Create pairs by matching images randomly or cycling"""
        pairs = []
        len1, len2 = len(self.class1_paths), len(self.class2_paths)
        
        if len1 == 0 or len2 == 0:
            return []
        
        # If one class has more images, we'll cycle the smaller one
        if len1 < len2:
            # Cycle class1 to match length of class2
            class1_cycled = list(islice(cycle(self.class1_paths), len2))
            pairs = list(zip(class1_cycled, self.class2_paths))
        else:
            # Cycle class2 to match length of class1
            class2_cycled = list(islice(cycle(self.class2_paths), len1))
            pairs = list(zip(self.class1_paths, class2_cycled))
        
        return pairs
    
    def __len__(self):
        return len(self.pairs)
    
    def __getitem__(self, idx):
        img1_path, img2_path = self.pairs[idx]
        
        try:
            img1 = Image.open(img1_path).convert('RGB')
            img2 = Image.open(img2_path).convert('RGB')
            
            return self.transform(img1), self.transform(img2)
        except Exception as e:
            print(f"Error loading images {img1_path}, {img2_path}: {e}")
            # Return black images as fallback
            black_img = torch.zeros(3, self.image_size, self.image_size)
            return black_img, black_img

# ==================== GUI Application ====================

class AutoencoderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Dual Autoencoder System - 2 Cores")
        self.root.geometry("950x750")  # Larger window for tabs
        
        # Training parameters
        self.class1_paths = []
        self.class2_paths = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Performance tracking
        self.num_workers = 2
        
        # Setup notebook (tabs)
        self.setup_notebook()
        
        # Start message handler
        self.root.after(100, self.process_messages)
    
    def setup_notebook(self):
        # Create notebook (tabbed interface)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Training Tab
        self.train_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.train_tab, text="Training")
        self.setup_training_tab()
        
        # Testing Tab
        self.test_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.test_tab, text="Testing")
        self.setup_testing_tab()
    
    def setup_training_tab(self):
        # Create main container for training tab
        main_container = tk.Frame(self.train_tab, padx=5, pady=5)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Left panel for controls
        left_frame = tk.Frame(main_container, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        title_label = tk.Label(left_frame, text="Dual Autoencoder Trainer", 
                              font=("Arial", 12, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 10))
        
        # Image size selection
        tk.Label(left_frame, text="Image Size:").grid(row=1, column=0, sticky="w", pady=(0, 5))
        self.size_var = tk.StringVar(value="64")
        size_frame = tk.Frame(left_frame)
        size_frame.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        tk.Radiobutton(size_frame, text="32x32", variable=self.size_var, value="32").pack(side=tk.LEFT, padx=(0, 10))
        tk.Radiobutton(size_frame, text="64x64", variable=self.size_var, value="64").pack(side=tk.LEFT)
        
        # Class 1 images
        tk.Label(left_frame, text="Class 1 Images:").grid(row=3, column=0, sticky="w", pady=(10, 5))
        tk.Button(left_frame, text="Add Class 1 Images", 
                 command=lambda: self.add_images('class1')).grid(row=4, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Class 1 listbox
        class1_frame = tk.Frame(left_frame)
        class1_frame.grid(row=5, column=0, columnspan=2, sticky="nsew", pady=(0, 5))
        class1_frame.grid_rowconfigure(0, weight=1)
        class1_frame.grid_columnconfigure(0, weight=1)
        
        self.class1_listbox = tk.Listbox(class1_frame, height=6)
        self.class1_listbox.grid(row=0, column=0, sticky="nsew")
        
        class1_scrollbar = tk.Scrollbar(class1_frame, orient=tk.VERTICAL, command=self.class1_listbox.yview)
        class1_scrollbar.grid(row=0, column=1, sticky="ns")
        self.class1_listbox.config(yscrollcommand=class1_scrollbar.set)
        
        # Class 2 images
        tk.Label(left_frame, text="Class 2 Images:").grid(row=6, column=0, sticky="w", pady=(10, 5))
        tk.Button(left_frame, text="Add Class 2 Images", 
                 command=lambda: self.add_images('class2')).grid(row=7, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Class 2 listbox
        class2_frame = tk.Frame(left_frame)
        class2_frame.grid(row=8, column=0, columnspan=2, sticky="nsew", pady=(0, 10))
        class2_frame.grid_rowconfigure(0, weight=1)
        class2_frame.grid_columnconfigure(0, weight=1)
        
        self.class2_listbox = tk.Listbox(class2_frame, height=6)
        self.class2_listbox.grid(row=0, column=0, sticky="nsew")
        
        class2_scrollbar = tk.Scrollbar(class2_frame, orient=tk.VERTICAL, command=self.class2_listbox.yview)
        class2_scrollbar.grid(row=0, column=1, sticky="ns")
        self.class2_listbox.config(yscrollcommand=class2_scrollbar.set)
        
        # Clear buttons
        clear_frame = tk.Frame(left_frame)
        clear_frame.grid(row=9, column=0, columnspan=2, sticky="ew", pady=5)
        tk.Button(clear_frame, text="Clear Class 1", 
                 command=lambda: self.clear_images('class1')).pack(side=tk.LEFT, expand=True, padx=2)
        tk.Button(clear_frame, text="Clear Class 2", 
                 command=lambda: self.clear_images('class2')).pack(side=tk.LEFT, expand=True, padx=2)
        
        # Training controls
        tk.Label(left_frame, text="Training Controls:").grid(row=10, column=0, sticky="w", pady=(10, 5))
        
        tk.Button(left_frame, text="Initialize Model", 
                 command=self.initialize_model, height=2).grid(row=11, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Label(left_frame, text="Epochs:").grid(row=12, column=0, sticky="w")
        self.epoch_var = tk.StringVar(value="50")
        epoch_entry = tk.Entry(left_frame, textvariable=self.epoch_var)
        epoch_entry.grid(row=13, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        tk.Button(left_frame, text="Start Training", 
                 command=self.start_training, height=2, bg="lightgreen").grid(row=14, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Stop Training", 
                 command=self.stop_training, height=2, bg="salmon").grid(row=15, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Performance info
        perf_frame = tk.LabelFrame(left_frame, text="Performance", padx=5, pady=2)
        perf_frame.grid(row=16, column=0, columnspan=2, sticky="ew", pady=(10, 5))
        
        self.perf_label = tk.Label(perf_frame, 
                                  text="CPU Threads: 2\nData Workers: 2", 
                                  font=("Arial", 9),
                                  justify=tk.LEFT)
        self.perf_label.pack()
        
        # Status
        tk.Label(left_frame, text="Status:").grid(row=17, column=0, sticky="w", pady=(10, 5))
        self.status_label = tk.Label(left_frame, text="Ready", 
                                    relief=tk.SUNKEN, 
                                    height=2,
                                    anchor="w",
                                    padx=5)
        self.status_label.grid(row=18, column=0, columnspan=2, sticky="ew", pady=(0, 5))
        
        # Configure grid weights
        left_frame.grid_rowconfigure(5, weight=1)
        left_frame.grid_rowconfigure(8, weight=1)
        left_frame.grid_columnconfigure(0, weight=1)
        left_frame.grid_columnconfigure(1, weight=1)
        
        # Right panel for preview and log
        right_frame = tk.Frame(main_container)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Image display area
        display_frame = tk.Frame(right_frame)
        display_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Class 1 sample
        tk.Label(display_frame, text="Class 1 Sample").grid(row=0, column=0, padx=5)
        self.class1_sample_frame = tk.Frame(display_frame, relief=tk.SUNKEN, bd=1)
        self.class1_sample_frame.grid(row=1, column=0, padx=5, pady=5)
        self.class1_label = tk.Label(self.class1_sample_frame, width=128, height=128)
        self.class1_label.pack(padx=2, pady=2)
        
        # Class 2 sample
        tk.Label(display_frame, text="Class 2 Sample").grid(row=0, column=1, padx=5)
        self.class2_sample_frame = tk.Frame(display_frame, relief=tk.SUNKEN, bd=1)
        self.class2_sample_frame.grid(row=1, column=1, padx=5, pady=5)
        self.class2_label = tk.Label(self.class2_sample_frame, width=128, height=128)
        self.class2_label.pack(padx=2, pady=2)
        
        # Transformation preview
        tk.Label(display_frame, text="AE1(Class1)").grid(row=0, column=2, padx=5)
        self.ae1_output_frame = tk.Frame(display_frame, relief=tk.SUNKEN, bd=1)
        self.ae1_output_frame.grid(row=1, column=2, padx=5, pady=5)
        self.ae1_label = tk.Label(self.ae1_output_frame, width=128, height=128)
        self.ae1_label.pack(padx=2, pady=2)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        log_frame.grid_rowconfigure(0, weight=1)
        log_frame.grid_columnconfigure(0, weight=1)
        
        self.log_text = tk.Text(log_frame, height=15, width=60, font=("Courier", 9))
        self.log_text.grid(row=0, column=0, sticky="nsew")
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.config(yscrollcommand=scrollbar.set)
    
    def setup_testing_tab(self):
        # Main container for testing tab
        main_container = tk.Frame(self.test_tab, padx=10, pady=10)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Left panel - Pipeline controls
        left_frame = tk.Frame(main_container, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        tk.Label(left_frame, text="Pipeline Configuration", 
                font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 10))
        
        # Pipeline steps
        tk.Label(left_frame, text="Step 1:").pack(anchor=tk.W, pady=(5, 0))
        self.step1_var = tk.StringVar(value="none")
        step1_menu = ttk.Combobox(left_frame, textvariable=self.step1_var, 
                                 values=["none", "ae1", "ae2"], state="readonly", width=15)
        step1_menu.pack(anchor=tk.W, pady=(0, 5))
        
        tk.Label(left_frame, text="Step 2:").pack(anchor=tk.W, pady=(5, 0))
        self.step2_var = tk.StringVar(value="none")
        step2_menu = ttk.Combobox(left_frame, textvariable=self.step2_var, 
                                 values=["none", "ae1", "ae2"], state="readonly", width=15)
        step2_menu.pack(anchor=tk.W, pady=(0, 5))
        
        tk.Label(left_frame, text="Step 3:").pack(anchor=tk.W, pady=(5, 0))
        self.step3_var = tk.StringVar(value="none")
        step3_menu = ttk.Combobox(left_frame, textvariable=self.step3_var, 
                                 values=["none", "ae1", "ae2"], state="readonly", width=15)
        step3_menu.pack(anchor=tk.W, pady=(0, 10))
        
        # Input selection
        tk.Label(left_frame, text="Input Image Source:", 
                font=("Arial", 10)).pack(anchor=tk.W, pady=(10, 5))
        
        self.input_source_var = tk.StringVar(value="class1")
        tk.Radiobutton(left_frame, text="Class 1 Image", 
                      variable=self.input_source_var, value="class1").pack(anchor=tk.W)
        tk.Radiobutton(left_frame, text="Class 2 Image", 
                      variable=self.input_source_var, value="class2").pack(anchor=tk.W)
        tk.Radiobutton(left_frame, text="Custom Image", 
                      variable=self.input_source_var, value="custom").pack(anchor=tk.W)
        
        # Custom image button
        self.custom_image_btn = tk.Button(left_frame, text="Load Custom Image", 
                                         command=self.load_custom_image, state=tk.DISABLED)
        self.custom_image_btn.pack(anchor=tk.W, pady=5)
        
        # Image selection (for class images)
        self.image_selection_frame = tk.Frame(left_frame)
        self.image_selection_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(self.image_selection_frame, text="Select Image:").pack(anchor=tk.W)
        self.image_index_var = tk.StringVar(value="0")
        self.image_spinbox = tk.Spinbox(self.image_selection_frame, from_=0, to=0, 
                                       textvariable=self.image_index_var, width=10)
        self.image_spinbox.pack(anchor=tk.W)
        
        # Update spinbox when source changes
        self.input_source_var.trace('w', self.update_input_controls)
        
        # Process button
        tk.Button(left_frame, text="Process Pipeline", 
                 command=self.process_pipeline, height=2, bg="lightblue").pack(fill=tk.X, pady=20)
        
        # Pipeline description
        self.pipeline_desc = tk.Label(left_frame, text="Pipeline: none", 
                                     font=("Arial", 9), wraplength=280)
        self.pipeline_desc.pack(anchor=tk.W, pady=10)
        
        # Right panel - Image display
        right_frame = tk.Frame(main_container)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Input image display
        input_frame = tk.LabelFrame(right_frame, text="Input Image", padx=5, pady=5)
        input_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.input_image_label = tk.Label(input_frame, width=256, height=256, bg="gray")
        self.input_image_label.pack(padx=5, pady=5)
        
        # Output image display
        output_frame = tk.LabelFrame(right_frame, text="Output Image", padx=5, pady=5)
        output_frame.pack(fill=tk.BOTH, expand=True)
        
        self.output_image_label = tk.Label(output_frame, width=256, height=256, bg="gray")
        self.output_image_label.pack(padx=5, pady=5)
        
        # Update pipeline description
        self.step1_var.trace('w', self.update_pipeline_desc)
        self.step2_var.trace('w', self.update_pipeline_desc)
        self.step3_var.trace('w', self.update_pipeline_desc)
    
    def update_input_controls(self, *args):
        """Enable/disable controls based on input source"""
        source = self.input_source_var.get()
        
        if source == "custom":
            self.custom_image_btn.config(state=tk.NORMAL)
            self.image_selection_frame.pack_forget()
        else:
            self.custom_image_btn.config(state=tk.DISABLED)
            self.image_selection_frame.pack(fill=tk.X, pady=5)
            
            # Update spinbox range
            if source == "class1":
                max_val = max(0, len(self.class1_paths) - 1)
            else:  # class2
                max_val = max(0, len(self.class2_paths) - 1)
            
            self.image_spinbox.config(from_=0, to=max_val)
            self.image_index_var.set("0")
    
    def update_pipeline_desc(self, *args):
        """Update pipeline description"""
        steps = []
        for step_var in [self.step1_var, self.step2_var, self.step3_var]:
            step = step_var.get()
            if step != "none":
                steps.append(step)
        
        if steps:
            desc = "Pipeline: " + " → ".join(steps)
        else:
            desc = "Pipeline: none (identity)"
        
        self.pipeline_desc.config(text=desc)
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
                status_text = message[:40] + "..." if len(message) > 40 else message
                self.status_label.config(text=status_text)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def add_images(self, class_name):
        files = filedialog.askopenfilenames(
            title=f"Select {class_name} images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        if class_name == 'class1':
            target_list = self.class1_paths
            listbox = self.class1_listbox
        else:
            target_list = self.class2_paths
            listbox = self.class2_listbox
        
        for file in files:
            if file not in target_list:
                target_list.append(file)
                filename = os.path.basename(file)
                listbox.insert(tk.END, filename)
        
        self.log_message(f"Added {len(files)} images to {class_name}. Total: {len(target_list)}")
        
        # Update sample images
        if target_list:
            self.display_sample_image(target_list[0], class_name)
    
    def clear_images(self, class_name):
        if class_name == 'class1':
            self.class1_paths = []
            self.class1_listbox.delete(0, tk.END)
            self.class1_label.config(image='')
        else:
            self.class2_paths = []
            self.class2_listbox.delete(0, tk.END)
            self.class2_label.config(image='')
        
        self.log_message(f"Cleared all {class_name} images")
    
    def display_sample_image(self, path, class_name):
        try:
            img = Image.open(path).convert('RGB')
            img = img.resize((128, 128), Image.NEAREST)
            photo = ImageTk.PhotoImage(img)
            
            if class_name == 'class1':
                self.class1_label.config(image=photo)
                self.class1_label.image = photo
            else:
                self.class2_label.config(image=photo)
                self.class2_label.image = photo
        except:
            pass
    
    def initialize_model(self):
        try:
            image_size = int(self.size_var.get())
            self.model = DualAutoencoderSystem(image_size=image_size)
            self.log_message(f"Initialized Dual Autoencoder System for {image_size}x{image_size} images")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            self.perf_label.config(text=f"CPU Threads: {torch.get_num_threads()}\nData Workers: {self.num_workers}")
        except Exception as e:
            self.log_message(f"Error initializing model: {str(e)}")
    
    def start_training(self):
        if not self.class1_paths or not self.class2_paths:
            self.log_message("Error: Need images for both classes!")
            return
        
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            image_size = int(self.size_var.get())
            
            self.training = True
            self.current_epoch = 0
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_model,
                args=(epochs, image_size),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Class 1: {len(self.class1_paths)} images, Class 2: {len(self.class2_paths)} images")
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
    
    def train_model(self, epochs, image_size):
        try:
            # Create dataset
            dataset = PairedImageDataset(
                self.class1_paths, 
                self.class2_paths, 
                image_size
            )
            
            if len(dataset) == 0:
                self.log_message("Error: Could not create valid pairs!")
                return
            
            dataloader = DataLoader(
                dataset, 
                batch_size=8, 
                shuffle=True,
                num_workers=self.num_workers,
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss1 = 0
                total_loss2 = 0
                total_loss = 0
                batch_count = 0
                
                for i, (class1_batch, class2_batch) in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    loss1, loss2, loss_total = self.model.train_step(class1_batch, class2_batch)
                    
                    total_loss1 += loss1
                    total_loss2 += loss2
                    total_loss += loss_total
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss1 = total_loss1 / batch_count
                    avg_loss2 = total_loss2 / batch_count
                    avg_total = total_loss / batch_count
                    
                    self.log_message(f"Epoch {epoch+1}/{epochs} | AE1 Loss: {avg_loss1:.4f} | AE2 Loss: {avg_loss2:.4f} | Total: {avg_total:.4f}")
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
                
                # Generate and display transformation samples every 5 epochs
                if (epoch + 1) % 5 == 0:
                    self.display_transformation_sample()
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
    
    def display_transformation_sample(self):
        """Display sample transformation during training"""
        if not self.model or not self.class1_paths:
            return
        
        try:
            # Load a sample image from class1
            sample_path = self.class1_paths[0]
            img = Image.open(sample_path).convert('RGB')
            
            transform = transforms.Compose([
                transforms.Resize((int(self.size_var.get()), int(self.size_var.get()))),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            img_tensor = transform(img).unsqueeze(0).to(self.model.device)
            
            # Transform through AE1
            with torch.no_grad():
                transformed = self.model.ae1(img_tensor)
                
                # Convert to display image
                display_img = transformed[0].cpu()
                display_img = (display_img + 1) / 2  # Denormalize
                display_img = transforms.ToPILImage()(display_img)
                display_img = display_img.resize((128, 128), Image.NEAREST)
                
                # Update display
                photo = ImageTk.PhotoImage(display_img)
                self.ae1_label.config(image=photo)
                self.ae1_label.image = photo
                
        except Exception as e:
            pass
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")
    
    def load_custom_image(self):
        file = filedialog.askopenfilename(
            title="Select custom image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        if file:
            self.custom_image_path = file
            self.display_custom_image(file)
            self.log_message(f"Loaded custom image: {os.path.basename(file)}")
    
    def display_custom_image(self, path):
        try:
            img = Image.open(path).convert('RGB')
            img = img.resize((256, 256), Image.NEAREST)
            photo = ImageTk.PhotoImage(img)
            self.input_image_label.config(image=photo)
            self.input_image_label.image = photo
            self.current_custom_image = img
        except Exception as e:
            self.log_message(f"Error loading custom image: {str(e)}")
    
    def process_pipeline(self):
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        # Get pipeline steps
        pipeline = []
        for step_var in [self.step1_var, self.step2_var, self.step3_var]:
            step = step_var.get()
            if step != "none":
                pipeline.append(step)
        
        if not pipeline:
            self.log_message("Pipeline is empty (no transformations)")
            return
        
        try:
            # Get input image
            source = self.input_source_var.get()
            
            if source == "custom":
                if not hasattr(self, 'current_custom_image'):
                    self.log_message("Error: No custom image loaded!")
                    return
                
                img = self.current_custom_image
                img_size = int(self.size_var.get())
                
                transform = transforms.Compose([
                    transforms.Resize((img_size, img_size)),
                    transforms.ToTensor(),
                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
                ])
                
                img_tensor = transform(img).unsqueeze(0)
                
            else:  # class1 or class2
                if source == "class1":
                    paths = self.class1_paths
                else:
                    paths = self.class2_paths
                
                if not paths:
                    self.log_message(f"Error: No {source} images available!")
                    return
                
                idx = int(self.image_index_var.get())
                if idx >= len(paths):
                    idx = 0
                
                img = Image.open(paths[idx]).convert('RGB')
                img_size = int(self.size_var.get())
                
                transform = transforms.Compose([
                    transforms.Resize((img_size, img_size)),
                    transforms.ToTensor(),
                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
                ])
                
                img_tensor = transform(img).unsqueeze(0)
                
                # Display input image
                display_img = img.resize((256, 256), Image.NEAREST)
                photo = ImageTk.PhotoImage(display_img)
                self.input_image_label.config(image=photo)
                self.input_image_label.image = photo
            
            # Apply pipeline
            with torch.no_grad():
                output_tensor = self.model.transform_image(img_tensor, pipeline)
                
                # Convert output to display
                output_img = output_tensor[0]
                output_img = (output_img + 1) / 2  # Denormalize
                output_img = transforms.ToPILImage()(output_img)
                output_img = output_img.resize((256, 256), Image.NEAREST)
                
                # Display output
                photo = ImageTk.PhotoImage(output_img)
                self.output_image_label.config(image=photo)
                self.output_image_label.image = photo
            
            self.log_message(f"Processed image through pipeline: {' → '.join(pipeline)}")
            
        except Exception as e:
            self.log_message(f"Error processing pipeline: {str(e)}")
            import traceback
            traceback.print_exc()

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Dual Autoencoder System with 2 cores...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    
    # Set multiprocessing start method for compatibility
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = AutoencoderApp(root)
    root.mainloop()