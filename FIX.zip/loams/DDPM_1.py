import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import math
import traceback

# ==================== DDPM Model (Standard Noise Prediction) ====================

class SimpleDDPM:
    def __init__(self, image_size=32, latent_dim=64, nf=64, timesteps=100):
        self.image_size = image_size
        self.latent_dim = latent_dim
        self.timesteps = timesteps
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Pre-compute noise schedule
        self.betas = torch.linspace(1e-4, 0.02, timesteps)
        self.alphas = 1. - self.betas
        self.alpha_cumprod = torch.cumprod(self.alphas, dim=0)
        self.sqrt_alpha_cumprod = torch.sqrt(self.alpha_cumprod)
        self.sqrt_one_minus_alpha_cumprod = torch.sqrt(1. - self.alpha_cumprod)
        
        # Compute reverse process parameters
        self.sqrt_recip_alphas = torch.sqrt(1.0 / self.alphas)
        self.alphas_cumprod_prev = torch.cat([torch.tensor([1.0]), self.alpha_cumprod[:-1]])
        
        # Calculate posterior variance: β̃_t = (1 - α̅_{t-1})/(1 - α̅_t) * β_t
        self.posterior_variance = self.betas * (1. - self.alphas_cumprod_prev) / (1. - self.alpha_cumprod)
        
        # U-Net for noise prediction (standard DDPM)
        class UNet(nn.Module):
            def __init__(self, in_channels=3, nf=64, timesteps=100):
                super().__init__()
                self.timesteps = timesteps
                
                # Timestep embedding
                self.time_embed = nn.Sequential(
                    nn.Linear(1, nf * 4),
                    nn.ReLU(),
                    nn.Linear(nf * 4, nf * 4)
                )
                
                # Project time embedding to different feature sizes
                self.time_proj_bottleneck = nn.Conv2d(nf * 4, nf * 4, 1, 1, 0)
                self.time_proj_enc1 = nn.Conv2d(nf * 4, nf, 1, 1, 0)
                self.time_proj_enc2 = nn.Conv2d(nf * 4, nf * 2, 1, 1, 0)
                
                # Encoder
                self.enc1 = nn.Sequential(
                    nn.Conv2d(in_channels, nf, 3, 1, 1),
                    nn.BatchNorm2d(nf),
                    nn.ReLU(),
                    nn.Conv2d(nf, nf, 3, 1, 1),
                    nn.BatchNorm2d(nf),
                    nn.ReLU()
                )
                
                self.pool1 = nn.MaxPool2d(2)
                
                self.enc2 = nn.Sequential(
                    nn.Conv2d(nf, nf * 2, 3, 1, 1),
                    nn.BatchNorm2d(nf * 2),
                    nn.ReLU(),
                    nn.Conv2d(nf * 2, nf * 2, 3, 1, 1),
                    nn.BatchNorm2d(nf * 2),
                    nn.ReLU()
                )
                
                self.pool2 = nn.MaxPool2d(2)
                
                # Bottleneck
                self.bottleneck = nn.Sequential(
                    nn.Conv2d(nf * 2, nf * 4, 3, 1, 1),
                    nn.BatchNorm2d(nf * 4),
                    nn.ReLU(),
                    nn.Conv2d(nf * 4, nf * 4, 3, 1, 1),
                    nn.BatchNorm2d(nf * 4),
                    nn.ReLU(),
                    nn.Conv2d(nf * 4, nf * 4, 3, 1, 1),
                    nn.BatchNorm2d(nf * 4),
                    nn.ReLU()
                )
                
                # Decoder
                self.up2 = nn.ConvTranspose2d(nf * 4, nf * 2, 2, 2)
                self.dec2 = nn.Sequential(
                    nn.Conv2d(nf * 4, nf * 2, 3, 1, 1),
                    nn.BatchNorm2d(nf * 2),
                    nn.ReLU(),
                    nn.Conv2d(nf * 2, nf, 3, 1, 1),
                    nn.BatchNorm2d(nf),
                    nn.ReLU()
                )
                
                self.up1 = nn.ConvTranspose2d(nf, nf, 2, 2)
                self.dec1 = nn.Sequential(
                    nn.Conv2d(nf * 2, nf, 3, 1, 1),
                    nn.BatchNorm2d(nf),
                    nn.ReLU(),
                    nn.Conv2d(nf, 3, 3, 1, 1)
                )
                
            def forward(self, x, t):
                # Normalize timestep to [0, 1]
                t_norm = t.float() / self.timesteps
                t_norm = t_norm.view(-1, 1)
                
                # Time embedding
                time_feat = self.time_embed(t_norm)
                time_feat = time_feat.view(-1, time_feat.size(1), 1, 1)
                
                # Encoder
                enc1_out = self.enc1(x)
                pool1_out = self.pool1(enc1_out)
                
                enc2_out = self.enc2(pool1_out)
                pool2_out = self.pool2(enc2_out)
                
                # Bottleneck with time conditioning
                bottleneck_out = self.bottleneck(pool2_out)
                
                time_proj_bottleneck = self.time_proj_bottleneck(time_feat)
                _, _, h, w = bottleneck_out.shape
                time_proj_bottleneck = nn.functional.interpolate(
                    time_proj_bottleneck, size=(h, w), mode='nearest'
                )
                bottleneck_out = bottleneck_out + time_proj_bottleneck
                
                # Add time conditioning to encoder features
                time_proj_enc1 = self.time_proj_enc1(time_feat)
                _, _, h1, w1 = enc1_out.shape
                time_proj_enc1 = nn.functional.interpolate(
                    time_proj_enc1, size=(h1, w1), mode='nearest'
                )
                enc1_out = enc1_out + time_proj_enc1
                
                time_proj_enc2 = self.time_proj_enc2(time_feat)
                _, _, h2, w2 = enc2_out.shape
                time_proj_enc2 = nn.functional.interpolate(
                    time_proj_enc2, size=(h2, w2), mode='nearest'
                )
                enc2_out = enc2_out + time_proj_enc2
                
                # Decoder with skip connections
                up2_out = self.up2(bottleneck_out)
                if up2_out.shape[2:] != enc2_out.shape[2:]:
                    up2_out = nn.functional.interpolate(
                        up2_out, size=enc2_out.shape[2:], mode='nearest'
                    )
                dec2_in = torch.cat([up2_out, enc2_out], dim=1)
                dec2_out = self.dec2(dec2_in)
                
                up1_out = self.up1(dec2_out)
                if up1_out.shape[2:] != enc1_out.shape[2:]:
                    up1_out = nn.functional.interpolate(
                        up1_out, size=enc1_out.shape[2:], mode='nearest'
                    )
                dec1_in = torch.cat([up1_out, enc1_out], dim=1)
                output = self.dec1(dec1_in)
                
                return output
        
        self.unet = UNet(nf=nf, timesteps=timesteps)
        
        # Loss - MSE for noise prediction (standard DDPM)
        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(self.unet.parameters(), lr=0.0001, betas=(0.5, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.unet.to(self.device)
        
        # Move schedules to device
        self.betas = self.betas.to(self.device)
        self.alphas = self.alphas.to(self.device)
        self.alpha_cumprod = self.alpha_cumprod.to(self.device)
        self.sqrt_alpha_cumprod = self.sqrt_alpha_cumprod.to(self.device)
        self.sqrt_one_minus_alpha_cumprod = self.sqrt_one_minus_alpha_cumprod.to(self.device)
        self.sqrt_recip_alphas = self.sqrt_recip_alphas.to(self.device)
        self.alphas_cumprod_prev = self.alphas_cumprod_prev.to(self.device)
        self.posterior_variance = self.posterior_variance.to(self.device)
    
    def add_noise(self, x, t):
        """Add noise to images at timestep t"""
        noise = torch.randn_like(x)
        sqrt_alpha_cumprod_t = self.sqrt_alpha_cumprod[t]
        sqrt_one_minus_alpha_cumprod_t = self.sqrt_one_minus_alpha_cumprod[t]
        
        sqrt_alpha_cumprod_t = sqrt_alpha_cumprod_t.view(-1, 1, 1, 1)
        sqrt_one_minus_alpha_cumprod_t = sqrt_one_minus_alpha_cumprod_t.view(-1, 1, 1, 1)
        
        noisy_x = sqrt_alpha_cumprod_t * x + sqrt_one_minus_alpha_cumprod_t * noise
        return noisy_x, noise
    
    def predict_noise(self, x, t):
        """Predict the noise in the noisy image (standard DDPM)"""
        if t.dim() == 0:
            t = t.unsqueeze(0)
        
        predicted_noise = self.unet(x, t)
        return predicted_noise

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class DDPMApp:
    def __init__(self, root):
        self.root = root
        self.root.title("DDPM Trainer - Multi-Core (Standard Noise Prediction)")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.ddpm = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_dim': tk.IntVar(value=64),
            'nf': tk.IntVar(value=64),
            'timesteps': tk.IntVar(value=100),
            'batch_size': tk.IntVar(value=4),
            'learning_rate': tk.DoubleVar(value=0.0001),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(2, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
            'generate_interval': tk.IntVar(value=5)
        }
        
        # Sampling settings
        self.sampling_settings = {
            'sampling_steps': tk.IntVar(value=100),
            'sampling_noise': tk.DoubleVar(value=0.05)
        }
        
        # Performance tracking
        self.num_workers = min(2, multiprocessing.cpu_count())
        self.start_time = None
        
        # For storing generated images
        self.generated_images = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="DDPM Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text="Image Size: 32x32")
        self.size_display.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize DDPM", 
                 command=self.initialize_ddpm, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Single image display
        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="DDPM Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Image size
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed)", width=20, anchor='w').pack(side=tk.LEFT, padx=5)
        
        # Network parameters
        settings_list = [
            ("Latent Dimension:", 'latent_dim', 16, 128),
            ("Network Features (nf):", 'nf', 32, 256),
            ("Timesteps:", 'timesteps', 10, 1000),
            ("Batch Size:", 'batch_size', 1, 32),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(4, multiprocessing.cpu_count())),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Sampling settings
        sampling_frame = tk.LabelFrame(scrollable_frame, text="Sampling Parameters", padx=10, pady=10)
        sampling_frame.pack(fill=tk.X, pady=(0, 10))
        
        sampling_settings = [
            ("Sampling Steps:", 'sampling_steps', 10, 1000),
            ("Sampling Noise:", 'sampling_noise', 0.0, 0.9),
        ]
        
        for label_text, var_name, min_val, max_val in sampling_settings:
            frame = tk.Frame(sampling_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.sampling_settings[var_name],
                    orient=tk.HORIZONTAL, length=200, resolution=0.01 if var_name == 'sampling_noise' else 1).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.sampling_settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset to Fast", 
                 command=self.reset_to_fast, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load DDPM", 
                 command=self.load_ddpm, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=4)
        tk.Scale(gen_frame, from_=1, to=16, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def update_size_display(self):
        self.size_display.config(text="Image Size: 32x32")

    def log_message(self, message):
        self.message_queue.put(message)

    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_ddpm(self):
        try:
            image_size = self.settings['image_size'].get()
            latent_dim = self.settings['latent_dim'].get()
            nf = self.settings['nf'].get()
            timesteps = self.settings['timesteps'].get()
            
            self.ddpm = SimpleDDPM(
                image_size=image_size,
                latent_dim=latent_dim,
                nf=nf,
                timesteps=timesteps
            )
            
            self.log_message(f"Initialized DDPM for {image_size}x{image_size} images")
            self.log_message(f"Latent dim: {latent_dim}, Features: {nf}, Timesteps: {timesteps}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing DDPM: {str(e)}")
            self.log_message(f"Traceback: {traceback.format_exc()}")

    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.ddpm:
            self.log_message("Error: DDPM not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            
            # Update optimizer
            for param_group in self.ddpm.optimizer.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_ddpm,
                args=(epochs, batch_size, num_workers),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}")
            self.log_message(f"Using standard DDPM with noise prediction and MSE loss")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_ddpm(self, epochs, batch_size, num_workers):
        try:
            image_size = self.settings['image_size'].get()
            generate_interval = self.settings['generate_interval'].get()
            
            # Create dataset and dataloader
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss = 0
                batch_count = 0
                epoch_start = time.time()
                
                for clean_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = clean_images.size(0)
                    clean_images = clean_images.to(self.ddpm.device)
                    
                    # Train DDPM
                    self.ddpm.optimizer.zero_grad()
                    
                    # Sample random timesteps
                    t = torch.randint(0, self.ddpm.timesteps, (batch_size_actual,), 
                                     device=self.ddpm.device)
                    
                    # Add noise to images
                    noisy_images, noise = self.ddpm.add_noise(clean_images, t)
                    
                    # Network predicts the noise (standard DDPM)
                    predicted_noise = self.ddpm.predict_noise(noisy_images, t)
                    
                    # Loss - MSE between predicted and actual noise
                    loss = self.ddpm.criterion(predicted_noise, noise)
                    loss.backward()
                    self.ddpm.optimizer.step()
                    
                    total_loss += loss.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss = total_loss / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"MSE Loss: {avg_loss:.6f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Total: {elapsed:.1f}s")
                    
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.log_message(f"Traceback: {traceback.format_exc()}")
            self.training = False
        finally:
            self.training = False

    def generate_training_samples(self):
        if not self.ddpm:
            return
        
        try:
            with torch.no_grad():
                # Use fewer steps during training for speed
                steps = min(30, self.ddpm.timesteps)
                # Create a linearly spaced set of timesteps from the total
                sampling_timesteps = torch.linspace(0, self.ddpm.timesteps-1, steps, dtype=torch.long).flip(0)
                
                # Start from pure noise
                x = torch.randn(1, 3, self.ddpm.image_size, self.ddpm.image_size).to(self.ddpm.device)
                
                # Reverse diffusion process
                for t in sampling_timesteps:
                    t_tensor = torch.full((1,), t, device=self.ddpm.device, dtype=torch.long)
                    
                    # Predict noise
                    predicted_noise = self.ddpm.predict_noise(x, t_tensor)
                    
                    # Get the parameters for this timestep
                    alpha_t = self.ddpm.alphas[t]
                    sqrt_recip_alpha_t = self.ddpm.sqrt_recip_alphas[t]
                    beta_t = self.ddpm.betas[t]
                    sqrt_one_minus_alpha_cumprod_t = self.ddpm.sqrt_one_minus_alpha_cumprod[t]
                    
                    # Predict x0
                    predicted_x0 = (x - sqrt_one_minus_alpha_cumprod_t * predicted_noise) / self.ddpm.sqrt_alpha_cumprod[t]
                    
                    if t > 0:
                        # Get posterior variance
                        posterior_variance_t = self.ddpm.posterior_variance[t]
                        
                        # Sample from the posterior
                        noise = torch.randn_like(x)
                        x = sqrt_recip_alpha_t * (x - beta_t / sqrt_one_minus_alpha_cumprod_t * predicted_noise) + \
                            torch.sqrt(posterior_variance_t) * noise
                    else:
                        x = predicted_x0
                
                img_tensor = x[0].cpu()
                img = self.tensor_to_pil(img_tensor)
                
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
                
                self.log_message(f"Generated training sample at epoch {self.current_epoch + 1} (using {steps} steps)")
                
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")
            self.log_message(f"Traceback: {traceback.format_exc()}")

    def tensor_to_pil(self, tensor):
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        if not self.ddpm:
            self.log_message("Error: DDPM not initialized!")
            return
        
        try:
            with torch.no_grad():
                # Get sampling settings
                requested_steps = self.sampling_settings['sampling_steps'].get()
                sampling_noise = self.sampling_settings['sampling_noise'].get()
                
                # Clamp steps to model's timesteps
                steps = min(requested_steps, self.ddpm.timesteps)
                
                self.log_message(f"Generating sample with {steps} steps (requested: {requested_steps})...")
                
                # Create a linearly spaced set of timesteps from the total
                sampling_timesteps = torch.linspace(0, self.ddpm.timesteps-1, steps, dtype=torch.long).flip(0)
                
                # Start from pure noise
                x = torch.randn(1, 3, self.ddpm.image_size, self.ddpm.image_size).to(self.ddpm.device)
                
                # Reverse diffusion process
                for t in sampling_timesteps:
                    t_tensor = torch.full((1,), t, device=self.ddpm.device, dtype=torch.long)
                    
                    # Predict noise
                    predicted_noise = self.ddpm.predict_noise(x, t_tensor)
                    
                    # Get the parameters for this timestep
                    alpha_t = self.ddpm.alphas[t]
                    sqrt_recip_alpha_t = self.ddpm.sqrt_recip_alphas[t]
                    beta_t = self.ddpm.betas[t]
                    sqrt_one_minus_alpha_cumprod_t = self.ddpm.sqrt_one_minus_alpha_cumprod[t]
                    
                    # Predict x0
                    predicted_x0 = (x - sqrt_one_minus_alpha_cumprod_t * predicted_noise) / self.ddpm.sqrt_alpha_cumprod[t]
                    
                    if t > 0:
                        # Get posterior variance
                        posterior_variance_t = self.ddpm.posterior_variance[t]
                        
                        # Sample from the posterior
                        noise = torch.randn_like(x)
                        x = sqrt_recip_alpha_t * (x - beta_t / sqrt_one_minus_alpha_cumprod_t * predicted_noise) + \
                            torch.sqrt(posterior_variance_t) * noise * sampling_noise
                    else:
                        x = predicted_x0
                
                img_tensor = x[0].cpu()
                img = self.tensor_to_pil(img_tensor)
                
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
                
                self.log_message(f"Generated sample with {steps} steps")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")
            self.log_message(f"Traceback: {traceback.format_exc()}")

    def save_model(self):
        if not self.ddpm:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'unet_state_dict': self.ddpm.unet.state_dict(),
                    'optimizer_state_dict': self.ddpm.optimizer.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'nf': self.settings['nf'].get(),
                    'timesteps': self.settings['timesteps'].get(),
                    'betas': self.ddpm.betas.cpu(),
                    'alphas': self.ddpm.alphas.cpu(),
                    'alpha_cumprod': self.ddpm.alpha_cumprod.cpu(),
                    'sqrt_recip_alphas': self.ddpm.sqrt_recip_alphas.cpu(),
                    'alphas_cumprod_prev': self.ddpm.alphas_cumprod_prev.cpu(),
                    'posterior_variance': self.ddpm.posterior_variance.cpu(),
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_ddpm(self):
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                if 'image_size' in checkpoint:
                    self.settings['image_size'].set(checkpoint['image_size'])
                    self.update_size_display()
                
                if 'latent_dim' in checkpoint:
                    self.settings['latent_dim'].set(checkpoint['latent_dim'])
                
                if 'nf' in checkpoint:
                    self.settings['nf'].set(checkpoint['nf'])
                
                if 'timesteps' in checkpoint:
                    self.settings['timesteps'].set(checkpoint['timesteps'])
                
                # Initialize DDPM with loaded settings
                self.initialize_ddpm()
                
                # Load state dicts
                self.ddpm.unet.load_state_dict(checkpoint['unet_state_dict'])
                if 'optimizer_state_dict' in checkpoint:
                    self.ddpm.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                
                # Load noise schedules
                if 'betas' in checkpoint:
                    self.ddpm.betas = checkpoint['betas'].to(self.ddpm.device)
                    self.ddpm.alphas = checkpoint['alphas'].to(self.ddpm.device)
                    self.ddpm.alpha_cumprod = checkpoint['alpha_cumprod'].to(self.ddpm.device)
                    self.ddpm.sqrt_alpha_cumprod = torch.sqrt(self.ddpm.alpha_cumprod)
                    self.ddpm.sqrt_one_minus_alpha_cumprod = torch.sqrt(1. - self.ddpm.alpha_cumprod)
                    self.ddpm.sqrt_recip_alphas = torch.sqrt(1.0 / self.ddpm.alphas)
                    self.ddpm.alphas_cumprod_prev = torch.cat([
                        torch.tensor([1.0], device=self.ddpm.device), 
                        self.ddpm.alpha_cumprod[:-1]
                    ])
                    self.ddpm.posterior_variance = self.ddpm.betas * (1. - self.ddpm.alphas_cumprod_prev) / (1. - self.ddpm.alpha_cumprod)
                
                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        if not self.ddpm:
            self.log_message("Error: DDPM not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            requested_steps = self.sampling_settings['sampling_steps'].get()
            sampling_noise = self.sampling_settings['sampling_noise'].get()
            
            # Clamp steps to model's timesteps
            steps = min(requested_steps, self.ddpm.timesteps)
            
            self.log_message(f"Generating {num_images} images with {steps} steps each (requested: {requested_steps})...")
            start_time = time.time()
            
            with torch.no_grad():
                all_images = []
                
                for img_idx in range(num_images):
                    # Start from pure noise
                    x = torch.randn(1, 3, self.ddpm.image_size, self.ddpm.image_size).to(self.ddpm.device)
                    
                    # Create a linearly spaced set of timesteps
                    sampling_timesteps = torch.linspace(0, self.ddpm.timesteps-1, steps, dtype=torch.long).flip(0)
                    
                    # Reverse diffusion process
                    for t in sampling_timesteps:
                        t_tensor = torch.full((1,), t, device=self.ddpm.device, dtype=torch.long)
                        
                        # Predict noise
                        predicted_noise = self.ddpm.predict_noise(x, t_tensor)
                        
                        # Get the parameters for this timestep
                        alpha_t = self.ddpm.alphas[t]
                        sqrt_recip_alpha_t = self.ddpm.sqrt_recip_alphas[t]
                        beta_t = self.ddpm.betas[t]
                        sqrt_one_minus_alpha_cumprod_t = self.ddpm.sqrt_one_minus_alpha_cumprod[t]
                        
                        # Predict x0
                        predicted_x0 = (x - sqrt_one_minus_alpha_cumprod_t * predicted_noise) / self.ddpm.sqrt_alpha_cumprod[t]
                        
                        if t > 0:
                            # Get posterior variance
                            posterior_variance_t = self.ddpm.posterior_variance[t]
                            
                            # Sample from the posterior
                            noise = torch.randn_like(x)
                            x = sqrt_recip_alpha_t * (x - beta_t / sqrt_one_minus_alpha_cumprod_t * predicted_noise) + \
                                torch.sqrt(posterior_variance_t) * noise * sampling_noise
                        else:
                            x = predicted_x0
                    
                    all_images.append(x[0].cpu())
                
                # Clear previous images
                for widget in self.gen_scroll_frame.winfo_children():
                    widget.destroy()
                
                # Create grid
                cols = 2 if num_images <= 4 else 4
                rows = (num_images + cols - 1) // cols
                
                for i in range(rows):
                    row_frame = tk.Frame(self.gen_scroll_frame)
                    row_frame.pack(pady=5)
                    
                    for j in range(cols):
                        idx = i * cols + j
                        if idx < num_images:
                            img_tensor = all_images[idx]
                            img = self.tensor_to_pil(img_tensor)
                            img_display = img.resize((128, 128), Image.Resampling.NEAREST)
                            photo = ImageTk.PhotoImage(img_display)
                            
                            label = tk.Label(row_frame, image=photo)
                            label.image = photo
                            label.pack(side=tk.LEFT, padx=5)
            
            generation_time = time.time() - start_time
            self.log_message(f"Generated {num_images} images in {generation_time:.1f}s ({steps} steps each)")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")
            self.log_message(f"Traceback: {traceback.format_exc()}")

    def save_defaults(self):
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            defaults.update({k: v.get() for k, v in self.sampling_settings.items()})
            import json
            with open('ddpm_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        try:
            import json
            if os.path.exists('ddpm_defaults.json'):
                with open('ddpm_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                    elif key in self.sampling_settings:
                        self.sampling_settings[key].set(value)
                
                self.update_size_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_to_fast(self):
        fast_settings = {
            'image_size': 32,
            'latent_dim': 64,
            'nf': 64,
            'timesteps': 100,
            'batch_size': 2,
            'learning_rate': 0.0001,
            'beta1': 0.5,
            'num_workers': min(2, multiprocessing.cpu_count()),
            'save_interval': 10,
            'generate_interval': 5,
            'sampling_steps': 100,
            'sampling_noise': 0.05
        }
        
        for key, value in fast_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
            elif key in self.sampling_settings:
                self.sampling_settings[key].set(value)
        
        self.update_size_display()
        self.log_message("Reset to fast CPU training settings")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting DDPM Trainer (Standard Noise Prediction)...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = DDPMApp(root)
    root.mainloop()