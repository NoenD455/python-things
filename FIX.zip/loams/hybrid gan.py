import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import math

# ==================== Hybrid GAN ====================

class HybridGAN:
    def __init__(self, image_size=32, latent_dim=128, ngf=64, ndf=64):
        """
        Hybrid GAN combining:
        1. LSGAN: Least Squares loss for stability
        2. WGAN-GP: Gradient penalty for Lipschitz constraint
        3. EBGAN: Energy-based for diversity
        """
        self.image_size = image_size
        self.latent_dim = latent_dim
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Generator with residual connections
        class Generator(nn.Module):
            def __init__(self, image_size, latent_dim, ngf):
                super().__init__()
                self.image_size = image_size
                
                # Initial projection
                self.projection = nn.Sequential(
                    nn.ConvTranspose2d(latent_dim, ngf * 8, 4, 1, 0, bias=False),
                    nn.BatchNorm2d(ngf * 8),
                    nn.LeakyReLU(0.2, inplace=True)
                )
                
                # Main layers for 32x32
                if image_size == 32:
                    self.main = nn.Sequential(
                        # 8ngf x 4 x 4
                        nn.ConvTranspose2d(ngf * 8, ngf * 4, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(ngf * 4),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 4ngf x 8 x 8
                        nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(ngf * 2),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 2ngf x 16 x 16
                        nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(ngf),
                        nn.LeakyReLU(0.2, inplace=True),
                        # ngf x 32 x 32
                        nn.Conv2d(ngf, 3, 3, 1, 1, bias=False),
                        nn.Tanh()
                    )
                else:  # 64x64
                    self.main = nn.Sequential(
                        nn.ConvTranspose2d(ngf * 8, ngf * 8, 4, 1, 0, bias=False),
                        nn.BatchNorm2d(ngf * 8),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 8ngf x 4 x 4
                        nn.ConvTranspose2d(ngf * 8, ngf * 4, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(ngf * 4),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 4ngf x 8 x 8
                        nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(ngf * 2),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 2ngf x 16 x 16
                        nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(ngf),
                        nn.LeakyReLU(0.2, inplace=True),
                        # ngf x 32 x 32
                        nn.ConvTranspose2d(ngf, ngf // 2, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(ngf // 2),
                        nn.LeakyReLU(0.2, inplace=True),
                        # ngf/2 x 64 x 64
                        nn.Conv2d(ngf // 2, 3, 3, 1, 1, bias=False),
                        nn.Tanh()
                    )
                
            def forward(self, z):
                x = self.projection(z)
                return self.main(x)
        
        # Discriminator with spectral normalization
        class Discriminator(nn.Module):
            def __init__(self, image_size, ndf):
                super().__init__()
                
                def spectral_norm(module):
                    return nn.utils.spectral_norm(module)
                
                # Main convolutional path
                if image_size == 32:
                    self.conv_path = nn.Sequential(
                        # 3 x 32 x 32
                        spectral_norm(nn.Conv2d(3, ndf, 4, 2, 1, bias=False)),
                        nn.LeakyReLU(0.2, inplace=True),
                        # ndf x 16 x 16
                        spectral_norm(nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False)),
                        nn.InstanceNorm2d(ndf * 2),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 2ndf x 8 x 8
                        spectral_norm(nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False)),
                        nn.InstanceNorm2d(ndf * 4),
                        nn.LeakyReLU(0.2, inplace=True),
                        # 4ndf x 4 x 4
                    )
                    final_channels = ndf * 4
                else:  # 64x64
                    self.conv_path = nn.Sequential(
                        spectral_norm(nn.Conv2d(3, ndf, 4, 2, 1, bias=False)),
                        nn.LeakyReLU(0.2, inplace=True),
                        spectral_norm(nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False)),
                        nn.InstanceNorm2d(ndf * 2),
                        nn.LeakyReLU(0.2, inplace=True),
                        spectral_norm(nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False)),
                        nn.InstanceNorm2d(ndf * 4),
                        nn.LeakyReLU(0.2, inplace=True),
                        spectral_norm(nn.Conv2d(ndf * 4, ndf * 8, 4, 2, 1, bias=False)),
                        nn.InstanceNorm2d(ndf * 8),
                        nn.LeakyReLU(0.2, inplace=True),
                    )
                    final_channels = ndf * 8
                
                # Output head for adversarial loss
                self.adv_head = spectral_norm(nn.Conv2d(final_channels, 1, 4, 1, 0, bias=False))
                
                # Autoencoder for energy (EBGAN component)
                self.encoder = nn.Sequential(
                    spectral_norm(nn.Conv2d(final_channels, final_channels // 2, 3, 1, 1, bias=False)),
                    nn.InstanceNorm2d(final_channels // 2),
                    nn.LeakyReLU(0.2, inplace=True),
                )
                
                self.decoder = nn.Sequential(
                    spectral_norm(nn.ConvTranspose2d(final_channels // 2, final_channels, 3, 1, 1, bias=False)),
                    nn.InstanceNorm2d(final_channels),
                    nn.LeakyReLU(0.2, inplace=True),
                )
                
                self.reconstruction = spectral_norm(nn.Conv2d(final_channels, 3, 3, 1, 1, bias=False))
                
            def forward(self, x, return_energy=False):
                features = self.conv_path(x)
                
                # Adversarial output
                adv_out = self.adv_head(features).view(x.size(0), -1).mean(1, keepdim=True)
                
                if return_energy:
                    # Encode and decode for energy calculation
                    encoded = self.encoder(features)
                    decoded = self.decoder(encoded)
                    
                    # Reconstruct image at feature resolution
                    recon_features = self.reconstruction(decoded)
                    
                    # Upsample to match input size if needed
                    if recon_features.shape[-2:] != x.shape[-2:]:
                        recon_features = nn.functional.interpolate(
                            recon_features, size=x.shape[-2:], mode='bilinear', align_corners=False
                        )
                    
                    # Energy = MSE between input and reconstruction
                    energy = torch.mean((x - recon_features) ** 2, dim=[1, 2, 3]).unsqueeze(1)
                    return adv_out, energy
                
                return adv_out
        
        # Create networks
        self.generator = Generator(image_size, latent_dim, ngf)
        self.discriminator = Discriminator(image_size, ndf)
        
        # Loss functions
        self.mse_loss = nn.MSELoss()
        
        # Optimizers
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
        
        # Hyperparameters
        self.lambda_gp = 10.0  # Gradient penalty weight
        self.lambda_energy = 0.1  # Energy term weight
        
        # Monitoring
        self.real_energy = 0
        self.fake_energy = 0

    def compute_gradient_penalty(self, real_images, fake_images):
        """Calculate gradient penalty for WGAN-GP"""
        batch_size = real_images.size(0)
        
        # Random interpolation
        alpha = torch.rand(batch_size, 1, 1, 1, device=self.device)
        interpolated = (alpha * real_images + ((1 - alpha) * fake_images)).requires_grad_(True)
        
        # Discriminator output
        d_interpolated = self.discriminator(interpolated, return_energy=False)
        
        # Compute gradients
        gradients = torch.autograd.grad(
            outputs=d_interpolated,
            inputs=interpolated,
            grad_outputs=torch.ones_like(d_interpolated),
            create_graph=True,
            retain_graph=True,
            only_inputs=True
        )[0]
        
        gradients = gradients.view(batch_size, -1)
        gradient_norm = gradients.norm(2, dim=1)
        gradient_penalty = torch.mean((gradient_norm - 1.0) ** 2)
        
        return gradient_penalty

    def train_discriminator_step(self, real_images, batch_size):
        """Train discriminator with hybrid losses"""
        self.optimizerD.zero_grad()
        
        # Generate fake images
        noise = torch.randn(batch_size, self.latent_dim, 1, 1, device=self.device)
        with torch.no_grad():
            fake_images = self.generator(noise)
        
        # Get discriminator outputs with energy
        d_real, energy_real = self.discriminator(real_images, return_energy=True)
        d_fake, energy_fake = self.discriminator(fake_images, return_energy=True)
        
        # LSGAN loss (Least Squares)
        lsgan_loss_real = torch.mean((d_real - 1.0) ** 2)  # Real should be 1
        lsgan_loss_fake = torch.mean(d_fake ** 2)  # Fake should be 0
        
        # EBGAN energy loss
        energy_loss_real = torch.mean(energy_real)  # Real should have low energy
        energy_loss_fake = torch.relu(0.3 - energy_fake).mean()  # Push fake energy below threshold
        
        # WGAN-GP gradient penalty
        gradient_penalty = self.compute_gradient_penalty(real_images, fake_images)
        
        # Combined loss
        d_loss = (lsgan_loss_real + lsgan_loss_fake) + \
                 self.lambda_energy * (energy_loss_real + energy_loss_fake) + \
                 self.lambda_gp * gradient_penalty
        
        # Backward pass
        d_loss.backward()
        self.optimizerD.step()
        
        # Store for monitoring
        self.real_energy = energy_real.mean().item()
        self.fake_energy = energy_fake.mean().item()
        
        return {
            'd_loss': d_loss.item(),
            'lsgan_real': lsgan_loss_real.item(),
            'lsgan_fake': lsgan_loss_fake.item(),
            'energy_real': energy_loss_real.item(),
            'energy_fake': energy_loss_fake.item(),
            'gradient_penalty': gradient_penalty.item()
        }

    def train_generator_step(self, batch_size):
        """Train generator with hybrid losses"""
        self.optimizerG.zero_grad()
        
        # Generate fake images
        noise = torch.randn(batch_size, self.latent_dim, 1, 1, device=self.device)
        fake_images = self.generator(noise)
        
        # Get discriminator outputs
        d_fake, energy_fake = self.discriminator(fake_images, return_energy=True)
        
        # LSGAN loss (fakes should be classified as real)
        lsgan_loss = torch.mean((d_fake - 1.0) ** 2)
        
        # EBGAN energy loss (push fake energy low)
        energy_loss = torch.mean(energy_fake)
        
        # Combined generator loss
        g_loss = lsgan_loss + self.lambda_energy * energy_loss
        
        # Backward pass
        g_loss.backward()
        self.optimizerG.step()
        
        return {
            'g_loss': g_loss.item(),
            'lsgan_g': lsgan_loss.item(),
            'energy_g': energy_loss.item()
        }

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32, augment=True):
        self.image_paths = image_paths
        self.image_size = image_size
        self.augment = augment
        
        if augment:
            self.transform = transforms.Compose([
                transforms.RandomResizedCrop(image_size, scale=(0.8, 1.0)),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomApply([
                    transforms.ColorJitter(brightness=0.2, contrast=0.2)
                ], p=0.3),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class HybridGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("HybridGAN Trainer")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_dim': tk.IntVar(value=128),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'augment': tk.BooleanVar(value=True),
            'lambda_gp': tk.DoubleVar(value=10.0),
            'lambda_energy': tk.DoubleVar(value=0.1),
            'generate_interval': tk.IntVar(value=5)
        }
        
        # Performance tracking
        self.start_time = None
        
        # Generated images
        self.generated_images = []
        
        # Setup GUI
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="HybridGAN Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text=f"Image Size: {self.settings['image_size'].get()}x{self.settings['image_size'].get()}")
        self.size_display.pack(pady=(0, 10))
        
        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list
        list_frame = tk.Frame(img_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize GAN", 
                 command=self.initialize_gan, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.single_image_frame = tk.Frame(preview_frame, width=256, height=256, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="HybridGAN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Image size
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Radiobutton(size_frame, text="32x32", variable=self.settings['image_size'], 
                      value=32, command=self.update_size_display).pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(size_frame, text="64x64", variable=self.settings['image_size'], 
                      value=64, command=self.update_size_display).pack(side=tk.LEFT, padx=5)
        
        # Other parameters
        settings_list = [
            ("Latent Dimension:", 'latent_dim', 32, 512),
            ("Generator Features:", 'ngf', 32, 256),
            ("Discriminator Features:", 'ndf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 64),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200, resolution=1).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        # FIXED: Proper resolution for each slider
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Generate Interval:", 'generate_interval', 1, 50),
            ("Gradient Penalty λ:", 'lambda_gp', 0.0, 20.0),
            ("Energy Weight λ:", 'lambda_energy', 0.0, 1.0),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            # Set appropriate resolution for each slider type
            if var_name == 'learning_rate':
                resolution = 0.00001
                digits = 5
            elif var_name == 'beta1':
                resolution = 0.001
                digits = 3
            elif var_name == 'lambda_energy':
                resolution = 0.01  # FIXED: 0.01 steps for energy weight
                digits = 2
            elif var_name == 'lambda_gp':
                resolution = 0.1  # 0.1 steps for gradient penalty
                digits = 1
            else:  # Integer sliders
                resolution = 1
                digits = 0
            
            # Create slider with proper resolution
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                    orient=tk.HORIZONTAL, length=200, resolution=resolution,
                    digits=digits).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Augmentation toggle
        aug_frame = tk.Frame(train_frame)
        aug_frame.pack(fill=tk.X, pady=5)
        tk.Label(aug_frame, text="Use Augmentation:", width=30, anchor='w').pack(side=tk.LEFT)
        tk.Checkbutton(aug_frame, variable=self.settings['augment']).pack(side=tk.RIGHT)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load buttons
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save Settings", 
                 command=self.save_settings, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Settings", 
                 command=self.load_settings, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load Generator", 
                 command=self.load_generator, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def update_size_display(self):
        size = self.settings['image_size'].get()
        self.size_display.config(text=f"Image Size: {size}x{size}")

    def log_message(self, message):
        self.message_queue.put(message)

    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_gan(self):
        try:
            image_size = self.settings['image_size'].get()
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            
            self.gan = HybridGAN(
                image_size=image_size,
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf
            )
            
            # Update hyperparameters
            self.gan.lambda_gp = self.settings['lambda_gp'].get()
            self.gan.lambda_energy = self.settings['lambda_energy'].get()
            
            # Update optimizer learning rates
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            
            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            for param_group in self.gan.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            self.log_message(f"Initialized HybridGAN for {image_size}x{image_size} images")
            self.log_message(f"Latent dim: {latent_dim}, G features: {ngf}, D features: {ndf}")
            self.log_message(f"λ_gp: {self.gan.lambda_gp}, λ_energy: {self.gan.lambda_energy}")
            
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            augment = self.settings['augment'].get()
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, num_workers, augment),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Augmentation: {'ON' if augment else 'OFF'}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_gan(self, epochs, batch_size, num_workers, augment):
        try:
            image_size = self.settings['image_size'].get()
            generate_interval = self.settings['generate_interval'].get()
            
            # Create dataset and dataloader
            dataset = ImageDataset(self.image_paths, image_size, augment=augment)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                epoch_start = time.time()
                
                for real_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # Train discriminator
                    d_losses = self.gan.train_discriminator_step(real_images, batch_size_actual)
                    
                    # Train generator (every other batch)
                    if batch_count % 2 == 0:
                        g_losses = self.gan.train_generator_step(batch_size_actual)
                        total_loss_g += g_losses['g_loss']
                    
                    total_loss_d += d_losses['d_loss']
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / max(batch_count // 2, 1)
                    epoch_time = time.time() - epoch_start
                    
                    # Log progress
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"D Loss: {avg_loss_d:.4f} | "
                                   f"G Loss: {avg_loss_g:.4f} | "
                                   f"Real Energy: {self.gan.real_energy:.4f} | "
                                   f"Fake Energy: {self.gan.fake_energy:.4f} | "
                                   f"Time: {epoch_time:.1f}s")
                    
                    # Generate samples at interval
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_training_samples(self):
        if not self.gan:
            return
        
        try:
            with torch.no_grad():
                # Generate 1 image
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
                
                # Convert to PIL
                img_tensor = generated[0]
                img = self.tensor_to_pil(img_tensor)
                
                # FIXED: Use NEAREST neighbor for crisp display
                img_display = img.resize((256, 256), Image.Resampling.NEAREST)
                
                # Convert to PhotoImage
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                # Store
                self.generated_images.append(img)
                
                self.log_message(f"Generated training sample at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        img = (tensor + 1) / 2  # Denormalize
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
                img = self.tensor_to_pil(generated[0])
                
                # FIXED: Use NEAREST neighbor for crisp display
                img_display = img.resize((256, 256), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                # Store
                self.generated_images.append(img)
                
                self.log_message("Generated single sample")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def save_model(self):
        if not self.gan:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'discriminator_state_dict': self.gan.discriminator.state_dict(),
                    'optimizerG_state_dict': self.gan.optimizerG.state_dict(),
                    'optimizerD_state_dict': self.gan.optimizerD.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                    'lambda_gp': self.settings['lambda_gp'].get(),
                    'lambda_energy': self.settings['lambda_energy'].get(),
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_generator(self):
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                if 'image_size' in checkpoint:
                    self.settings['image_size'].set(checkpoint['image_size'])
                    self.update_size_display()
                
                if 'latent_dim' in checkpoint:
                    self.settings['latent_dim'].set(checkpoint['latent_dim'])
                
                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])
                
                if 'ndf' in checkpoint:
                    self.settings['ndf'].set(checkpoint['ndf'])
                
                if 'lambda_gp' in checkpoint:
                    self.settings['lambda_gp'].set(checkpoint['lambda_gp'])
                
                if 'lambda_energy' in checkpoint:
                    self.settings['lambda_energy'].set(checkpoint['lambda_energy'])
                
                # Initialize GAN
                self.initialize_gan()
                
                # Load state dicts
                self.gan.generator.load_state_dict(checkpoint['generator_state_dict'])
                if 'discriminator_state_dict' in checkpoint:
                    self.gan.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])
                
                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            
            with torch.no_grad():
                noise = torch.randn(num_images, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
            
            # Clear previous images
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            # Create grid
            cols = 4
            rows = (num_images + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_tensor = generated[idx]
                        img = self.tensor_to_pil(img_tensor)
                        
                        # FIXED: Use NEAREST neighbor for crisp thumbnails
                        img_display = img.resize((128, 128), Image.Resampling.NEAREST)
                        
                        photo = ImageTk.PhotoImage(img_display)
                        
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            
            self.log_message(f"Generated {num_images} images in grid")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def save_settings(self):
        try:
            import json
            settings = {k: v.get() for k, v in self.settings.items()}
            with open('hybridgan_settings.json', 'w') as f:
                json.dump(settings, f, indent=2)
            self.log_message("Settings saved")
        except Exception as e:
            self.log_message(f"Error saving settings: {str(e)}")

    def load_settings(self):
        try:
            import json
            if os.path.exists('hybridgan_settings.json'):
                with open('hybridgan_settings.json', 'r') as f:
                    settings = json.load(f)
                
                for key, value in settings.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.update_size_display()
                self.log_message("Loaded saved settings")
            else:
                self.log_message("No settings file found")
        except Exception as e:
            self.log_message(f"Error loading settings: {str(e)}")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting HybridGAN Trainer...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = HybridGANApp(root)
    root.mainloop()