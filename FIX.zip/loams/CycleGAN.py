import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
from pathlib import Path

# ==================== Helper for transparency ====================

def load_image_as_rgb(path):
    """
    Load an image from the given path.
    If the image has transparency (RGBA or palette with transparency),
    composite it onto a black background.
    Returns a PIL Image in RGB mode.
    """
    img = Image.open(path)

    # Convert palette images with transparency to RGBA first
    if img.mode == 'P' and 'transparency' in img.info:
        img = img.convert('RGBA')

    if img.mode == 'RGBA':
        # Create a black background image
        bg = Image.new('RGB', img.size, (0, 0, 0))
        # Use alpha channel as mask to paste the image onto the black background
        bg.paste(img, mask=img.split()[3])  # alpha channel
        return bg
    else:
        return img.convert('RGB')

# ==================== Neural Network (CycleGAN) ====================

class UNetGenerator(nn.Module):
    """U-Net generator for 32x32, input 3 channels, output 3 channels."""
    def __init__(self, in_channels=3, out_channels=3, features=64):
        super().__init__()
        self.down1 = self._down(in_channels, features, batchnorm=False)       # 32->16
        self.down2 = self._down(features, features*2)                         # 16->8
        self.down3 = self._down(features*2, features*4)                       # 8->4
        self.down4 = self._down(features*4, features*8)                       # 4->2
        self.down5 = self._down(features*8, features*8, batchnorm=False)      # 2->1

        self.up1 = self._up(features*8, features*8, dropout=True)             # 1->2
        self.up2 = self._up(features*16, features*4)                          # 2->4
        self.up3 = self._up(features*8, features*2)                           # 4->8
        self.up4 = self._up(features*4, features)                             # 8->16
        self.up5 = nn.Sequential(
            nn.ConvTranspose2d(features*2, out_channels, 4, 2, 1),
            nn.Tanh()
        )                                                                     # 16->32

    def _down(self, in_ch, out_ch, batchnorm=True):
        layers = [nn.Conv2d(in_ch, out_ch, 4, 2, 1)]
        if batchnorm:
            layers.append(nn.BatchNorm2d(out_ch))
        layers.append(nn.LeakyReLU(0.2))
        return nn.Sequential(*layers)

    def _up(self, in_ch, out_ch, dropout=False):
        layers = [nn.ConvTranspose2d(in_ch, out_ch, 4, 2, 1),
                  nn.BatchNorm2d(out_ch),
                  nn.ReLU()]
        if dropout:
            layers.append(nn.Dropout(0.5))
        return nn.Sequential(*layers)

    def forward(self, x):
        # Encoder
        d1 = self.down1(x)
        d2 = self.down2(d1)
        d3 = self.down3(d2)
        d4 = self.down4(d3)
        d5 = self.down5(d4)

        # Decoder
        u1 = self.up1(d5)
        u1 = torch.cat([u1, d4], dim=1)
        u2 = self.up2(u1)
        u2 = torch.cat([u2, d3], dim=1)
        u3 = self.up3(u2)
        u3 = torch.cat([u3, d2], dim=1)
        u4 = self.up4(u3)
        u4 = torch.cat([u4, d1], dim=1)
        u5 = self.up5(u4)
        return u5


class PatchGANDiscriminator(nn.Module):
    """PatchGAN discriminator for 32x32 input, outputs 8x8 patch scores."""
    def __init__(self, in_channels=3):
        super().__init__()
        self.model = nn.Sequential(
            nn.Conv2d(in_channels, 64, 4, 2, 1),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(64, 128, 4, 2, 1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(128, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(256, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(512, 1, 3, 1, 1),
        )

    def forward(self, img):
        return self.model(img)


class CycleGAN:
    def __init__(self, features=64, lambda_cycle=10.0, lambda_identity=5.0, label_smoothing=0.0):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        torch.set_num_threads(multiprocessing.cpu_count())
        print(f"Using device: {self.device}")

        # Generators
        self.G_AB = UNetGenerator(3, 3, features).to(self.device)  # A -> B
        self.G_BA = UNetGenerator(3, 3, features).to(self.device)  # B -> A

        # Discriminators
        self.D_A = PatchGANDiscriminator(3).to(self.device)        # real/fake for A
        self.D_B = PatchGANDiscriminator(3).to(self.device)        # real/fake for B

        # Losses
        self.criterion_gan = nn.BCEWithLogitsLoss()
        self.criterion_cycle = nn.L1Loss()
        self.criterion_identity = nn.L1Loss()

        self.lambda_cycle = lambda_cycle
        self.lambda_identity = lambda_identity
        self.label_smoothing = label_smoothing

        # Optimizers
        self.optimizer_G = optim.Adam(
            list(self.G_AB.parameters()) + list(self.G_BA.parameters()),
            lr=0.0002, betas=(0.5, 0.999)
        )
        self.optimizer_D_A = optim.Adam(self.D_A.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizer_D_B = optim.Adam(self.D_B.parameters(), lr=0.0002, betas=(0.5, 0.999))

    def train_step(self, real_A, real_B):
        """
        real_A: batch from domain A
        real_B: batch from domain B
        """
        batch_size = real_A.size(0)
        real_A = real_A.to(self.device)
        real_B = real_B.to(self.device)

        # PatchGAN labels (8x8) with optional smoothing
        if self.label_smoothing > 0:
            real_label_val = 1.0 - self.label_smoothing
            fake_label_val = self.label_smoothing
        else:
            real_label_val = 1.0
            fake_label_val = 0.0

        real_labels = torch.full((batch_size, 1, 8, 8), real_label_val, device=self.device)
        fake_labels = torch.full((batch_size, 1, 8, 8), fake_label_val, device=self.device)

        # ---------------------
        # Train Generators
        # ---------------------
        self.optimizer_G.zero_grad()

        # Identity loss (optional but helps)
        if self.lambda_identity > 0:
            # G_AB should output same as B when given B (identity)
            id_B = self.G_AB(real_B)
            loss_identity_B = self.criterion_identity(id_B, real_B) * self.lambda_identity
            # G_BA should output same as A when given A
            id_A = self.G_BA(real_A)
            loss_identity_A = self.criterion_identity(id_A, real_A) * self.lambda_identity
            loss_identity = (loss_identity_A + loss_identity_B) / 2
        else:
            loss_identity = 0.0

        # GAN loss
        fake_B = self.G_AB(real_A)
        pred_fake_B = self.D_B(fake_B)
        loss_GAN_AB = self.criterion_gan(pred_fake_B, real_labels)

        fake_A = self.G_BA(real_B)
        pred_fake_A = self.D_A(fake_A)
        loss_GAN_BA = self.criterion_gan(pred_fake_A, real_labels)

        # Cycle consistency loss
        recovered_A = self.G_BA(fake_B)
        loss_cycle_A = self.criterion_cycle(recovered_A, real_A) * self.lambda_cycle
        recovered_B = self.G_AB(fake_A)
        loss_cycle_B = self.criterion_cycle(recovered_B, real_B) * self.lambda_cycle

        # Total generator loss
        loss_G = loss_GAN_AB + loss_GAN_BA + loss_cycle_A + loss_cycle_B + loss_identity
        loss_G.backward()
        self.optimizer_G.step()

        # ---------------------
        # Train Discriminator A
        # ---------------------
        self.optimizer_D_A.zero_grad()
        # Real
        pred_real_A = self.D_A(real_A)
        loss_D_A_real = self.criterion_gan(pred_real_A, real_labels)
        # Fake (detached)
        fake_A_detached = fake_A.detach()
        pred_fake_A = self.D_A(fake_A_detached)
        loss_D_A_fake = self.criterion_gan(pred_fake_A, fake_labels)
        loss_D_A = (loss_D_A_real + loss_D_A_fake) * 0.5
        loss_D_A.backward()
        self.optimizer_D_A.step()

        # ---------------------
        # Train Discriminator B
        # ---------------------
        self.optimizer_D_B.zero_grad()
        pred_real_B = self.D_B(real_B)
        loss_D_B_real = self.criterion_gan(pred_real_B, real_labels)
        fake_B_detached = fake_B.detach()
        pred_fake_B = self.D_B(fake_B_detached)
        loss_D_B_fake = self.criterion_gan(pred_fake_B, fake_labels)
        loss_D_B = (loss_D_B_real + loss_D_B_fake) * 0.5
        loss_D_B.backward()
        self.optimizer_D_B.step()

        return {
            'G': loss_G.item(),
            'D_A': loss_D_A.item(),
            'D_B': loss_D_B.item(),
            'cycle_A': loss_cycle_A.item(),
            'cycle_B': loss_cycle_B.item(),
            'identity': loss_identity if isinstance(loss_identity, float) else loss_identity.item()
        }


# ==================== Unpaired Dataset ====================

class UnpairedImageDataset(Dataset):
    def __init__(self, paths, image_size=32, aug_settings=None):
        self.paths = paths
        self.image_size = image_size
        self.aug_settings = aug_settings or {}
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.paths)

    def apply_augmentations(self, pil_img):
        """Apply random augmentations to a single image."""
        img = pil_img.copy()
        seed = random.randint(0, 2**32)
        random.seed(seed)

        if self.aug_settings.get('stretch_height', False) and random.random() < 0.5:
            delta = random.randint(-8, 8)
            new_h = 32 + delta
            img = img.resize((32, new_h), Image.BICUBIC)
            img = img.resize((32, 32), Image.BICUBIC)

        if self.aug_settings.get('stretch_width', False) and random.random() < 0.5:
            delta = random.randint(-8, 8)
            new_w = 32 + delta
            img = img.resize((new_w, 32), Image.BICUBIC)
            img = img.resize((32, 32), Image.BICUBIC)

        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F.rotate(img, angle, interpolation=Image.BICUBIC)

        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F.hflip(img)

        if self.aug_settings.get('flip_vertical', False) and random.random() < 0.5:
            img = F.vflip(img)

        if self.aug_settings.get('affine_jitter', False) and random.random() < 0.5:
            translate_x = random.uniform(-0.1, 0.1) * 32
            translate_y = random.uniform(-0.1, 0.1) * 32
            scale = random.uniform(0.9, 1.1)
            shear = random.uniform(-10, 10)
            img = F.affine(img, angle=0, translate=(translate_x, translate_y),
                           scale=scale, shear=(shear, 0), interpolation=Image.BICUBIC)

        if self.aug_settings.get('brightness', False) and random.random() < 0.5:
            brightness_factor = random.uniform(0.8, 1.2)
            img = F.adjust_brightness(img, brightness_factor)

        if self.aug_settings.get('contrast', False) and random.random() < 0.5:
            contrast_factor = random.uniform(0.8, 1.2)
            img = F.adjust_contrast(img, contrast_factor)

        if self.aug_settings.get('saturation', False) and random.random() < 0.5:
            saturation_factor = random.uniform(0.8, 1.2)
            img = F.adjust_saturation(img, saturation_factor)

        if self.aug_settings.get('hue', False) and random.random() < 0.5:
            hue_factor = random.uniform(-0.1, 0.1)
            img = F.adjust_hue(img, hue_factor)

        if self.aug_settings.get('noise', False) and random.random() < 0.5:
            np_img = np.array(img).astype(np.float32)
            noise = np.random.normal(0, 10, np_img.shape)
            np_img = np.clip(np_img + noise, 0, 255).astype(np.uint8)
            img = Image.fromarray(np_img)

        if img.mode != 'RGB':
            img = img.convert('RGB')
        return img

    def __getitem__(self, idx):
        try:
            pil_img = load_image_as_rgb(self.paths[idx])
            pil_img = self.apply_augmentations(pil_img)
            tensor = self.transform(pil_img)
            return tensor
        except Exception as e:
            print(f"Error loading {self.paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)


# ==================== GUI Application ====================

class CycleGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("CycleGAN - Unpaired Image Translation")
        self.root.geometry("1000x700")

        self.pathsA = []
        self.pathsB = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()

        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'features': tk.IntVar(value=64),
            'lambda_cycle': tk.IntVar(value=10),
            'lambda_identity': tk.IntVar(value=5),
            'label_smoothing': tk.DoubleVar(value=0.0),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
        }

        # Augmentation settings
        self.aug_settings = {
            'stretch_height': tk.BooleanVar(value=False),
            'stretch_width': tk.BooleanVar(value=False),
            'rotation': tk.BooleanVar(value=False),
            'flip_horizontal': tk.BooleanVar(value=False),
            'flip_vertical': tk.BooleanVar(value=False),
            'affine_jitter': tk.BooleanVar(value=False),
            'brightness': tk.BooleanVar(value=False),
            'contrast': tk.BooleanVar(value=False),
            'saturation': tk.BooleanVar(value=False),
            'hue': tk.BooleanVar(value=False),
            'noise': tk.BooleanVar(value=False),
        }

        self.start_time = None

        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.inference_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.inference_tab, text='Inference')
        self.setup_inference_tab()

    # ------------------------------------------------------------------
    # Training Tab
    # ------------------------------------------------------------------
    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left panel
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="CycleGAN", font=("Arial", 12, "bold")).pack(pady=(0,10))

        # Domain selection
        domain_frame = tk.LabelFrame(left_frame, text="Unpaired Datasets", padx=10, pady=10)
        domain_frame.pack(fill=tk.X, pady=(0,10))

        # Domain A
        tk.Label(domain_frame, text="Domain A:").pack(anchor='w')
        btnA = tk.Button(domain_frame, text="Add Images to A", command=lambda: self.add_images('A'), width=20)
        btnA.pack(pady=2)
        self.listboxA = tk.Listbox(domain_frame, height=5)
        self.listboxA.pack(fill=tk.X, pady=2)

        # Domain B
        tk.Label(domain_frame, text="Domain B:").pack(anchor='w', pady=(5,0))
        btnB = tk.Button(domain_frame, text="Add Images to B", command=lambda: self.add_images('B'), width=20)
        btnB.pack(pady=2)
        self.listboxB = tk.Listbox(domain_frame, height=5)
        self.listboxB.pack(fill=tk.X, pady=2)

        # Clear buttons
        clear_frame = tk.Frame(domain_frame)
        clear_frame.pack(pady=5)
        tk.Button(clear_frame, text="Clear A", command=lambda: self.clear_domain('A'), width=8).pack(side=tk.LEFT, padx=2)
        tk.Button(clear_frame, text="Clear B", command=lambda: self.clear_domain('B'), width=8).pack(side=tk.LEFT, padx=2)

        # Model controls
        model_frame = tk.LabelFrame(left_frame, text="Model", padx=10, pady=10)
        model_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(model_frame, text="Initialize Model", command=self.initialize_model, width=20).pack(pady=5)

        # Training
        train_frame = tk.LabelFrame(left_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0,10))
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="Start Training", command=self.start_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", command=self.stop_training,
                  width=20, bg="salmon").pack(pady=5)

        # Save / Load
        save_frame = tk.LabelFrame(left_frame, text="Save/Load", padx=10, pady=10)
        save_frame.pack(fill=tk.X)
        tk.Button(save_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)
        tk.Button(save_frame, text="Load Model", command=self.load_model, width=20).pack(pady=5)

        # Right panel - preview and log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Preview frame (A→B and B→A)
        preview_frame = tk.LabelFrame(right_frame, text="Preview", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,10))

        preview_inner = tk.Frame(preview_frame)
        preview_inner.pack()

        # A -> B
        frame_ab = tk.Frame(preview_inner)
        frame_ab.pack(side=tk.LEFT, padx=5)
        tk.Label(frame_ab, text="A → B").pack()
        self.preview_A_canvas = tk.Canvas(frame_ab, width=100, height=100, bg='gray')
        self.preview_A_canvas.pack()
        self.preview_AB_canvas = tk.Canvas(frame_ab, width=100, height=100, bg='gray')
        self.preview_AB_canvas.pack()

        # B -> A
        frame_ba = tk.Frame(preview_inner)
        frame_ba.pack(side=tk.LEFT, padx=5)
        tk.Label(frame_ba, text="B → A").pack()
        self.preview_B_canvas = tk.Canvas(frame_ba, width=100, height=100, bg='gray')
        self.preview_B_canvas.pack()
        self.preview_BA_canvas = tk.Canvas(frame_ba, width=100, height=100, bg='gray')
        self.preview_BA_canvas.pack()

        # Log
        log_frame = tk.LabelFrame(right_frame, text="Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_log = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar_log.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar_log.set)

        self.status_label = tk.Label(self.training_tab, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def add_images(self, domain):
        files = filedialog.askopenfilenames(
            filetypes=[("Images", "*.jpg *.jpeg *.png *.bmp *.tif *.tiff *.webp")]
        )
        if domain == 'A':
            for f in files:
                if f not in self.pathsA:
                    self.pathsA.append(f)
                    self.listboxA.insert(tk.END, os.path.basename(f))
            self.log_message(f"Added {len(files)} images to A. Total A: {len(self.pathsA)}")
        else:
            for f in files:
                if f not in self.pathsB:
                    self.pathsB.append(f)
                    self.listboxB.insert(tk.END, os.path.basename(f))
            self.log_message(f"Added {len(files)} images to B. Total B: {len(self.pathsB)}")

    def clear_domain(self, domain):
        if domain == 'A':
            self.pathsA = []
            self.listboxA.delete(0, tk.END)
            self.log_message("Cleared domain A")
        else:
            self.pathsB = []
            self.listboxB.delete(0, tk.END)
            self.log_message("Cleared domain B")

    # ------------------------------------------------------------------
    # Settings Tab
    # ------------------------------------------------------------------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="CycleGAN Settings", font=("Arial",14,"bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Generator architecture
        net_frame = tk.LabelFrame(scrollable_frame, text="Generator Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=5)

        arch_params = [
            ("Base features:", 'features', 16, 128),
            ("Cycle consistency weight:", 'lambda_cycle', 1, 100),
            ("Identity weight:", 'lambda_identity', 0, 20),
        ]
        for label, key, low, high in arch_params:
            f = tk.Frame(net_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Training parameters
        train_frame = tk.LabelFrame(scrollable_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=5)

        train_params = [
            ("Batch size:", 'batch_size', 1, 64),
            ("Learning rate:", 'learning_rate', 1e-5, 1e-2),
            ("Beta1 (Adam):", 'beta1', 0.0, 0.999),
            ("Label smoothing:", 'label_smoothing', 0.0, 0.3),
            ("Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count()*2)),
        ]
        for label, key, low, high in train_params:
            f = tk.Frame(train_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            res = 0.00001 if key=='learning_rate' else (0.001 if key=='beta1' else (0.01 if key=='label_smoothing' else 1))
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Augmentations
        aug_frame = tk.LabelFrame(scrollable_frame, text="Image Augmentations (applied independently)", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)

        augs = [
            ("Stretch Height (±8 px)", 'stretch_height'),
            ("Stretch Width (±8 px)", 'stretch_width'),
            ("Rotation (±30°)", 'rotation'),
            ("Flip Horizontal", 'flip_horizontal'),
            ("Flip Vertical", 'flip_vertical'),
            ("Affine Jitter", 'affine_jitter'),
            ("Brightness (±20%)", 'brightness'),
            ("Contrast (±20%)", 'contrast'),
            ("Saturation (±20%)", 'saturation'),
            ("Hue (±10%)", 'hue'),
            ("Gaussian Noise", 'noise'),
        ]
        for label, key in augs:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=5)
        cpu = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU cores: {cpu}").pack(anchor='w')
        tk.Label(sys_frame, text=f"PyTorch threads: {torch.get_num_threads()}").pack(anchor='w')
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}").pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ------------------------------------------------------------------
    # Inference Tab
    # ------------------------------------------------------------------
    def setup_inference_tab(self):
        main_frame = tk.Frame(self.inference_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Inference: Translate Images", font=("Arial",14,"bold")).pack(pady=(0,20))

        # Direction selection
        dir_frame = tk.Frame(main_frame)
        dir_frame.pack(fill=tk.X, pady=5)
        tk.Label(dir_frame, text="Direction:").pack(side=tk.LEFT, padx=5)
        self.direction_var = tk.StringVar(value="A → B")
        dir_combo = ttk.Combobox(dir_frame, textvariable=self.direction_var,
                                  values=["A → B", "B → A"], state="readonly")
        dir_combo.pack(side=tk.LEFT, padx=5)

        # Load image button
        tk.Button(main_frame, text="Load Image", command=self.load_image_for_inference).pack(pady=5)
        tk.Button(main_frame, text="Generate", command=self.run_inference).pack(pady=5)

        # Display area
        display_frame = tk.LabelFrame(main_frame, text="Input/Output", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True)

        inner = tk.Frame(display_frame)
        inner.pack(pady=10)

        self.infer_input_canvas = tk.Canvas(inner, width=150, height=150, bg='lightgray')
        self.infer_input_canvas.pack(side=tk.LEFT, padx=10)
        self.infer_input_canvas.create_text(75, 75, text="Input")

        self.infer_output_canvas = tk.Canvas(inner, width=150, height=150, bg='lightgray')
        self.infer_output_canvas.pack(side=tk.LEFT, padx=10)
        self.infer_output_canvas.create_text(75, 75, text="Output")

        self.infer_info = tk.Label(display_frame, text="", fg="blue")
        self.infer_info.pack(pady=5)

        self.current_input_tensor = None
        self.current_input_pil = None

    def load_image_for_inference(self):
        f = filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png *.bmp *.tif *.webp")])
        if not f:
            return
        try:
            pil_img = load_image_as_rgb(f)
            pil_img_resized = pil_img.resize((32,32), Image.BICUBIC)
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))
            ])
            img_tensor = transform(pil_img_resized).unsqueeze(0)
            self.current_input_tensor = img_tensor
            self.current_input_pil = pil_img_resized

            disp_img = pil_img_resized.resize((150,150), Image.BICUBIC)
            self.input_photo = ImageTk.PhotoImage(disp_img)
            self.infer_input_canvas.delete("all")
            self.infer_input_canvas.create_image(75, 75, image=self.input_photo)

            self.infer_info.config(text="Image loaded. Select direction and click Generate.")
        except Exception as e:
            self.log_message(f"Error loading image: {e}")

    def run_inference(self):
        if not self.model:
            self.infer_info.config(text="Model not loaded!")
            return
        if self.current_input_tensor is None:
            self.infer_info.config(text="No input image!")
            return

        try:
            direction = self.direction_var.get()
            input_tensor = self.current_input_tensor.to(self.model.device)

            self.model.G_AB.eval()
            self.model.G_BA.eval()
            with torch.no_grad():
                if direction == "A → B":
                    output = self.model.G_AB(input_tensor)
                else:
                    output = self.model.G_BA(input_tensor)

            output_np = output[0].cpu().numpy().transpose(1,2,0)
            output_np = ((output_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            output_pil = Image.fromarray(output_np).resize((150,150), Image.BICUBIC)
            self.output_photo = ImageTk.PhotoImage(output_pil)
            self.infer_output_canvas.delete("all")
            self.infer_output_canvas.create_image(75, 75, image=self.output_photo)

            self.infer_info.config(text="Generated successfully.")
        except Exception as e:
            self.infer_info.config(text=f"Error: {e}")
            self.log_message(f"Inference error: {e}")

    # ------------------------------------------------------------------
    # Core functions
    # ------------------------------------------------------------------
    def log_message(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(msg)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def initialize_model(self):
        try:
            self.model = CycleGAN(
                features=self.settings['features'].get(),
                lambda_cycle=self.settings['lambda_cycle'].get(),
                lambda_identity=self.settings['lambda_identity'].get(),
                label_smoothing=self.settings['label_smoothing'].get()
            )
            self.log_message("CycleGAN model initialized.")
        except Exception as e:
            self.log_message(f"Error: {e}")

    def start_training(self):
        if not self.pathsA or not self.pathsB:
            self.log_message("Both domains need images!")
            return
        if not self.model:
            self.log_message("Model not initialized!")
            return
        if self.training:
            self.log_message("Already training.")
            return

        try:
            epochs = int(self.epoch_var.get())
        except:
            self.log_message("Invalid epochs")
            return

        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()

        # Update optimizers with current settings
        lr = self.settings['learning_rate'].get()
        beta1 = self.settings['beta1'].get()
        for pg in self.model.optimizer_G.param_groups:
            pg['lr'] = lr
            pg['betas'] = (beta1, 0.999)
        for pg in self.model.optimizer_D_A.param_groups:
            pg['lr'] = lr
            pg['betas'] = (beta1, 0.999)
        for pg in self.model.optimizer_D_B.param_groups:
            pg['lr'] = lr
            pg['betas'] = (beta1, 0.999)

        thread = threading.Thread(target=self.train_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_message(f"Training started for {epochs} epochs.")

    def train_loop(self, epochs):
        try:
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}

            datasetA = UnpairedImageDataset(self.pathsA, 32, aug_settings=aug_dict)
            datasetB = UnpairedImageDataset(self.pathsB, 32, aug_settings=aug_dict)
            loaderA = DataLoader(datasetA, batch_size=batch_size, shuffle=True,
                                 num_workers=num_workers, pin_memory=torch.cuda.is_available(),
                                 persistent_workers=num_workers>0, drop_last=True)
            loaderB = DataLoader(datasetB, batch_size=batch_size, shuffle=True,
                                 num_workers=num_workers, pin_memory=torch.cuda.is_available(),
                                 persistent_workers=num_workers>0, drop_last=True)

            # Use infinite iterators
            iterA = iter(loaderA)
            iterB = iter(loaderB)

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                epoch_losses = {'G': 0.0, 'D_A': 0.0, 'D_B': 0.0, 'cycle_A': 0.0, 'cycle_B': 0.0, 'identity': 0.0}
                batches = 0

                # Loop over min of lengths (approx)
                for _ in range(min(len(loaderA), len(loaderB))):
                    if not self.training:
                        break

                    try:
                        batchA = next(iterA)
                    except StopIteration:
                        iterA = iter(loaderA)
                        batchA = next(iterA)
                    try:
                        batchB = next(iterB)
                    except StopIteration:
                        iterB = iter(loaderB)
                        batchB = next(iterB)

                    losses = self.model.train_step(batchA, batchB)

                    for k in epoch_losses:
                        epoch_losses[k] += losses[k]
                    batches += 1

                # Average losses
                for k in epoch_losses:
                    epoch_losses[k] /= batches if batches else 1

                elapsed = time.time() - self.start_time
                self.log_message(
                    f"Epoch {epoch+1}/{epochs} | G: {epoch_losses['G']:.4f} | D_A: {epoch_losses['D_A']:.4f} | D_B: {epoch_losses['D_B']:.4f} | cycle: {epoch_losses['cycle_A']:.3f}/{epoch_losses['cycle_B']:.3f} | id: {epoch_losses['identity']:.3f} | Time: {elapsed:.1f}s"
                )

                # Show preview every 5 epochs
                if (epoch+1) % 5 == 0:
                    self.show_preview(loaderA, loaderB)

            self.training = False
            self.log_message("Training finished.")
        except Exception as e:
            self.log_message(f"Training error: {e}")
            import traceback
            traceback.print_exc()
            self.training = False

    def show_preview(self, loaderA, loaderB):
        """Show one example from each direction."""
        if not self.model:
            return
        try:
            # Get one image from A and one from B
            sampleA = next(iter(loaderA))[0:1].to(self.model.device)
            sampleB = next(iter(loaderB))[0:1].to(self.model.device)

            self.model.G_AB.eval()
            self.model.G_BA.eval()
            with torch.no_grad():
                fakeB = self.model.G_AB(sampleA)
                fakeA = self.model.G_BA(sampleB)

            # Convert to display
            def tensor_to_pil(t):
                arr = t[0].cpu().numpy().transpose(1,2,0)
                arr = ((arr + 1) / 2 * 255).clip(0,255).astype(np.uint8)
                return Image.fromarray(arr).resize((100,100), Image.BICUBIC)

            # A and A->B
            imgA_pil = tensor_to_pil(sampleA)
            imgAB_pil = tensor_to_pil(fakeB)
            self.photoA = ImageTk.PhotoImage(imgA_pil)
            self.photoAB = ImageTk.PhotoImage(imgAB_pil)
            self.preview_A_canvas.delete("all")
            self.preview_A_canvas.create_image(50, 50, image=self.photoA)
            self.preview_AB_canvas.delete("all")
            self.preview_AB_canvas.create_image(50, 50, image=self.photoAB)

            # B and B->A
            imgB_pil = tensor_to_pil(sampleB)
            imgBA_pil = tensor_to_pil(fakeA)
            self.photoB = ImageTk.PhotoImage(imgB_pil)
            self.photoBA = ImageTk.PhotoImage(imgBA_pil)
            self.preview_B_canvas.delete("all")
            self.preview_B_canvas.create_image(50, 50, image=self.photoB)
            self.preview_BA_canvas.delete("all")
            self.preview_BA_canvas.create_image(50, 50, image=self.photoBA)

        except Exception as e:
            self.log_message(f"Preview error: {e}")

    def stop_training(self):
        self.training = False
        self.log_message("Training stopped.")

    def save_model(self):
        if not self.model:
            self.log_message("No model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth",
                                              filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'G_AB': self.model.G_AB.state_dict(),
                'G_BA': self.model.G_BA.state_dict(),
                'D_A': self.model.D_A.state_dict(),
                'D_B': self.model.D_B.state_dict(),
                'optimizer_G': self.model.optimizer_G.state_dict(),
                'optimizer_D_A': self.model.optimizer_D_A.state_dict(),
                'optimizer_D_B': self.model.optimizer_D_B.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items()},
                'aug_settings': {k:v.get() for k,v in self.aug_settings.items()}
            }, fname)
            self.log_message(f"Model saved to {fname}")

    def load_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            if 'settings' in ckpt:
                s = ckpt['settings']
                self.settings['features'].set(s.get('features',64))
                self.settings['lambda_cycle'].set(s.get('lambda_cycle',10))
                self.settings['lambda_identity'].set(s.get('lambda_identity',5))
                self.settings['label_smoothing'].set(s.get('label_smoothing',0.0))
            if 'aug_settings' in ckpt:
                for k, v in ckpt['aug_settings'].items():
                    if k in self.aug_settings:
                        self.aug_settings[k].set(v)
            self.initialize_model()
            self.model.G_AB.load_state_dict(ckpt['G_AB'])
            self.model.G_BA.load_state_dict(ckpt['G_BA'])
            self.model.D_A.load_state_dict(ckpt['D_A'])
            self.model.D_B.load_state_dict(ckpt['D_B'])
            self.model.optimizer_G.load_state_dict(ckpt['optimizer_G'])
            self.model.optimizer_D_A.load_state_dict(ckpt['optimizer_D_A'])
            self.model.optimizer_D_B.load_state_dict(ckpt['optimizer_D_B'])
            self.model.G_AB.to(self.model.device)
            self.model.G_BA.to(self.model.device)
            self.model.D_A.to(self.model.device)
            self.model.D_B.to(self.model.device)
            self.log_message(f"Model loaded from {fname}")
        except Exception as e:
            self.log_message(f"Load error: {e}")


# ==================== Main ====================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = CycleGANApp(root)
    root.mainloop()