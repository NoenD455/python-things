import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import queue
import numpy as np
from PIL import Image, ImageTk, ImageOps, ImageFilter
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
import os
from pathlib import Path
import random
import time
torch.set_num_threads(2)           # For intra-op parallelism
torch.set_num_interop_threads(2)

# ==================== GRADUALLY SCALED GENERATOR WITH SIZE OPTIONS ====================
class GradualGenerator(nn.Module):
    """Generator with gradual upscaling, refinement layers, and size options"""
    def __init__(self, latent_dim=128, channels=3, image_size=32, 
                 use_refinement=True, num_refinement=1,
                 model_size="medium"):  # Added model size parameter
        super().__init__()
        self.image_size = image_size
        self.use_refinement = use_refinement
        self.num_refinement = num_refinement
        self.model_size = model_size
        
        # Adjust base channels based on model size (SMALLER as requested)
        if model_size == "tiny":
            self.base_channels = 64
        elif model_size == "large":
            self.base_channels = 128  # Changed from 256 to 128
        else:  # medium
            self.base_channels = 96   # Changed from 128 to 96
        
        # Calculate number of upsampling steps needed
        scale_factors = []
        current_size = 4
        while current_size < image_size:
            current_size *= 2
            scale_factors.append(2)
        
        # Initial projection with capacity based on model size
        self.initial = nn.Sequential(
            nn.Linear(latent_dim, self.base_channels * 4 * 4 * 2),
            nn.BatchNorm1d(self.base_channels * 4 * 4 * 2),
            nn.ReLU(True),
            nn.Linear(self.base_channels * 4 * 4 * 2, self.base_channels * 4 * 4),
            nn.BatchNorm1d(self.base_channels * 4 * 4),
            nn.ReLU(True)
        )
        
        # Store the channel count after initial projection
        self.init_channels = self.base_channels
        
        # Build gradual upscaling blocks
        self.upscale_blocks = nn.ModuleList()
        in_channels = self.base_channels
        
        # Channel sequence based on model size and image size (SMALLER as requested)
        if model_size == "tiny":
            if image_size <= 32:
                channel_sequence = [self.base_channels, 48, 32, 16]  # Smaller
            elif image_size <= 64:
                channel_sequence = [self.base_channels, 64, 48, 32, 16, 8]
            else:
                channel_sequence = [self.base_channels, 128, 96, 64, 48, 32, 16, 8]
        elif model_size == "large":
            if image_size <= 32:
                channel_sequence = [self.base_channels, 96, 64, 48]  # Smaller
            elif image_size <= 64:
                channel_sequence = [self.base_channels, 128, 96, 64, 48, 32]
            else:
                channel_sequence = [self.base_channels, 192, 128, 96, 64, 48, 32, 16]
        else:  # medium
            if image_size <= 32:
                channel_sequence = [self.base_channels, 64, 48, 32]  # Smaller
            elif image_size <= 64:
                channel_sequence = [self.base_channels, 96, 64, 48, 32, 16]
            else:
                channel_sequence = [self.base_channels, 128, 96, 64, 48, 32, 16, 8]
        
        # Only take as many channels as we have upscaling steps
        channel_sequence = channel_sequence[:len(scale_factors) + 1]
        
        for i in range(len(scale_factors)):
            out_channels = channel_sequence[i + 1] if i + 1 < len(channel_sequence) else channel_sequence[-1]
            
            self.upscale_blocks.append(
                GradualUpscaleBlock(
                    in_channels, 
                    out_channels,
                    use_refinement=use_refinement,
                    num_refinement=num_refinement
                )
            )
            in_channels = out_channels
        
        # Final refinement after all upscaling
        self.final_refinement = nn.Sequential()
        if use_refinement:
            for i in range(num_refinement):
                self.final_refinement.append(
                    RefinementBlock(in_channels, in_channels)
                )
        
        # Final layer to produce RGB
        self.final = nn.Sequential(
            nn.Conv2d(in_channels, channels, 3, padding=1),
            nn.Tanh()
        )
    
    def forward(self, z):
        # Initial projection
        x = self.initial(z)
        x = x.view(-1, self.init_channels, 4, 4)
        
        # Gradual upscaling with refinement
        for block in self.upscale_blocks:
            x = block(x)
        
        # Final refinement
        if self.use_refinement:
            x = self.final_refinement(x)
        
        # Final output
        return self.final(x)

class GradualUpscaleBlock(nn.Module):
    """Single upscaling step with optional refinement"""
    def __init__(self, in_channels, out_channels, use_refinement=True, num_refinement=2):
        super().__init__()
        self.use_refinement = use_refinement
        
        # PRE-upsample refinement
        self.pre_refinement = nn.Sequential()
        if use_refinement:
            for i in range(num_refinement // 2):
                self.pre_refinement.append(
                    RefinementBlock(in_channels, in_channels)
                )
        
        # Upsampling (always nearest neighbor for clean upscale)
        self.upsample = nn.Upsample(scale_factor=2, mode='nearest')
        
        # Post-upsample convolution with residual
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu1 = nn.ReLU(True)
        
        # POST-upsample refinement
        self.post_refinement = nn.Sequential()
        if use_refinement:
            for i in range(num_refinement // 2):
                self.post_refinement.append(
                    RefinementBlock(out_channels, out_channels)
                )
    
    def forward(self, x):
        # Pre-upsample refinement
        if self.use_refinement:
            x = self.pre_refinement(x)
        
        # Upsample
        x = self.upsample(x)
        
        # Post-upsample convolution
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu1(x)
        
        # Post-upsample refinement
        if self.use_refinement:
            x = self.post_refinement(x)
        
        return x

class RefinementBlock(nn.Module):
    """Simple refinement block to improve details"""
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu1 = nn.ReLU(True)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)
        
        # Residual connection
        if in_channels != out_channels:
            self.residual = nn.Conv2d(in_channels, out_channels, 1)
        else:
            self.residual = nn.Identity()
        
        self.relu2 = nn.ReLU(True)
    
    def forward(self, x):
        residual = self.residual(x)
        
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu1(x)
        
        x = self.conv2(x)
        x = self.bn2(x)
        
        x = x + residual
        x = self.relu2(x)
        
        return x

# ==================== SIZE-AWARE DISCRIMINATOR ====================
class SizeAwareDiscriminator(nn.Module):
    """Discriminator that adjusts to model size"""
    def __init__(self, channels=3, image_size=32, model_size="medium"):
        super().__init__()
        self.model_size = model_size
        
        # Base channels based on model size (SMALLER as requested)
        if model_size == "tiny":
            base_channels = 32
        elif model_size == "large":
            base_channels = 64  # Changed from 128 to 64
        else:  # medium
            base_channels = 48  # Changed from 64 to 48
        
        layers = []
        in_channels = channels
        
        # Determine number of downsampling steps
        num_downsamples = 0
        size = image_size
        while size > 4:
            size //= 2
            num_downsamples += 1
        
        # Build layers with model-size-appropriate channels
        for i in range(num_downsamples):
            out_channels = min(base_channels * (2 ** i), 256)  # Reduced max from 512 to 256
            layers.append(nn.Conv2d(in_channels, out_channels, 4, stride=2, padding=1))
            if i > 0:  # No batch norm on first layer
                layers.append(nn.BatchNorm2d(out_channels))
            layers.append(nn.LeakyReLU(0.2, inplace=True))
            in_channels = out_channels
        
        # Final layers
        layers.append(nn.Conv2d(in_channels, 1, 4))
        layers.append(nn.Sigmoid())
        
        self.main = nn.Sequential(*layers)
    
    def forward(self, img):
        return self.main(img).view(img.size(0), -1).mean(1)

# ==================== LIGHTWEIGHT DATASET ====================
class LightweightDataset(Dataset):
    """Ultra-lightweight dataset for CPU training"""
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        # Minimal transforms for CPU efficiency
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.RandomHorizontalFlip(p=0.3),  # Only essential augmentation
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            # Try to load with minimal overhead
            with Image.open(self.image_paths[idx]) as img:
                img = img.convert('RGB')
                return self.transform(img)
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            # Return black image as fallback
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== CPU-OPTIMIZED GAN TRAINER WITH SIZE OPTIONS ====================
class SizeAwareGANTrainer:
    def __init__(self, device, latent_dim=128, image_size=32, 
                 use_refinement=True, num_refinement=1,
                 model_size="medium"):  # Added model size
        self.device = device
        self.latent_dim = latent_dim
        self.image_size = image_size
        self.model_size = model_size
        
        # Adjust learning rate based on model size
        if model_size == "tiny":
            lr = 0.0002  # Faster for small models
        elif model_size == "large":
            lr = 0.0001  # Adjusted for smaller large model
        else:  # medium
            lr = 0.00015
        
        # Initialize networks with size options
        self.generator = GradualGenerator(
            latent_dim=latent_dim,
            image_size=image_size,
            model_size=model_size,
            use_refinement=use_refinement,
            num_refinement=num_refinement
        ).to(device)
        
        self.discriminator = SizeAwareDiscriminator(
            image_size=image_size,
            model_size=model_size
        ).to(device)
        
        # Optimizers with size-appropriate learning rates
        self.optimizer_g = optim.Adam(
            self.generator.parameters(), 
            lr=lr,
            betas=(0.5, 0.999)
        )
        
        self.optimizer_d = optim.Adam(
            self.discriminator.parameters(), 
            lr=lr,
            betas=(0.5, 0.999)
        )
        
        # Loss function
        self.criterion = nn.BCELoss()
        
        # Training state
        self.epoch = 0
        self.batch = 0
        self.g_loss_history = []
        self.d_loss_history = []
        
        # Fixed noise for consistent previews
        self.fixed_noise = torch.randn(16, latent_dim, device=device)
        
        # Display queue
        self.display_queue = queue.Queue()
    
    def train_step(self, real_images):
        batch_size = real_images.size(0)
        
        # Train discriminator
        self.optimizer_d.zero_grad()
        
        # Real images
        real_pred = self.discriminator(real_images)
        real_labels = torch.ones(batch_size, device=self.device)
        d_loss_real = self.criterion(real_pred, real_labels)
        
        # Fake images
        z = torch.randn(batch_size, self.latent_dim, device=self.device)
        fake_images = self.generator(z)
        fake_pred = self.discriminator(fake_images.detach())
        fake_labels = torch.zeros(batch_size, device=self.device)
        d_loss_fake = self.criterion(fake_pred, fake_labels)
        
        d_loss = (d_loss_real + d_loss_fake) / 2
        d_loss.backward()
        self.optimizer_d.step()
        
        # Train generator
        self.optimizer_g.zero_grad()
        
        z = torch.randn(batch_size, self.latent_dim, device=self.device)
        fake_images = self.generator(z)
        fake_pred = self.discriminator(fake_images)
        
        g_loss = self.criterion(fake_pred, real_labels)
        g_loss.backward()
        self.optimizer_g.step()
        
        # Send to display occasionally (but not too often for CPU)
        if self.batch % 25 == 0:
            self.display_queue.put(fake_images[:4].detach().cpu())
        
        self.batch += 1
        
        return {
            'd_loss': d_loss.item(),
            'g_loss': g_loss.item(),
            'fake_images': fake_images.detach().cpu()
        }
    
    def generate_images(self, num_images=4):
        with torch.no_grad():
            z = torch.randn(num_images, self.latent_dim, device=self.device)
            return self.generator(z).cpu()
    
    def save_model(self, path):
        torch.save({
            'epoch': self.epoch,
            'image_size': self.image_size,
            'latent_dim': self.latent_dim,
            'model_size': self.model_size,
            'generator': self.generator.state_dict(),
            'discriminator': self.discriminator.state_dict(),
            'optimizer_g': self.optimizer_g.state_dict(),
            'optimizer_d': self.optimizer_d.state_dict(),
            'g_loss_history': self.g_loss_history,
            'd_loss_history': self.d_loss_history,
            'fixed_noise': self.fixed_noise.cpu()
        }, path)
    
    def load_model(self, path):
        checkpoint = torch.load(path, map_location=self.device)
        
        # Update settings
        self.image_size = checkpoint.get('image_size', 32)
        self.latent_dim = checkpoint.get('latent_dim', 128)
        self.model_size = checkpoint.get('model_size', 'medium')
        
        # Recreate models with loaded size
        self.generator = GradualGenerator(
            latent_dim=self.latent_dim,
            image_size=self.image_size,
            model_size=self.model_size,
            use_refinement=True,
            num_refinement=1
        ).to(self.device)
        
        self.discriminator = SizeAwareDiscriminator(
            image_size=self.image_size,
            model_size=self.model_size
        ).to(self.device)
        
        self.generator.load_state_dict(checkpoint['generator'])
        self.discriminator.load_state_dict(checkpoint['discriminator'])
        self.optimizer_g.load_state_dict(checkpoint['optimizer_g'])
        self.optimizer_d.load_state_dict(checkpoint['optimizer_d'])
        self.epoch = checkpoint['epoch']
        self.g_loss_history = checkpoint['g_loss_history']
        self.d_loss_history = checkpoint['d_loss_history']
        self.fixed_noise = checkpoint['fixed_noise'].to(self.device)

# ==================== ENHANCED GUI WITH FILTER OPTIONS ====================
class EnhancedGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("CPU GAN Pro - Size & Filter Controls")
        self.root.geometry("1100x650")
        
        # Device
        self.device = torch.device('cpu')
        print(f"Using device: {self.device}")
        print(f"CPU Threads: {torch.get_num_threads()}")
        
        # Default settings optimized for CPU
        self.image_size = 32
        self.model_size = "medium"  # tiny, medium, large
        self.filter_mode = Image.Resampling.LANCZOS  # Default to Lanczos
        self.display_scale = 4  # How much to upscale for display
        
        # Filter options mapping
        self.filter_options = {
            "Lanczos (Sharp)": Image.Resampling.LANCZOS,
            "Bicubic (Smooth)": Image.Resampling.BICUBIC,
            "Bilinear (Balanced)": Image.Resampling.BILINEAR,
            "Nearest (Pixelated)": Image.Resampling.NEAREST,
            "Box (Blurry)": Image.Resampling.BOX,
            "Hamming (Medium)": Image.Resampling.HAMMING
        }
        
        # Filter reverse lookup for UI
        self.filter_names = {v: k for k, v in self.filter_options.items()}
        
        # GAN Trainer
        self.trainer = SizeAwareGANTrainer(
            self.device, 
            image_size=self.image_size,
            model_size=self.model_size
        )
        
        # Training state
        self.training = False
        self.image_paths = []
        
        # Setup GUI
        self.setup_gui()
        
        # Start display thread
        threading.Thread(target=self.display_thread, daemon=True).start()
    
    def setup_gui(self):
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Left panel (controls)
        left_frame = ttk.Frame(main_frame, width=280)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        title = ttk.Label(left_frame, text="CPU GAN Pro", font=("Arial", 14, "bold"))
        title.pack(pady=(0, 10))
        
        # Dataset section
        dataset_frame = ttk.LabelFrame(left_frame, text="Dataset", padding="10")
        dataset_frame.pack(fill=tk.X, pady=(0, 10))
        
        button_frame = ttk.Frame(dataset_frame)
        button_frame.pack(fill=tk.X, pady=2)
        
        ttk.Button(button_frame, text="📂 Load Images", 
                  command=self.load_images).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))
        ttk.Button(button_frame, text="🗑️ Clear Images", 
                  command=self.clear_images).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(2, 0))
        
        self.image_count_label = ttk.Label(dataset_frame, text="Images: 0")
        self.image_count_label.pack()
        
        # Model size selection
        size_frame = ttk.LabelFrame(left_frame, text="Model Size", padding="10")
        size_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.size_var = tk.StringVar(value="medium")
        size_buttons_frame = ttk.Frame(size_frame)
        size_buttons_frame.pack()
        
        for size in ["tiny", "medium", "large"]:
            ttk.Radiobutton(size_buttons_frame, text=size.capitalize(), 
                          variable=self.size_var, value=size,
                          command=self.on_model_size_change).pack(side=tk.LEFT, padx=5)
        
        # Model info label
        self.model_info_label = ttk.Label(size_frame, text="Medium: 96 base channels")
        self.model_info_label.pack(pady=(5, 0))
        
        # Display settings
        display_frame = ttk.LabelFrame(left_frame, text="Display", padding="10")
        display_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Filter selection
        ttk.Label(display_frame, text="Upscale Filter:").pack(anchor=tk.W)
        self.filter_var = tk.StringVar(value="Lanczos (Sharp)")
        filter_combo = ttk.Combobox(display_frame, textvariable=self.filter_var,
                                   values=list(self.filter_options.keys()), 
                                   state="readonly", width=20)
        filter_combo.pack(anchor=tk.W, pady=(0, 5))
        filter_combo.bind('<<ComboboxSelected>>', self.on_filter_change)
        
        # Display scale
        scale_frame = ttk.Frame(display_frame)
        scale_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(scale_frame, text="Upscale:").pack(side=tk.LEFT, padx=(0, 5))
        self.scale_var = tk.StringVar(value="4x")
        scale_combo = ttk.Combobox(scale_frame, textvariable=self.scale_var,
                                  values=["2x", "4x", "6x", "8x"], 
                                  state="readonly", width=6)
        scale_combo.pack(side=tk.LEFT)
        scale_combo.bind('<<ComboboxSelected>>', self.on_scale_change)
        
        # Training settings
        train_frame = ttk.LabelFrame(left_frame, text="Training", padding="10")
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Image size
        ttk.Label(train_frame, text="Image Size:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.img_size_var = tk.StringVar(value="32")
        img_size_combo = ttk.Combobox(train_frame, textvariable=self.img_size_var,
                                     values=["32", "64", "128"], width=8, state="readonly")
        img_size_combo.grid(row=0, column=1, sticky=tk.W, pady=2)
        img_size_combo.bind('<<ComboboxSelected>>', self.on_image_size_change)
        
        # Batch size
        ttk.Label(train_frame, text="Batch Size:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.batch_var = tk.StringVar(value="4")
        batch_entry = ttk.Entry(train_frame, textvariable=self.batch_var, width=8)
        batch_entry.grid(row=1, column=1, sticky=tk.W, pady=2)
        
        # Epochs
        ttk.Label(train_frame, text="Epochs:").grid(row=2, column=0, sticky=tk.W, pady=2)
        self.epochs_var = tk.StringVar(value="50")
        epochs_entry = ttk.Entry(train_frame, textvariable=self.epochs_var, width=8)
        epochs_entry.grid(row=2, column=1, sticky=tk.W, pady=2)
        
        # Training buttons
        button_frame = ttk.Frame(train_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)
        
        ttk.Button(button_frame, text="▶ Start Training", 
                  command=self.start_training).pack(side=tk.LEFT, padx=2)
        ttk.Button(button_frame, text="■ Stop", 
                  command=self.stop_training).pack(side=tk.LEFT, padx=2)
        
        # Model buttons
        model_frame = ttk.Frame(train_frame)
        model_frame.grid(row=4, column=0, columnspan=2, pady=5)
        
        ttk.Button(model_frame, text="📂 Load Model", 
                  command=self.load_model, width=15).pack(side=tk.LEFT, padx=2)
        ttk.Button(model_frame, text="💾 Save Model", 
                  command=self.save_model, width=15).pack(side=tk.LEFT, padx=2)
        
        # Generation buttons
        gen_frame = ttk.LabelFrame(left_frame, text="Generation", padding="10")
        gen_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(gen_frame, text="🎨 Generate Images", 
                  command=self.generate_images).pack(fill=tk.X, pady=2)
        ttk.Button(gen_frame, text="💾 Save Generated", 
                  command=self.save_generated).pack(fill=tk.X, pady=2)
        
        ttk.Button(gen_frame, text="🔄 Refresh Display", 
                  command=self.refresh_display).pack(fill=tk.X, pady=2)
        
        # Training info
        info_frame = ttk.LabelFrame(left_frame, text="Training Info", padding="10")
        info_frame.pack(fill=tk.X)
        
        self.epoch_label = ttk.Label(info_frame, text="Epoch: 0")
        self.epoch_label.pack(anchor=tk.W)
        
        self.g_loss_label = ttk.Label(info_frame, text="G Loss: -")
        self.g_loss_label.pack(anchor=tk.W)
        
        self.d_loss_label = ttk.Label(info_frame, text="D Loss: -")
        self.d_loss_label.pack(anchor=tk.W)
        
        self.model_size_label = ttk.Label(info_frame, text="Model: Medium (96)")
        self.model_size_label.pack(anchor=tk.W)
        
        self.filter_label = ttk.Label(info_frame, text="Filter: Lanczos")
        self.filter_label.pack(anchor=tk.W)
        
        self.status_label = ttk.Label(info_frame, text="Status: Ready", foreground="blue")
        self.status_label.pack(anchor=tk.W, pady=(5, 0))
        
        # Right panel (images)
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated images with title
        title_frame = ttk.Frame(right_frame)
        title_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(title_frame, text="Generated Images", font=("Arial", 11, "bold")).pack(side=tk.LEFT)
        
        filter_info = ttk.Label(title_frame, text=" | Filter: Lanczos", font=("Arial", 9))
        filter_info.pack(side=tk.LEFT, padx=(10, 0))
        self.filter_info_label = filter_info
        
        # 2x2 grid for images with larger display
        self.gen_canvases = []
        display_size = 250  # Larger display area
        
        for i in range(4):
            row, col = divmod(i, 2)
            
            if col == 0:
                row_frame = ttk.Frame(right_frame)
                row_frame.pack(expand=True, pady=5)
            
            # Frame with border
            cell_frame = ttk.Frame(row_frame, relief=tk.RIDGE, borderwidth=2)
            cell_frame.pack(side=tk.LEFT, padx=10, pady=5)
            
            # Canvas for image
            canvas = tk.Canvas(cell_frame, width=display_size, height=display_size,
                              bg='#1a1a1a', highlightthickness=0)
            canvas.pack()
            self.gen_canvases.append(canvas)
            
            # Info label below each image
            if col == 1:  # Only add label to right side images
                info_label = ttk.Label(row_frame, text=f"Image {i+1}", font=("Arial", 8))
                info_label.pack(side=tk.LEFT, padx=10)
    
    def clear_images(self):
        """Clear all loaded images"""
        self.image_paths.clear()
        self.image_count_label.config(text="Images: 0")
        self.update_status("Cleared all images")
    
    def on_model_size_change(self):
        if self.training:
            messagebox.showwarning("Warning", "Stop training before changing model size")
            self.size_var.set(self.model_size)
            return
        
        new_size = self.size_var.get()
        if new_size != self.model_size:
            self.model_size = new_size
            
            # Update model info label with new sizes (64, 96, 128)
            if new_size == "tiny":
                self.model_info_label.config(text="Tiny: 64 base channels (fastest)")
                self.model_size_label.config(text="Model: Tiny (64)")
            elif new_size == "large":
                self.model_info_label.config(text="Large: 128 base channels (slowest)")
                self.model_size_label.config(text="Model: Large (128)")
            else:
                self.model_info_label.config(text="Medium: 96 base channels (balanced)")
                self.model_size_label.config(text="Model: Medium (96)")
            
            self.recreate_trainer()
            self.update_status(f"Model size: {new_size}")
    
    def on_filter_change(self, event=None):
        filter_name = self.filter_var.get()
        if filter_name in self.filter_options:
            self.filter_mode = self.filter_options[filter_name]
            self.filter_label.config(text=f"Filter: {filter_name.split(' ')[0]}")
            self.filter_info_label.config(text=f" | Filter: {filter_name.split(' ')[0]}")
            self.update_status(f"Filter: {filter_name}")
            
            # Refresh display with new filter
            self.refresh_display()
    
    def on_scale_change(self, event=None):
        scale_str = self.scale_var.get()
        try:
            self.display_scale = int(scale_str.replace('x', ''))
            self.update_status(f"Display scale: {self.display_scale}x")
            self.refresh_display()
        except:
            pass
    
    def on_image_size_change(self, event=None):
        if self.training:
            messagebox.showwarning("Warning", "Stop training before changing image size")
            self.img_size_var.set(str(self.image_size))
            return
        
        try:
            new_size = int(self.img_size_var.get())
            if new_size != self.image_size:
                self.image_size = new_size
                self.recreate_trainer()
                self.update_status(f"Image size: {new_size}px")
        except:
            pass
    
    def load_images(self):
        files = filedialog.askopenfilenames(
            title="Select Images",
            filetypes=[("Images", "*.jpg *.jpeg *.png *.bmp")]
        )
        
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
        
        self.image_count_label.config(text=f"Images: {len(self.image_paths)}")
        self.update_status(f"Loaded {len(files)} images")
    
    def start_training(self):
        if len(self.image_paths) < 4:
            messagebox.showerror("Error", "Need at least 4 images")
            return
        
        if self.training:
            return
        
        self.training = True
        
        try:
            batch_size = int(self.batch_var.get())
            max_epochs = int(self.epochs_var.get())
        except ValueError:
            batch_size = 4
            max_epochs = 50
        
        self.update_status(f"Training {self.image_size}px with {self.model_size} model")
        
        threading.Thread(target=self.training_thread, 
                        args=(batch_size, max_epochs), 
                        daemon=True).start()
    
    def stop_training(self):
        self.training = False
        self.update_status("Training stopped")
    
    def recreate_trainer(self):
        self.trainer = SizeAwareGANTrainer(
            self.device, 
            image_size=self.image_size,
            model_size=self.model_size
        )
    
    def training_thread(self, batch_size, max_epochs):
        try:
            dataset = LightweightDataset(self.image_paths, image_size=self.image_size)
            dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, 
                                  num_workers=0, pin_memory=False)
            
            start_time = time.time()
            
            while self.training and self.trainer.epoch < max_epochs:
                epoch_loss_g = 0
                epoch_loss_d = 0
                batch_count = 0
                
                for real_batch in dataloader:
                    if not self.training:
                        break
                    
                    real_batch = real_batch.to(self.device)
                    info = self.trainer.train_step(real_batch)
                    
                    epoch_loss_g += info['g_loss']
                    epoch_loss_d += info['d_loss']
                    batch_count += 1
                
                self.trainer.epoch += 1
                
                if batch_count > 0:
                    self.trainer.g_loss_history.append(epoch_loss_g / batch_count)
                    self.trainer.d_loss_history.append(epoch_loss_d / batch_count)
                
                # Update GUI
                self.root.after(0, self.update_training_info, 
                               self.trainer.epoch, 
                               epoch_loss_g / batch_count if batch_count > 0 else 0,
                               epoch_loss_d / batch_count if batch_count > 0 else 0)
                
                if self.trainer.epoch % 5 == 0:
                    elapsed = time.time() - start_time
                    self.update_status(f"Epoch {self.trainer.epoch}/{max_epochs} ({elapsed:.1f}s)")
            
            self.training = False
            self.update_status("Training complete")
            
        except Exception as e:
            self.update_status(f"Error: {str(e)}")
            print(f"Training error: {e}")
            import traceback
            traceback.print_exc()
            self.training = False
    
    def update_training_info(self, epoch, g_loss, d_loss):
        self.epoch_label.config(text=f"Epoch: {epoch}")
        self.g_loss_label.config(text=f"G Loss: {g_loss:.4f}")
        self.d_loss_label.config(text=f"D Loss: {d_loss:.4f}")
    
    def generate_images(self):
        try:
            images = self.trainer.generate_images(4)
            self.display_images(images)
            self.update_status(f"Generated {self.model_size} model images")
        except Exception as e:
            self.update_status(f"Gen error: {str(e)}")
    
    def save_generated(self):
        try:
            images = self.trainer.generate_images(4)
            os.makedirs("output", exist_ok=True)
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            
            for i, img_tensor in enumerate(images):
                img = img_tensor * 0.5 + 0.5
                img = transforms.ToPILImage()(img)
                
                # Save original size
                img.save(f"output/gen_{self.model_size}_{self.image_size}_{timestamp}_{i}.png")
                
                # Also save upscaled version with current filter
                upscaled = img.resize(
                    (self.image_size * self.display_scale, 
                     self.image_size * self.display_scale), 
                    self.filter_mode
                )
                upscaled.save(f"output/gen_{self.model_size}_{self.image_size}_upscaled_{timestamp}_{i}.png")
            
            self.update_status(f"Saved {self.model_size} images to output/")
        except Exception as e:
            self.update_status(f"Save error: {str(e)}")
    
    def save_model(self):
        file = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("Model", "*.pth")]
        )
        
        if file:
            self.trainer.save_model(file)
            self.update_status(f"Saved {self.model_size} model")
    
    def load_model(self):
        file = filedialog.askopenfilename(
            filetypes=[("Model", "*.pth")]
        )
        
        if file:
            try:
                self.trainer.load_model(file)
                self.model_size = self.trainer.model_size
                self.size_var.set(self.model_size)
                self.update_status(f"Loaded {self.model_size} model")
                self.generate_images()
            except Exception as e:
                self.update_status(f"Load error: {str(e)}")
    
    def display_images(self, images):
        if images is None or len(images) == 0:
            return
        
        images = images * 0.5 + 0.5
        
        for i, canvas in enumerate(self.gen_canvases):
            canvas.delete("all")
            
            if i < images.shape[0]:
                try:
                    img_tensor = images[i]
                    img = transforms.ToPILImage()(img_tensor)
                    
                    # Calculate display size
                    display_size = 250
                    img_size = self.image_size * self.display_scale
                    
                    # Resize with selected filter
                    img = img.resize((img_size, img_size), self.filter_mode)
                    
                    # If image is larger than display, scale down
                    if img_size > display_size:
                        img = img.resize((display_size, display_size), Image.Resampling.LANCZOS)
                    
                    photo = ImageTk.PhotoImage(img)
                    canvas.image = photo
                    
                    # Center the image on canvas
                    x_offset = (250 - img.width) // 2
                    y_offset = (250 - img.height) // 2
                    canvas.create_image(x_offset, y_offset, anchor=tk.NW, image=photo)
                    
                except Exception as e:
                    print(f"Display error: {e}")
                    canvas.create_text(125, 125, text="Error", fill="white", font=("Arial", 12))
    
    def refresh_display(self):
        """Refresh display with current filter settings"""
        try:
            # Try to regenerate and redisplay
            if hasattr(self.trainer, 'generator'):
                images = self.trainer.generate_images(4)
                self.display_images(images)
                self.update_status(f"Refreshed with {self.filter_var.get()}")
        except:
            pass
    
    def display_thread(self):
        while True:
            try:
                images = self.trainer.display_queue.get(timeout=0.5)
                self.root.after(0, self.display_images, images)
            except queue.Empty:
                continue
            except Exception as e:
                print(f"Display thread error: {e}")
    
    def update_status(self, msg):
        self.status_label.config(text=f"Status: {msg}")
        print(f"Status: {msg}")

# ==================== MAIN ====================
if __name__ == "__main__":
    print("=" * 60)
    print("CPU GAN Pro - Size & Filter Controls")
    print("=" * 60)
    print("Model Sizes (Smaller as requested):")
    print("- Tiny: 64 channels (Fast, low detail)")
    print("- Medium: 96 channels (Balanced)")
    print("- Large: 128 channels (Slow, high detail)")
    print("")
    print("Filter Options:")
    print("- Lanczos: Sharpest, best for detail")
    print("- Bicubic: Smooth, good for faces")
    print("- Bilinear: Balanced")
    print("- Nearest: Pixelated, retro look")
    print("- Box: Very blurry")
    print("- Hamming: Medium sharpness")
    print("=" * 60)
    print(f"CPU Threads: {torch.get_num_threads()}")
    print("=" * 60)
    
    root = tk.Tk()
    app = EnhancedGANApp(root)
    root.mainloop()