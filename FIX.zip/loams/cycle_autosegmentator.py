import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path

# ==================== Neural Network (U‑Net with feature head + Reconstructor) ====================

class AutoSegmentator:
    def __init__(self, in_channels=3, n_classes=5, init_filters=64, depth=3, latent_dim=128,
                 rec_init_filters=64, rec_depth=3):
        """
        U‑Net that outputs segmentation logits (n_classes) and provides a feature map
        for region embedding. Plus a second U‑Net that reconstructs the image from the segmentation.
        """
        self.n_classes = n_classes
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        torch.set_num_threads(multiprocessing.cpu_count())
        print(f"Using device: {self.device}, CPU threads: {torch.get_num_threads()}")

        # ----- Encoder -----
        class EncoderBlock(nn.Module):
            def __init__(self, in_ch, out_ch):
                super().__init__()
                self.conv = nn.Sequential(
                    nn.Conv2d(in_ch, out_ch, 3, padding=1),
                    nn.BatchNorm2d(out_ch),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(out_ch, out_ch, 3, padding=1),
                    nn.BatchNorm2d(out_ch),
                    nn.ReLU(inplace=True)
                )
                self.pool = nn.MaxPool2d(2)

            def forward(self, x):
                skip = self.conv(x)
                return skip, self.pool(skip)

        # ----- Decoder -----
        class DecoderBlock(nn.Module):
            def __init__(self, in_ch, out_ch):
                super().__init__()
                self.up = nn.ConvTranspose2d(in_ch, out_ch, 2, stride=2)
                self.conv = nn.Sequential(
                    nn.Conv2d(out_ch + out_ch, out_ch, 3, padding=1),
                    nn.BatchNorm2d(out_ch),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(out_ch, out_ch, 3, padding=1),
                    nn.BatchNorm2d(out_ch),
                    nn.ReLU(inplace=True)
                )

            def forward(self, x, skip):
                x = self.up(x)
                if x.size() != skip.size():
                    x = nn.functional.interpolate(x, size=skip.shape[2:])
                x = torch.cat([x, skip], dim=1)
                return self.conv(x)

        # ----- Full U‑Net (can be used for segmenter or reconstructor) -----
        class UNet(nn.Module):
            def __init__(self, in_ch, out_ch, init_filters, depth):
                super().__init__()
                self.depth = depth
                filters = [init_filters * (2**i) for i in range(depth+1)]
                self.enc_blocks = nn.ModuleList()
                in_ch_enc = in_ch
                for i in range(depth):
                    self.enc_blocks.append(EncoderBlock(in_ch_enc, filters[i]))
                    in_ch_enc = filters[i]
                self.bottleneck = nn.Sequential(
                    nn.Conv2d(in_ch_enc, filters[depth], 3, padding=1),
                    nn.BatchNorm2d(filters[depth]),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(filters[depth], filters[depth], 3, padding=1),
                    nn.BatchNorm2d(filters[depth]),
                    nn.ReLU(inplace=True)
                )
                self.dec_blocks = nn.ModuleList()
                for i in range(depth-1, -1, -1):
                    self.dec_blocks.append(DecoderBlock(filters[i+1], filters[i]))
                self.out_conv = nn.Conv2d(filters[0], out_ch, 1)

            def forward(self, x):
                skips = []
                for enc in self.enc_blocks:
                    skip, x = enc(x)
                    skips.append(skip)
                x = self.bottleneck(x)
                bottleneck_feat = x  # save for possible use
                for i, dec in enumerate(self.dec_blocks):
                    x = dec(x, skips[-(i+1)])
                out = self.out_conv(x)
                return out, bottleneck_feat

        # Segmenter
        self.unet = UNet(in_channels, n_classes, init_filters, depth).to(self.device)
        # Reconstructor: input = segmentation probabilities (n_classes), output = RGB image (3)
        self.reconstructor = UNet(n_classes, 3, rec_init_filters, rec_depth).to(self.device)

        # ----- Region feature projector (only for segmenter) -----
        bottleneck_dim = init_filters * (2**depth)
        self.projection = nn.Sequential(
            nn.Linear(bottleneck_dim, latent_dim),
            nn.ReLU(),
            nn.Linear(latent_dim, latent_dim)
        ).to(self.device)

        # ----- Optimizer (now includes reconstructor) -----
        self.optimizer = optim.Adam(
            list(self.unet.parameters()) + list(self.projection.parameters()) + list(self.reconstructor.parameters()),
            lr=0.0002, betas=(0.5, 0.999)
        )
        self.criterion = nn.MSELoss()          # for feature consistency
        self.l1_loss = nn.L1Loss()             # for reconstruction and cycle

    # -------------------- Original region feature methods (unchanged) --------------------
    def get_region_features(self, images, logits, bottleneck_feat):
        """
        images: (B,3,H,W) in [-1,1]
        logits: (B,n_classes,H,W)
        bottleneck_feat: (B, feat_dim, H', W')
        Returns:
            class_present: (B, n_classes) boolean
            region_feats: (B, n_classes, latent_dim) - features for each class (zero if absent)
        """
        B, n_classes, H, W = logits.shape
        probs = torch.softmax(logits, dim=1)  # (B, n_classes, H, W)

        # Downsample probs to bottleneck spatial size
        H_b, W_b = bottleneck_feat.shape[2:]
        probs_down = nn.functional.interpolate(probs, size=(H_b, W_b), mode='bilinear', align_corners=False)

        # Compute region features: weighted sum of bottleneck features, normalized by mask sum
        D = bottleneck_feat.shape[1]
        feat_expanded = bottleneck_feat.unsqueeze(1)           # (B, 1, D, H_b, W_b)
        probs_expanded = probs_down.unsqueeze(2)               # (B, n_classes, 1, H_b, W_b)
        weighted = feat_expanded * probs_expanded               # (B, n_classes, D, H_b, W_b)
        sum_weighted = weighted.sum(dim=(-1, -2))               # (B, n_classes, D)
        mask_sum = probs_down.sum(dim=(-1, -2)) + 1e-8          # (B, n_classes)

        region_raw = sum_weighted / mask_sum.unsqueeze(-1)      # (B, n_classes, D)
        # Project to latent space
        region_feats = self.projection(region_raw.view(-1, D))  # (B*n_classes, latent_dim)
        region_feats = region_feats.view(B, n_classes, -1)      # (B, n_classes, latent_dim)

        class_present = mask_sum > 1e-4
        return class_present, region_feats

    def compute_feature_loss(self, images, logits, bottleneck_feat):
        """
        Unsupervised loss: features of same class across batch should be close,
        different class prototypes should be far apart.
        """
        class_present, region_feats = self.get_region_features(images, logits, bottleneck_feat)
        B, n_classes, latent_dim = region_feats.shape

        loss = 0.0
        prototypes = []
        for c in range(n_classes):
            present_mask = class_present[:, c]
            if present_mask.sum() > 1:
                feats_c = region_feats[present_mask, c]            # (M, latent_dim)
                proto_c = feats_c.mean(dim=0, keepdim=True)        # (1, latent_dim)
                prototypes.append(proto_c)
                loss += self.criterion(feats_c, proto_c.expand_as(feats_c))
            else:
                prototypes.append(None)

        valid_protos = [p for p in prototypes if p is not None]
        if len(valid_protos) >= 2:
            proto_matrix = torch.cat(valid_protos, dim=0)          # (K, latent_dim)
            proto_norm = proto_matrix / (proto_matrix.norm(dim=1, keepdim=True) + 1e-8)
            sim = proto_norm @ proto_norm.T
            eye = torch.eye(len(valid_protos), device=self.device)
            off_diag = sim * (1 - eye)
            loss -= off_diag.mean() * 0.1
        return loss

    # -------------------- New cycle-consistency losses --------------------
    def compute_cycle_loss(self, images, cycle_weight=1.0, rec_weight=1.0):
        """
        images: (B,3,H,W) in [-1,1]
        Returns:
            total_loss: combined feature loss + reconstruction loss + cycle loss
        """
        # Segmenter forward
        logits, bottleneck_feat = self.unet(images)
        probs = torch.softmax(logits, dim=1)  # (B, n_classes, H, W)

        # Reconstructor forward (from soft segmentation)
        reconstructed, _ = self.reconstructor(probs)  # (B, 3, H, W)

        # Cycle: segment reconstructed image
        logits2, _ = self.unet(reconstructed)
        probs2 = torch.softmax(logits2, dim=1)

        # Losses
        feat_loss = self.compute_feature_loss(images, logits, bottleneck_feat)
        rec_loss = self.l1_loss(reconstructed, images)
        cycle_loss = self.l1_loss(probs2, probs)

        total = feat_loss + rec_weight * rec_loss + cycle_weight * cycle_loss
        return total, feat_loss, rec_loss, cycle_loss

# ==================== Dataset (unchanged) ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except:
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class AutoSegmentatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("AutoSegmentator - Unsupervised Segmentation with Cycle Reconstruction")
        self.root.geometry("1000x700")

        self.image_paths = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()

        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),          # fixed
            'init_filters': tk.IntVar(value=64),
            'depth': tk.IntVar(value=3),
            'latent_dim': tk.IntVar(value=128),
            'rec_init_filters': tk.IntVar(value=64),    # new for reconstructor
            'rec_depth': tk.IntVar(value=3),            # new
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
            'cycle_weight': tk.DoubleVar(value=1.0),    # new
            'rec_weight': tk.DoubleVar(value=1.0),      # new
        }

        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        self.segmentation_images = []   # for display

        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.segment_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.segment_tab, text='Segment')
        self.setup_segment_tab()

        # ---------- New Reconstruct Tab ----------
        self.reconstruct_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.reconstruct_tab, text='Reconstruct')
        self.setup_reconstruct_tab()

    # ------------------------------------------------------------------
    # Training Tab (unchanged)
    # ------------------------------------------------------------------
    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left panel
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="Segmentation Controls", font=("Arial",12,"bold")).pack(pady=(0,10))

        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=5)

        list_frame = tk.Frame(img_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=scrollbar.set)

        # Model controls
        model_frame = tk.LabelFrame(left_frame, text="Model", padx=10, pady=10)
        model_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(model_frame, text="Initialize Model", command=self.initialize_model, width=20).pack(pady=5)

        # Training
        train_frame = tk.LabelFrame(left_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0,10))
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="Start Training", command=self.start_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", command=self.stop_training,
                  width=20, bg="salmon").pack(pady=5)

        # Save / Load
        save_frame = tk.LabelFrame(left_frame, text="Save/Load", padx=10, pady=10)
        save_frame.pack(fill=tk.X)
        tk.Button(save_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)
        tk.Button(save_frame, text="Load Model", command=self.load_model, width=20).pack(pady=5)

        # Right panel - preview and log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Segmentation preview (single image)
        preview_frame = tk.LabelFrame(right_frame, text="Current Segmentation", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,10))
        self.preview_canvas = tk.Canvas(preview_frame, width=200, height=200, bg='gray')
        self.preview_canvas.pack(pady=10)

        # Log
        log_frame = tk.LabelFrame(right_frame, text="Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_log = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar_log.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar_log.set)

        self.status_label = tk.Label(self.training_tab, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    # ------------------------------------------------------------------
    # Settings Tab (added reconstructor parameters and loss weights)
    # ------------------------------------------------------------------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Model Settings", font=("Arial",14,"bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Network architecture (Segmenter)
        net_frame = tk.LabelFrame(scrollable_frame, text="Segmenter U‑Net", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=5)

        arch_params = [
            ("Segmenter initial filters:", 'init_filters', 16, 256),
            ("Segmenter depth:", 'depth', 2, 4),
            ("Latent dimension (feature head):", 'latent_dim', 32, 256),
        ]
        for label, key, low, high in arch_params:
            f = tk.Frame(net_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Reconstructor architecture (new)
        rec_frame = tk.LabelFrame(scrollable_frame, text="Reconstructor U‑Net", padx=10, pady=10)
        rec_frame.pack(fill=tk.X, pady=5)

        rec_params = [
            ("Reconstructor initial filters:", 'rec_init_filters', 16, 256),
            ("Reconstructor depth:", 'rec_depth', 2, 4),
        ]
        for label, key, low, high in rec_params:
            f = tk.Frame(rec_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Training parameters
        train_frame = tk.LabelFrame(scrollable_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=5)

        train_params = [
            ("Batch size:", 'batch_size', 1, 64),
            ("Learning rate:", 'learning_rate', 1e-5, 1e-2),
            ("Beta1 (Adam):", 'beta1', 0.0, 0.999),
            ("Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count()*2)),
        ]
        for label, key, low, high in train_params:
            f = tk.Frame(train_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            res = 0.00001 if key=='learning_rate' else (0.001 if key=='beta1' else 1)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Loss weights (new)
        loss_frame = tk.LabelFrame(scrollable_frame, text="Cycle Loss Weights", padx=10, pady=10)
        loss_frame.pack(fill=tk.X, pady=5)

        loss_params = [
            ("Reconstruction weight:", 'rec_weight', 0.0, 10.0),
            ("Cycle consistency weight:", 'cycle_weight', 0.0, 10.0),
        ]
        for label, key, low, high in loss_params:
            f = tk.Frame(loss_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=0.1).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=5)
        cpu = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU cores: {cpu}").pack(anchor='w')
        tk.Label(sys_frame, text=f"PyTorch threads: {torch.get_num_threads()}").pack(anchor='w')
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}").pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ------------------------------------------------------------------
    # Segment Tab (unchanged)
    # ------------------------------------------------------------------
    def setup_segment_tab(self):
        main_frame = tk.Frame(self.segment_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Segment an Image", font=("Arial",14,"bold")).pack(pady=(0,20))

        # Top controls
        ctrl_frame = tk.Frame(main_frame)
        ctrl_frame.pack(fill=tk.X, pady=5)

        tk.Button(ctrl_frame, text="Load Image", command=self.load_query_image).pack(side=tk.LEFT, padx=5)
        tk.Button(ctrl_frame, text="Load Dataset Folder", command=self.load_dataset_folder).pack(side=tk.LEFT, padx=5)
        tk.Label(ctrl_frame, text="Top K:").pack(side=tk.LEFT, padx=(20,5))
        self.topk_var = tk.IntVar(value=4)
        tk.Spinbox(ctrl_frame, from_=1, to=20, textvariable=self.topk_var, width=5).pack(side=tk.LEFT)
        tk.Button(ctrl_frame, text="Find Similar", command=self.find_similar).pack(side=tk.LEFT, padx=20)

        # Query display
        query_frame = tk.LabelFrame(main_frame, text="Query", padx=10, pady=10)
        query_frame.pack(fill=tk.X, pady=10)

        # Original image canvas (150x150)
        orig_container = tk.Frame(query_frame, width=150, height=150, bg='lightgray')
        orig_container.pack(side=tk.LEFT, padx=10)
        orig_container.pack_propagate(False)
        self.query_orig_canvas = tk.Canvas(orig_container, width=150, height=150, bg='lightgray', highlightthickness=0)
        self.query_orig_canvas.pack()
        self.query_orig_canvas.create_text(75, 75, text="Original", fill='black')

        # Segmented image canvas (150x150)
        seg_container = tk.Frame(query_frame, width=150, height=150, bg='lightgray')
        seg_container.pack(side=tk.LEFT, padx=10)
        seg_container.pack_propagate(False)
        self.query_seg_canvas = tk.Canvas(seg_container, width=150, height=150, bg='lightgray', highlightthickness=0)
        self.query_seg_canvas.pack()
        self.query_seg_canvas.create_text(75, 75, text="Segmented", fill='black')

        # Results scroll area
        results_frame = tk.LabelFrame(main_frame, text="Similar Images", padx=10, pady=10)
        results_frame.pack(fill=tk.BOTH, expand=True)

        self.results_canvas = tk.Canvas(results_frame, bg='white')
        scrollbar = tk.Scrollbar(results_frame, orient="vertical", command=self.results_canvas.yview)
        self.results_scroll_frame = tk.Frame(self.results_canvas)
        self.results_scroll_frame.bind(
            "<Configure>",
            lambda e: self.results_canvas.configure(scrollregion=self.results_canvas.bbox("all"))
        )
        self.results_canvas.create_window((0,0), window=self.results_scroll_frame, anchor="nw")
        self.results_canvas.configure(yscrollcommand=scrollbar.set)

        self.results_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.query_image_path = None
        self.query_image_pil = None
        self.dataset_folder = None
        self.dataset_paths = []

    # ------------------------------------------------------------------
    # New Reconstruct Tab
    # ------------------------------------------------------------------
    def setup_reconstruct_tab(self):
        main_frame = tk.Frame(self.reconstruct_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Reconstruct an Image", font=("Arial",14,"bold")).pack(pady=(0,20))

        # Load button
        btn_frame = tk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=5)
        tk.Button(btn_frame, text="Load Image", command=self.load_reconstruct_image).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Run Reconstruction", command=self.run_reconstruction).pack(side=tk.LEFT, padx=5)

        # Display area: three panels side by side
        display_frame = tk.Frame(main_frame)
        display_frame.pack(fill=tk.BOTH, expand=True, pady=10)

        # Original
        orig_container = tk.Frame(display_frame, width=200, height=200, bg='lightgray', relief=tk.RIDGE, bd=2)
        orig_container.pack(side=tk.LEFT, padx=10, expand=True, fill=tk.BOTH)
        orig_container.pack_propagate(False)
        tk.Label(orig_container, text="Original", font=("Arial",10,"bold")).pack()
        self.rec_orig_canvas = tk.Canvas(orig_container, width=180, height=180, bg='lightgray', highlightthickness=0)
        self.rec_orig_canvas.pack(pady=5)
        self.rec_orig_canvas.create_text(90, 90, text="No image", fill='black')

        # Segmented
        seg_container = tk.Frame(display_frame, width=200, height=200, bg='lightgray', relief=tk.RIDGE, bd=2)
        seg_container.pack(side=tk.LEFT, padx=10, expand=True, fill=tk.BOTH)
        seg_container.pack_propagate(False)
        tk.Label(seg_container, text="Segmented", font=("Arial",10,"bold")).pack()
        self.rec_seg_canvas = tk.Canvas(seg_container, width=180, height=180, bg='lightgray', highlightthickness=0)
        self.rec_seg_canvas.pack(pady=5)
        self.rec_seg_canvas.create_text(90, 90, text="Run after loading", fill='black')

        # Reconstructed
        rec_container = tk.Frame(display_frame, width=200, height=200, bg='lightgray', relief=tk.RIDGE, bd=2)
        rec_container.pack(side=tk.LEFT, padx=10, expand=True, fill=tk.BOTH)
        rec_container.pack_propagate(False)
        tk.Label(rec_container, text="Reconstructed", font=("Arial",10,"bold")).pack()
        self.rec_rec_canvas = tk.Canvas(rec_container, width=180, height=180, bg='lightgray', highlightthickness=0)
        self.rec_rec_canvas.pack(pady=5)
        self.rec_rec_canvas.create_text(90, 90, text="Run after loading", fill='black')

        self.reconstruct_image_path = None
        self.reconstruct_image_pil = None

    def load_reconstruct_image(self):
        f = filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png")])
        if not f:
            return
        self.reconstruct_image_path = f
        self.reconstruct_image_pil = Image.open(f).convert('RGB')
        # Show original (resized to 180x180)
        orig_small = self.reconstruct_image_pil.resize((180,180), Image.Resampling.LANCZOS)
        self.rec_photo_orig = ImageTk.PhotoImage(orig_small)
        self.rec_orig_canvas.delete("all")
        self.rec_orig_canvas.create_image(90, 90, image=self.rec_photo_orig)

    def run_reconstruction(self):
        if not self.model:
            self.log_message("No model loaded!")
            return
        if not self.reconstruct_image_pil:
            self.log_message("No image loaded!")
            return

        # Preprocess
        transform = transforms.Compose([
            transforms.Resize((32,32)),
            transforms.ToTensor(),
            transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
        ])
        img_t = transform(self.reconstruct_image_pil).unsqueeze(0).to(self.model.device)

        self.model.unet.eval()
        self.model.reconstructor.eval()
        with torch.no_grad():
            logits, _ = self.model.unet(img_t)
            probs = torch.softmax(logits, dim=1)
            seg = torch.argmax(logits, dim=1).cpu().numpy()[0]  # (32,32)
            reconstructed, _ = self.model.reconstructor(probs)   # (1,3,32,32)
        self.model.unet.train()
        self.model.reconstructor.train()

        # Convert segmentation to color for display
        seg_color = self.seg_to_color(seg)
        seg_pil = Image.fromarray(seg_color).resize((180,180), Image.NEAREST)
        self.rec_photo_seg = ImageTk.PhotoImage(seg_pil)
        self.rec_seg_canvas.delete("all")
        self.rec_seg_canvas.create_image(90, 90, image=self.rec_photo_seg)

        # Convert reconstructed tensor to PIL
        # reconstructed is in [-1,1] range
        rec_img = reconstructed[0].cpu().numpy().transpose(1,2,0)  # (32,32,3)
        rec_img = (rec_img * 0.5 + 0.5) * 255  # to [0,255]
        rec_img = np.clip(rec_img, 0, 255).astype(np.uint8)
        rec_pil = Image.fromarray(rec_img).resize((180,180), Image.Resampling.LANCZOS)
        self.rec_photo_rec = ImageTk.PhotoImage(rec_pil)
        self.rec_rec_canvas.delete("all")
        self.rec_rec_canvas.create_image(90, 90, image=self.rec_photo_rec)

        self.log_message("Reconstruction done.")

    # ------------------------------------------------------------------
    # Core functions (modified training and save/load)
    # ------------------------------------------------------------------
    def log_message(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(msg)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            filetypes=[("Images", "*.jpg *.jpeg *.png *.bmp")]
        )
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images")

    def initialize_model(self):
        try:
            self.model = AutoSegmentator(
                in_channels=3,
                n_classes=5,
                init_filters=self.settings['init_filters'].get(),
                depth=self.settings['depth'].get(),
                latent_dim=self.settings['latent_dim'].get(),
                rec_init_filters=self.settings['rec_init_filters'].get(),
                rec_depth=self.settings['rec_depth'].get()
            )
            self.log_message("Model initialized with reconstructor.")
        except Exception as e:
            self.log_message(f"Error: {e}")

    def start_training(self):
        if not self.image_paths:
            self.log_message("No images!")
            return
        if not self.model:
            self.log_message("Model not initialized!")
            return
        if self.training:
            self.log_message("Already training.")
            return

        try:
            epochs = int(self.epoch_var.get())
        except:
            self.log_message("Invalid epochs")
            return

        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()

        # Update optimizer hyperparameters
        for pg in self.model.optimizer.param_groups:
            pg['lr'] = self.settings['learning_rate'].get()
            pg['betas'] = (self.settings['beta1'].get(), 0.999)

        thread = threading.Thread(target=self.train_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_message(f"Training started for {epochs} epochs with cycle losses.")

    def train_loop(self, epochs):
        try:
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            dataset = ImageDataset(self.image_paths, 32)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=torch.cuda.is_available(),
                                persistent_workers=num_workers>0)

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                epoch_total_loss = 0.0
                epoch_feat_loss = 0.0
                epoch_rec_loss = 0.0
                epoch_cycle_loss = 0.0
                batches = 0
                epoch_start = time.time()

                for images in loader:
                    if not self.training:
                        break
                    images = images.to(self.model.device)
                    self.model.optimizer.zero_grad()

                    # Compute combined loss
                    total_loss, feat_loss, rec_loss, cycle_loss = self.model.compute_cycle_loss(
                        images,
                        cycle_weight=self.settings['cycle_weight'].get(),
                        rec_weight=self.settings['rec_weight'].get()
                    )
                    total_loss.backward()
                    self.model.optimizer.step()

                    epoch_total_loss += total_loss.item()
                    epoch_feat_loss += feat_loss.item()
                    epoch_rec_loss += rec_loss.item()
                    epoch_cycle_loss += cycle_loss.item()
                    batches += 1

                avg_total = epoch_total_loss / batches if batches else 0
                avg_feat = epoch_feat_loss / batches
                avg_rec = epoch_rec_loss / batches
                avg_cycle = epoch_cycle_loss / batches
                elapsed = time.time() - self.start_time
                self.log_message(
                    f"Epoch {epoch+1}/{epochs} | Total: {avg_total:.4f} | "
                    f"Feat: {avg_feat:.4f} | Rec: {avg_rec:.4f} | Cycle: {avg_cycle:.4f} | Time: {elapsed:.1f}s"
                )

                # Show a sample segmentation every 5 epochs
                if (epoch+1) % 5 == 0:
                    self.show_sample_segmentation(loader)

            self.training = False
            self.log_message("Training finished.")
        except Exception as e:
            self.log_message(f"Training error: {e}")
            import traceback
            traceback.print_exc()
            self.training = False

    def show_sample_segmentation(self, loader):
        """Pick a random image from loader, segment it, and display on GUI."""
        if not self.model:
            return
        try:
            data_iter = iter(loader)
            images = next(data_iter)
            img = images[0:1].to(self.model.device)
            self.model.unet.eval()
            with torch.no_grad():
                logits, _ = self.model.unet(img)
                seg = torch.argmax(logits, dim=1, keepdim=True)  # (1,1,H,W)
            self.model.unet.train()

            color_img = self.seg_to_color(seg[0,0].cpu().numpy())
            color_pil = Image.fromarray(color_img).resize((200,200), Image.NEAREST)
            photo = ImageTk.PhotoImage(color_pil)
            self.preview_canvas.create_image(100,100, image=photo)
            self.preview_canvas.image = photo
        except Exception as e:
            self.log_message(f"Preview error: {e}")

    def seg_to_color(self, seg_map):
        """Convert (H,W) integer labels to RGB image."""
        h,w = seg_map.shape
        color = np.zeros((h,w,3), dtype=np.uint8)
        color[seg_map==0] = [255,0,0]      # red
        color[seg_map==1] = [0,255,0]      # green
        color[seg_map==2] = [0,0,255]      # blue
        color[seg_map==3] = [255,0,255]    # magenta
        color[seg_map==4] = [255,255,0]    # yellow
        return color

    def stop_training(self):
        self.training = False
        self.log_message("Training stopped.")

    def save_model(self):
        if not self.model:
            self.log_message("No model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth",
                                              filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'unet': self.model.unet.state_dict(),
                'projection': self.model.projection.state_dict(),
                'reconstructor': self.model.reconstructor.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items()}
            }, fname)
            self.log_message(f"Model saved to {fname}")

    def load_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            if 'settings' in ckpt:
                s = ckpt['settings']
                self.settings['init_filters'].set(s.get('init_filters',64))
                self.settings['depth'].set(s.get('depth',3))
                self.settings['latent_dim'].set(s.get('latent_dim',128))
                self.settings['rec_init_filters'].set(s.get('rec_init_filters',64))
                self.settings['rec_depth'].set(s.get('rec_depth',3))
            self.initialize_model()
            self.model.unet.load_state_dict(ckpt['unet'])
            self.model.projection.load_state_dict(ckpt['projection'])
            if 'reconstructor' in ckpt:
                self.model.reconstructor.load_state_dict(ckpt['reconstructor'])
            self.model.unet.to(self.model.device)
            self.model.projection.to(self.model.device)
            self.model.reconstructor.to(self.model.device)
            self.log_message(f"Model loaded from {fname}")
        except Exception as e:
            self.log_message(f"Load error: {e}")

    # ------------------------------------------------------------------
    # Segment tab functions (unchanged)
    # ------------------------------------------------------------------
    def load_query_image(self):
        f = filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png")])
        if not f:
            return
        self.query_image_path = f
        self.query_image_pil = Image.open(f).convert('RGB')
        orig_small = self.query_image_pil.resize((150,150), Image.Resampling.LANCZOS)
        self.photo_orig = ImageTk.PhotoImage(orig_small)
        self.query_orig_canvas.delete("all")
        self.query_orig_canvas.create_image(75, 75, image=self.photo_orig)
        if self.model:
            self.segment_and_display_query()
        else:
            self.query_seg_canvas.delete("all")
            self.query_seg_canvas.create_text(75, 75, text="No model", fill='black')

    def segment_and_display_query(self):
        if not self.model or not self.query_image_pil:
            return
        transform = transforms.Compose([
            transforms.Resize((32,32)),
            transforms.ToTensor(),
            transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
        ])
        img_t = transform(self.query_image_pil).unsqueeze(0).to(self.model.device)
        self.model.unet.eval()
        with torch.no_grad():
            logits, _ = self.model.unet(img_t)
            seg = torch.argmax(logits, dim=1).cpu().numpy()[0]
        self.model.unet.train()
        seg_color = self.seg_to_color(seg)
        seg_pil = Image.fromarray(seg_color).resize((150,150), Image.NEAREST)
        self.photo_seg = ImageTk.PhotoImage(seg_pil)
        self.query_seg_canvas.delete("all")
        self.query_seg_canvas.create_image(75, 75, image=self.photo_seg)
        self.last_query_seg = seg

    def load_dataset_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.dataset_folder = folder
            self.dataset_paths = list(Path(folder).glob("*.jpg")) + list(Path(folder).glob("*.png"))
            self.log_message(f"Loaded {len(self.dataset_paths)} images from folder.")

    def find_similar(self):
        if not self.model or not self.query_image_path or not self.dataset_paths:
            self.log_message("Missing model, query image, or dataset folder.")
            return
        if not hasattr(self, 'last_query_seg'):
            self.segment_and_display_query()
            if not hasattr(self, 'last_query_seg'):
                return

        topk = self.topk_var.get()
        similarities = []
        transform = transforms.Compose([
            transforms.Resize((32,32)),
            transforms.ToTensor(),
            transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
        ])
        self.model.unet.eval()
        with torch.no_grad():
            query_flat = self.last_query_seg.flatten()
            for path in self.dataset_paths:
                try:
                    img = Image.open(path).convert('RGB')
                    img_t = transform(img).unsqueeze(0).to(self.model.device)
                    logits, _ = self.model.unet(img_t)
                    seg = torch.argmax(logits, dim=1).cpu().numpy()[0]
                    sim = (seg.flatten() == query_flat).mean()
                    similarities.append((sim, path, seg))
                except:
                    continue
        self.model.unet.train()

        similarities.sort(key=lambda x: x[0], reverse=True)
        top = similarities[:topk]

        for w in self.results_scroll_frame.winfo_children():
            w.destroy()

        for i, (sim, path, seg) in enumerate(top):
            row_frame = tk.Frame(self.results_scroll_frame, relief=tk.RIDGE, bd=2)
            row_frame.pack(fill=tk.X, pady=5, padx=5)

            orig_frame = tk.Frame(row_frame, width=64, height=64, bg='white')
            orig_frame.pack(side=tk.LEFT, padx=5)
            orig_frame.pack_propagate(False)
            orig_img = Image.open(path).convert('RGB').resize((64,64), Image.Resampling.LANCZOS)
            photo_orig = ImageTk.PhotoImage(orig_img)
            lbl_orig = tk.Label(orig_frame, image=photo_orig)
            lbl_orig.image = photo_orig
            lbl_orig.pack(fill=tk.BOTH, expand=True)

            seg_frame = tk.Frame(row_frame, width=64, height=64, bg='white')
            seg_frame.pack(side=tk.LEFT, padx=5)
            seg_frame.pack_propagate(False)
            seg_color = self.seg_to_color(seg)
            seg_pil = Image.fromarray(seg_color).resize((64,64), Image.NEAREST)
            photo_seg = ImageTk.PhotoImage(seg_pil)
            lbl_seg = tk.Label(seg_frame, image=photo_seg)
            lbl_seg.image = photo_seg
            lbl_seg.pack(fill=tk.BOTH, expand=True)

            tk.Label(row_frame, text=f"Sim: {sim:.3f}").pack(side=tk.LEFT, padx=10)

        self.log_message(f"Displayed top {topk} similar images.")

# ==================== Main ====================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = AutoSegmentatorApp(root)
    root.mainloop()