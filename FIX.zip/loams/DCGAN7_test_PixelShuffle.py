import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import math

# ==================== Self-Attention Module (Fixed - No Inplace) ====================

class SelfAttention(nn.Module):
    """Self-Attention Module without inplace operations"""
    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels
        
        # Query, Key, Value transformations (1x1 convolutions)
        self.query = nn.Conv2d(in_channels, in_channels // 8, 1, bias=False)
        self.key = nn.Conv2d(in_channels, in_channels // 8, 1, bias=False)
        self.value = nn.Conv2d(in_channels, in_channels, 1, bias=False)
        
        # Gamma parameter (learnable)
        self.gamma = nn.Parameter(torch.zeros(1))
        
        self.softmax = nn.Softmax(dim=-1)
        
        # Initialize conv layers
        nn.init.normal_(self.query.weight, 0.0, 0.02)
        nn.init.normal_(self.key.weight, 0.0, 0.02)
        nn.init.normal_(self.value.weight, 0.0, 0.02)

    def forward(self, x):
        batch_size, C, width, height = x.size()
        
        # Get queries, keys, values
        q = self.query(x).view(batch_size, -1, width * height).permute(0, 2, 1)
        k = self.key(x).view(batch_size, -1, width * height)
        v = self.value(x).view(batch_size, -1, width * height)
        
        # Calculate attention
        attention = torch.bmm(q, k)
        attention = self.softmax(attention)
        
        # Apply attention to values
        out = torch.bmm(v, attention.permute(0, 2, 1))
        out = out.view(batch_size, C, width, height)
        
        # Add to input with learnable weight (NO inplace operation)
        return self.gamma * out + x

# ==================== Improved Neural Network with PixelShuffle ====================

class ImprovedDCGAN:
    def __init__(self, image_size=32, latent_dim=100, ngf=64, ndf=64, 
                 use_attention=True, use_sn=True, use_orthogonal=True,
                 use_pixelshuffle=True):  # New parameter
        self.image_size = image_size
        self.latent_dim = latent_dim
        self.use_attention = use_attention
        self.use_sn = use_sn
        self.use_orthogonal = use_orthogonal
        self.use_pixelshuffle = use_pixelshuffle  # PixelShuffle toggle
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Generator
        class Generator(nn.Module):
            def __init__(self, image_size, latent_dim, ngf, use_attention, use_sn, use_orthogonal, use_pixelshuffle):
                super().__init__()
                self.use_pixelshuffle = use_pixelshuffle
                
                # Initial linear layer
                self.init_size = image_size // 8
                self.l1 = nn.Linear(latent_dim, ngf * 8 * self.init_size * self.init_size)
                
                if use_pixelshuffle:
                    # ===== PixelShuffle Architecture =====
                    # Start with ngf*8 channels at 4x4
                    self.initial_conv = nn.Conv2d(ngf * 8, ngf * 8, 3, 1, 1, bias=False)
                    self.bn1 = nn.BatchNorm2d(ngf * 8)
                    
                    # First PixelShuffle: 4x4 -> 8x8 (ngf*8 -> ngf*4)
                    self.ps1 = nn.PixelShuffle(2)
                    self.conv_after_ps1 = nn.Conv2d(ngf * 2, ngf * 4, 3, 1, 1, bias=False)  # Note: channels after shuffle
                    self.bn2 = nn.BatchNorm2d(ngf * 4)
                    
                    # Second PixelShuffle: 8x8 -> 16x16 (ngf*4 -> ngf*2)
                    self.ps2 = nn.PixelShuffle(2)
                    self.conv_after_ps2 = nn.Conv2d(ngf * 1, ngf * 2, 3, 1, 1, bias=False)  # Note: channels after shuffle
                    self.bn3 = nn.BatchNorm2d(ngf * 2)
                    
                    # Add self-attention at 16x16 resolution (ngf*2 channels)
                    self.attention = None
                    if use_attention:
                        self.attention = SelfAttention(ngf * 2)
                    
                    # Third PixelShuffle: 16x16 -> 32x32 (ngf*2 -> ngf)
                    self.ps3 = nn.PixelShuffle(2)
                    self.conv_after_ps3 = nn.Conv2d(ngf // 2, ngf, 3, 1, 1, bias=False)  # Note: channels after shuffle
                    self.bn4 = nn.BatchNorm2d(ngf)
                    
                    # Final to 3 channels
                    self.final_conv = nn.Conv2d(ngf, 3, 3, 1, 1, bias=False)
                    
                    # Apply spectral norm if enabled
                    if use_sn:
                        self.initial_conv = nn.utils.spectral_norm(self.initial_conv)
                        self.conv_after_ps1 = nn.utils.spectral_norm(self.conv_after_ps1)
                        self.conv_after_ps2 = nn.utils.spectral_norm(self.conv_after_ps2)
                        self.conv_after_ps3 = nn.utils.spectral_norm(self.conv_after_ps3)
                        self.final_conv = nn.utils.spectral_norm(self.final_conv)
                else:
                    # ===== Original ConvTranspose Architecture =====
                    # Main conv layers
                    self.conv1 = nn.ConvTranspose2d(ngf * 8, ngf * 4, 4, 2, 1, bias=False)
                    self.conv2 = nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False)
                    self.conv3 = nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False)
                    self.conv4 = nn.Conv2d(ngf, 3, 3, 1, 1, bias=False)
                    
                    # Batch norms
                    self.bn1 = nn.BatchNorm2d(ngf * 8)
                    self.bn2 = nn.BatchNorm2d(ngf * 4)
                    self.bn3 = nn.BatchNorm2d(ngf * 2)
                    self.bn4 = nn.BatchNorm2d(ngf)
                    
                    # Add self-attention at 16x16 resolution (ngf*2 channels)
                    self.attention = None
                    if use_attention:
                        self.attention = SelfAttention(ngf * 2)
                    
                    # Apply spectral norm if enabled
                    if use_sn:
                        self.conv1 = nn.utils.spectral_norm(self.conv1)
                        self.conv2 = nn.utils.spectral_norm(self.conv2)
                        self.conv3 = nn.utils.spectral_norm(self.conv3)
                        self.conv4 = nn.utils.spectral_norm(self.conv4)
                
                # Initialize weights
                self._initialize_weights(use_orthogonal)
                
            def _initialize_weights(self, use_orthogonal):
                """Initialize weights"""
                for m in self.modules():
                    if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d, nn.Linear)):
                        if use_orthogonal:
                            nn.init.orthogonal_(m.weight)
                            if m.bias is not None:
                                nn.init.constant_(m.bias, 0)
                        else:
                            nn.init.normal_(m.weight, 0.0, 0.02)
                            
                    elif isinstance(m, nn.BatchNorm2d):
                        nn.init.normal_(m.weight, 1.0, 0.02)
                        nn.init.constant_(m.bias, 0)
                
            def forward(self, z):
                # Linear layer
                out = self.l1(z)
                out = out.view(out.shape[0], -1, self.init_size, self.init_size)
                
                if self.use_pixelshuffle:
                    # ===== PixelShuffle Forward Pass =====
                    # Initial processing at 4x4
                    out = self.initial_conv(out)
                    out = self.bn1(out)
                    out = torch.relu(out)
                    
                    # First PixelShuffle: 4x4 -> 8x8
                    out = self.ps1(out)  # ngf*8 -> ngf*2 (channels divided by 4)
                    out = self.conv_after_ps1(out)
                    out = self.bn2(out)
                    out = torch.relu(out)
                    
                    # Second PixelShuffle: 8x8 -> 16x16
                    out = self.ps2(out)  # ngf*4 -> ngf*1 (channels divided by 4)
                    out = self.conv_after_ps2(out)
                    out = self.bn3(out)
                    out = torch.relu(out)
                    
                    # Self-attention at 16x16 (ngf*2 channels)
                    if self.attention is not None:
                        out = self.attention(out)
                    
                    # Third PixelShuffle: 16x16 -> 32x32
                    out = self.ps3(out)  # ngf*2 -> ngf//2 (channels divided by 4)
                    out = self.conv_after_ps3(out)
                    out = self.bn4(out)
                    out = torch.relu(out)
                    
                    # Final to 3 channels
                    out = self.final_conv(out)
                    out = torch.tanh(out)
                else:
                    # ===== Original ConvTranspose Forward Pass =====
                    # ngf*8 x 4x4 -> ngf*4 x 8x8
                    out = self.bn1(out)
                    out = torch.relu(out)
                    out = self.conv1(out)
                    
                    # ngf*4 x 8x8 -> ngf*2 x 16x16
                    out = self.bn2(out)
                    out = torch.relu(out)
                    out = self.conv2(out)
                    
                    # Self-attention at 16x16 (ngf*2 channels)
                    if self.attention is not None:
                        out = self.attention(out)
                    
                    # ngf*2 x 16x16 -> ngf x 32x32
                    out = self.bn3(out)
                    out = torch.relu(out)
                    out = self.conv3(out)
                    
                    # Final to 3 channels
                    out = self.bn4(out)
                    out = torch.relu(out)
                    out = self.conv4(out)
                    out = torch.tanh(out)
                
                return out
        
        # Discriminator (remains the same, but we can also optionally add PixelShuffle downsampling)
        class Discriminator(nn.Module):
            def __init__(self, image_size, ndf, use_attention, use_sn):
                super().__init__()
                
                self.conv1 = nn.Conv2d(3, ndf, 4, 2, 1, bias=False)
                self.conv2 = nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False)
                self.conv3 = nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False)
                self.conv4 = nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False)
                
                self.bn2 = nn.BatchNorm2d(ndf * 2)
                self.bn3 = nn.BatchNorm2d(ndf * 4)
                
                # Add self-attention at 8x8 resolution (ndf*2 channels)
                self.attention = None
                if use_attention:
                    self.attention = SelfAttention(ndf * 2)
                
                # Apply spectral norm if enabled
                if use_sn:
                    self.conv1 = nn.utils.spectral_norm(self.conv1)
                    self.conv2 = nn.utils.spectral_norm(self.conv2)
                    self.conv3 = nn.utils.spectral_norm(self.conv3)
                    self.conv4 = nn.utils.spectral_norm(self.conv4)
                
                # Initialize weights
                self._initialize_weights(use_orthogonal)
                
            def _initialize_weights(self, use_orthogonal):
                """Initialize weights"""
                for m in self.modules():
                    if isinstance(m, (nn.Conv2d, nn.Linear)):
                        if use_orthogonal:
                            nn.init.orthogonal_(m.weight)
                            if m.bias is not None:
                                nn.init.constant_(m.bias, 0)
                        else:
                            nn.init.normal_(m.weight, 0.0, 0.02)
                            
                    elif isinstance(m, nn.BatchNorm2d):
                        nn.init.normal_(m.weight, 1.0, 0.02)
                        nn.init.constant_(m.bias, 0)
                
            def forward(self, img):
                # 3 x 32x32 -> ndf x 16x16
                out = self.conv1(img)
                out = torch.nn.functional.leaky_relu(out, 0.2)
                
                # ndf x 16x16 -> ndf*2 x 8x8
                out = self.conv2(out)
                out = self.bn2(out)
                out = torch.nn.functional.leaky_relu(out, 0.2)
                
                # Self-attention at 8x8 (ndf*2 channels)
                if self.attention is not None:
                    out = self.attention(out)
                
                # ndf*2 x 8x8 -> ndf*4 x 4x4
                out = self.conv3(out)
                out = self.bn3(out)
                out = torch.nn.functional.leaky_relu(out, 0.2)
                
                # ndf*4 x 4x4 -> 1 x 1x1
                out = self.conv4(out)
                
                return out.view(-1, 1)
        
        # Create networks
        self.generator = Generator(image_size, latent_dim, ngf, use_attention, use_sn, use_orthogonal, use_pixelshuffle)
        self.discriminator = Discriminator(image_size, ndf, use_attention, use_sn)
        
        # Loss with label smoothing for better generalization
        self.criterion = nn.BCEWithLogitsLoss()
        
        # Optimizers
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
        
        # For tracking training stats
        self.d_losses = []
        self.g_losses = []
        self.real_scores = []
        self.fake_scores = []

# ==================== Enhanced Dataset with Augmentation ====================

class EnhancedImageDataset(Dataset):
    """Dataset with augmentations for better training"""
    def __init__(self, image_paths, image_size=32, augment=True):
        self.image_paths = image_paths
        self.image_size = image_size
        self.augment = augment
        
        # Basic transforms
        self.base_transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
        
        # Augmentation transforms
        if augment:
            self.augment_transform = transforms.Compose([
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomRotation(5),
                transforms.ColorJitter(brightness=0.1, contrast=0.1),
            ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            
            # Apply augmentation if enabled
            if self.augment and np.random.random() > 0.5:
                img = self.augment_transform(img)
            
            return self.base_transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            # Return a random noise image as fallback
            return torch.rand(3, self.image_size, self.image_size) * 2 - 1

# ==================== GUI Application ====================

class EnhancedDCGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Enhanced DCGAN Trainer - Modern Techniques")
        self.root.geometry("1000x700")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_dim': tk.IntVar(value=100),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=32),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
            'generate_interval': tk.IntVar(value=5),
            # Enhanced settings
            'use_attention': tk.BooleanVar(value=True),
            'use_spectral_norm': tk.BooleanVar(value=True),
            'use_orthogonal': tk.BooleanVar(value=True),
            'use_pixelshuffle': tk.BooleanVar(value=True),  # New setting
            'use_data_augmentation': tk.BooleanVar(value=True),
            'label_smoothing': tk.BooleanVar(value=True),
        }
        
        # Performance tracking
        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None
        
        # For storing generated images
        self.generated_images = []
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Enhanced DCGAN Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text="Image Size: 32x32")
        self.size_display.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize GAN", 
                 command=self.initialize_gan, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Single image display (200x200)
        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar at bottom
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="Enhanced DCGAN Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar for many settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Image size - Fixed to 32x32
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed)", width=20, anchor='w').pack(side=tk.LEFT, padx=5)
        
        # Other network parameters
        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 10, 500),
            ("Generator Features (ngf):", 'ngf', 32, 256),
            ("Discriminator Features (ndf):", 'ndf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 128),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Enhanced techniques
        enhanced_frame = tk.LabelFrame(scrollable_frame, text="Enhanced Techniques", padx=10, pady=10)
        enhanced_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Create 2 columns for checkboxes
        left_frame = tk.Frame(enhanced_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10)
        
        right_frame = tk.Frame(enhanced_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10)
        
        # Left column
        tk.Checkbutton(left_frame, text="Self-Attention", 
                      variable=self.settings['use_attention'], anchor='w').pack(fill=tk.X, pady=5)
        tk.Checkbutton(left_frame, text="Spectral Normalization", 
                      variable=self.settings['use_spectral_norm'], anchor='w').pack(fill=tk.X, pady=5)
        tk.Checkbutton(left_frame, text="Orthogonal Initialization", 
                      variable=self.settings['use_orthogonal'], anchor='w').pack(fill=tk.X, pady=5)
        tk.Checkbutton(left_frame, text="PixelShuffle (Generator)", 
                      variable=self.settings['use_pixelshuffle'], anchor='w').pack(fill=tk.X, pady=5)
        
        # Right column
        tk.Checkbutton(right_frame, text="Data Augmentation", 
                      variable=self.settings['use_data_augmentation'], anchor='w').pack(fill=tk.X, pady=5)
        tk.Checkbutton(right_frame, text="Label Smoothing", 
                      variable=self.settings['label_smoothing'], anchor='w').pack(fill=tk.X, pady=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset to Paper", 
                 command=self.reset_to_paper, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(load_frame, text="Load Generator", 
                 command=self.load_generator, width=20).pack(pady=5)
        
        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var, 
                orient=tk.HORIZONTAL, length=300).pack(pady=5)
        
        tk.Button(gen_frame, text="Generate Grid", 
                 command=self.generate_grid, width=20).pack(pady=10)
        
        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)
        
        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )
        
        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)
        
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def update_size_display(self):
        """Update image size display in training tab"""
        self.size_display.config(text=f"Image Size: {self.settings['image_size'].get()}x{self.settings['image_size'].get()}")

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                # Add to log
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                
                # Update status with first line
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                
                print(message)  # Also print to console
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_gan(self):
        """Initialize GAN with current settings"""
        try:
            image_size = self.settings['image_size'].get()
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            use_attention = self.settings['use_attention'].get()
            use_sn = self.settings['use_spectral_norm'].get()
            use_orthogonal = self.settings['use_orthogonal'].get()
            use_pixelshuffle = self.settings['use_pixelshuffle'].get()
            
            self.gan = ImprovedDCGAN(
                image_size=image_size,
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf,
                use_attention=use_attention,
                use_sn=use_sn,
                use_orthogonal=use_orthogonal,
                use_pixelshuffle=use_pixelshuffle
            )
            
            self.log_message(f"Initialized Enhanced DCGAN for {image_size}x{image_size} images")
            self.log_message(f"Features: Attention={use_attention}, SN={use_sn}, Orthogonal={use_orthogonal}, PixelShuffle={use_pixelshuffle}")
            self.log_message(f"Latent dim: {latent_dim}, G features: {ngf}, D features: {ndf}")
            
            # Test generator with a sample
            if self.test_generator():
                self.log_message("Generator test passed! Ready for training.")
            else:
                self.log_message("Warning: Generator test failed!")
            
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
            import traceback
            traceback_str = traceback.format_exc()
            self.log_message("Full traceback:")
            self.log_message(traceback_str)

    def test_generator(self):
        """Test if generator works"""
        try:
            with torch.no_grad():
                # Test with batch size 1
                noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                output = self.gan.generator(noise)
                self.log_message(f"Generator test: Output shape: {output.shape}")
                
                # Test with batch size 4 (typical training)
                noise = torch.randn(4, self.gan.latent_dim, device=self.gan.device)
                output = self.gan.generator(noise)
                self.log_message(f"Generator test with batch 4: Output shape: {output.shape}")
                
                # Test discriminator
                test_img = torch.randn(4, 3, 32, 32, device=self.gan.device)
                disc_output = self.gan.discriminator(test_img)
                self.log_message(f"Discriminator test: Output shape: {disc_output.shape}")
                
                return True
        except Exception as e:
            self.log_message(f"Generator test failed: {str(e)}")
            import traceback
            traceback_str = traceback.format_exc()
            self.log_message("Full traceback:")
            self.log_message(traceback_str)
            return False

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            # Get settings
            use_augmentation = self.settings['use_data_augmentation'].get()
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            epochs = int(self.epoch_var.get())
            
            # Update optimizers
            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            for param_group in self.gan.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_enhanced,
                args=(epochs, batch_size, num_workers, use_augmentation),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Starting Enhanced Training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr:.6f}, Beta1: {beta1:.3f}")
            self.log_message(f"Augmentation: {use_augmentation}")
            
        except ValueError as e:
            self.log_message(f"Error: Invalid number of epochs! {str(e)}")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")
            import traceback
            traceback_str = traceback.format_exc()
            self.log_message("Full traceback:")
            self.log_message(traceback_str)

    def train_enhanced(self, epochs, batch_size, num_workers, use_augmentation):
        """Enhanced training loop with modern techniques"""
        try:
            image_size = self.settings['image_size'].get()
            generate_interval = self.settings['generate_interval'].get()
            label_smoothing = self.settings['label_smoothing'].get()
            
            # Create enhanced dataset
            dataset = EnhancedImageDataset(self.image_paths, image_size, augment=use_augmentation)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                total_real_score = 0
                total_fake_score = 0
                batch_count = 0
                epoch_start = time.time()
                
                for real_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # Label smoothing
                    if label_smoothing:
                        real_labels = torch.full((batch_size_actual, 1), 0.9, device=self.gan.device)
                        fake_labels = torch.full((batch_size_actual, 1), 0.1, device=self.gan.device)
                    else:
                        real_labels = torch.ones(batch_size_actual, 1, device=self.gan.device)
                        fake_labels = torch.zeros(batch_size_actual, 1, device=self.gan.device)
                    
                    # ===== Train Discriminator =====
                    self.gan.optimizerD.zero_grad(set_to_none=True)
                    
                    # Real images
                    output_real = self.gan.discriminator(real_images)
                    loss_real = self.gan.criterion(output_real, real_labels)
                    
                    # Fake images
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    output_fake = self.gan.discriminator(fake_images.detach())
                    loss_fake = self.gan.criterion(output_fake, fake_labels)
                    
                    # Total discriminator loss
                    loss_d = (loss_real + loss_fake) / 2
                    loss_d.backward()
                    self.gan.optimizerD.step()
                    
                    # Track scores (for monitoring)
                    total_real_score += torch.sigmoid(output_real).mean().item()
                    total_fake_score += torch.sigmoid(output_fake).mean().item()
                    
                    # ===== Train Generator =====
                    self.gan.optimizerG.zero_grad(set_to_none=True)
                    output_fake = self.gan.discriminator(fake_images)
                    loss_g = self.gan.criterion(output_fake, real_labels)
                    loss_g.backward()
                    self.gan.optimizerG.step()
                    
                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    avg_real_score = total_real_score / batch_count
                    avg_fake_score = total_fake_score / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    # Store for tracking
                    self.gan.d_losses.append(avg_loss_d)
                    self.gan.g_losses.append(avg_loss_g)
                    self.gan.real_scores.append(avg_real_score)
                    self.gan.fake_scores.append(avg_fake_score)
                    
                    # Log progress
                    elapsed = time.time() - self.start_time
                    progress = (epoch + 1) / epochs * 100
                    
                    self.log_message(f"Epoch {epoch+1}/{epochs} [{progress:.1f}%] | "
                                   f"D Loss: {avg_loss_d:.4f} | "
                                   f"G Loss: {avg_loss_g:.4f} | "
                                   f"Real: {avg_real_score:.3f} | "
                                   f"Fake: {avg_fake_score:.3f} | "
                                   f"Time: {epoch_time:.1f}s")
                    
                    # Generate samples
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                
                # Monitor training health
                if len(self.gan.real_scores) > 10:
                    recent_real = np.mean(self.gan.real_scores[-5:])
                    recent_fake = np.mean(self.gan.fake_scores[-5:])
                    
                    # If discriminator is too strong, log warning
                    if recent_real > 0.95 and recent_fake < 0.05:
                        self.log_message("Warning: Discriminator too strong! Consider reducing learning rate.")
                    # If generator is winning too much
                    elif recent_fake > 0.7:
                        self.log_message("Warning: Generator might be overpowering discriminator.")
            
            self.training = False
            total_time = time.time() - self.start_time
            self.log_message(f"Training completed in {total_time:.1f}s ({total_time/60:.1f} minutes)!")
            
            # Plot training curves if matplotlib is available
            self.plot_training_curves()
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.log_message("Full error traceback:")
            import traceback
            traceback_str = traceback.format_exc()
            self.log_message(traceback_str)
            self.training = False
        finally:
            self.training = False

    def generate_training_samples(self):
        """Generate sample images during training"""
        if not self.gan:
            return
        
        try:
            with torch.no_grad():
                # Generate 1 image
                noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                generated = self.gan.generator(noise).cpu()
                
                # Convert to PIL
                img_tensor = generated[0]
                img = self.tensor_to_pil(img_tensor)
                
                # Resize to 200x200 for display using NEAREST
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                
                # Convert to PhotoImage
                photo = ImageTk.PhotoImage(img_display)
                
                # Update single image display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo  # Keep reference
                
                # Store for later
                self.generated_images.append(img)
                
                self.log_message(f"Generated sample at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")
            import traceback
            traceback_str = traceback.format_exc()
            self.log_message("Full traceback:")
            self.log_message(traceback_str)

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        img = (tensor + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        """Generate a single sample"""
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, device=self.gan.device)
                generated = self.gan.generator(noise).cpu()
                img = self.tensor_to_pil(generated[0])
                
                # Resize for display using NEAREST
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                
                # Store
                self.generated_images.append(img)
                
                self.log_message("Generated single sample")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")
            import traceback
            traceback_str = traceback.format_exc()
            self.log_message("Full traceback:")
            self.log_message(traceback_str)

    def save_model(self):
        """Save current model"""
        if not self.gan:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'discriminator_state_dict': self.gan.discriminator.state_dict(),
                    'optimizerG_state_dict': self.gan.optimizerG.state_dict(),
                    'optimizerD_state_dict': self.gan.optimizerD.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                    'use_attention': self.settings['use_attention'].get(),
                    'use_sn': self.settings['use_spectral_norm'].get(),
                    'use_orthogonal': self.settings['use_orthogonal'].get(),
                    'use_pixelshuffle': self.settings['use_pixelshuffle'].get(),
                    'd_losses': self.gan.d_losses,
                    'g_losses': self.gan.g_losses,
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")
                import traceback
                traceback_str = traceback.format_exc()
                self.log_message("Full traceback:")
                self.log_message(traceback_str)

    def load_generator(self):
        """Load generator from file"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                if 'image_size' in checkpoint:
                    self.settings['image_size'].set(checkpoint['image_size'])
                    self.update_size_display()
                
                if 'latent_dim' in checkpoint:
                    self.settings['latent_dim'].set(checkpoint['latent_dim'])
                
                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])
                
                if 'ndf' in checkpoint:
                    self.settings['ndf'].set(checkpoint['ndf'])
                
                # Load enhanced settings if available
                if 'use_attention' in checkpoint:
                    self.settings['use_attention'].set(checkpoint['use_attention'])
                if 'use_sn' in checkpoint:
                    self.settings['use_spectral_norm'].set(checkpoint['use_sn'])
                if 'use_orthogonal' in checkpoint:
                    self.settings['use_orthogonal'].set(checkpoint['use_orthogonal'])
                if 'use_pixelshuffle' in checkpoint:
                    self.settings['use_pixelshuffle'].set(checkpoint['use_pixelshuffle'])
                
                # Initialize GAN with loaded settings
                self.initialize_gan()
                
                # Load state dicts
                self.gan.generator.load_state_dict(checkpoint['generator_state_dict'])
                if 'discriminator_state_dict' in checkpoint:
                    self.gan.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])
                
                # Load training stats if available
                if 'd_losses' in checkpoint:
                    self.gan.d_losses = checkpoint['d_losses']
                if 'g_losses' in checkpoint:
                    self.gan.g_losses = checkpoint['g_losses']
                
                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")
                import traceback
                traceback_str = traceback.format_exc()
                self.log_message("Full traceback:")
                self.log_message(traceback_str)

    def generate_grid(self):
        """Generate a grid of images"""
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            num_images = self.num_gen_var.get()
            
            with torch.no_grad():
                noise = torch.randn(num_images, self.gan.latent_dim, device=self.gan.device)
                generated = self.gan.generator(noise).cpu()
            
            # Clear previous images
            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()
            
            # Create grid
            cols = 4
            rows = (num_images + cols - 1) // cols
            
            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)
                
                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_tensor = generated[idx]
                        img = self.tensor_to_pil(img_tensor)
                        
                        # Resize for display using NEAREST
                        img_display = img.resize((128, 128), Image.Resampling.NEAREST)
                        
                        photo = ImageTk.PhotoImage(img_display)
                        
                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)
            
            self.log_message(f"Generated {num_images} images in grid")
            
        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")
            import traceback
            traceback_str = traceback.format_exc()
            self.log_message("Full traceback:")
            self.log_message(traceback_str)

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('dcgan_enhanced_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            import json
            if os.path.exists('dcgan_enhanced_defaults.json'):
                with open('dcgan_enhanced_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.update_size_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_to_paper(self):
        """Reset to DCGAN paper settings"""
        paper_settings = {
            'image_size': 32,
            'latent_dim': 100,
            'ngf': 64,
            'ndf': 64,
            'batch_size': 128,
            'learning_rate': 0.0002,
            'beta1': 0.5,
            'num_workers': min(4, multiprocessing.cpu_count()),
            'save_interval': 10,
            'generate_interval': 5,
            'use_attention': False,
            'use_spectral_norm': False,
            'use_orthogonal': False,
            'use_pixelshuffle': False,
            'use_data_augmentation': False,
            'label_smoothing': False,
        }
        
        for key, value in paper_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        
        self.update_size_display()
        self.log_message("Reset to DCGAN paper settings (basic)")

    def plot_training_curves(self):
        """Plot training curves using matplotlib if available"""
        try:
            import matplotlib.pyplot as plt
            
            if hasattr(self.gan, 'd_losses') and len(self.gan.d_losses) > 0:
                fig, axes = plt.subplots(1, 2, figsize=(12, 4))
                
                # Loss curves
                axes[0].plot(self.gan.d_losses, label='Discriminator Loss')
                axes[0].plot(self.gan.g_losses, label='Generator Loss')
                axes[0].set_xlabel('Epoch')
                axes[0].set_ylabel('Loss')
                axes[0].set_title('Training Losses')
                axes[0].legend()
                axes[0].grid(True, alpha=0.3)
                
                # Score curves
                if hasattr(self.gan, 'real_scores') and len(self.gan.real_scores) > 0:
                    axes[1].plot(self.gan.real_scores, label='Real Score')
                    axes[1].plot(self.gan.fake_scores, label='Fake Score')
                    axes[1].set_xlabel('Epoch')
                    axes[1].set_ylabel('Score')
                    axes[1].set_title('Discriminator Scores')
                    axes[1].legend()
                    axes[1].grid(True, alpha=0.3)
                    axes[1].set_ylim([0, 1])
                
                plt.tight_layout()
                plt.savefig('training_curves.png', dpi=100, bbox_inches='tight')
                plt.close()
                
                self.log_message("Saved training curves to 'training_curves.png'")
                
        except ImportError:
            self.log_message("Matplotlib not available for plotting")
        except Exception as e:
            self.log_message(f"Error plotting curves: {str(e)}")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Enhanced DCGAN Trainer...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = EnhancedDCGANApp(root)
    root.mainloop()