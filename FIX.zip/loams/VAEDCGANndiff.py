import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
from pathlib import Path
import json
import random
import math

# ==================== Hybrid DCGAN-VAE Neural Network ====================

class HybridDCGAN_VAE:
    def __init__(self, image_size=32, latent_dim=100, ngf=64, ndf=64):
        self.image_size = image_size
        self.latent_dim = latent_dim
        self.ngf = ngf
        self.ndf = ndf
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # ========== ENCODER (from VAE) ==========
        class Encoder(nn.Module):
            def __init__(self, image_size, latent_dim, ndf):
                super().__init__()
                
                # For 32x32 images
                self.conv_layers = nn.Sequential(
                    # Input: 3 x 32 x 32
                    nn.Conv2d(3, ndf, kernel_size=4, stride=2, padding=1, bias=False),  # ndf x 16 x 16
                    nn.BatchNorm2d(ndf),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf, ndf * 2, kernel_size=4, stride=2, padding=1, bias=False),  # ndf*2 x 8 x 8
                    nn.BatchNorm2d(ndf * 2),
                    nn.LeakyReLU(0.2, inplace=True),
                    nn.Conv2d(ndf * 2, ndf * 4, kernel_size=4, stride=2, padding=1, bias=False),  # ndf*4 x 4 x 4
                    nn.BatchNorm2d(ndf * 4),
                    nn.LeakyReLU(0.2, inplace=True),
                )
                self.flatten_size = ndf * 4 * 4 * 4
                
                # MLP for mean and log variance
                self.fc_mu = nn.Linear(self.flatten_size, latent_dim)
                self.fc_logvar = nn.Linear(self.flatten_size, latent_dim)
                
            def forward(self, x):
                x = self.conv_layers(x)
                x = x.view(x.size(0), -1)  # Flatten
                mu = self.fc_mu(x)
                logvar = self.fc_logvar(x)
                return mu, logvar
        
        # ========== GENERATOR-DECODER (Combined) ==========
        class GeneratorDecoder(nn.Module):
            def __init__(self, image_size, latent_dim, ngf):
                super().__init__()
                
                # First layer to expand latent vector for DCGAN-like generation
                self.init_size = 4
                self.init_channels = ngf * 4
                
                self.fc = nn.Linear(latent_dim, self.init_channels * self.init_size * self.init_size)
                
                self.main = nn.Sequential(
                    # Input: ngf*4 x 4 x 4
                    nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf * 2),
                    nn.ReLU(True),
                    # ngf*2 x 8 x 8
                    nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ngf),
                    nn.ReLU(True),
                    # ngf x 16 x 16
                    nn.ConvTranspose2d(ngf, 3, 4, 2, 1, bias=False),
                    nn.Tanh()
                    # 3 x 32 x 32
                )
                
            def forward(self, z):
                # For DCGAN: z is random noise
                # For VAE decoding: z is encoded representation (deterministic)
                x = self.fc(z)
                x = x.view(x.size(0), self.init_channels, self.init_size, self.init_size)
                return self.main(x)
        
        # ========== DISCRIMINATOR (from DCGAN) ==========
        class Discriminator(nn.Module):
            def __init__(self, image_size, ndf):
                super().__init__()
                
                self.main = nn.Sequential(
                    nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf x 16 x 16
                    nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 2),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf*2 x 8 x 8
                    nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
                    nn.BatchNorm2d(ndf * 4),
                    nn.LeakyReLU(0.2, inplace=True),
                    # ndf*4 x 4 x 4
                    nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False),
                )
                
            def forward(self, x):
                # Output: batch_size x 1
                return self.main(x).view(-1, 1)
        
        # Reparameterization trick (from VAE) - ONLY USED DURING TRAINING
        def reparameterize(mu, logvar):
            std = torch.exp(0.5 * logvar)
            eps = torch.randn_like(std)
            return mu + eps * std
        
        # Initialize networks
        self.encoder = Encoder(image_size, latent_dim, ndf)
        self.generator_decoder = GeneratorDecoder(image_size, latent_dim, ngf)
        self.discriminator = Discriminator(image_size, ndf)
        self.reparameterize = reparameterize
        
        # Loss functions
        self.criterion_gan = nn.BCEWithLogitsLoss()  # DCGAN loss
        self.criterion_recon = nn.MSELoss()  # Reconstruction loss for VAE
        
        # Optimizers
        self.optimizerG = optim.Adam(
            list(self.generator_decoder.parameters()) + list(self.encoder.parameters()),
            lr=0.0002, betas=(0.5, 0.999)
        )
        self.optimizerD = optim.Adam(self.discriminator.parameters(), 
                                     lr=0.0002, betas=(0.5, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        
        # Move to device
        self.encoder.to(self.device)
        self.generator_decoder.to(self.device)
        self.discriminator.to(self.device)
    
    def encode(self, x, deterministic=True):
        """Encode image to latent vector (deterministic by default)"""
        mu, logvar = self.encoder(x)
        if deterministic:
            return mu  # Return mean only (deterministic)
        else:
            return self.reparameterize(mu, logvar)  # Add noise (variational)

# ==================== Latent Walker ====================

class LatentWalker:
    def __init__(self):
        self.latent_vectors = []
        self.image_paths = []
        self.current_vector = None
        self.target_vector = None
        self.current_step = 0
        self.total_steps = 10
        self.walking = False
        self.refresh_rate = 0.1  # seconds
        
    def init_walk(self, model, image_paths):
        """Initialize walker with encoded images"""
        self.latent_vectors = []
        self.image_paths = image_paths
        
        model.encoder.eval()
        image_size = model.image_size
        transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
        
        with torch.no_grad():
            for img_path in image_paths:
                try:
                    img = Image.open(img_path).convert('RGB')
                    img_tensor = transform(img).unsqueeze(0).to(model.device)
                    # Use DETERMINISTIC encoding (mean only)
                    z = model.encode(img_tensor, deterministic=True)
                    self.latent_vectors.append(z.cpu().detach().numpy().flatten())
                except Exception as e:
                    print(f"Error encoding {img_path}: {e}")
        
        # Start with random vector
        if self.latent_vectors:
            self.current_vector = random.choice(self.latent_vectors)
            self.set_new_target()
            return len(self.latent_vectors)
        return 0
    
    def set_new_target(self):
        """Set a new random target vector"""
        if self.latent_vectors:
            self.target_vector = random.choice(self.latent_vectors)
            self.current_step = 0
    
    def step_toward_target(self, step_size=0.1):
        """Take a step toward the target vector"""
        if self.current_vector is None or self.target_vector is None:
            return None
        
        current = np.array(self.current_vector)
        target = np.array(self.target_vector)
        
        # Calculate direction and distance
        direction = target - current
        distance = np.linalg.norm(direction)
        
        if distance < step_size:
            # If we're closer than step size, just go to target
            self.current_vector = target
            # Set new target
            self.set_new_target()
        else:
            # Move toward target
            step = (direction / distance) * step_size
            self.current_vector = current + step
            
            # Smooth interpolation using cosine easing
            self.current_step += 1
            progress = self.current_step / self.total_steps
            t = (1 - math.cos(progress * math.pi)) / 2  # Cosine easing
            self.current_vector = current * (1 - t) + target * t
            
            # If we've taken enough steps, switch to new target
            if progress >= 1.0:
                self.set_new_target()
        
        return self.current_vector

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            # Return a black image as fallback
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class HybridDCGAN_VAE_App:
    def __init__(self, root):
        self.root = root
        self.root.title("Hybrid DCGAN-VAE Trainer")
        self.root.geometry("1200x800")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # For interpolation
        self.image1_path = None
        self.image2_path = None
        self.vector1 = None
        self.vector2 = None
        
        # For encode/decode
        self.encode_decode_path = None
        
        # For latent walk
        self.latent_walker = LatentWalker()
        self.walk_thread = None
        self.walk_running = False
        
        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_dim': tk.IntVar(value=100),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=16),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'recon_weight': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'generate_interval': tk.IntVar(value=5)
        }
        
        # Performance tracking
        self.start_time = None
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Interpolation
        self.interpolation_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.interpolation_tab, text='Interpolation')
        self.setup_interpolation_tab()
        
        # Tab 4: Encode/Decode
        self.encode_decode_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.encode_decode_tab, text='Encode/Decode')
        self.setup_encode_decode_tab()
        
        # Tab 5: Latent Walk
        self.walk_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.walk_tab, text='Latent Walk')
        self.setup_walk_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Hybrid DCGAN-VAE Controls", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image size display
        self.size_display = tk.Label(left_frame, text=f"Image Size: {self.settings['image_size'].get()}x{self.settings['image_size'].get()}")
        self.size_display.pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize Model", 
                 command=self.initialize_model, width=20).pack(pady=5)
        
        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)
        
        tk.Button(gen_frame, text="Generate Sample", 
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Encode & Decode", 
                 command=self.encode_decode_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model", 
                 command=self.save_model, width=20).pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display
        preview_frame = tk.LabelFrame(right_frame, text="Generated/Reconstructed Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Single image display
        self.single_image_frame = tk.Frame(preview_frame, width=256, height=256, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)
        
        self.single_image_label = tk.Label(self.single_image_frame, text="No image", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Mode label
        self.mode_label = tk.Label(preview_frame, text="Mode: N/A", font=("Arial", 10))
        self.mode_label.pack(pady=5)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Status bar at bottom
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        tk.Label(main_frame, text="Hybrid DCGAN-VAE Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Create a canvas with scrollbar
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Image size
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed)").pack(side=tk.LEFT, padx=5)
        
        # Network parameters
        settings_list = [
            ("Latent Dimension:", 'latent_dim', 10, 500),
            ("Generator Features (ngf):", 'ngf', 32, 256),
            ("Discriminator Features (ndf):", 'ndf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 128),
            ("Reconstruction Weight:", 'recon_weight', 0.1, 1.0),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset Defaults", 
                 command=self.reset_defaults, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_interpolation_tab(self):
        main_frame = tk.Frame(self.interpolation_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Image Interpolation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Top frame for image selection
        top_frame = tk.Frame(main_frame)
        top_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Image 1 selection
        img1_frame = tk.LabelFrame(top_frame, text="Image 1", padx=10, pady=10)
        img1_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        self.img1_btn = tk.Button(img1_frame, text="Select Image 1", 
                                 command=lambda: self.select_interpolation_image(1), width=20)
        self.img1_btn.pack(pady=5)
        
        self.img1_label = tk.Label(img1_frame, text="No image selected", wraplength=200)
        self.img1_label.pack(pady=5)
        
        self.img1_preview = tk.Label(img1_frame, text="Preview", width=20, height=8, bg='gray')
        self.img1_preview.pack(pady=5)
        
        # Image 2 selection
        img2_frame = tk.LabelFrame(top_frame, text="Image 2", padx=10, pady=10)
        img2_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(10, 0))
        
        self.img2_btn = tk.Button(img2_frame, text="Select Image 2", 
                                 command=lambda: self.select_interpolation_image(2), width=20)
        self.img2_btn.pack(pady=5)
        
        self.img2_label = tk.Label(img2_frame, text="No image selected", wraplength=200)
        self.img2_label.pack(pady=5)
        
        self.img2_preview = tk.Label(img2_frame, text="Preview", width=20, height=8, bg='gray')
        self.img2_preview.pack(pady=5)
        
        # Encode button
        encode_frame = tk.Frame(main_frame)
        encode_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(encode_frame, text="Encode Images", 
                 command=self.encode_interpolation_images, width=20, bg="lightblue").pack(pady=10)
        
        self.encode_status = tk.Label(encode_frame, text="Images not encoded")
        self.encode_status.pack()
        
        # Interpolation slider
        slider_frame = tk.LabelFrame(main_frame, text="Interpolation Control", padx=10, pady=10)
        slider_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(slider_frame, text="Interpolation Factor:").pack(pady=5)
        
        self.interp_slider = tk.Scale(slider_frame, from_=0, to=100, orient=tk.HORIZONTAL,
                                     length=400, command=self.update_interpolation)
        self.interp_slider.set(50)
        self.interp_slider.pack(pady=10)
        
        tk.Label(slider_frame, text="0 = Image 1, 50 = Middle, 100 = Image 2").pack()
        
        # Interpolated image display
        display_frame = tk.LabelFrame(main_frame, text="Interpolated Image", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.interp_image_frame = tk.Frame(display_frame, width=256, height=256, bg='gray')
        self.interp_image_frame.pack(pady=10)
        self.interp_image_frame.pack_propagate(False)
        
        self.interp_image_label = tk.Label(self.interp_image_frame, text="Move slider to interpolate", bg='gray')
        self.interp_image_label.pack(fill=tk.BOTH, expand=True)

    def setup_encode_decode_tab(self):
        main_frame = tk.Frame(self.encode_decode_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Encode & Decode Test", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Top frame for image selection
        top_frame = tk.Frame(main_frame)
        top_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Image selection
        select_frame = tk.LabelFrame(top_frame, text="Select Image", padx=10, pady=10)
        select_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.encode_decode_btn = tk.Button(select_frame, text="Select Image", 
                                          command=self.select_encode_decode_image, width=20)
        self.encode_decode_btn.pack(pady=5)
        
        self.encode_decode_label = tk.Label(select_frame, text="No image selected", wraplength=200)
        self.encode_decode_label.pack(pady=5)
        
        self.encode_decode_preview = tk.Label(select_frame, text="Preview", width=20, height=8, bg='gray')
        self.encode_decode_preview.pack(pady=5)
        
        # Encode/Decode button
        encode_decode_frame = tk.Frame(main_frame)
        encode_decode_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Button(encode_decode_frame, text="Encode & Decode", 
                 command=self.perform_encode_decode, width=20, bg="lightgreen").pack(pady=10)
        
        self.encode_decode_status = tk.Label(encode_decode_frame, text="Select image and click Encode & Decode")
        self.encode_decode_status.pack()
        
        # Display frames
        display_frame = tk.Frame(main_frame)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        # Original image
        orig_frame = tk.LabelFrame(display_frame, text="Original Image", padx=10, pady=10)
        orig_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        self.orig_image_frame = tk.Frame(orig_frame, width=256, height=256, bg='gray')
        self.orig_image_frame.pack(pady=10)
        self.orig_image_frame.pack_propagate(False)
        
        self.orig_image_label = tk.Label(self.orig_image_frame, text="Original", bg='gray')
        self.orig_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Reconstructed image
        recon_frame = tk.LabelFrame(display_frame, text="Reconstructed Image", padx=10, pady=10)
        recon_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0))
        
        self.recon_image_frame = tk.Frame(recon_frame, width=256, height=256, bg='gray')
        self.recon_image_frame.pack(pady=10)
        self.recon_image_frame.pack_propagate(False)
        
        self.recon_image_label = tk.Label(self.recon_image_frame, text="Reconstructed", bg='gray')
        self.recon_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Info frame
        info_frame = tk.LabelFrame(main_frame, text="Reconstruction Info", padx=10, pady=10)
        info_frame.pack(fill=tk.X, pady=(20, 0))
        
        self.recon_info = tk.Label(info_frame, text="Reconstruction quality will be shown here")
        self.recon_info.pack()

    def setup_walk_tab(self):
        main_frame = tk.Frame(self.walk_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Latent Space Walk", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Controls frame
        controls_frame = tk.LabelFrame(main_frame, text="Walk Controls", padx=10, pady=10)
        controls_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Init button
        tk.Button(controls_frame, text="Initialize Latent Walk", 
                 command=self.init_latent_walk, width=25).pack(pady=5)
        
        self.walk_status = tk.Label(controls_frame, text="Not initialized")
        self.walk_status.pack(pady=5)
        
        # Parameters frame
        params_frame = tk.Frame(controls_frame)
        params_frame.pack(fill=tk.X, pady=10)
        
        # Step size
        tk.Label(params_frame, text="Step Size:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
        self.step_size_var = tk.DoubleVar(value=0.1)
        tk.Scale(params_frame, from_=0.05, to=1.0, variable=self.step_size_var, 
                orient=tk.HORIZONTAL, length=150, resolution=0.05).grid(row=0, column=1, padx=5, pady=5)
        tk.Label(params_frame, textvariable=self.step_size_var, width=5).grid(row=0, column=2, padx=5)
        
        # Refresh rate
        tk.Label(params_frame, text="Refresh Rate (s):").grid(row=1, column=0, padx=5, pady=5, sticky='w')
        self.refresh_rate_var = tk.DoubleVar(value=0.1)
        tk.Scale(params_frame, from_=0.05, to=2.0, variable=self.refresh_rate_var, 
                orient=tk.HORIZONTAL, length=150, resolution=0.05).grid(row=1, column=1, padx=5, pady=5)
        tk.Label(params_frame, textvariable=self.refresh_rate_var, width=5).grid(row=1, column=2, padx=5)
        
        # Steps per target
        tk.Label(params_frame, text="Steps per Target:").grid(row=2, column=0, padx=5, pady=5, sticky='w')
        self.steps_per_target_var = tk.IntVar(value=10)
        tk.Scale(params_frame, from_=5, to=50, variable=self.steps_per_target_var, 
                orient=tk.HORIZONTAL, length=150).grid(row=2, column=1, padx=5, pady=5)
        tk.Label(params_frame, textvariable=self.steps_per_target_var, width=5).grid(row=2, column=2, padx=5)
        
        # Start/Stop buttons
        btn_frame = tk.Frame(controls_frame)
        btn_frame.pack(pady=10)
        
        self.start_walk_btn = tk.Button(btn_frame, text="Start Walk", 
                                       command=self.start_latent_walk, width=15, bg="lightgreen")
        self.start_walk_btn.pack(side=tk.LEFT, padx=5)
        
        self.stop_walk_btn = tk.Button(btn_frame, text="Stop Walk", 
                                      command=self.stop_latent_walk, width=15, bg="salmon")
        self.stop_walk_btn.pack(side=tk.LEFT, padx=5)
        self.stop_walk_btn.config(state=tk.DISABLED)
        
        # Display frame
        display_frame = tk.LabelFrame(main_frame, text="Walk Visualization", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.walk_image_frame = tk.Frame(display_frame, width=256, height=256, bg='gray')
        self.walk_image_frame.pack(pady=10)
        self.walk_image_frame.pack_propagate(False)
        
        self.walk_image_label = tk.Label(self.walk_image_frame, text="Start walk to begin", bg='gray')
        self.walk_image_label.pack(fill=tk.BOTH, expand=True)
        
        # Info label
        self.walk_info = tk.Label(display_frame, text="")
        self.walk_info.pack(pady=5)

    def update_size_display(self):
        """Update image size display in training tab"""
        size = self.settings['image_size'].get()
        self.size_display.config(text=f"Image Size: {size}x{size}")

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                # Add to log
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                
                # Update status with first line
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                
                print(message)  # Also print to console
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_model(self):
        """Initialize Hybrid DCGAN-VAE with current settings"""
        try:
            image_size = self.settings['image_size'].get()
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()
            
            self.model = HybridDCGAN_VAE(
                image_size=image_size,
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf
            )
            
            self.log_message(f"Initialized Hybrid DCGAN-VAE for {image_size}x{image_size} images")
            self.log_message(f"Latent dim: {latent_dim}, G features: {ngf}, D features: {ndf}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing model: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            recon_weight = self.settings['recon_weight'].get()
            
            # Update optimizers with new settings
            for param_group in self.model.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            for param_group in self.model.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_model,
                args=(epochs, batch_size, num_workers, recon_weight),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}, Recon weight: {recon_weight}")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_model(self, epochs, batch_size, num_workers, recon_weight):
        """Training loop in separate thread"""
        try:
            image_size = self.settings['image_size'].get()
            generate_interval = self.settings['generate_interval'].get()
            
            # Create dataset and dataloader
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g_gan = 0
                total_loss_g_recon = 0
                batch_count = 0
                epoch_start = time.time()
                
                for real_images in dataloader:
                    if not self.training:
                        break
                    
                    batch_size_actual = real_images.size(0)
                    real_images = real_images.to(self.model.device)
                    
                    # ========== TRAIN DISCRIMINATOR ==========
                    self.model.optimizerD.zero_grad()
                    
                    # Real images
                    real_labels = torch.ones(batch_size_actual, 1, device=self.model.device)
                    output_real = self.model.discriminator(real_images)
                    loss_real = self.model.criterion_gan(output_real, real_labels)
                    
                    # Fake images from random noise
                    noise = torch.randn(batch_size_actual, self.model.latent_dim, device=self.model.device)
                    fake_images = self.model.generator_decoder(noise)
                    fake_labels = torch.zeros(batch_size_actual, 1, device=self.model.device)
                    output_fake = self.model.discriminator(fake_images.detach())
                    loss_fake = self.model.criterion_gan(output_fake, fake_labels)
                    
                    # Total discriminator loss
                    loss_d = (loss_real + loss_fake) / 2
                    loss_d.backward()
                    self.model.optimizerD.step()
                    
                    # ========== TRAIN GENERATOR-DECODER & ENCODER ==========
                    self.model.optimizerG.zero_grad()
                    
                    # Adversarial loss for generator
                    output_fake = self.model.discriminator(fake_images)
                    loss_g_gan = self.model.criterion_gan(output_fake, real_labels)
                    
                    # Reconstruction loss (image -> latent -> image) - DETERMINISTIC
                    mu_real, logvar_real = self.model.encoder(real_images)
                    z_real = mu_real  # DETERMINISTIC: Use mean only (no noise in reconstruction)
                    recon_real = self.model.generator_decoder(z_real)
                    loss_recon_real = self.model.criterion_recon(recon_real, real_images)
                    
                    # KL divergence loss (regularization)
                    kl_loss = -0.5 * torch.sum(1 + logvar_real - mu_real.pow(2) - logvar_real.exp()) / batch_size_actual
                    
                    # Total generator loss (GAN + Reconstruction + KL)
                    loss_g = loss_g_gan + recon_weight * loss_recon_real + 0.001 * kl_loss
                    loss_g.backward()
                    self.model.optimizerG.step()
                    
                    total_loss_d += loss_d.item()
                    total_loss_g_gan += loss_g_gan.item()
                    total_loss_g_recon += loss_recon_real.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g_gan = total_loss_g_gan / batch_count
                    avg_loss_g_recon = total_loss_g_recon / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    # Log progress
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"D Loss: {avg_loss_d:.4f} | "
                                   f"G GAN Loss: {avg_loss_g_gan:.4f} | "
                                   f"G Recon Loss: {avg_loss_g_recon:.4f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Total: {elapsed:.1f}s")
                    
                    # Generate samples at interval
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_training_samples(self):
        """Generate sample images during training"""
        if not self.model:
            return
        
        try:
            with torch.no_grad():
                # Generate from random noise
                noise = torch.randn(1, self.model.latent_dim).to(self.model.device)
                generated = self.model.generator_decoder(noise).cpu()
                
                # Convert to PIL
                img = self.tensor_to_pil(generated[0])
                
                # Resize for display
                img_display = img.resize((256, 256), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.mode_label.config(text="Mode: Generated from noise")
                
                self.log_message(f"Generated training sample at epoch {self.current_epoch + 1}")
                
        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        """Convert tensor to PIL Image"""
        img = (tensor + 1) / 2  # Denormalize from [-1, 1] to [0, 1]
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        """Generate a single sample from random noise"""
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.model.latent_dim).to(self.model.device)
                generated = self.model.generator_decoder(noise).cpu()
                img = self.tensor_to_pil(generated[0])
                
                # Resize for display
                img_display = img.resize((256, 256), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.mode_label.config(text="Mode: Generated from noise")
                
                self.log_message("Generated sample from random noise")
                
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def encode_decode_sample(self):
        """Encode then decode a random training image"""
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        if not self.image_paths:
            self.log_message("Error: No training images available!")
            return
        
        try:
            # Randomly select an image
            img_path = random.choice(self.image_paths)
            
            # Create transform
            image_size = self.settings['image_size'].get()
            transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            with torch.no_grad():
                # Load and encode image
                img = Image.open(img_path).convert('RGB')
                img_tensor = transform(img).unsqueeze(0).to(self.model.device)
                # DETERMINISTIC encoding (no reconstruction noise)
                z = self.model.encode(img_tensor, deterministic=True)
                
                # Decode back to image
                reconstructed = self.model.generator_decoder(z).cpu()
                recon_img = self.tensor_to_pil(reconstructed[0])
                
                # Resize for display
                img_display = recon_img.resize((256, 256), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                
                # Update display
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.mode_label.config(text=f"Mode: Encoded & Decoded {os.path.basename(img_path)}")
                
                self.log_message(f"Encoded and decoded: {os.path.basename(img_path)}")
                
        except Exception as e:
            self.log_message(f"Error in encode-decode: {str(e)}")

    def save_model(self):
        """Save current model"""
        if not self.model:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'encoder_state_dict': self.model.encoder.state_dict(),
                    'generator_decoder_state_dict': self.model.generator_decoder.state_dict(),
                    'discriminator_state_dict': self.model.discriminator.state_dict(),
                    'optimizerG_state_dict': self.model.optimizerG.state_dict(),
                    'optimizerD_state_dict': self.model.optimizerD.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_model(self):
        """Load model from file"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Update settings from checkpoint
                if 'image_size' in checkpoint:
                    self.settings['image_size'].set(checkpoint['image_size'])
                    self.update_size_display()
                
                if 'latent_dim' in checkpoint:
                    self.settings['latent_dim'].set(checkpoint['latent_dim'])
                
                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])
                
                if 'ndf' in checkpoint:
                    self.settings['ndf'].set(checkpoint['ndf'])
                
                # Initialize model with loaded settings
                self.initialize_model()
                
                # Load state dicts
                self.model.encoder.load_state_dict(checkpoint['encoder_state_dict'])
                self.model.generator_decoder.load_state_dict(checkpoint['generator_decoder_state_dict'])
                self.model.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])
                
                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    # Interpolation Tab Methods
    def select_interpolation_image(self, image_num):
        """Select image for interpolation"""
        filename = filedialog.askopenfilename(
            title=f"Select Image {image_num}",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if filename:
            if image_num == 1:
                self.image1_path = filename
                self.img1_label.config(text=os.path.basename(filename))
                self.load_image_preview(filename, self.img1_preview)
            else:
                self.image2_path = filename
                self.img2_label.config(text=os.path.basename(filename))
                self.load_image_preview(filename, self.img2_preview)
            
            self.log_message(f"Selected Image {image_num}: {os.path.basename(filename)}")

    def load_image_preview(self, path, label_widget):
        """Load image preview"""
        try:
            img = Image.open(path)
            img.thumbnail((150, 150), Image.Resampling.NEAREST)
            photo = ImageTk.PhotoImage(img)
            label_widget.config(image=photo, text="")
            label_widget.image = photo  # Keep reference
        except Exception as e:
            self.log_message(f"Error loading preview: {e}")

    def encode_interpolation_images(self):
        """Encode both images for interpolation"""
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        if not self.image1_path or not self.image2_path:
            self.log_message("Error: Select both images first!")
            return
        
        try:
            # Create transform
            image_size = self.settings['image_size'].get()
            transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            with torch.no_grad():
                # Encode image 1 - DETERMINISTIC
                img1 = Image.open(self.image1_path).convert('RGB')
                img1_tensor = transform(img1).unsqueeze(0).to(self.model.device)
                self.vector1 = self.model.encode(img1_tensor, deterministic=True).cpu().detach().numpy().flatten()
                
                # Encode image 2 - DETERMINISTIC
                img2 = Image.open(self.image2_path).convert('RGB')
                img2_tensor = transform(img2).unsqueeze(0).to(self.model.device)
                self.vector2 = self.model.encode(img2_tensor, deterministic=True).cpu().detach().numpy().flatten()
            
            self.encode_status.config(text="Images encoded - Move slider to interpolate")
            self.log_message("Both images encoded successfully")
            
        except Exception as e:
            self.log_message(f"Error encoding images: {str(e)}")
            import traceback
            traceback.print_exc()

    def update_interpolation(self, value):
        """Update interpolation based on slider value"""
        if self.vector1 is None or self.vector2 is None:
            return
        
        try:
            # Calculate interpolation factor (0 to 1)
            factor = float(value) / 100.0
            
            # Smooth interpolation using cosine easing
            t = (1 - math.cos(factor * math.pi)) / 2
            
            # Interpolate vectors
            interpolated = self.vector1 * (1 - t) + self.vector2 * t
            
            # Decode interpolated vector
            with torch.no_grad():
                vector_tensor = torch.FloatTensor(interpolated).unsqueeze(0).to(self.model.device)
                generated = self.model.generator_decoder(vector_tensor).cpu()
                img = self.tensor_to_pil(generated[0])
            
            # Resize for display
            img_display = img.resize((256, 256), Image.Resampling.NEAREST)
            photo = ImageTk.PhotoImage(img_display)
            
            # Update display
            self.interp_image_label.config(image=photo, text="")
            self.interp_image_label.image = photo
            
        except Exception as e:
            self.log_message(f"Error in interpolation: {str(e)}")

    # Encode/Decode Tab Methods
    def select_encode_decode_image(self):
        """Select image for encode/decode test"""
        filename = filedialog.askopenfilename(
            title="Select Image for Encode/Decode",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if filename:
            self.encode_decode_path = filename
            self.encode_decode_label.config(text=os.path.basename(filename))
            
            # Load preview
            try:
                img = Image.open(filename)
                img.thumbnail((150, 150), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img)
                self.encode_decode_preview.config(image=photo, text="")
                self.encode_decode_preview.image = photo
            except Exception as e:
                self.log_message(f"Error loading preview: {e}")
            
            self.log_message(f"Selected image for encode/decode: {os.path.basename(filename)}")
    
    def perform_encode_decode(self):
        """Encode and decode the selected image"""
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        if not self.encode_decode_path:
            self.log_message("Error: Select an image first!")
            return
        
        try:
            # Create transform
            image_size = self.settings['image_size'].get()
            transform = transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            # Load original image
            img = Image.open(self.encode_decode_path).convert('RGB')
            img_tensor = transform(img).unsqueeze(0)
            
            # Show original image
            orig_img = self.tensor_to_pil(img_tensor[0])
            orig_display = orig_img.resize((256, 256), Image.Resampling.NEAREST)
            orig_photo = ImageTk.PhotoImage(orig_display)
            self.orig_image_label.config(image=orig_photo, text="")
            self.orig_image_label.image = orig_photo
            
            with torch.no_grad():
                # Encode image - DETERMINISTIC (no reconstruction noise)
                img_tensor = img_tensor.to(self.model.device)
                z = self.model.encode(img_tensor, deterministic=True)
                
                # Decode back to image
                reconstructed = self.model.generator_decoder(z).cpu()
                recon_img = self.tensor_to_pil(reconstructed[0])
            
            # Show reconstructed image
            recon_display = recon_img.resize((256, 256), Image.Resampling.NEAREST)
            recon_photo = ImageTk.PhotoImage(recon_display)
            self.recon_image_label.config(image=recon_photo, text="")
            self.recon_image_label.image = recon_photo
            
            # Calculate reconstruction error
            mse = F.mse_loss(reconstructed, img_tensor.cpu()).item()
            psnr = 10 * math.log10(1.0 / mse) if mse > 0 else float('inf')
            
            self.recon_info.config(text=f"Reconstruction MSE: {mse:.6f}, PSNR: {psnr:.2f} dB")
            self.encode_decode_status.config(text="Encode/Decode completed successfully")
            
            self.log_message(f"Encoded and decoded: {os.path.basename(self.encode_decode_path)}")
            self.log_message(f"Reconstruction MSE: {mse:.6f}, PSNR: {psnr:.2f} dB")
            
        except Exception as e:
            self.log_message(f"Error in encode/decode: {str(e)}")
            import traceback
            traceback.print_exc()

    # Latent Walk Tab Methods
    def init_latent_walk(self):
        """Initialize latent walk with training images"""
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        try:
            num_vectors = self.latent_walker.init_walk(self.model, self.image_paths)
            self.walk_status.config(text=f"Initialized with {num_vectors} latent vectors")
            self.log_message(f"Latent walk initialized with {num_vectors} vectors")
            
        except Exception as e:
            self.log_message(f"Error initializing latent walk: {str(e)}")

    def start_latent_walk(self):
        """Start the latent walk"""
        if not self.latent_walker.latent_vectors:
            self.log_message("Error: Initialize latent walk first!")
            return
        
        self.walk_running = True
        self.latent_walker.walking = True
        self.latent_walker.total_steps = self.steps_per_target_var.get()
        self.latent_walker.refresh_rate = self.refresh_rate_var.get()
        
        self.start_walk_btn.config(state=tk.DISABLED)
        self.stop_walk_btn.config(state=tk.NORMAL)
        
        # Start walk thread
        self.walk_thread = threading.Thread(target=self.run_latent_walk, daemon=True)
        self.walk_thread.start()
        
        self.log_message("Latent walk started")

    def run_latent_walk(self):
        """Run the latent walk in a separate thread"""
        step_count = 0
        
        while self.walk_running and self.latent_walker.walking:
            try:
                # Take a step
                current_vector = self.latent_walker.step_toward_target(
                    step_size=self.step_size_var.get()
                )
                
                if current_vector is not None:
                    # Decode current vector
                    with torch.no_grad():
                        vector_tensor = torch.FloatTensor(current_vector).unsqueeze(0).to(self.model.device)
                        generated = self.model.generator_decoder(vector_tensor).cpu()
                        img = self.tensor_to_pil(generated[0])
                    
                    # Update display in main thread
                    self.root.after(0, self.update_walk_display, img, step_count)
                    
                    step_count += 1
                
                # Sleep for refresh rate
                time.sleep(self.latent_walker.refresh_rate)
                
            except Exception as e:
                self.log_message(f"Error in latent walk: {str(e)}")
                break
        
        self.root.after(0, self.walk_stopped)

    def update_walk_display(self, img, step_count):
        """Update walk display in main thread"""
        try:
            # Resize for display
            img_display = img.resize((256, 256), Image.Resampling.NEAREST)
            photo = ImageTk.PhotoImage(img_display)
            
            # Update display
            self.walk_image_label.config(image=photo, text="")
            self.walk_image_label.image = photo
            
            # Update info
            self.walk_info.config(text=f"Step: {step_count}")
            
        except Exception as e:
            self.log_message(f"Error updating walk display: {str(e)}")

    def stop_latent_walk(self):
        """Stop the latent walk"""
        self.walk_running = False
        self.latent_walker.walking = False
        self.log_message("Latent walk stopped")

    def walk_stopped(self):
        """Clean up after walk stops"""
        self.start_walk_btn.config(state=tk.NORMAL)
        self.stop_walk_btn.config(state=tk.DISABLED)
        self.walk_info.config(text="Walk stopped")

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            with open('hybrid_dcgan_vae_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            if os.path.exists('hybrid_dcgan_vae_defaults.json'):
                with open('hybrid_dcgan_vae_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.update_size_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_defaults(self):
        """Reset to default settings"""
        default_settings = {
            'image_size': 32,
            'latent_dim': 100,
            'ngf': 64,
            'ndf': 64,
            'batch_size': 16,
            'learning_rate': 0.0002,
            'beta1': 0.5,
            'recon_weight': 0.5,
            'num_workers': min(4, multiprocessing.cpu_count()),
            'generate_interval': 5
        }
        
        for key, value in default_settings.items():
            if key in self.settings:
                self.settings[key].set(value)
        
        self.update_size_display()
        self.log_message("Reset to default settings")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Hybrid DCGAN-VAE Trainer...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = HybridDCGAN_VAE_App(root)
    root.mainloop()