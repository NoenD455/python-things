import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
from pathlib import Path

# ==================== Helper for transparency ====================

def load_image_as_rgb(path):
    """
    Load an image from the given path.
    If the image has transparency (RGBA or palette with transparency),
    composite it onto a black background.
    Returns a PIL Image in RGB mode.
    """
    img = Image.open(path)

    # Convert palette images with transparency to RGBA first
    if img.mode == 'P' and 'transparency' in img.info:
        img = img.convert('RGBA')

    if img.mode == 'RGBA':
        # Create a black background image
        bg = Image.new('RGB', img.size, (0, 0, 0))
        # Use alpha channel as mask to paste the image onto the black background
        bg.paste(img, mask=img.split()[3])  # alpha channel
        return bg
    else:
        return img.convert('RGB')

# ==================== Feature extraction for matching ====================

def extract_feature_vector(pil_img, size=(16,16)):
    """Convert PIL image to grayscale, resize to size, return normalized flat vector."""
    img = pil_img.convert('L').resize(size, Image.BICUBIC)
    vec = np.array(img).astype(np.float32).flatten()
    # Normalize to [0,1] (avoid division by zero)
    vec = vec / 255.0
    return vec

def compute_pairing_similarity(paths_small, paths_large):
    """
    Greedy matching: for each image in smaller set, find the most similar (lowest L2)
    unused image in larger set. Returns list of (idx_small, idx_large) pairs.
    """
    print("Computing feature vectors for matching...")
    # Precompute features for all images
    features_small = []
    for p in paths_small:
        try:
            img = load_image_as_rgb(p)
            features_small.append(extract_feature_vector(img))
        except Exception as e:
            print(f"Error extracting features from {p}: {e}")
            # Use zero vector as fallback
            features_small.append(np.zeros(16*16, dtype=np.float32))

    features_large = []
    for p in paths_large:
        try:
            img = load_image_as_rgb(p)
            features_large.append(extract_feature_vector(img))
        except Exception as e:
            print(f"Error extracting features from {p}: {e}")
            features_large.append(np.zeros(16*16, dtype=np.float32))

    print("Matching images greedily...")
    used_large = set()
    pairs = []
    total_dist = 0.0
    for i, feat_s in enumerate(features_small):
        best_idx = -1
        best_dist = float('inf')
        for j, feat_l in enumerate(features_large):
            if j in used_large:
                continue
            dist = np.linalg.norm(feat_s - feat_l)
            if dist < best_dist:
                best_dist = dist
                best_idx = j
        if best_idx != -1:
            used_large.add(best_idx)
            pairs.append((i, best_idx))
            total_dist += best_dist
        else:
            # Should not happen if sizes are correct
            print(f"Warning: no available image for small index {i}")
    if pairs:
        print(f"Matching done. Average L2 distance: {total_dist/len(pairs):.4f}")
    return pairs

# ==================== Neural Network (Bidirectional Pix2Pix with control) ====================

class UNetGeneratorCorrect(nn.Module):
    """U-Net for 32x32 with 5 down/up steps. Input: (3 RGB + 1 control) = 4 channels."""
    def __init__(self, in_channels=4, out_channels=3, features=64):
        super().__init__()
        self.down1 = self._down(in_channels, features, batchnorm=False)       # 32->16
        self.down2 = self._down(features, features*2)                         # 16->8
        self.down3 = self._down(features*2, features*4)                       # 8->4
        self.down4 = self._down(features*4, features*8)                       # 4->2
        self.down5 = self._down(features*8, features*8, batchnorm=False)      # 2->1

        self.up1 = self._up(features*8, features*8, dropout=True)             # 1->2
        self.up2 = self._up(features*16, features*4)                          # 2->4
        self.up3 = self._up(features*8, features*2)                           # 4->8
        self.up4 = self._up(features*4, features)                             # 8->16
        self.up5 = nn.Sequential(
            nn.ConvTranspose2d(features*2, out_channels, 4, 2, 1),
            nn.Tanh()
        )                                                                     # 16->32

    def _down(self, in_ch, out_ch, batchnorm=True):
        layers = [nn.Conv2d(in_ch, out_ch, 4, 2, 1)]
        if batchnorm:
            layers.append(nn.BatchNorm2d(out_ch))
        layers.append(nn.LeakyReLU(0.2))
        return nn.Sequential(*layers)

    def _up(self, in_ch, out_ch, dropout=False):
        layers = [nn.ConvTranspose2d(in_ch, out_ch, 4, 2, 1),
                  nn.BatchNorm2d(out_ch),
                  nn.ReLU()]
        if dropout:
            layers.append(nn.Dropout(0.5))
        return nn.Sequential(*layers)

    def forward(self, x):
        # Encoder
        d1 = self.down1(x)
        d2 = self.down2(d1)
        d3 = self.down3(d2)
        d4 = self.down4(d3)
        d5 = self.down5(d4)

        # Decoder
        u1 = self.up1(d5)
        u1 = torch.cat([u1, d4], dim=1)
        u2 = self.up2(u1)
        u2 = torch.cat([u2, d3], dim=1)
        u3 = self.up3(u2)
        u3 = torch.cat([u3, d2], dim=1)
        u4 = self.up4(u3)
        u4 = torch.cat([u4, d1], dim=1)
        u5 = self.up5(u4)

        return u5


class PatchGANDiscriminator(nn.Module):
    """PatchGAN discriminator for 32x32 input, outputs 8x8 patch scores.
       Input: source RGB (3) + control (1) + target RGB (3) = 7 channels."""
    def __init__(self, in_channels=7):
        super().__init__()
        self.model = nn.Sequential(
            # down to 16x16
            nn.Conv2d(in_channels, 64, 4, 2, 1),
            nn.LeakyReLU(0.2, inplace=True),
            # down to 8x8
            nn.Conv2d(64, 128, 4, 2, 1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
            # now 8x8, keep size with kernel=3, padding=1
            nn.Conv2d(128, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(256, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(512, 1, 3, 1, 1),
        )

    def forward(self, source, control, target):
        # source: (B,3,32,32), control: (B,1,32,32) (filled with 0 or 1), target: (B,3,32,32)
        x = torch.cat([source, control, target], dim=1)  # (B,7,32,32)
        return self.model(x)


class BidirectionalPix2Pix:
    def __init__(self, in_channels=4, out_channels=3, features=64, lambda_L1=100):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        torch.set_num_threads(multiprocessing.cpu_count())
        print(f"Using device: {self.device}")

        self.generator = UNetGeneratorCorrect(in_channels, out_channels, features).to(self.device)
        self.discriminator = PatchGANDiscriminator(in_channels + out_channels).to(self.device)  # 4+3=7

        self.criterion_gan = nn.BCEWithLogitsLoss()
        self.criterion_l1 = nn.L1Loss()
        self.lambda_l1 = lambda_L1

        self.optimizer_G = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizer_D = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))

    def train_step(self, imgA, imgB):
        """
        imgA, imgB: batches of RGB images from domain A and B, each in [-1,1].
        For each item we randomly choose direction: 0 (A->B) or 1 (B->A).
        """
        batch_size = imgA.size(0)
        imgA = imgA.to(self.device)
        imgB = imgB.to(self.device)

        # Randomly assign direction (0 = A->B, 1 = B->A)
        direction = torch.randint(0, 2, (batch_size, 1, 1, 1), device=self.device).float()  # (B,1,1,1)

        # Build source and target according to direction
        source = torch.where(direction == 0, imgA, imgB)   # if 0 use imgA, else use imgB
        target = torch.where(direction == 0, imgB, imgA)   # opposite

        # Expand control to spatial dimensions (B,1,32,32) filled with direction value
        control = direction.expand(-1, 1, 32, 32)          # (B,1,32,32)

        # Generator input: concatenate source and control
        gen_input = torch.cat([source, control], dim=1)    # (B,4,32,32)

        # Labels for adversarial loss (patchGAN: 8x8)
        real_labels = torch.ones(batch_size, 1, 8, 8, device=self.device)
        fake_labels = torch.zeros(batch_size, 1, 8, 8, device=self.device)

        # ---------------------
        # Train Discriminator
        # ---------------------
        self.optimizer_D.zero_grad()

        # Real
        pred_real = self.discriminator(source, control, target)
        loss_D_real = self.criterion_gan(pred_real, real_labels)

        # Fake
        fake_images = self.generator(gen_input)
        pred_fake = self.discriminator(source, control, fake_images.detach())
        loss_D_fake = self.criterion_gan(pred_fake, fake_labels)

        loss_D = (loss_D_real + loss_D_fake) * 0.5
        loss_D.backward()
        self.optimizer_D.step()

        # ---------------------
        # Train Generator
        # ---------------------
        self.optimizer_G.zero_grad()

        # Adversarial loss (try to fool D)
        pred_fake = self.discriminator(source, control, fake_images)
        loss_G_adv = self.criterion_gan(pred_fake, real_labels)

        # L1 loss (pixelwise difference)
        loss_G_l1 = self.criterion_l1(fake_images, target) * self.lambda_l1

        loss_G = loss_G_adv + loss_G_l1
        loss_G.backward()
        self.optimizer_G.step()

        return loss_D.item(), loss_G_adv.item(), loss_G_l1.item()


# ==================== Paired Dataset ====================

class PairedImageDataset(Dataset):
    def __init__(self, pathsA, pathsB, image_size=32, aug_settings=None):
        """
        pathsA, pathsB: lists of full paths to images (must be in same order, i.e., paired).
        """
        assert len(pathsA) == len(pathsB), "Number of images in two domains must match"
        self.pathsA = pathsA
        self.pathsB = pathsB
        self.image_size = image_size
        self.aug_settings = aug_settings or {}
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))  # images to [-1,1]
        ])

    def __len__(self):
        return len(self.pathsA)

    def apply_augmentations(self, pil_imgA, pil_imgB):
        """Apply identical random augmentations to both images."""
        imgA = pil_imgA.copy()
        imgB = pil_imgB.copy()

        # Set random seed for reproducibility (same transform for both images)
        seed = random.randint(0, 2**32)

        def apply_with_seed(img, seed):
            random.seed(seed)
            # Each enabled augmentation has a 50% chance to be applied
            if self.aug_settings.get('stretch_height', False) and random.random() < 0.5:
                delta = random.randint(-8, 8)
                new_h = 32 + delta
                img = img.resize((32, new_h), Image.BICUBIC)
                img = img.resize((32, 32), Image.BICUBIC)

            if self.aug_settings.get('stretch_width', False) and random.random() < 0.5:
                delta = random.randint(-8, 8)
                new_w = 32 + delta
                img = img.resize((new_w, 32), Image.BICUBIC)
                img = img.resize((32, 32), Image.BICUBIC)

            if self.aug_settings.get('rotation', False) and random.random() < 0.5:
                angle = random.uniform(-30, 30)
                img = F.rotate(img, angle, interpolation=Image.BICUBIC)

            if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
                img = F.hflip(img)

            if self.aug_settings.get('flip_vertical', False) and random.random() < 0.5:
                img = F.vflip(img)

            if self.aug_settings.get('affine_jitter', False) and random.random() < 0.5:
                translate_x = random.uniform(-0.1, 0.1) * 32
                translate_y = random.uniform(-0.1, 0.1) * 32
                scale = random.uniform(0.9, 1.1)
                shear = random.uniform(-10, 10)
                img = F.affine(img, angle=0, translate=(translate_x, translate_y),
                               scale=scale, shear=(shear, 0), interpolation=Image.BICUBIC)

            if self.aug_settings.get('brightness', False) and random.random() < 0.5:
                brightness_factor = random.uniform(0.8, 1.2)
                img = F.adjust_brightness(img, brightness_factor)

            if self.aug_settings.get('contrast', False) and random.random() < 0.5:
                contrast_factor = random.uniform(0.8, 1.2)
                img = F.adjust_contrast(img, contrast_factor)

            if self.aug_settings.get('saturation', False) and random.random() < 0.5:
                saturation_factor = random.uniform(0.8, 1.2)
                img = F.adjust_saturation(img, saturation_factor)

            if self.aug_settings.get('hue', False) and random.random() < 0.5:
                hue_factor = random.uniform(-0.1, 0.1)
                img = F.adjust_hue(img, hue_factor)

            if self.aug_settings.get('noise', False) and random.random() < 0.5:
                np_img = np.array(img).astype(np.float32)
                noise = np.random.normal(0, 10, np_img.shape)
                np_img = np.clip(np_img + noise, 0, 255).astype(np.uint8)
                img = Image.fromarray(np_img)

            return img

        imgA = apply_with_seed(imgA, seed)
        imgB = apply_with_seed(imgB, seed)

        # Ensure both are RGB
        if imgA.mode != 'RGB':
            imgA = imgA.convert('RGB')
        if imgB.mode != 'RGB':
            imgB = imgB.convert('RGB')
        return imgA, imgB

    def __getitem__(self, idx):
        try:
            imgA_pil = load_image_as_rgb(self.pathsA[idx])
            imgB_pil = load_image_as_rgb(self.pathsB[idx])
            imgA_pil, imgB_pil = self.apply_augmentations(imgA_pil, imgB_pil)

            imgA_tensor = self.transform(imgA_pil)  # (3,32,32) in [-1,1]
            imgB_tensor = self.transform(imgB_pil)
            return imgA_tensor, imgB_tensor
        except Exception as e:
            print(f"Error loading pair {idx}: {e}")
            return torch.zeros(3, self.image_size, self.image_size), torch.zeros(3, self.image_size, self.image_size)


# ==================== GUI Application ====================

class Pix2PixApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Bidirectional Pix2Pix - Paired Translation")
        self.root.geometry("1000x700")

        self.pathsA = []
        self.pathsB = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()

        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'features': tk.IntVar(value=64),
            'lambda_l1': tk.IntVar(value=100),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
        }

        # Augmentation settings
        self.aug_settings = {
            'stretch_height': tk.BooleanVar(value=False),
            'stretch_width': tk.BooleanVar(value=False),
            'rotation': tk.BooleanVar(value=False),
            'flip_horizontal': tk.BooleanVar(value=False),
            'flip_vertical': tk.BooleanVar(value=False),
            'affine_jitter': tk.BooleanVar(value=False),
            'brightness': tk.BooleanVar(value=False),
            'contrast': tk.BooleanVar(value=False),
            'saturation': tk.BooleanVar(value=False),
            'hue': tk.BooleanVar(value=False),
            'noise': tk.BooleanVar(value=False),
        }

        self.start_time = None

        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.inference_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.inference_tab, text='Inference')
        self.setup_inference_tab()

    # ------------------------------------------------------------------
    # Training Tab
    # ------------------------------------------------------------------
    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left panel
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="Bidirectional Pix2Pix", font=("Arial", 12, "bold")).pack(pady=(0,10))

        # Domain selection
        domain_frame = tk.LabelFrame(left_frame, text="Paired Datasets", padx=10, pady=10)
        domain_frame.pack(fill=tk.X, pady=(0,10))

        tk.Button(domain_frame, text="Select Domain A folder", command=self.select_domainA, width=20).pack(pady=5)
        tk.Button(domain_frame, text="Select Domain B folder", command=self.select_domainB, width=20).pack(pady=5)

        # Matching option
        match_frame = tk.Frame(domain_frame)
        match_frame.pack(fill=tk.X, pady=5)
        self.match_var = tk.BooleanVar(value=False)
        tk.Checkbutton(match_frame, text="Match by pixel similarity (slower)", variable=self.match_var).pack(anchor='w')

        tk.Button(domain_frame, text="Load Pairs", command=self.load_pairs, width=20).pack(pady=5)

        list_frame = tk.Frame(domain_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.pair_listbox = tk.Listbox(list_frame, height=8)
        self.pair_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.pair_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.pair_listbox.config(yscrollcommand=scrollbar.set)

        tk.Button(domain_frame, text="Clear All", command=self.clear_pairs, width=20).pack(pady=5)

        # Model controls
        model_frame = tk.LabelFrame(left_frame, text="Model", padx=10, pady=10)
        model_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(model_frame, text="Initialize Model", command=self.initialize_model, width=20).pack(pady=5)

        # Training
        train_frame = tk.LabelFrame(left_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0,10))
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="Start Training", command=self.start_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", command=self.stop_training,
                  width=20, bg="salmon").pack(pady=5)

        # Save / Load
        save_frame = tk.LabelFrame(left_frame, text="Save/Load", padx=10, pady=10)
        save_frame.pack(fill=tk.X)
        tk.Button(save_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)
        tk.Button(save_frame, text="Load Model", command=self.load_model, width=20).pack(pady=5)

        # Right panel - preview and log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Preview frame (source → generated)
        preview_frame = tk.LabelFrame(right_frame, text="Preview (Source → Generated)", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,10))

        preview_inner = tk.Frame(preview_frame)
        preview_inner.pack()

        self.preview_source_canvas = tk.Canvas(preview_inner, width=150, height=150, bg='gray')
        self.preview_source_canvas.pack(side=tk.LEFT, padx=5)
        self.preview_source_canvas.create_text(75, 75, text="Source")

        self.preview_gen_canvas = tk.Canvas(preview_inner, width=150, height=150, bg='gray')
        self.preview_gen_canvas.pack(side=tk.LEFT, padx=5)
        self.preview_gen_canvas.create_text(75, 75, text="Generated")

        # Log
        log_frame = tk.LabelFrame(right_frame, text="Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_log = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar_log.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar_log.set)

        self.status_label = tk.Label(self.training_tab, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def select_domainA(self):
        folder = filedialog.askdirectory(title="Select Domain A folder")
        if folder:
            self.domainA_folder = folder
            self.log_message(f"Domain A folder: {folder}")

    def select_domainB(self):
        folder = filedialog.askdirectory(title="Select Domain B folder")
        if folder:
            self.domainB_folder = folder
            self.log_message(f"Domain B folder: {folder}")

    def load_pairs(self):
        if not hasattr(self, 'domainA_folder') or not hasattr(self, 'domainB_folder'):
            self.log_message("Please select both folders first")
            return
        # Get all image files in each folder
        exts = ('.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp')
        filesA = sorted([f for f in os.listdir(self.domainA_folder) if f.lower().endswith(exts)])
        filesB = sorted([f for f in os.listdir(self.domainB_folder) if f.lower().endswith(exts)])

        if not filesA or not filesB:
            self.log_message("One of the folders has no image files")
            return

        full_pathsA = [os.path.join(self.domainA_folder, f) for f in filesA]
        full_pathsB = [os.path.join(self.domainB_folder, f) for f in filesB]

        if self.match_var.get():
            # Determine smaller set
            if len(full_pathsA) <= len(full_pathsB):
                small_paths = full_pathsA
                large_paths = full_pathsB
                small_is_A = True
            else:
                small_paths = full_pathsB
                large_paths = full_pathsA
                small_is_A = False

            # Compute greedy matching
            pairs = compute_pairing_similarity(small_paths, large_paths)
            # Build the paired lists
            if small_is_A:
                self.pathsA = [small_paths[i] for i, _ in pairs]
                self.pathsB = [large_paths[j] for _, j in pairs]
            else:
                self.pathsA = [large_paths[j] for _, j in pairs]
                self.pathsB = [small_paths[i] for i, _ in pairs]
            self.log_message(f"Matched {len(self.pathsA)} pairs based on pixel similarity")
        else:
            # Use common filenames (original behavior)
            namesA = {os.path.splitext(f)[0].lower(): f for f in filesA}
            namesB = {os.path.splitext(f)[0].lower(): f for f in filesB}
            common = set(namesA.keys()) & set(namesB.keys())
            if not common:
                self.log_message("No matching filenames found. Enable matching if you want content-based pairing.")
                return
            self.pathsA = [os.path.join(self.domainA_folder, namesA[name]) for name in sorted(common)]
            self.pathsB = [os.path.join(self.domainB_folder, namesB[name]) for name in sorted(common)]
            self.log_message(f"Paired {len(self.pathsA)} images by filename")

        # Update listbox
        self.pair_listbox.delete(0, tk.END)
        for i, (pA, pB) in enumerate(zip(self.pathsA, self.pathsB)):
            self.pair_listbox.insert(tk.END, f"{i+1}: {os.path.basename(pA)} ↔ {os.path.basename(pB)}")

    def clear_pairs(self):
        self.pathsA = []
        self.pathsB = []
        self.pair_listbox.delete(0, tk.END)
        self.log_message("Cleared all pairs")

    # ------------------------------------------------------------------
    # Settings Tab (same as before, but removed OpenCV/Canny references)
    # ------------------------------------------------------------------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Model Settings", font=("Arial",14,"bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Network architecture
        net_frame = tk.LabelFrame(scrollable_frame, text="Generator Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=5)

        arch_params = [
            ("Base features:", 'features', 16, 128),
            ("L1 lambda:", 'lambda_l1', 10, 200),
        ]
        for label, key, low, high in arch_params:
            f = tk.Frame(net_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Training parameters
        train_frame = tk.LabelFrame(scrollable_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=5)

        train_params = [
            ("Batch size:", 'batch_size', 1, 64),
            ("Learning rate:", 'learning_rate', 1e-5, 1e-2),
            ("Beta1 (Adam):", 'beta1', 0.0, 0.999),
            ("Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count()*2)),
        ]
        for label, key, low, high in train_params:
            f = tk.Frame(train_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            res = 0.00001 if key=='learning_rate' else (0.001 if key=='beta1' else 1)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # ----- Augmentations (same) -----
        aug_frame = tk.LabelFrame(scrollable_frame, text="Image Augmentations (randomly applied to both images)", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)

        augs = [
            ("Stretch Height (±8 px)", 'stretch_height'),
            ("Stretch Width (±8 px)", 'stretch_width'),
            ("Rotation (±30°)", 'rotation'),
            ("Flip Horizontal", 'flip_horizontal'),
            ("Flip Vertical", 'flip_vertical'),
            ("Affine Jitter (translate, scale, shear)", 'affine_jitter'),
            ("Brightness (±20%)", 'brightness'),
            ("Contrast (±20%)", 'contrast'),
            ("Saturation (±20%)", 'saturation'),
            ("Hue (±10%)", 'hue'),
            ("Gaussian Noise (σ=10)", 'noise'),
        ]
        for label, key in augs:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=5)
        cpu = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU cores: {cpu}").pack(anchor='w')
        tk.Label(sys_frame, text=f"PyTorch threads: {torch.get_num_threads()}").pack(anchor='w')
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}").pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ------------------------------------------------------------------
    # Inference Tab (unchanged)
    # ------------------------------------------------------------------
    def setup_inference_tab(self):
        main_frame = tk.Frame(self.inference_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Inference: Translate between Domains", font=("Arial",14,"bold")).pack(pady=(0,20))

        # Direction selection
        dir_frame = tk.Frame(main_frame)
        dir_frame.pack(fill=tk.X, pady=5)
        tk.Label(dir_frame, text="Direction:").pack(side=tk.LEFT, padx=5)
        self.direction_var = tk.StringVar(value="A->B")
        dir_combo = ttk.Combobox(dir_frame, textvariable=self.direction_var, values=["A->B", "B->A"], state="readonly")
        dir_combo.pack(side=tk.LEFT, padx=5)

        # Load image button
        tk.Button(main_frame, text="Load Image", command=self.load_image_for_inference).pack(pady=5)
        tk.Button(main_frame, text="Generate", command=self.run_inference).pack(pady=5)

        # Display area
        display_frame = tk.LabelFrame(main_frame, text="Input/Output", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True)

        inner = tk.Frame(display_frame)
        inner.pack(pady=10)

        self.infer_input_canvas = tk.Canvas(inner, width=150, height=150, bg='lightgray')
        self.infer_input_canvas.pack(side=tk.LEFT, padx=10)
        self.infer_input_canvas.create_text(75, 75, text="Input")

        self.infer_output_canvas = tk.Canvas(inner, width=150, height=150, bg='lightgray')
        self.infer_output_canvas.pack(side=tk.LEFT, padx=10)
        self.infer_output_canvas.create_text(75, 75, text="Output")

        self.infer_info = tk.Label(display_frame, text="", fg="blue")
        self.infer_info.pack(pady=5)

        self.current_input_tensor = None
        self.current_input_pil = None

    def load_image_for_inference(self):
        f = filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png *.bmp *.tif *.webp")])
        if not f:
            return
        try:
            pil_img = load_image_as_rgb(f)
            pil_img_resized = pil_img.resize((32,32), Image.BICUBIC)
            # Convert to tensor for model
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))
            ])
            img_tensor = transform(pil_img_resized).unsqueeze(0)  # (1,3,32,32)
            self.current_input_tensor = img_tensor
            self.current_input_pil = pil_img_resized

            # Display input
            disp_img = pil_img_resized.resize((150,150), Image.BICUBIC)
            self.input_photo = ImageTk.PhotoImage(disp_img)
            self.infer_input_canvas.delete("all")
            self.infer_input_canvas.create_image(75, 75, image=self.input_photo)

            self.infer_info.config(text="Image loaded. Select direction and click Generate.")
        except Exception as e:
            self.log_message(f"Error loading image: {e}")

    def run_inference(self):
        if not self.model:
            self.infer_info.config(text="Model not loaded!")
            return
        if self.current_input_tensor is None:
            self.infer_info.config(text="No input image!")
            return

        try:
            direction = 0 if self.direction_var.get() == "A->B" else 1
            control = torch.full((1,1,32,32), direction, dtype=torch.float32, device=self.model.device)
            source = self.current_input_tensor.to(self.model.device)
            gen_input = torch.cat([source, control], dim=1)

            self.model.generator.eval()
            with torch.no_grad():
                fake = self.model.generator(gen_input)
            self.model.generator.train()

            fake_np = fake[0].cpu().numpy().transpose(1,2,0)
            fake_np = ((fake_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            fake_pil = Image.fromarray(fake_np).resize((150,150), Image.BICUBIC)
            self.output_photo = ImageTk.PhotoImage(fake_pil)
            self.infer_output_canvas.delete("all")
            self.infer_output_canvas.create_image(75, 75, image=self.output_photo)

            self.infer_info.config(text="Generated successfully.")
        except Exception as e:
            self.infer_info.config(text=f"Error: {e}")
            self.log_message(f"Inference error: {e}")

    # ------------------------------------------------------------------
    # Core functions (logging, training loop, save/load, etc.)
    # ------------------------------------------------------------------
    def log_message(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(msg)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def initialize_model(self):
        try:
            self.model = BidirectionalPix2Pix(
                in_channels=4,   # 3 RGB + 1 control
                out_channels=3,
                features=self.settings['features'].get(),
                lambda_L1=self.settings['lambda_l1'].get()
            )
            self.log_message("Model initialized.")
        except Exception as e:
            self.log_message(f"Error: {e}")

    def start_training(self):
        if not self.pathsA or not self.pathsB:
            self.log_message("No image pairs loaded!")
            return
        if not self.model:
            self.log_message("Model not initialized!")
            return
        if self.training:
            self.log_message("Already training.")
            return

        try:
            epochs = int(self.epoch_var.get())
        except:
            self.log_message("Invalid epochs")
            return

        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()

        # Update optimizer hyperparameters
        for pg in self.model.optimizer_G.param_groups:
            pg['lr'] = self.settings['learning_rate'].get()
            pg['betas'] = (self.settings['beta1'].get(), 0.999)
        for pg in self.model.optimizer_D.param_groups:
            pg['lr'] = self.settings['learning_rate'].get()
            pg['betas'] = (self.settings['beta1'].get(), 0.999)

        thread = threading.Thread(target=self.train_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_message(f"Training started for {epochs} epochs.")

    def train_loop(self, epochs):
        try:
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()

            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}
            dataset = PairedImageDataset(self.pathsA, self.pathsB, 32, aug_settings=aug_dict)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=torch.cuda.is_available(),
                                persistent_workers=num_workers>0)

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                epoch_loss_D = 0.0
                epoch_loss_G_adv = 0.0
                epoch_loss_G_l1 = 0.0
                batches = 0

                for imgA, imgB in loader:
                    if not self.training:
                        break
                    loss_D, loss_G_adv, loss_G_l1 = self.model.train_step(imgA, imgB)

                    epoch_loss_D += loss_D
                    epoch_loss_G_adv += loss_G_adv
                    epoch_loss_G_l1 += loss_G_l1
                    batches += 1

                avg_D = epoch_loss_D / batches if batches else 0
                avg_G_adv = epoch_loss_G_adv / batches if batches else 0
                avg_G_l1 = epoch_loss_G_l1 / batches if batches else 0
                elapsed = time.time() - self.start_time
                self.log_message(f"Epoch {epoch+1}/{epochs} | D: {avg_D:.4f} | G_adv: {avg_G_adv:.4f} | G_l1: {avg_G_l1:.4f} | Time: {elapsed:.1f}s")

                # Show a preview every 5 epochs
                if (epoch+1) % 5 == 0:
                    self.show_preview(loader)

            self.training = False
            self.log_message("Training finished.")
        except Exception as e:
            self.log_message(f"Training error: {e}")
            import traceback
            traceback.print_exc()
            self.training = False

    def show_preview(self, loader):
        """Pick a random batch, show source and generated image."""
        if not self.model:
            return
        try:
            data_iter = iter(loader)
            imgA, imgB = next(data_iter)
            # Take first item and a random direction
            direction = random.randint(0, 1)
            if direction == 0:
                source = imgA[0:1].to(self.model.device)
                target = imgB[0:1]
                control = torch.zeros(1,1,32,32, device=self.model.device)
            else:
                source = imgB[0:1].to(self.model.device)
                target = imgA[0:1]
                control = torch.ones(1,1,32,32, device=self.model.device)

            gen_input = torch.cat([source, control], dim=1)

            self.model.generator.eval()
            with torch.no_grad():
                fake = self.model.generator(gen_input)
            self.model.generator.train()

            # Display source
            source_np = source[0].cpu().numpy().transpose(1,2,0)
            source_np = ((source_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            source_pil = Image.fromarray(source_np).resize((150,150), Image.BICUBIC)
            self.source_photo = ImageTk.PhotoImage(source_pil)
            self.preview_source_canvas.delete("all")
            self.preview_source_canvas.create_image(75, 75, image=self.source_photo)

            # Display generated
            fake_np = fake[0].cpu().numpy().transpose(1,2,0)
            fake_np = ((fake_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            fake_pil = Image.fromarray(fake_np).resize((150,150), Image.BICUBIC)
            self.fake_photo = ImageTk.PhotoImage(fake_pil)
            self.preview_gen_canvas.delete("all")
            self.preview_gen_canvas.create_image(75, 75, image=self.fake_photo)

        except Exception as e:
            self.log_message(f"Preview error: {e}")

    def stop_training(self):
        self.training = False
        self.log_message("Training stopped.")

    def save_model(self):
        if not self.model:
            self.log_message("No model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth",
                                              filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'generator': self.model.generator.state_dict(),
                'discriminator': self.model.discriminator.state_dict(),
                'optimizer_G': self.model.optimizer_G.state_dict(),
                'optimizer_D': self.model.optimizer_D.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items()},
                'aug_settings': {k:v.get() for k,v in self.aug_settings.items()}
            }, fname)
            self.log_message(f"Model saved to {fname}")

    def load_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            if 'settings' in ckpt:
                s = ckpt['settings']
                self.settings['features'].set(s.get('features',64))
                self.settings['lambda_l1'].set(s.get('lambda_l1',100))
            if 'aug_settings' in ckpt:
                for k, v in ckpt['aug_settings'].items():
                    if k in self.aug_settings:
                        self.aug_settings[k].set(v)
            self.initialize_model()
            self.model.generator.load_state_dict(ckpt['generator'])
            self.model.discriminator.load_state_dict(ckpt['discriminator'])
            self.model.generator.to(self.model.device)
            self.model.discriminator.to(self.model.device)
            self.model.optimizer_G.load_state_dict(ckpt['optimizer_G'])
            self.model.optimizer_D.load_state_dict(ckpt['optimizer_D'])
            self.log_message(f"Model loaded from {fname}")
        except Exception as e:
            self.log_message(f"Load error: {e}")


# ==================== Main ====================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = Pix2PixApp(root)
    root.mainloop()