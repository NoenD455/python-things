import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F
from PIL import Image, ImageTk, ImageOps
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
from pathlib import Path

# Optional OpenCV for Canny edge detection
try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False
    print("OpenCV not installed. Will use a simple Sobel edge detector as fallback.")

# ==================== Helper for transparency ====================

def load_image_as_rgb_with_black_bg(path):
    """
    Load an image from the given path.
    If the image has transparency (RGBA or palette with transparency),
    composite it onto a black background.
    Returns a PIL Image in RGB mode.
    """
    img = Image.open(path)

    # Convert palette images with transparency to RGBA first
    if img.mode == 'P' and 'transparency' in img.info:
        img = img.convert('RGBA')

    if img.mode == 'RGBA':
        # Create a black background image
        bg = Image.new('RGB', img.size, (0, 0, 0))
        # Use alpha channel as mask to paste the image onto the black background
        bg.paste(img, mask=img.split()[3])  # alpha channel
        return bg
    else:
        return img.convert('RGB')

# ==================== Neural Network (Pix2Pix with PatchGAN) ====================

class UNetGeneratorCorrect(nn.Module):
    """Proper U-Net for 32x32 with 5 down/up steps."""
    def __init__(self, in_channels=1, out_channels=3, features=64):
        super().__init__()
        self.down1 = self._down(in_channels, features, batchnorm=False)       # 32->16
        self.down2 = self._down(features, features*2)                         # 16->8
        self.down3 = self._down(features*2, features*4)                       # 8->4
        self.down4 = self._down(features*4, features*8)                       # 4->2
        self.down5 = self._down(features*8, features*8, batchnorm=False)      # 2->1

        self.up1 = self._up(features*8, features*8, dropout=True)             # 1->2
        self.up2 = self._up(features*16, features*4)                          # 2->4
        self.up3 = self._up(features*8, features*2)                           # 4->8
        self.up4 = self._up(features*4, features)                             # 8->16
        self.up5 = nn.Sequential(
            nn.ConvTranspose2d(features*2, out_channels, 4, 2, 1),
            nn.Tanh()
        )                                                                     # 16->32

    def _down(self, in_ch, out_ch, batchnorm=True):
        layers = [nn.Conv2d(in_ch, out_ch, 4, 2, 1)]
        if batchnorm:
            layers.append(nn.BatchNorm2d(out_ch))
        layers.append(nn.LeakyReLU(0.2))
        return nn.Sequential(*layers)

    def _up(self, in_ch, out_ch, dropout=False):
        layers = [nn.ConvTranspose2d(in_ch, out_ch, 4, 2, 1),
                  nn.BatchNorm2d(out_ch),
                  nn.ReLU()]
        if dropout:
            layers.append(nn.Dropout(0.5))
        return nn.Sequential(*layers)

    def forward(self, x):
        # Encoder
        d1 = self.down1(x)
        d2 = self.down2(d1)
        d3 = self.down3(d2)
        d4 = self.down4(d3)
        d5 = self.down5(d4)

        # Decoder
        u1 = self.up1(d5)
        u1 = torch.cat([u1, d4], dim=1)
        u2 = self.up2(u1)
        u2 = torch.cat([u2, d3], dim=1)
        u3 = self.up3(u2)
        u3 = torch.cat([u3, d2], dim=1)
        u4 = self.up4(u3)
        u4 = torch.cat([u4, d1], dim=1)
        u5 = self.up5(u4)

        return u5


class PatchGANDiscriminator(nn.Module):
    """PatchGAN discriminator for 32x32 input, outputs 8x8 patch scores."""
    def __init__(self, in_channels=4):  # input: edge (1) + real/fake RGB (3) = 4
        super().__init__()
        self.model = nn.Sequential(
            # down to 16x16
            nn.Conv2d(in_channels, 64, 4, 2, 1),
            nn.LeakyReLU(0.2, inplace=True),
            # down to 8x8
            nn.Conv2d(64, 128, 4, 2, 1),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
            # now 8x8, keep size with kernel=3, padding=1
            nn.Conv2d(128, 256, 3, 1, 1),
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(256, 512, 3, 1, 1),
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(512, 1, 3, 1, 1),
        )

    def forward(self, edge, img):
        # edge: (B,1,32,32), img: (B,3,32,32)
        x = torch.cat([edge, img], dim=1)  # (B,4,32,32)
        return self.model(x)


class Pix2Pix:
    def __init__(self, in_channels=1, out_channels=3, features=64, lambda_L1=100):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        torch.set_num_threads(multiprocessing.cpu_count())
        print(f"Using device: {self.device}")

        self.generator = UNetGeneratorCorrect(in_channels, out_channels, features).to(self.device)
        self.discriminator = PatchGANDiscriminator(in_channels+out_channels).to(self.device)

        self.criterion_gan = nn.BCEWithLogitsLoss()
        self.criterion_l1 = nn.L1Loss()
        self.lambda_l1 = lambda_L1

        self.optimizer_G = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizer_D = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))

    def train_step(self, real_edges, real_images):
        batch_size = real_edges.size(0)
        real_edges = real_edges.to(self.device)
        real_images = real_images.to(self.device)

        # Labels for adversarial loss
        real_labels = torch.ones(batch_size, 1, 8, 8, device=self.device)   # patch GAN output 8x8
        fake_labels = torch.zeros(batch_size, 1, 8, 8, device=self.device)

        # ---------------------
        # Train Discriminator
        # ---------------------
        self.optimizer_D.zero_grad()

        # Real
        pred_real = self.discriminator(real_edges, real_images)
        loss_D_real = self.criterion_gan(pred_real, real_labels)

        # Fake
        fake_images = self.generator(real_edges)
        pred_fake = self.discriminator(real_edges, fake_images.detach())
        loss_D_fake = self.criterion_gan(pred_fake, fake_labels)

        loss_D = (loss_D_real + loss_D_fake) * 0.5
        loss_D.backward()
        self.optimizer_D.step()

        # ---------------------
        # Train Generator
        # ---------------------
        self.optimizer_G.zero_grad()

        # Adversarial loss (try to fool D)
        pred_fake = self.discriminator(real_edges, fake_images)
        loss_G_adv = self.criterion_gan(pred_fake, real_labels)

        # L1 loss
        loss_G_l1 = self.criterion_l1(fake_images, real_images) * self.lambda_l1

        loss_G = loss_G_adv + loss_G_l1
        loss_G.backward()
        self.optimizer_G.step()

        return loss_D.item(), loss_G_adv.item(), loss_G_l1.item()


# ==================== Canny Edge Helper ====================

def compute_canny_edge(pil_img, low_thresh=100, high_thresh=200):
    """Convert PIL RGB to Canny edge (single channel, values in [0,1] or [-1,1]?)"""
    # Convert to numpy array (H,W,3) uint8
    np_img = np.array(pil_img.convert('L'))  # grayscale
    if HAS_CV2:
        edges = cv2.Canny(np_img, low_thresh, high_thresh)
        # edges is uint8 (0 or 255)
        edges = edges.astype(np.float32) / 255.0  # [0,1]
    else:
        # Simple Sobel fallback
        import scipy.ndimage as ndi
        sx = ndi.sobel(np_img, axis=0)
        sy = ndi.sobel(np_img, axis=1)
        edges = np.hypot(sx, sy)
        edges = np.clip(edges / edges.max(), 0, 1) if edges.max() > 0 else edges
    # Normalize to [-1,1] for input to generator (like ToTensor does for images)
    edges = edges * 2 - 1   # [0,1] -> [-1,1]
    return edges

# ==================== Augmented Dataset ====================

class AugmentedEdgeImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32, aug_settings=None):
        self.image_paths = image_paths
        self.image_size = image_size
        self.aug_settings = aug_settings or {}  # dict with flags and parameters
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))  # images to [-1,1]
        ])

    def __len__(self):
        return len(self.image_paths)

    def apply_augmentations(self, pil_img):
        """Apply randomly selected augmentations to the PIL image."""
        img = pil_img.copy()
        # Each enabled augmentation has a 50% chance to be applied
        if self.aug_settings.get('stretch_height', False) and random.random() < 0.5:
            delta = random.randint(-8, 8)
            new_h = 32 + delta
            img = img.resize((32, new_h), Image.BICUBIC)
            img = img.resize((32, 32), Image.BICUBIC)  # back to 32x32, distorting aspect

        if self.aug_settings.get('stretch_width', False) and random.random() < 0.5:
            delta = random.randint(-8, 8)
            new_w = 32 + delta
            img = img.resize((new_w, 32), Image.BICUBIC)
            img = img.resize((32, 32), Image.BICUBIC)

        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F.rotate(img, angle, interpolation=Image.BICUBIC)

        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F.hflip(img)

        if self.aug_settings.get('flip_vertical', False) and random.random() < 0.5:
            img = F.vflip(img)

        if self.aug_settings.get('affine_jitter', False) and random.random() < 0.5:
            # Random affine: small translation, scale, shear
            translate_x = random.uniform(-0.1, 0.1) * 32
            translate_y = random.uniform(-0.1, 0.1) * 32
            scale = random.uniform(0.9, 1.1)
            shear = random.uniform(-10, 10)
            img = F.affine(img, angle=0, translate=(translate_x, translate_y),
                           scale=scale, shear=(shear, 0), interpolation=Image.BICUBIC)

        if self.aug_settings.get('brightness', False) and random.random() < 0.5:
            brightness_factor = random.uniform(0.8, 1.2)
            img = F.adjust_brightness(img, brightness_factor)

        if self.aug_settings.get('contrast', False) and random.random() < 0.5:
            contrast_factor = random.uniform(0.8, 1.2)
            img = F.adjust_contrast(img, contrast_factor)

        if self.aug_settings.get('saturation', False) and random.random() < 0.5:
            saturation_factor = random.uniform(0.8, 1.2)
            img = F.adjust_saturation(img, saturation_factor)

        if self.aug_settings.get('hue', False) and random.random() < 0.5:
            hue_factor = random.uniform(-0.1, 0.1)
            img = F.adjust_hue(img, hue_factor)

        if self.aug_settings.get('noise', False) and random.random() < 0.5:
            # Add Gaussian noise to image (convert to numpy, add noise, back to PIL)
            np_img = np.array(img).astype(np.float32)
            noise = np.random.normal(0, 10, np_img.shape)  # sigma=10
            np_img = np.clip(np_img + noise, 0, 255).astype(np.uint8)
            img = Image.fromarray(np_img)

        # Ensure image is RGB
        if img.mode != 'RGB':
            img = img.convert('RGB')
        return img

    def __getitem__(self, idx):
        try:
            # Use the transparency‑handling loader
            img_pil = load_image_as_rgb_with_black_bg(self.image_paths[idx])
            # Apply augmentations
            aug_pil = self.apply_augmentations(img_pil)
            # Compute edge on augmented image (resized to 32x32 already)
            edge = compute_canny_edge(aug_pil.resize((self.image_size, self.image_size), Image.BICUBIC))
            edge_tensor = torch.from_numpy(edge).unsqueeze(0).float()  # (1,32,32) in [-1,1]
            # Transform augmented image to tensor
            img_tensor = self.transform(aug_pil)  # (3,32,32) in [-1,1]
            return edge_tensor, img_tensor
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            return torch.zeros(1, self.image_size, self.image_size), torch.zeros(3, self.image_size, self.image_size)


# ==================== GUI Application ====================

class Pix2PixApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Pix2Pix - Edge to Image")
        self.root.geometry("1000x700")

        self.image_paths = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()

        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),          # fixed
            'features': tk.IntVar(value=64),
            'lambda_l1': tk.IntVar(value=100),
            'batch_size': tk.IntVar(value=8),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'save_interval': tk.IntVar(value=10),
        }

        # Augmentation settings
        self.aug_settings = {
            'stretch_height': tk.BooleanVar(value=False),
            'stretch_width': tk.BooleanVar(value=False),
            'rotation': tk.BooleanVar(value=False),
            'flip_horizontal': tk.BooleanVar(value=False),
            'flip_vertical': tk.BooleanVar(value=False),
            'affine_jitter': tk.BooleanVar(value=False),
            'brightness': tk.BooleanVar(value=False),
            'contrast': tk.BooleanVar(value=False),
            'saturation': tk.BooleanVar(value=False),
            'hue': tk.BooleanVar(value=False),
            'noise': tk.BooleanVar(value=False),
        }

        self.num_workers = min(4, multiprocessing.cpu_count())
        self.start_time = None

        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.inference_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.inference_tab, text='Inference')
        self.setup_inference_tab()

        # Drawing Tab
        self.draw_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.draw_tab, text='Draw')
        self.setup_draw_tab()

    # ------------------------------------------------------------------
    # Training Tab (unchanged)
    # ------------------------------------------------------------------
    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left panel
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="Pix2Pix Controls", font=("Arial", 12, "bold")).pack(pady=(0,10))

        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=5)

        list_frame = tk.Frame(img_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=scrollbar.set)

        # Model controls
        model_frame = tk.LabelFrame(left_frame, text="Model", padx=10, pady=10)
        model_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(model_frame, text="Initialize Model", command=self.initialize_model, width=20).pack(pady=5)

        # Training
        train_frame = tk.LabelFrame(left_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0,10))
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="Start Training", command=self.start_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", command=self.stop_training,
                  width=20, bg="salmon").pack(pady=5)

        # Save / Load
        save_frame = tk.LabelFrame(left_frame, text="Save/Load", padx=10, pady=10)
        save_frame.pack(fill=tk.X)
        tk.Button(save_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)
        tk.Button(save_frame, text="Load Model", command=self.load_model, width=20).pack(pady=5)

        # Right panel - preview and log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Preview frame (edge and generated image)
        preview_frame = tk.LabelFrame(right_frame, text="Preview (Edge → Generated)", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,10))

        # Two canvases side by side
        preview_inner = tk.Frame(preview_frame)
        preview_inner.pack()

        self.preview_edge_canvas = tk.Canvas(preview_inner, width=150, height=150, bg='gray')
        self.preview_edge_canvas.pack(side=tk.LEFT, padx=5)
        self.preview_edge_canvas.create_text(75, 75, text="Edge")

        self.preview_gen_canvas = tk.Canvas(preview_inner, width=150, height=150, bg='gray')
        self.preview_gen_canvas.pack(side=tk.LEFT, padx=5)
        self.preview_gen_canvas.create_text(75, 75, text="Generated")

        # Log
        log_frame = tk.LabelFrame(right_frame, text="Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_log = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar_log.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar_log.set)

        self.status_label = tk.Label(self.training_tab, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    # ------------------------------------------------------------------
    # Settings Tab (with augmentations)
    # ------------------------------------------------------------------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Model Settings", font=("Arial",14,"bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Network architecture
        net_frame = tk.LabelFrame(scrollable_frame, text="Generator Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=5)

        arch_params = [
            ("Base features:", 'features', 16, 128),
            ("L1 lambda:", 'lambda_l1', 10, 200),
        ]
        for label, key, low, high in arch_params:
            f = tk.Frame(net_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Training parameters
        train_frame = tk.LabelFrame(scrollable_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=5)

        train_params = [
            ("Batch size:", 'batch_size', 1, 64),
            ("Learning rate:", 'learning_rate', 1e-5, 1e-2),
            ("Beta1 (Adam):", 'beta1', 0.0, 0.999),
            ("Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count()*2)),
        ]
        for label, key, low, high in train_params:
            f = tk.Frame(train_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            res = 0.00001 if key=='learning_rate' else (0.001 if key=='beta1' else 1)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # ----- Augmentations -----
        aug_frame = tk.LabelFrame(scrollable_frame, text="Image Augmentations (randomly applied per image)", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)

        augs = [
            ("Stretch Height (±8 px)", 'stretch_height'),
            ("Stretch Width (±8 px)", 'stretch_width'),
            ("Rotation (±30°)", 'rotation'),
            ("Flip Horizontal", 'flip_horizontal'),
            ("Flip Vertical", 'flip_vertical'),
            ("Affine Jitter (translate, scale, shear)", 'affine_jitter'),
            ("Brightness (±20%)", 'brightness'),
            ("Contrast (±20%)", 'contrast'),
            ("Saturation (±20%)", 'saturation'),
            ("Hue (±10%)", 'hue'),
            ("Gaussian Noise (σ=10)", 'noise'),
        ]
        for label, key in augs:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=5)
        cpu = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU cores: {cpu}").pack(anchor='w')
        tk.Label(sys_frame, text=f"PyTorch threads: {torch.get_num_threads()}").pack(anchor='w')
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}").pack(anchor='w')
        tk.Label(sys_frame, text=f"OpenCV available: {HAS_CV2}").pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ------------------------------------------------------------------
    # Inference Tab (fixed transparency)
    # ------------------------------------------------------------------
    def setup_inference_tab(self):
        main_frame = tk.Frame(self.inference_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Inference: Edge → Image", font=("Arial",14,"bold")).pack(pady=(0,20))

        # Top controls
        ctrl_frame = tk.Frame(main_frame)
        ctrl_frame.pack(fill=tk.X, pady=5)

        tk.Button(ctrl_frame, text="Load Image (→ Edge)", command=self.load_image_for_inference).pack(side=tk.LEFT, padx=5)
        tk.Button(ctrl_frame, text="Load Edge Image", command=self.load_edge_for_inference).pack(side=tk.LEFT, padx=5)
        tk.Button(ctrl_frame, text="Generate", command=self.run_inference).pack(side=tk.LEFT, padx=20)

        # Display area
        display_frame = tk.LabelFrame(main_frame, text="Input/Output", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True)

        # Two canvases side by side
        inner = tk.Frame(display_frame)
        inner.pack(pady=10)

        # Input (edge) canvas 150x150
        self.infer_input_canvas = tk.Canvas(inner, width=150, height=150, bg='lightgray')
        self.infer_input_canvas.pack(side=tk.LEFT, padx=10)
        self.infer_input_canvas.create_text(75, 75, text="Input (Edge)")

        # Output (generated) canvas 150x150
        self.infer_output_canvas = tk.Canvas(inner, width=150, height=150, bg='lightgray')
        self.infer_output_canvas.pack(side=tk.LEFT, padx=10)
        self.infer_output_canvas.create_text(75, 75, text="Output")

        # Info label
        self.infer_info = tk.Label(display_frame, text="", fg="blue")
        self.infer_info.pack(pady=5)

        # Storage
        self.current_edge_tensor = None
        self.current_edge_pil = None

    # ------------------------------------------------------------------
    # Drawing Tab (unchanged)
    # ------------------------------------------------------------------
    def setup_draw_tab(self):
        main_frame = tk.Frame(self.draw_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left side: drawing canvas
        left_frame = tk.Frame(main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0,10))

        draw_label = tk.Label(left_frame, text="Draw Edge (white on black)", font=("Arial",12,"bold"))
        draw_label.pack(pady=(0,5))

        # Drawing canvas (200x200, representing 32x32 grid)
        self.draw_canvas = tk.Canvas(left_frame, width=200, height=200, bg='black')
        self.draw_canvas.pack()

        # Info label for brush
        self.brush_info = tk.Label(left_frame, text="Left=White (edge), Right=Black (erase)", fg="blue")
        self.brush_info.pack(pady=5)

        # Clear button
        clear_btn = tk.Button(left_frame, text="Clear Canvas", command=self.clear_draw_canvas)
        clear_btn.pack(pady=5)

        # Right side: output and controls
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Output canvas (150x150)
        out_label = tk.Label(right_frame, text="Generated Image", font=("Arial",12,"bold"))
        out_label.pack(pady=(0,5))
        self.draw_output_canvas = tk.Canvas(right_frame, width=150, height=150, bg='lightgray')
        self.draw_output_canvas.pack()
        self.draw_output_canvas.create_text(75, 75, text="Output")

        # Controls
        ctrl_frame = tk.Frame(right_frame)
        ctrl_frame.pack(pady=10)

        self.real_time_var = tk.BooleanVar(value=False)
        real_time_cb = tk.Checkbutton(ctrl_frame, text="Real-time update",
                                      variable=self.real_time_var,
                                      command=self.toggle_real_time)
        real_time_cb.grid(row=0, column=0, columnspan=2, pady=5)

        tk.Label(ctrl_frame, text="Interval (ms):").grid(row=1, column=0, sticky='e', padx=5)
        self.interval_var = tk.IntVar(value=500)
        tk.Entry(ctrl_frame, textvariable=self.interval_var, width=8).grid(row=1, column=1, sticky='w')

        generate_btn = tk.Button(ctrl_frame, text="Generate", command=self.generate_from_draw)
        generate_btn.grid(row=2, column=0, columnspan=2, pady=10)

        self.draw_status = tk.Label(right_frame, text="", fg="green")
        self.draw_status.pack()

        # Internal state for drawing
        self.draw_grid = np.full((32, 32), -1.0, dtype=np.float32)  # -1 = black (no edge)
        self.last_draw_point = None
        self.draw_photo = None
        self.real_time_after_id = None
        self.generation_in_progress = False

        # Bind mouse events
        self.draw_canvas.bind("<Button-1>", self.start_draw_white)
        self.draw_canvas.bind("<Button-3>", self.start_draw_black)
        self.draw_canvas.bind("<B1-Motion>", self.continue_draw_white)
        self.draw_canvas.bind("<B3-Motion>", self.continue_draw_black)
        self.draw_canvas.bind("<ButtonRelease-1>", self.end_draw)
        self.draw_canvas.bind("<ButtonRelease-3>", self.end_draw)

        # Initial display
        self.update_draw_canvas()

    # Drawing helpers (unchanged)
    def clear_draw_canvas(self):
        self.draw_grid.fill(-1.0)
        self.update_draw_canvas()
        self.draw_status.config(text="Canvas cleared")

    def update_draw_canvas(self):
        grid_uint8 = ((self.draw_grid + 1) / 2 * 255).astype(np.uint8)
        img = Image.fromarray(grid_uint8, mode='L')
        img = img.resize((200, 200), Image.NEAREST)
        self.draw_photo = ImageTk.PhotoImage(img)
        self.draw_canvas.delete("all")
        self.draw_canvas.create_image(0, 0, anchor=tk.NW, image=self.draw_photo)

    def _canvas_to_grid(self, x, y):
        grid_x = int(x * 32 / 200)
        grid_y = int(y * 32 / 200)
        grid_x = max(0, min(31, grid_x))
        grid_y = max(0, min(31, grid_y))
        return grid_x, grid_y

    def draw_line_on_grid(self, x0, y0, x1, y1, value):
        dx = abs(x1 - x0)
        dy = -abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx + dy
        while True:
            if 0 <= x0 < 32 and 0 <= y0 < 32:
                self.draw_grid[y0, x0] = value
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def start_draw_white(self, event):
        self.last_draw_point = self._canvas_to_grid(event.x, event.y)
        self.draw_on_point(self.last_draw_point, 1.0)

    def start_draw_black(self, event):
        self.last_draw_point = self._canvas_to_grid(event.x, event.y)
        self.draw_on_point(self.last_draw_point, -1.0)

    def continue_draw_white(self, event):
        if self.last_draw_point is None:
            return
        new_point = self._canvas_to_grid(event.x, event.y)
        self.draw_line_on_grid(self.last_draw_point[0], self.last_draw_point[1],
                               new_point[0], new_point[1], 1.0)
        self.last_draw_point = new_point
        self.update_draw_canvas()
        if self.real_time_var.get():
            self.schedule_generation()

    def continue_draw_black(self, event):
        if self.last_draw_point is None:
            return
        new_point = self._canvas_to_grid(event.x, event.y)
        self.draw_line_on_grid(self.last_draw_point[0], self.last_draw_point[1],
                               new_point[0], new_point[1], -1.0)
        self.last_draw_point = new_point
        self.update_draw_canvas()
        if self.real_time_var.get():
            self.schedule_generation()

    def draw_on_point(self, point, value):
        x, y = point
        self.draw_grid[y, x] = value
        self.update_draw_canvas()

    def end_draw(self, event):
        self.last_draw_point = None
        if self.real_time_var.get():
            self.schedule_generation()

    def toggle_real_time(self):
        if self.real_time_var.get():
            self.schedule_generation()
        else:
            if self.real_time_after_id:
                self.root.after_cancel(self.real_time_after_id)
                self.real_time_after_id = None

    def schedule_generation(self):
        if self.real_time_after_id:
            self.root.after_cancel(self.real_time_after_id)
        if self.real_time_var.get():
            self.real_time_after_id = self.root.after(self.interval_var.get(),
                                                       self.generate_from_draw)

    def generate_from_draw(self):
        if self.generation_in_progress or self.model is None:
            if self.model is None:
                self.draw_status.config(text="No model loaded!")
            return
        self.generation_in_progress = True
        self.draw_status.config(text="Generating...")
        thread = threading.Thread(target=self._generate_thread, daemon=True)
        thread.start()

    def _generate_thread(self):
        try:
            edge_tensor = torch.from_numpy(self.draw_grid).unsqueeze(0).unsqueeze(0).float()
            edge_tensor = edge_tensor.to(self.model.device)

            self.model.generator.eval()
            with torch.no_grad():
                fake = self.model.generator(edge_tensor)
            self.model.generator.train()

            fake_np = fake[0].cpu().numpy().transpose(1,2,0)
            fake_np = ((fake_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            fake_pil = Image.fromarray(fake_np).resize((150,150), Image.BICUBIC)

            self.root.after(0, self._display_generated, fake_pil)
        except Exception as e:
            self.root.after(0, self.draw_status.config, text=f"Error: {e}")
        finally:
            self.generation_in_progress = False

    def _display_generated(self, pil_image):
        self.draw_output_photo = ImageTk.PhotoImage(pil_image)
        self.draw_output_canvas.delete("all")
        self.draw_output_canvas.create_image(75, 75, image=self.draw_output_photo)
        self.draw_status.config(text="Generated")

    # ------------------------------------------------------------------
    # Core functions
    # ------------------------------------------------------------------
    def log_message(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(msg)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.webm *.bmp")]
        )
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images")

    def initialize_model(self):
        try:
            self.model = Pix2Pix(
                in_channels=1,
                out_channels=3,
                features=self.settings['features'].get(),
                lambda_L1=self.settings['lambda_l1'].get()
            )
            self.log_message("Model initialized.")
        except Exception as e:
            self.log_message(f"Error: {e}")

    def start_training(self):
        if not self.image_paths:
            self.log_message("No images!")
            return
        if not self.model:
            self.log_message("Model not initialized!")
            return
        if self.training:
            self.log_message("Already training.")
            return

        try:
            epochs = int(self.epoch_var.get())
        except:
            self.log_message("Invalid epochs")
            return

        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()

        # Update optimizer hyperparameters
        for pg in self.model.optimizer_G.param_groups:
            pg['lr'] = self.settings['learning_rate'].get()
            pg['betas'] = (self.settings['beta1'].get(), 0.999)
        for pg in self.model.optimizer_D.param_groups:
            pg['lr'] = self.settings['learning_rate'].get()
            pg['betas'] = (self.settings['beta1'].get(), 0.999)

        thread = threading.Thread(target=self.train_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_message(f"Training started for {epochs} epochs.")

    def train_loop(self, epochs):
        try:
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()

            # Build augmentation settings dict from GUI variables
            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}

            dataset = AugmentedEdgeImageDataset(self.image_paths, 32, aug_settings=aug_dict)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=torch.cuda.is_available(),
                                persistent_workers=num_workers>0)

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                epoch_loss_D = 0.0
                epoch_loss_G_adv = 0.0
                epoch_loss_G_l1 = 0.0
                batches = 0

                for edges, images in loader:
                    if not self.training:
                        break
                    loss_D, loss_G_adv, loss_G_l1 = self.model.train_step(edges, images)

                    epoch_loss_D += loss_D
                    epoch_loss_G_adv += loss_G_adv
                    epoch_loss_G_l1 += loss_G_l1
                    batches += 1

                avg_D = epoch_loss_D / batches if batches else 0
                avg_G_adv = epoch_loss_G_adv / batches if batches else 0
                avg_G_l1 = epoch_loss_G_l1 / batches if batches else 0
                elapsed = time.time() - self.start_time
                self.log_message(f"Epoch {epoch+1}/{epochs} | D: {avg_D:.4f} | G_adv: {avg_G_adv:.4f} | G_l1: {avg_G_l1:.4f} | Time: {elapsed:.1f}s")

                # Show a preview every 5 epochs
                if (epoch+1) % 5 == 0:
                    self.show_preview(loader)

            self.training = False
            self.log_message("Training finished.")
        except Exception as e:
            self.log_message(f"Training error: {e}")
            import traceback
            traceback.print_exc()
            self.training = False

    def show_preview(self, loader):
        """Pick a random batch, show edge and generated image."""
        if not self.model:
            return
        try:
            data_iter = iter(loader)
            edges, images = next(data_iter)
            # Take first item
            edge = edges[0:1].to(self.model.device)
            self.model.generator.eval()
            with torch.no_grad():
                fake = self.model.generator(edge)
            self.model.generator.train()

            # Convert edge to display (from [-1,1] to [0,255] grayscale)
            edge_np = edge[0,0].cpu().numpy()
            edge_np = ((edge_np + 1) / 2 * 255).astype(np.uint8)
            edge_pil = Image.fromarray(edge_np, mode='L').resize((150,150), Image.NEAREST)
            self.edge_photo = ImageTk.PhotoImage(edge_pil)
            self.preview_edge_canvas.delete("all")
            self.preview_edge_canvas.create_image(75, 75, image=self.edge_photo)

            # Convert generated image
            fake_np = fake[0].cpu().numpy().transpose(1,2,0)
            fake_np = ((fake_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            fake_pil = Image.fromarray(fake_np).resize((150,150), Image.BICUBIC)
            self.fake_photo = ImageTk.PhotoImage(fake_pil)
            self.preview_gen_canvas.delete("all")
            self.preview_gen_canvas.create_image(75, 75, image=self.fake_photo)

        except Exception as e:
            self.log_message(f"Preview error: {e}")

    def stop_training(self):
        self.training = False
        self.log_message("Training stopped.")

    def save_model(self):
        if not self.model:
            self.log_message("No model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth",
                                              filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'generator': self.model.generator.state_dict(),
                'discriminator': self.model.discriminator.state_dict(),
                'optimizer_G': self.model.optimizer_G.state_dict(),
                'optimizer_D': self.model.optimizer_D.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items()},
                'aug_settings': {k:v.get() for k,v in self.aug_settings.items()}
            }, fname)
            self.log_message(f"Model saved to {fname}")

    def load_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            # Recreate model with saved settings (if present)
            if 'settings' in ckpt:
                s = ckpt['settings']
                self.settings['features'].set(s.get('features',64))
                self.settings['lambda_l1'].set(s.get('lambda_l1',100))
            if 'aug_settings' in ckpt:
                for k, v in ckpt['aug_settings'].items():
                    if k in self.aug_settings:
                        self.aug_settings[k].set(v)
            self.initialize_model()
            self.model.generator.load_state_dict(ckpt['generator'])
            self.model.discriminator.load_state_dict(ckpt['discriminator'])
            self.model.generator.to(self.model.device)
            self.model.discriminator.to(self.model.device)
            self.model.optimizer_G.load_state_dict(ckpt['optimizer_G'])
            self.model.optimizer_D.load_state_dict(ckpt['optimizer_D'])
            self.log_message(f"Model loaded from {fname}")
        except Exception as e:
            self.log_message(f"Load error: {e}")

    # ------------------------------------------------------------------
    # Inference functions (fixed transparency)
    # ------------------------------------------------------------------
    def load_image_for_inference(self):
        f = filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png *.jfif *.webp *.webm")])
        if not f:
            return
        try:
            # Load with transparency handled (composite onto black)
            pil_img = load_image_as_rgb_with_black_bg(f)
            pil_img_resized = pil_img.resize((32,32), Image.BICUBIC)
            edge_np = compute_canny_edge(pil_img_resized)
            edge_tensor = torch.from_numpy(edge_np).unsqueeze(0).unsqueeze(0).float()
            self.current_edge_tensor = edge_tensor
            self.current_edge_pil = pil_img_resized

            edge_disp = ((edge_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            edge_disp_pil = Image.fromarray(edge_disp, mode='L').resize((150,150), Image.NEAREST)
            self.edge_disp_photo = ImageTk.PhotoImage(edge_disp_pil)
            self.infer_input_canvas.delete("all")
            self.infer_input_canvas.create_image(75, 75, image=self.edge_disp_photo)

            self.infer_info.config(text="Edge computed from image. Click Generate.")
        except Exception as e:
            self.log_message(f"Error loading image: {e}")

    def load_edge_for_inference(self):
        f = filedialog.askopenfilename(filetypes=[("Images","*.jpg *.jpeg *.png *.jfif *.webp *.webm")])
        if not f:
            return
        try:
            # Assume the file is a grayscale edge image (no transparency issues)
            edge_pil = Image.open(f).convert('L')
            edge_pil_resized = edge_pil.resize((32,32), Image.NEAREST)
            edge_np = np.array(edge_pil_resized).astype(np.float32)
            edge_np = edge_np / 255.0 * 2 - 1
            edge_tensor = torch.from_numpy(edge_np).unsqueeze(0).unsqueeze(0).float()

            self.current_edge_tensor = edge_tensor
            self.current_edge_pil = None

            edge_disp = ((edge_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            edge_disp_pil = Image.fromarray(edge_disp, mode='L').resize((150,150), Image.NEAREST)
            self.edge_disp_photo = ImageTk.PhotoImage(edge_disp_pil)
            self.infer_input_canvas.delete("all")
            self.infer_input_canvas.create_image(75, 75, image=self.edge_disp_photo)

            self.infer_info.config(text="Edge image loaded. Click Generate.")
        except Exception as e:
            self.log_message(f"Error loading edge: {e}")

    def run_inference(self):
        if not self.model:
            self.infer_info.config(text="Model not loaded!")
            return
        if self.current_edge_tensor is None:
            self.infer_info.config(text="No edge input!")
            return

        try:
            self.model.generator.eval()
            with torch.no_grad():
                edge = self.current_edge_tensor.to(self.model.device)
                fake = self.model.generator(edge)
            self.model.generator.train()

            fake_np = fake[0].cpu().numpy().transpose(1,2,0)
            fake_np = ((fake_np + 1) / 2 * 255).clip(0,255).astype(np.uint8)
            fake_pil = Image.fromarray(fake_np).resize((150,150), Image.BICUBIC)
            self.fake_disp_photo = ImageTk.PhotoImage(fake_pil)
            self.infer_output_canvas.delete("all")
            self.infer_output_canvas.create_image(75, 75, image=self.fake_disp_photo)

            self.infer_info.config(text="Generated successfully.")
        except Exception as e:
            self.infer_info.config(text=f"Error: {e}")
            self.log_message(f"Inference error: {e}")

# ==================== Main ====================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = Pix2PixApp(root)
    root.mainloop()