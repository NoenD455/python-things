import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk, ImageDraw, ImageFont
import os
import threading
import queue
import numpy as np
import multiprocessing
from torchvision.utils import make_grid

# ==================== Big Simple DCGAN ====================

class BigSimpleDCGAN:
    def __init__(self, image_size=64, latent_dim=100):
        self.image_size = image_size
        self.latent_dim = latent_dim
        
        torch.set_num_threads(2)
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # Generator
        class Generator(nn.Module):
            def __init__(self, image_size, latent_dim):
                super().__init__()
                
                if image_size == 64:
                    self.main = nn.Sequential(
                        nn.ConvTranspose2d(latent_dim, 1024, 4, 1, 0, bias=False),
                        nn.BatchNorm2d(1024),
                        nn.ReLU(True),
                        
                        nn.ConvTranspose2d(1024, 512, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(512),
                        nn.ReLU(True),
                        
                        nn.ConvTranspose2d(512, 256, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(256),
                        nn.ReLU(True),
                        
                        nn.ConvTranspose2d(256, 128, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(128),
                        nn.ReLU(True),
                        
                        nn.ConvTranspose2d(128, 64, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(64),
                        nn.ReLU(True),
                        
                        nn.ConvTranspose2d(64, 3, 3, 1, 1, bias=False),
                        nn.Tanh()
                    )
                else:  # 32x32
                    self.main = nn.Sequential(
                        nn.ConvTranspose2d(latent_dim, 1024, 4, 1, 0, bias=False),
                        nn.BatchNorm2d(1024),
                        nn.ReLU(True),
                        
                        nn.ConvTranspose2d(1024, 512, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(512),
                        nn.ReLU(True),
                        
                        nn.ConvTranspose2d(512, 256, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(256),
                        nn.ReLU(True),
                        
                        nn.ConvTranspose2d(256, 128, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(128),
                        nn.ReLU(True),
                        
                        nn.ConvTranspose2d(128, 3, 3, 1, 1, bias=False),
                        nn.Tanh()
                    )
                
            def forward(self, x):
                return self.main(x)
        
        # Discriminator
        class Discriminator(nn.Module):
            def __init__(self, image_size):
                super().__init__()
                
                if image_size == 64:
                    self.main = nn.Sequential(
                        nn.Conv2d(3, 64, 4, 2, 1, bias=False),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(64, 128, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(128),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(128, 256, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(256),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(256, 512, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(512),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(512, 1024, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(1024),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(1024, 1, 2, 1, 0, bias=False),
                        nn.Sigmoid()
                    )
                else:  # 32x32
                    self.main = nn.Sequential(
                        nn.Conv2d(3, 64, 4, 2, 1, bias=False),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(64, 128, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(128),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(128, 256, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(256),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(256, 512, 4, 2, 1, bias=False),
                        nn.BatchNorm2d(512),
                        nn.LeakyReLU(0.2, inplace=True),
                        
                        nn.Conv2d(512, 1, 2, 1, 0, bias=False),
                        nn.Sigmoid()
                    )
                
            def forward(self, x):
                return self.main(x).view(-1)
        
        self.generator = Generator(image_size, latent_dim)
        self.discriminator = Discriminator(image_size)
        
        self._initialize_weights()
        
        self.criterion = nn.BCELoss()
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.generator.to(self.device)
        self.discriminator.to(self.device)
    
    def _initialize_weights(self):
        for m in self.generator.modules():
            if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
                nn.init.normal_(m.weight.data, 0.0, 0.02)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.normal_(m.weight.data, 1.0, 0.02)
                nn.init.constant_(m.bias.data, 0)
        
        for m in self.discriminator.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight.data, 0.0, 0.02)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.normal_(m.weight.data, 1.0, 0.02)
                nn.init.constant_(m.bias.data, 0)

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=64):
        self.image_paths = image_paths
        self.image_size = image_size
        
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size), Image.NEAREST),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except:
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI with Interpolation ====================

class DCGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("DCGAN Explorer - Latent Space Visualizer")
        self.root.geometry("950x750")
        
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        self.num_workers = 0
        
        # Store interpolation images
        self.interpolation_images = []
        
        self.setup_gui()
        self.root.after(100, self.process_messages)
    
    def setup_gui(self):
        main_container = tk.Frame(self.root, padx=5, pady=5)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Left panel
        left_frame = tk.Frame(main_container, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        title_label = tk.Label(left_frame, text="DCGAN Latent Space Explorer", 
                              font=("Arial", 12, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 10), sticky="w")
        
        # Image size
        tk.Label(left_frame, text="Image Size:").grid(row=1, column=0, sticky="w", pady=(0, 5))
        self.size_var = tk.StringVar(value="32")
        size_frame = tk.Frame(left_frame)
        size_frame.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        tk.Radiobutton(size_frame, text="32x32", variable=self.size_var, value="32").pack(side=tk.LEFT, padx=(0, 10))
        tk.Radiobutton(size_frame, text="64x64", variable=self.size_var, value="64").pack(side=tk.LEFT)
        
        # Add images
        tk.Button(left_frame, text="Add Training Images", 
                 command=self.add_images, height=2).grid(row=3, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Image list
        tk.Label(left_frame, text="Training Images:").grid(row=4, column=0, sticky="w", pady=(10, 5))
        
        list_frame = tk.Frame(left_frame)
        list_frame.grid(row=5, column=0, columnspan=2, sticky="nsew", pady=(0, 10))
        
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)
        
        self.image_listbox = tk.Listbox(list_frame, height=6)
        self.image_listbox.grid(row=0, column=0, sticky="nsew")
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.grid(row=0, column=1, sticky="ns")
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Clear button
        tk.Button(left_frame, text="Clear All Images", 
                 command=self.clear_images).grid(row=6, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Training controls
        tk.Label(left_frame, text="Training Controls:").grid(row=7, column=0, sticky="w", pady=(10, 5))
        
        tk.Button(left_frame, text="Initialize GAN", 
                 command=self.initialize_gan, height=2).grid(row=8, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Label(left_frame, text="Epochs:").grid(row=9, column=0, sticky="w")
        self.epoch_var = tk.StringVar(value="50")
        tk.Entry(left_frame, textvariable=self.epoch_var).grid(row=10, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        tk.Label(left_frame, text="Batch Size:").grid(row=11, column=0, sticky="w")
        self.batch_var = tk.StringVar(value="32")
        tk.Entry(left_frame, textvariable=self.batch_var).grid(row=12, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        tk.Button(left_frame, text="Start Training", 
                 command=self.start_training, height=2, bg="lightgreen").grid(row=13, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Stop Training", 
                 command=self.stop_training, height=2, bg="salmon").grid(row=14, column=0, columnspan=2, sticky="ew", pady=5)
        
        # Generation controls
        tk.Label(left_frame, text="Generation:").grid(row=15, column=0, sticky="w", pady=(10, 5))
        
        tk.Button(left_frame, text="Generate Sample", 
                 command=self.generate_sample, height=2).grid(row=16, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Button(left_frame, text="Generate Interpolation Grid", 
                 command=self.generate_interpolation_grid, height=2, bg="lightblue").grid(row=17, column=0, columnspan=2, sticky="ew", pady=5)
        
        tk.Label(left_frame, text="Interpolation Steps:").grid(row=18, column=0, sticky="w", pady=(10, 5))
        self.steps_var = tk.StringVar(value="14")
        tk.Entry(left_frame, textvariable=self.steps_var).grid(row=19, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        
        # Status
        tk.Label(left_frame, text="Status:").grid(row=20, column=0, sticky="w", pady=(10, 5))
        self.status_label = tk.Label(left_frame, text="Ready", 
                                    relief=tk.SUNKEN, 
                                    height=2,
                                    anchor="w",
                                    padx=5)
        self.status_label.grid(row=21, column=0, columnspan=2, sticky="ew", pady=(0, 5))
        
        left_frame.grid_rowconfigure(5, weight=1)
        left_frame.grid_columnconfigure(0, weight=1)
        left_frame.grid_columnconfigure(1, weight=1)
        
        # Right panel
        right_frame = tk.Frame(main_container)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Top: Single image display
        single_frame = tk.LabelFrame(right_frame, text="Single Generation", padx=5, pady=5)
        single_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.image_label = tk.Label(single_frame)
        self.image_label.pack(pady=5)
        
        # Bottom: Interpolation grid display
        grid_frame = tk.LabelFrame(right_frame, text="Latent Space Interpolation Grid", padx=5, pady=5)
        grid_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create a canvas for the grid with scrollbars
        self.grid_canvas = tk.Canvas(grid_frame, bg="white")
        self.grid_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        grid_scrollbar = tk.Scrollbar(grid_frame, orient=tk.VERTICAL, command=self.grid_canvas.yview)
        grid_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.grid_canvas.configure(yscrollcommand=grid_scrollbar.set)
        
        # Frame inside canvas for images
        self.grid_frame = tk.Frame(self.grid_canvas, bg="white")
        self.canvas_window = self.grid_canvas.create_window((0, 0), window=self.grid_frame, anchor="nw")
        
        # Bind canvas resize
        self.grid_frame.bind("<Configure>", self._on_frame_configure)
        self.grid_canvas.bind("<Configure>", self._on_canvas_configure)
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=5, pady=5)
        log_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.log_text = tk.Text(log_frame, height=6, width=60, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        log_scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=log_scrollbar.set)
    
    def _on_frame_configure(self, event=None):
        self.grid_canvas.configure(scrollregion=self.grid_canvas.bbox("all"))
    
    def _on_canvas_configure(self, event):
        self.grid_canvas.itemconfig(self.canvas_window, width=event.width)
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
                status_text = message[:40] + "..." if len(message) > 40 else message
                self.status_label.config(text=status_text)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")
    
    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")
    
    def initialize_gan(self):
        try:
            image_size = int(self.size_var.get())
            self.gan = BigSimpleDCGAN(image_size=image_size)
            self.log_message(f"Initialized DCGAN for {image_size}x{image_size} images")
            self.log_message(f"Latent space dimension: 100")
        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
    
    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            batch_size = int(self.batch_var.get())
            image_size = int(self.size_var.get())
            
            self.training = True
            self.current_epoch = 0
            
            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, image_size),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}")
        except ValueError:
            self.log_message("Error: Invalid parameters!")
    
    def train_gan(self, epochs, batch_size, image_size):
        try:
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=0,
                pin_memory=False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                batch_count = 0
                
                for i, real_images in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    batch_size_current = real_images.size(0)
                    real_images = real_images.to(self.gan.device)
                    
                    # Train Discriminator
                    self.gan.optimizerD.zero_grad()
                    
                    real_labels = torch.ones(batch_size_current).to(self.gan.device)
                    output_real = self.gan.discriminator(real_images)
                    loss_real = self.gan.criterion(output_real, real_labels)
                    
                    noise = torch.randn(batch_size_current, self.gan.latent_dim, 1, 1).to(self.gan.device)
                    fake_images = self.gan.generator(noise)
                    fake_labels = torch.zeros(batch_size_current).to(self.gan.device)
                    output_fake = self.gan.discriminator(fake_images.detach())
                    loss_fake = self.gan.criterion(output_fake, fake_labels)
                    
                    loss_d = (loss_real + loss_fake) / 2
                    loss_d.backward()
                    self.gan.optimizerD.step()
                    
                    # Train Generator
                    self.gan.optimizerG.zero_grad()
                    
                    output_fake = self.gan.discriminator(fake_images)
                    loss_g = self.gan.criterion(output_fake, real_labels)
                    loss_g.backward()
                    self.gan.optimizerG.step()
                    
                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    
                    self.log_message(f"Epoch {epoch+1}/{epochs} | D Loss: {avg_loss_d:.4f} | G Loss: {avg_loss_g:.4f}")
                
                if (epoch + 1) % 5 == 0:
                    self.generate_sample_internal(show=False)
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")
    
    def generate_sample_internal(self, show=True, noise=None):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            with torch.no_grad():
                if noise is None:
                    noise = torch.randn(1, self.gan.latent_dim, 1, 1, device=self.gan.device)
                generated = self.gan.generator(noise)
                
                img = generated[0].cpu()
                img = (img + 1) / 2
                img = transforms.ToPILImage()(img)
                
                img = img.resize((256, 256), Image.NEAREST)
                
                if show:
                    self.display_image(img)
                
                return img
        except Exception as e:
            self.log_message(f"Generation error: {str(e)}")
    
    def generate_sample(self):
        img = self.generate_sample_internal(show=True)
        if img:
            self.log_message("Generated new sample image")
    
    def generate_interpolation_grid(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return
        
        try:
            steps = int(self.steps_var.get())
            
            # Clear previous grid
            for widget in self.grid_frame.winfo_children():
                widget.destroy()
            
            self.log_message(f"Generating interpolation grid with {steps} steps...")
            
            # Generate two random noise vectors
            noise1 = torch.randn(1, self.gan.latent_dim, 1, 1, device=self.gan.device)
            noise2 = torch.randn(1, self.gan.latent_dim, 1, 1, device=self.gan.device)
            
            # Store interpolation images
            self.interpolation_images = []
            
            # Create interpolation steps
            for i in range(steps + 2):  # +2 for the endpoints
                alpha = i / (steps + 1)  # 0 to 1 inclusive
                
                # Spherical interpolation (slerp) for smoother transitions
                if alpha == 0:
                    noise = noise1
                elif alpha == 1:
                    noise = noise2
                else:
                    # Linear interpolation (can switch to slerp if you want)
                    noise = (1 - alpha) * noise1 + alpha * noise2
                
                # Generate image
                with torch.no_grad():
                    generated = self.gan.generator(noise)
                    img = generated[0].cpu()
                    img = (img + 1) / 2
                    img = transforms.ToPILImage()(img)
                    
                    # Resize for display
                    display_size = 128
                    img = img.resize((display_size, display_size), Image.NEAREST)
                    
                    # Add label
                    label_img = Image.new('RGB', (display_size, display_size + 20), color='white')
                    label_img.paste(img, (0, 0))
                    
                    draw = ImageDraw.Draw(label_img)
                    try:
                        font = ImageFont.truetype("arial.ttf", 12)
                    except:
                        font = ImageFont.load_default()
                    
                    if i == 0:
                        label = "Noise A"
                    elif i == steps + 1:
                        label = "Noise B"
                    else:
                        label = f"Step {i}"
                    
                    draw.text((5, display_size + 5), label, fill='black', font=font)
                    
                    self.interpolation_images.append(label_img)
            
            # Display in grid
            num_cols = min(8, len(self.interpolation_images))
            num_rows = (len(self.interpolation_images) + num_cols - 1) // num_cols
            
            for idx, img in enumerate(self.interpolation_images):
                row = idx // num_cols
                col = idx % num_cols
                
                photo = ImageTk.PhotoImage(img)
                label = tk.Label(self.grid_frame, image=photo, bg="white")
                label.image = photo  # Keep reference
                label.grid(row=row, column=col, padx=5, pady=5)
            
            self.log_message(f"Generated {len(self.interpolation_images)} interpolation images")
            self.log_message("From Noise A → ... → Noise B (linear interpolation in latent space)")
            
        except Exception as e:
            self.log_message(f"Interpolation error: {str(e)}")
    
    def display_image(self, img):
        photo = ImageTk.PhotoImage(img)
        self.image_label.config(image=photo)
        self.image_label.image = photo

# ==================== Main ====================

if __name__ == "__main__":
    print("DCGAN Latent Space Explorer")
    print("Features:")
    print("1. Big simple DCGAN architecture")
    print("2. Latent space interpolation visualization")
    print("3. Watch the 'jagged but smooth when shook' transitions!")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = DCGANApp(root)
    root.mainloop()