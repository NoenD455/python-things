import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
import json
import traceback

# ==================== Combined GAN Components ====================

class MappingNetwork(nn.Module):
    """MLP that maps latent z to intermediate style code w."""
    def __init__(self, latent_dim, w_dim, depth):
        super().__init__()
        layers = []
        in_dim = latent_dim
        for i in range(depth):
            out_dim = w_dim if i == depth-1 else w_dim
            layers.append(nn.Linear(in_dim, out_dim))
            if i < depth-1:
                layers.append(nn.LeakyReLU(0.2))
            in_dim = out_dim
        self.net = nn.Sequential(*layers)

    def forward(self, z):
        return self.net(z)


class AdaINLayer(nn.Module):
    """Adaptive Instance Normalization with optional stochastic noise."""
    def __init__(self, channels, w_dim):
        super().__init__()
        self.channels = channels
        self.gamma_fc = nn.Linear(w_dim, channels)
        self.beta_fc  = nn.Linear(w_dim, channels)
        self.noise_scale = nn.Parameter(torch.zeros(1, channels, 1, 1))

    def forward(self, x, w, noise=None):
        gamma = self.gamma_fc(w).view(-1, self.channels, 1, 1)
        beta  = self.beta_fc(w).view(-1, self.channels, 1, 1)

        # Instance norm
        mean = x.mean(dim=[2,3], keepdim=True)
        var  = x.var(dim=[2,3], keepdim=True, unbiased=False)
        x_norm = (x - mean) / (torch.sqrt(var + 1e-8))

        # Modulate
        x_out = x_norm * (1 + gamma) + beta

        if noise is not None:
            x_out = x_out + self.noise_scale * noise
        return x_out


class SLE(nn.Module):
    """Skip-Layer Excitation (from FastGAN)."""
    def __init__(self, low_channels, high_channels):
        super().__init__()
        self.conv = nn.Sequential(
            nn.AdaptiveAvgPool2d(4),
            nn.Conv2d(low_channels, low_channels, 4, 4, 0),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(low_channels, high_channels, 1, 1, 0),
            nn.Sigmoid()
        )

    def forward(self, low, high):
        gate = self.conv(low)          # (B, high_channels, 1, 1)
        return high * gate


class SynthesisNetwork(nn.Module):
    """Generator synthesis network with AdaIN, noise, and SLE connections."""
    def __init__(self, latent_dim, w_dim, ngf, use_noise):
        super().__init__()
        self.latent_dim = latent_dim
        self.w_dim = w_dim
        self.use_noise = use_noise
        self.ngf = ngf

        # Initial: from latent (1x1) to 4x4 feature map
        self.initial_conv = nn.ConvTranspose2d(latent_dim, ngf * 8, 4, 1, 0, bias=False)
        self.adain0 = AdaINLayer(ngf * 8, w_dim)

        # 4x4 -> 8x8
        self.conv1 = nn.ConvTranspose2d(ngf * 8, ngf * 4, 4, 2, 1, bias=False)
        self.adain1 = AdaINLayer(ngf * 4, w_dim)

        # 8x8 -> 16x16
        self.conv2 = nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False)
        self.adain2 = AdaINLayer(ngf * 2, w_dim)

        # 16x16 -> 32x32 (features)
        self.conv3 = nn.ConvTranspose2d(ngf * 2, ngf, 4, 2, 1, bias=False)
        self.adain3 = AdaINLayer(ngf, w_dim)

        # To RGB
        self.to_rgb = nn.Conv2d(ngf, 3, 3, 1, 1, bias=False)

        # SLE connections
        self.sle_4_to_16 = SLE(ngf * 8, ngf * 2)   # from 4x4 to 16x16
        self.sle_8_to_32 = SLE(ngf * 4, ngf)       # from 8x8 to 32x32

        self.leaky_relu = nn.LeakyReLU(0.2)

    def forward(self, z, w):
        batch_size = z.size(0)
        # Initial 4x4
        x0 = self.initial_conv(z)                     # (B, ngf*8, 4,4)
        noise = torch.randn(batch_size, 1, 4, 4, device=x0.device) if self.use_noise else None
        x0 = self.adain0(x0, w, noise)
        x0 = self.leaky_relu(x0)

        # 4x4 -> 8x8
        x1 = self.conv1(x0)                            # (B, ngf*4, 8,8)
        noise = torch.randn(batch_size, 1, 8, 8, device=x1.device) if self.use_noise else None
        x1 = self.adain1(x1, w, noise)
        x1 = self.leaky_relu(x1)

        # 8x8 -> 16x16
        x2 = self.conv2(x1)                            # (B, ngf*2, 16,16)
        # SLE from x0 to x2
        x2 = self.sle_4_to_16(x0, x2)
        noise = torch.randn(batch_size, 1, 16, 16, device=x2.device) if self.use_noise else None
        x2 = self.adain2(x2, w, noise)
        x2 = self.leaky_relu(x2)

        # 16x16 -> 32x32 (features)
        x3 = self.conv3(x2)                            # (B, ngf, 32,32)
        # SLE from x1 to x3
        x3 = self.sle_8_to_32(x1, x3)
        noise = torch.randn(batch_size, 1, 32, 32, device=x3.device) if self.use_noise else None
        x3 = self.adain3(x3, w, noise)
        x3 = self.leaky_relu(x3)

        out = self.to_rgb(x3)
        out = torch.tanh(out)
        return out


class Generator(nn.Module):
    """Full generator with mapping network and synthesis."""
    def __init__(self, latent_dim, w_dim, mapping_depth, ngf, use_noise):
        super().__init__()
        self.latent_dim = latent_dim
        self.w_dim = w_dim
        self.mapping = MappingNetwork(latent_dim, w_dim, mapping_depth)
        self.synthesis = SynthesisNetwork(latent_dim, w_dim, ngf, use_noise)

    def forward(self, z):
        # z: (B, latent_dim, 1, 1)
        batch_size = z.size(0)
        z_flat = z.view(batch_size, self.latent_dim)
        w = self.mapping(z_flat)
        return self.synthesis(z, w)


class Discriminator(nn.Module):
    """Discriminator with two decoders (full and patch) for self-supervision."""
    def __init__(self, ndf=64):
        super().__init__()
        self.ndf = ndf

        # Downsampling blocks
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
            nn.LeakyReLU(0.2, inplace=True)
        )  # -> (ndf, 16, 16)   f1

        self.conv2 = nn.Sequential(
            nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 2),
            nn.LeakyReLU(0.2, inplace=True)
        )  # -> (ndf*2, 8, 8)   f2

        self.conv3 = nn.Sequential(
            nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 4),
            nn.LeakyReLU(0.2, inplace=True)
        )  # -> (ndf*4, 4, 4)

        self.conv4 = nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False)   # final logit

        # Full decoder: from 8x8 feature (f2) to 32x32 image
        self.full_decoder = nn.Sequential(
            nn.ConvTranspose2d(ndf * 2, ndf, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf),
            nn.LeakyReLU(0.2, inplace=True),   # -> 16x16
            nn.ConvTranspose2d(ndf, 3, 4, 2, 1, bias=False),
            nn.Tanh()                           # -> 32x32
        )

        # Patch decoder: from cropped 16x16 feature (f1, 8x8 crop) to 16x16 patch
        self.patch_decoder = nn.Sequential(
            nn.ConvTranspose2d(ndf, ndf, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf),
            nn.LeakyReLU(0.2, inplace=True),   # -> 16x16
            nn.Conv2d(ndf, 3, 3, 1, 1, bias=False),
            nn.Tanh()                           # output 16x16
        )

    def forward(self, x, return_features=False):
        f1 = self.conv1(x)          # (B, ndf, 16, 16)
        f2 = self.conv2(f1)         # (B, ndf*2, 8, 8)
        f3 = self.conv3(f2)         # (B, ndf*4, 4, 4)
        logit = self.conv4(f3).view(-1, 1)

        if return_features:
            return logit, f1, f2
        return logit

    def decode_full(self, f2):
        return self.full_decoder(f2)

    def decode_patch(self, f1_crop):
        return self.patch_decoder(f1_crop)


class UltimateGAN:
    """Combined GAN with all features: mapping network, AdaIN, noise, SLE, dual decoders."""
    def __init__(self, image_size=32, latent_dim=100, w_dim=64, mapping_depth=8,
                 ngf=64, ndf=64, use_noise=True):
        self.image_size = image_size
        self.latent_dim = latent_dim
        self.w_dim = w_dim
        self.mapping_depth = mapping_depth
        self.ngf = ngf
        self.ndf = ndf
        self.use_noise = use_noise

        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")

        self.generator = Generator(latent_dim, w_dim, mapping_depth, ngf, use_noise)
        self.discriminator = Discriminator(ndf)

        # Losses
        self.criterion_adv = nn.HingeEmbeddingLoss()  # not used directly; we implement hinge manually
        self.criterion_recon = nn.L1Loss()

        # Optimizers
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.generator.to(self.device)
        self.discriminator.to(self.device)

        self.w_avg = None  # for truncation trick

    def update_w_avg(self, num_samples=10000):
        """Estimate average w for truncation."""
        self.generator.eval()
        with torch.no_grad():
            z = torch.randn(num_samples, self.latent_dim, 1, 1, device=self.device)
            z_flat = z.view(num_samples, self.latent_dim)
            w = self.generator.mapping(z_flat)
            self.w_avg = w.mean(dim=0, keepdim=True)   # [1, w_dim]
        self.generator.train()
        print(f"Updated w_avg (shape {self.w_avg.shape})")

    def truncation_trick(self, w, psi=0.7):
        """w' = w_avg + psi * (w - w_avg)"""
        if self.w_avg is None:
            self.update_w_avg()
        w_avg = self.w_avg.to(w.device)
        return w_avg + psi * (w - w_avg)


# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size

        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)


# ==================== GUI Application ====================

class UltimateGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Ultimate GAN: StyleGAN + FastGAN Fusion")
        self.root.geometry("1100x750")

        # Training state
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()

        # Settings (all features combined)
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_dim': tk.IntVar(value=100),
            'w_dim': tk.IntVar(value=64),
            'mapping_depth': tk.IntVar(value=8),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'use_noise': tk.BooleanVar(value=True),
            'batch_size': tk.IntVar(value=4),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=min(2, multiprocessing.cpu_count())),
            'generate_interval': tk.IntVar(value=5),
            'reconstruction_weight': tk.DoubleVar(value=10.0),
            'truncation_psi': tk.DoubleVar(value=0.7),   # for generation
        }

        self.start_time = None
        self.generated_images = []
        self.fixed_noise = None

        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Tabs
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    # ---------- Training Tab ----------
    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))

        tk.Label(left_frame, text="Ultimate GAN Controls",
                font=("Arial", 12, "bold")).pack(pady=(0, 10))

        self.size_display = tk.Label(left_frame, text="Image Size: 32x32")
        self.size_display.pack(pady=(0, 10))

        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))

        tk.Button(img_select_frame, text="Add Images",
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All",
                 command=self.clear_images, width=20).pack(pady=5)

        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=scrollbar.set)

        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))

        tk.Button(train_frame, text="Initialize GAN",
                 command=self.initialize_gan, width=20).pack(pady=5)

        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="Start Training",
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training",
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)

        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)

        tk.Button(gen_frame, text="Generate Sample",
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model",
                 command=self.save_model, width=20).pack(pady=5)

        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)

        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)

        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)

        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

        self.status_label = tk.Label(self.training_tab, text="Ready",
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    # ---------- Settings Tab ----------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Ultimate GAN Settings",
                font=("Arial", 14, "bold")).pack(pady=(0, 20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Network architecture
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))

        # Fixed image size
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed)", width=20, anchor='w').pack(side=tk.LEFT, padx=5)

        arch_params = [
            ("Latent Dimension (z):", 'latent_dim', 10, 500),
            ("W Dimension (style):", 'w_dim', 16, 256),
            ("Mapping Network Depth:", 'mapping_depth', 1, 16),
            ("Generator Features (ngf):", 'ngf', 32, 256),
            ("Discriminator Features (ndf):", 'ndf', 32, 256),
        ]

        for label, key, minv, maxv in arch_params:
            f = tk.Frame(net_frame)
            f.pack(fill=tk.X, pady=5)
            tk.Label(f, text=label, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(f, from_=minv, to=maxv, variable=self.settings[key],
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT, padx=5)

        # Training parameters
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))

        train_params = [
            ("Batch Size:", 'batch_size', 1, 16),
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1 (Adam):", 'beta1', 0.0, 0.999),
            ("Reconstruction Loss Weight:", 'reconstruction_weight', 0.1, 100.0),
            ("Number of Workers:", 'num_workers', 0, min(4, multiprocessing.cpu_count())),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]

        for label, key, minv, maxv in train_params:
            f = tk.Frame(train_frame)
            f.pack(fill=tk.X, pady=5)
            tk.Label(f, text=label, width=30, anchor='w').pack(side=tk.LEFT)
            res = 0.00001 if key == 'learning_rate' else (0.001 if key == 'beta1' else (0.1 if key == 'reconstruction_weight' else 1))
            tk.Scale(f, from_=minv, to=maxv, variable=self.settings[key],
                    orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT, padx=5)

        # Options
        opt_frame = tk.LabelFrame(scrollable_frame, text="Options", padx=10, pady=10)
        opt_frame.pack(fill=tk.X, pady=(0, 10))

        tk.Checkbutton(opt_frame, text="Enable Stochastic Noise in Generator",
                       variable=self.settings['use_noise']).pack(anchor='w', pady=2)

        tk.Label(opt_frame, text="Truncation Psi (for generation):", anchor='w').pack(anchor='w', pady=5)
        tk.Scale(opt_frame, from_=0.1, to=1.0, variable=self.settings['truncation_psi'],
                orient=tk.HORIZONTAL, length=300, resolution=0.05).pack(anchor='w', pady=5)

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))

        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}",
                anchor='w').pack(fill=tk.X, pady=2)

        # Buttons
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)

        tk.Button(btn_frame, text="Save as Default",
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults",
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset to Recommended",
                 command=self.reset_to_recommended, width=15).pack(side=tk.LEFT, padx=5)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ---------- Generate Tab ----------
    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Image Generation with Truncation",
                font=("Arial", 14, "bold")).pack(pady=(0, 20))

        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))

        tk.Button(load_frame, text="Load Generator",
                 command=self.load_generator, width=20).pack(pady=5)

        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))

        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var,
                orient=tk.HORIZONTAL, length=300).pack(pady=5)

        tk.Button(gen_frame, text="Generate Grid",
                 command=self.generate_grid, width=20).pack(pady=10)

        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)

        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)

        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )

        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)

        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ---------- Helper Methods ----------
    def log_message(self, message):
        self.message_queue.put(message)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(msg)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff *.webp")]
        )
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths.clear()
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images.")

    def initialize_gan(self):
        try:
            self.gan = UltimateGAN(
                image_size=self.settings['image_size'].get(),
                latent_dim=self.settings['latent_dim'].get(),
                w_dim=self.settings['w_dim'].get(),
                mapping_depth=self.settings['mapping_depth'].get(),
                ngf=self.settings['ngf'].get(),
                ndf=self.settings['ndf'].get(),
                use_noise=self.settings['use_noise'].get()
            )
            self.fixed_noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
            self.log_message("GAN initialized with all features.")
        except Exception as e:
            self.log_message(f"Init error: {e}")
            traceback.print_exc()

    def start_training(self):
        if not self.image_paths:
            self.log_message("No images!")
            return
        if not self.gan:
            self.log_message("GAN not initialized!")
            return
        if self.training:
            self.log_message("Already training!")
            return

        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()

            # Update optimizers with current settings
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            for pg in self.gan.optimizerG.param_groups:
                pg['lr'] = lr
                pg['betas'] = (beta1, 0.999)
            for pg in self.gan.optimizerD.param_groups:
                pg['lr'] = lr
                pg['betas'] = (beta1, 0.999)

            thread = threading.Thread(
                target=self.train_loop,
                args=(epochs, self.settings['batch_size'].get(),
                      self.settings['num_workers'].get()),
                daemon=True
            )
            thread.start()
            self.log_message(f"Training started for {epochs} epochs.")
        except Exception as e:
            self.log_message(f"Start error: {e}")

    def train_loop(self, epochs, batch_size, num_workers):
        try:
            dataset = ImageDataset(self.image_paths, self.settings['image_size'].get())
            loader = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=True,
                num_workers=num_workers,
                pin_memory=torch.cuda.is_available(),
                persistent_workers=num_workers > 0
            )

            recon_weight = self.settings['reconstruction_weight'].get()
            generate_interval = self.settings['generate_interval'].get()

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                loss_d_sum = 0.0
                loss_g_sum = 0.0
                recon_full_sum = 0.0
                recon_patch_sum = 0.0
                n_batches = 0
                epoch_start = time.time()

                for real in loader:
                    if not self.training:
                        break
                    bs = real.size(0)
                    real = real.to(self.gan.device)

                    # Train Discriminator
                    self.gan.optimizerD.zero_grad()

                    # Real
                    real_logit, f1, f2 = self.gan.discriminator(real, return_features=True)
                    loss_real = torch.mean(torch.relu(1.0 - real_logit))

                    # Fake
                    noise = torch.randn(bs, self.gan.latent_dim, 1, 1, device=self.gan.device)
                    fake = self.gan.generator(noise)
                    fake_logit = self.gan.discriminator(fake.detach())
                    loss_fake = torch.mean(torch.relu(1.0 + fake_logit))

                    # Reconstruction losses
                    # Full
                    recon_full = self.gan.discriminator.decode_full(f2)
                    loss_recon_full = self.gan.criterion_recon(recon_full, real)

                    # Patch
                    loss_recon_patch = 0.0
                    patch_size_feat = 8
                    patch_size_img = 16
                    for i in range(bs):
                        top = random.randint(0, 16 - patch_size_feat)
                        left = random.randint(0, 16 - patch_size_feat)
                        f1_crop = f1[i, :, top:top+patch_size_feat, left:left+patch_size_feat].unsqueeze(0)
                        patch_rec = self.gan.discriminator.decode_patch(f1_crop)
                        img_top = top * 2
                        img_left = left * 2
                        img_patch = real[i, :, img_top:img_top+patch_size_img, img_left:img_left+patch_size_img].unsqueeze(0)
                        loss_recon_patch += self.gan.criterion_recon(patch_rec, img_patch)
                    loss_recon_patch /= bs

                    loss_d = loss_real + loss_fake + recon_weight * (loss_recon_full + loss_recon_patch)
                    loss_d.backward()
                    self.gan.optimizerD.step()

                    # Train Generator
                    self.gan.optimizerG.zero_grad()
                    noise = torch.randn(bs, self.gan.latent_dim, 1, 1, device=self.gan.device)
                    fake = self.gan.generator(noise)
                    fake_logit = self.gan.discriminator(fake)
                    loss_g = -torch.mean(fake_logit)  # hinge
                    loss_g.backward()
                    self.gan.optimizerG.step()

                    loss_d_sum += loss_d.item()
                    loss_g_sum += loss_g.item()
                    recon_full_sum += loss_recon_full.item()
                    recon_patch_sum += loss_recon_patch.item()
                    n_batches += 1

                if n_batches > 0:
                    epoch_time = time.time() - epoch_start
                    total_time = time.time() - self.start_time
                    self.log_message(
                        f"Epoch {epoch+1}/{epochs} | "
                        f"D: {loss_d_sum/n_batches:.3f} | G: {loss_g_sum/n_batches:.3f} | "
                        f"ReconF: {recon_full_sum/n_batches:.3f} | ReconP: {recon_patch_sum/n_batches:.3f} | "
                        f"Time: {epoch_time:.1f}s | Total: {total_time:.1f}s"
                    )
                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1}: no batches")

            self.training = False
            self.log_message("Training finished.")
        except Exception as e:
            self.log_message(f"Training error: {e}")
            traceback.print_exc()
            self.training = False

    def generate_training_samples(self):
        if not self.gan:
            return
        try:
            with torch.no_grad():
                noise = self.fixed_noise if self.fixed_noise is not None else torch.randn(1, self.gan.latent_dim, 1, 1, device=self.gan.device)
                # No truncation during training
                generated = self.gan.generator(noise).cpu()
                img = self.tensor_to_pil(generated[0])
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
                self.log_message(f"Sample at epoch {self.current_epoch+1}")
        except Exception as e:
            self.log_message(f"Sample gen error: {e}")

    def tensor_to_pil(self, tensor):
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        return transforms.ToPILImage()(img)

    def stop_training(self):
        self.training = False
        self.log_message("Training stopped.")

    def generate_sample(self):
        if not self.gan:
            self.log_message("GAN not initialized!")
            return
        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                z_flat = noise.view(1, self.gan.latent_dim)
                w = self.gan.generator.mapping(z_flat)
                psi = self.settings['truncation_psi'].get()
                if psi < 1.0:
                    w = self.gan.truncation_trick(w, psi)
                generated = self.gan.generator.synthesis(noise, w).cpu()
                img = self.tensor_to_pil(generated[0])
                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)
                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo
                self.generated_images.append(img)
                self.log_message(f"Generated sample (psi={psi:.2f})")
        except Exception as e:
            self.log_message(f"Generate error: {e}")

    def save_model(self):
        if not self.gan:
            self.log_message("No model to save!")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth", filetypes=[("PyTorch", "*.pth")])
        if fname:
            torch.save({
                'epoch': self.current_epoch,
                'generator': self.gan.generator.state_dict(),
                'discriminator': self.gan.discriminator.state_dict(),
                'optimG': self.gan.optimizerG.state_dict(),
                'optimD': self.gan.optimizerD.state_dict(),
                'settings': {k: v.get() for k, v in self.settings.items()}
            }, fname)
            self.log_message(f"Model saved to {fname}")

    def load_generator(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch", "*.pth *.pt")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            # Restore settings from checkpoint if present
            if 'settings' in ckpt:
                for k, v in ckpt['settings'].items():
                    if k in self.settings:
                        self.settings[k].set(v)
            self.initialize_gan()
            self.gan.generator.load_state_dict(ckpt['generator'])
            if 'discriminator' in ckpt:
                self.gan.discriminator.load_state_dict(ckpt['discriminator'])
            self.log_message(f"Loaded model from {fname}")
        except Exception as e:
            self.log_message(f"Load error: {e}")

    def generate_grid(self):
        if not self.gan:
            self.log_message("GAN not initialized!")
            return
        try:
            n = self.num_gen_var.get()
            psi = self.settings['truncation_psi'].get()
            with torch.no_grad():
                noise = torch.randn(n, self.gan.latent_dim, 1, 1).to(self.gan.device)
                z_flat = noise.view(n, self.gan.latent_dim)
                w = self.gan.generator.mapping(z_flat)
                if psi < 1.0:
                    w = self.gan.truncation_trick(w, psi)
                generated = self.gan.generator.synthesis(noise, w).cpu()

            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()

            cols = 4
            rows = (n + cols - 1) // cols
            for i in range(rows):
                row = tk.Frame(self.gen_scroll_frame)
                row.pack(pady=5)
                for j in range(cols):
                    idx = i * cols + j
                    if idx < n:
                        img = self.tensor_to_pil(generated[idx])
                        img_disp = img.resize((128, 128), Image.Resampling.NEAREST)
                        photo = ImageTk.PhotoImage(img_disp)
                        lbl = tk.Label(row, image=photo)
                        lbl.image = photo
                        lbl.pack(side=tk.LEFT, padx=5)
            self.log_message(f"Generated {n} images (psi={psi:.2f})")
        except Exception as e:
            self.log_message(f"Grid error: {e}")

    def save_defaults(self):
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            with open('ultimate_gan_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Defaults saved.")
        except Exception as e:
            self.log_message(f"Save defaults error: {e}")

    def load_defaults(self):
        try:
            if os.path.exists('ultimate_gan_defaults.json'):
                with open('ultimate_gan_defaults.json', 'r') as f:
                    defaults = json.load(f)
                for k, v in defaults.items():
                    if k in self.settings:
                        self.settings[k].set(v)
                self.log_message("Defaults loaded.")
            else:
                self.log_message("No defaults file.")
        except Exception as e:
            self.log_message(f"Load defaults error: {e}")

    def reset_to_recommended(self):
        rec = {
            'image_size': 32,
            'latent_dim': 100,
            'w_dim': 64,
            'mapping_depth': 8,
            'ngf': 64,
            'ndf': 64,
            'use_noise': True,
            'batch_size': 4,
            'learning_rate': 0.0002,
            'beta1': 0.5,
            'num_workers': min(2, multiprocessing.cpu_count()),
            'generate_interval': 5,
            'reconstruction_weight': 10.0,
            'truncation_psi': 0.7,
        }
        for k, v in rec.items():
            if k in self.settings:
                self.settings[k].set(v)
        self.log_message("Reset to recommended settings.")


# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Ultimate GAN (StyleGAN + FastGAN fusion)")
    print(f"CPU cores: {multiprocessing.cpu_count()}, PyTorch version: {torch.__version__}")
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    root = tk.Tk()
    app = UltimateGANApp(root)
    root.mainloop()