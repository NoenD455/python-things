import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random

# ==================== FastGAN Components ====================

class SLE(nn.Module):
    """Skip-Layer Excitation module: modulates high-res features using low-res features."""
    def __init__(self, low_channels, high_channels):
        super().__init__()
        # Reduce low-res feature map to a channel descriptor
        self.conv = nn.Sequential(
            nn.AdaptiveAvgPool2d(4),        # down to 4x4
            nn.Conv2d(low_channels, low_channels, 4, 4, 0),  # to 1x1
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(low_channels, high_channels, 1, 1, 0),  # match high channels
            nn.Sigmoid()
        )

    def forward(self, low, high):
        gate = self.conv(low)               # (B, C_high, 1, 1)
        return high * gate                   # channel‑wise multiplication


class FastGenerator(nn.Module):
    """Generator with SLE connections between scales."""
    def __init__(self, latent_dim=100, ngf=64):
        super().__init__()
        self.latent_dim = latent_dim
        self.ngf = ngf

        # Initial dense layer to 4x4
        self.init_conv = nn.Sequential(
            nn.ConvTranspose2d(latent_dim, ngf * 8, 4, 1, 0, bias=False),
            nn.BatchNorm2d(ngf * 8),
            nn.ReLU(True)
        )  # -> (ngf*8, 4, 4)

        # Upsample blocks
        self.block1 = self._make_block(ngf * 8, ngf * 4)   # 4x4 → 8x8
        self.block2 = self._make_block(ngf * 4, ngf * 2)   # 8x8 → 16x16
        self.block3 = self._make_block(ngf * 2, ngf)       # 16x16 → 32x32
        self.to_rgb = nn.Sequential(
            nn.Conv2d(ngf, 3, 3, 1, 1, bias=False),
            nn.Tanh()
        )

        # SLE modules connecting different scales
        self.sle_4_to_16 = SLE(ngf * 8, ngf * 2)   # from 4x4 to 16x16
        self.sle_8_to_32 = SLE(ngf * 4, ngf)       # from 8x8 to 32x32

    def _make_block(self, in_ch, out_ch):
        return nn.Sequential(
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.Conv2d(in_ch, out_ch, 3, 1, 1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.LeakyReLU(0.2, inplace=True),
        )

    def forward(self, z):
        x = z.view(z.size(0), -1, 1, 1)
        x0 = self.init_conv(x)               # (B, ngf*8, 4, 4)

        x1 = self.block1(x0)                  # (B, ngf*4, 8, 8)
        x2 = self.block2(x1)                  # (B, ngf*2, 16, 16)
        # Apply SLE from 4x4 (x0) to 16x16 (x2)
        x2 = self.sle_4_to_16(x0, x2)

        x3 = self.block3(x2)                  # (B, ngf, 32, 32)
        # Apply SLE from 8x8 (x1) to 32x32 (x3)
        x3 = self.sle_8_to_32(x1, x3)

        out = self.to_rgb(x3)
        return out


class FastDiscriminator(nn.Module):
    """Discriminator with two decoders (full and patch) for self‑supervision."""
    def __init__(self, ndf=64):
        super().__init__()
        self.ndf = ndf

        # Downsampling blocks – we store intermediate features
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, ndf, 4, 2, 1, bias=False),
            nn.LeakyReLU(0.2, inplace=True)
        )  # -> (ndf, 16, 16)   f1

        self.conv2 = nn.Sequential(
            nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 2),
            nn.LeakyReLU(0.2, inplace=True)
        )  # -> (ndf*2, 8, 8)   f2

        self.conv3 = nn.Sequential(
            nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf * 4),
            nn.LeakyReLU(0.2, inplace=True)
        )  # -> (ndf*4, 4, 4)

        self.conv4 = nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False)   # final logit

        # --- Full decoder: from 8x8 feature (f2) to 32x32 image ---
        self.full_decoder = nn.Sequential(
            nn.ConvTranspose2d(ndf * 2, ndf, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf),
            nn.LeakyReLU(0.2, inplace=True),   # -> 16x16
            nn.ConvTranspose2d(ndf, 3, 4, 2, 1, bias=False),
            nn.Tanh()                           # -> 32x32
        )

        # --- Patch decoder: from cropped 16x16 feature (f1, 8x8 crop) to 16x16 patch ---
        self.patch_decoder = nn.Sequential(
            nn.ConvTranspose2d(ndf, ndf, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ndf),
            nn.LeakyReLU(0.2, inplace=True),   # -> 16x16
            nn.Conv2d(ndf, 3, 3, 1, 1, bias=False),
            nn.Tanh()                           # output 16x16
        )

    def forward(self, x, return_features=False):
        f1 = self.conv1(x)          # (B, ndf, 16, 16)
        f2 = self.conv2(f1)         # (B, ndf*2, 8, 8)
        f3 = self.conv3(f2)         # (B, ndf*4, 4, 4)
        logit = self.conv4(f3).view(-1, 1)

        if return_features:
            return logit, f1, f2
        return logit

    def decode_full(self, f2):
        """Reconstruct full 32x32 image from f2 (8x8 feature)."""
        return self.full_decoder(f2)

    def decode_patch(self, f1_crop):
        """Reconstruct a 16x16 patch from an 8x8 cropped feature."""
        return self.patch_decoder(f1_crop)


class FastGAN:
    def __init__(self, image_size=32, latent_dim=100, ngf=64, ndf=64):
        self.image_size = image_size
        self.latent_dim = latent_dim
        self.ngf = ngf
        self.ndf = ndf

        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")

        self.generator = FastGenerator(latent_dim, ngf)
        self.discriminator = FastDiscriminator(ndf)

        # Losses: no explicit loss objects – we use hinge loss directly
        self.reconstruction_loss = nn.L1Loss()

        # Optimizers
        self.optimizerG = optim.Adam(self.generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
        self.optimizerD = optim.Adam(self.discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.generator.to(self.device)
        self.discriminator.to(self.device)

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size

        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size),interpolation=0),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            return self.transform(img)
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================
# (Mostly unchanged, but references to FastGAN and training loop updated)

class FastGANApp:
    def __init__(self, root):
        self.root = root
        self.root.title("FastGAN Trainer (Full: Hinge + 2 Decoders)")
        self.root.geometry("1000x700")

        # Training parameters
        self.image_paths = []
        self.training = False
        self.gan = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()

        # Settings
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'latent_dim': tk.IntVar(value=100),
            'ngf': tk.IntVar(value=64),
            'ndf': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=4),          # lower for CPU
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.5),
            'num_workers': tk.IntVar(value=2),         # match physical cores
            'save_interval': tk.IntVar(value=10),
            'generate_interval': tk.IntVar(value=5),
            'reconstruction_weight': tk.DoubleVar(value=10.0),
        }

        # Performance tracking
        self.num_workers = min(2, multiprocessing.cpu_count())
        self.start_time = None

        # For storing generated images
        self.generated_images = []

        # GUI Setup
        self.setup_gui()

        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()

        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        # Tab 3: Generate
        self.generate_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generate_tab, text='Generate')
        self.setup_generate_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))

        # Title
        tk.Label(left_frame, text="FastGAN Controls",
                font=("Arial", 12, "bold")).pack(pady=(0, 10))

        # Image size display
        self.size_display = tk.Label(left_frame, text="Image Size: 32x32")
        self.size_display.pack(pady=(0, 10))

        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))

        tk.Button(img_select_frame, text="Add Images",
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All",
                 command=self.clear_images, width=20).pack(pady=5)

        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        self.image_listbox = tk.Listbox(list_frame, height=8)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)

        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))

        tk.Button(train_frame, text="Initialize FastGAN",
                 command=self.initialize_gan, width=20).pack(pady=5)

        # Epochs input
        epoch_frame = tk.Frame(train_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=10).pack(side=tk.LEFT, padx=5)

        tk.Button(train_frame, text="Start Training",
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training",
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)

        # Generation during training
        gen_frame = tk.LabelFrame(left_frame, text="Generation", padx=10, pady=10)
        gen_frame.pack(fill=tk.X)

        tk.Button(gen_frame, text="Generate Sample",
                 command=self.generate_sample, width=20).pack(pady=5)
        tk.Button(gen_frame, text="Save Model",
                 command=self.save_model, width=20).pack(pady=5)

        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Generated image display - SINGLE LARGE IMAGE
        preview_frame = tk.LabelFrame(right_frame, text="Generated Image", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        # Single image display (200x200)
        self.single_image_frame = tk.Frame(preview_frame, width=200, height=200, bg='gray')
        self.single_image_frame.pack(pady=10)
        self.single_image_frame.pack_propagate(False)

        self.single_image_label = tk.Label(self.single_image_frame, text="No image generated", bg='gray')
        self.single_image_label.pack(fill=tk.BOTH, expand=True)

        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)

        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

        # Status bar at bottom
        self.status_label = tk.Label(self.training_tab, text="Ready",
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        # Title
        tk.Label(main_frame, text="FastGAN Settings",
                font=("Arial", 14, "bold")).pack(pady=(0, 20))

        # Create a canvas with scrollbar for many settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Network settings
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))

        # Image size - Fixed to 32x32
        size_frame = tk.Frame(net_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Image Size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Label(size_frame, text="32x32 (Fixed)", width=20, anchor='w').pack(side=tk.LEFT, padx=5)

        # Other network parameters
        settings_list = [
            ("Latent Dimension (z):", 'latent_dim', 10, 500),
            ("Generator Features (ngf):", 'ngf', 32, 256),
            ("Discriminator Features (ndf):", 'ndf', 32, 256),
            ("Batch Size:", 'batch_size', 1, 16),   # limited for CPU
        ]

        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)

        # Training settings
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))

        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Reconstruction Loss Weight:", 'reconstruction_weight', 0.1, 100.0),
            ("Number of Workers:", 'num_workers', 0, min(4, multiprocessing.cpu_count())),
            ("Generate Interval (epochs):", 'generate_interval', 1, 50),
        ]

        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=30, anchor='w').pack(side=tk.LEFT)

            if var_name in ['learning_rate', 'beta1', 'reconstruction_weight']:
                resolution = 0.00001 if var_name == 'learning_rate' else (0.001 if var_name == 'beta1' else 0.1)
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)

            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))

        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}",
                anchor='w').pack(fill=tk.X, pady=2)

        # Save/Load defaults button
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)

        tk.Button(btn_frame, text="Save as Default",
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults",
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Reset to Paper",
                 command=self.reset_to_paper, width=15).pack(side=tk.LEFT, padx=5)

        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Image Generation",
                font=("Arial", 14, "bold")).pack(pady=(0, 20))

        # Model loading
        load_frame = tk.LabelFrame(main_frame, text="Load Model", padx=10, pady=10)
        load_frame.pack(fill=tk.X, pady=(0, 20))

        tk.Button(load_frame, text="Load Generator",
                 command=self.load_generator, width=20).pack(pady=5)

        # Generation controls
        gen_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        gen_frame.pack(fill=tk.X, pady=(0, 20))

        tk.Label(gen_frame, text="Number of Images:").pack(pady=5)
        self.num_gen_var = tk.IntVar(value=8)
        tk.Scale(gen_frame, from_=1, to=64, variable=self.num_gen_var,
                orient=tk.HORIZONTAL, length=300).pack(pady=5)

        tk.Button(gen_frame, text="Generate Grid",
                 command=self.generate_grid, width=20).pack(pady=10)

        # Display area for generated images
        self.gen_display_frame = tk.LabelFrame(main_frame, text="Generated Images", padx=10, pady=10)
        self.gen_display_frame.pack(fill=tk.BOTH, expand=True)

        self.gen_canvas = tk.Canvas(self.gen_display_frame, bg='white')
        scrollbar = tk.Scrollbar(self.gen_display_frame, orient="vertical", command=self.gen_canvas.yview)
        self.gen_scroll_frame = tk.Frame(self.gen_canvas)

        self.gen_scroll_frame.bind(
            "<Configure>",
            lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox("all"))
        )

        self.gen_canvas.create_window((0, 0), window=self.gen_scroll_frame, anchor="nw")
        self.gen_canvas.configure(yscrollcommand=scrollbar.set)

        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def update_size_display(self):
        self.size_display.config(text="Image Size: 32x32")

    def log_message(self, message):
        self.message_queue.put(message)

    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                print(message)
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff *.webp *.tiff *.jfif")]
        )

        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)

        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_gan(self):
        try:
            image_size = self.settings['image_size'].get()
            latent_dim = self.settings['latent_dim'].get()
            ngf = self.settings['ngf'].get()
            ndf = self.settings['ndf'].get()

            self.gan = FastGAN(
                image_size=image_size,
                latent_dim=latent_dim,
                ngf=ngf,
                ndf=ndf
            )

            self.log_message(f"Initialized FastGAN for {image_size}x{image_size} images")
            self.log_message(f"Latent dim: {latent_dim}, G features: {ngf}, D features: {ndf}")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")

        except Exception as e:
            self.log_message(f"Error initializing GAN: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return

        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return

        if self.training:
            self.log_message("Training already in progress!")
            return

        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()

            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()

            # Update optimizers
            for param_group in self.gan.optimizerG.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)

            for param_group in self.gan.optimizerD.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)

            thread = threading.Thread(
                target=self.train_gan,
                args=(epochs, batch_size, num_workers),
                daemon=True
            )
            thread.start()

            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}")

        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_gan(self, epochs, batch_size, num_workers):
        try:
            image_size = self.settings['image_size'].get()
            generate_interval = self.settings['generate_interval'].get()
            recon_weight = self.settings['reconstruction_weight'].get()

            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=True,
                num_workers=num_workers,
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )

            for epoch in range(epochs):
                if not self.training:
                    break

                self.current_epoch = epoch
                total_loss_d = 0
                total_loss_g = 0
                total_loss_recon_full = 0
                total_loss_recon_patch = 0
                batch_count = 0
                epoch_start = time.time()

                for real_images in dataloader:
                    if not self.training:
                        break

                    batch_size_actual = real_images.size(0)
                    real_images = real_images.to(self.gan.device)

                    # ---------------------
                    # Train Discriminator
                    # ---------------------
                    self.gan.optimizerD.zero_grad()

                    # Real images: get logit, f1 (16x16), f2 (8x8)
                    real_logit, f1, f2 = self.gan.discriminator(real_images, return_features=True)

                    # Hinge loss for real
                    loss_real = torch.mean(torch.relu(1.0 - real_logit))

                    # Fake images
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, 1, 1, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    fake_logit = self.gan.discriminator(fake_images.detach())
                    loss_fake = torch.mean(torch.relu(1.0 + fake_logit))

                    # Reconstruction losses (self-supervision)
                    # Full image reconstruction from f2
                    recon_full = self.gan.discriminator.decode_full(f2)
                    loss_recon_full = self.gan.reconstruction_loss(recon_full, real_images)

                    # Patch reconstruction from f1 with random cropping
                    # Crop a random 8x8 region from f1 (16x16) and corresponding 16x16 region from real image
                    # Generate random top and left for each image in batch
                    loss_recon_patch = 0.0
                    patch_size_feat = 8  # crop 8x8 from f1
                    patch_size_img = 16   # corresponds to 16x16 in image
                    for i in range(batch_size_actual):
                        # Random top-left corner for feature crop (0 to 16-8 = 8)
                        top = random.randint(0, 16 - patch_size_feat)
                        left = random.randint(0, 16 - patch_size_feat)
                        # Crop feature
                        f1_crop = f1[i, :, top:top+patch_size_feat, left:left+patch_size_feat].unsqueeze(0)
                        # Decode patch
                        patch_rec = self.gan.discriminator.decode_patch(f1_crop)  # (1,3,16,16)
                        # Crop corresponding image region (top*2, left*2 because stride 2)
                        img_top = top * 2
                        img_left = left * 2
                        img_patch = real_images[i, :, img_top:img_top+patch_size_img, img_left:img_left+patch_size_img].unsqueeze(0)
                        loss_recon_patch += self.gan.reconstruction_loss(patch_rec, img_patch)
                    loss_recon_patch /= batch_size_actual

                    # Total D loss
                    loss_d = loss_real + loss_fake + recon_weight * (loss_recon_full + loss_recon_patch)
                    loss_d.backward()
                    self.gan.optimizerD.step()

                    # ---------------------
                    # Train Generator
                    # ---------------------
                    self.gan.optimizerG.zero_grad()

                    # Generate new fake
                    noise = torch.randn(batch_size_actual, self.gan.latent_dim, 1, 1, device=self.gan.device)
                    fake_images = self.gan.generator(noise)
                    fake_logit = self.gan.discriminator(fake_images)
                    # Hinge loss for generator: we want D(fake) to be high (>=1), so minimize -D(fake)
                    loss_g = -torch.mean(fake_logit)
                    loss_g.backward()
                    self.gan.optimizerG.step()

                    total_loss_d += loss_d.item()
                    total_loss_g += loss_g.item()
                    total_loss_recon_full += loss_recon_full.item()
                    total_loss_recon_patch += loss_recon_patch.item()
                    batch_count += 1

                if batch_count > 0:
                    avg_loss_d = total_loss_d / batch_count
                    avg_loss_g = total_loss_g / batch_count
                    avg_recon_full = total_loss_recon_full / batch_count
                    avg_recon_patch = total_loss_recon_patch / batch_count
                    epoch_time = time.time() - epoch_start
                    elapsed = time.time() - self.start_time

                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"D Loss: {avg_loss_d:.4f} | G Loss: {avg_loss_g:.4f} | "
                                   f"ReconFull: {avg_recon_full:.4f} | ReconPatch: {avg_recon_patch:.4f} | "
                                   f"Time: {epoch_time:.1f}s | Total: {elapsed:.1f}s")

                    if (epoch + 1) % generate_interval == 0:
                        self.generate_training_samples()
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")

            self.training = False
            self.log_message("Training completed!")

        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def generate_training_samples(self):
        if not self.gan:
            return

        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()

                img_tensor = generated[0]
                img = self.tensor_to_pil(img_tensor)

                img_display = img.resize((200, 200), Image.Resampling.NEAREST)

                photo = ImageTk.PhotoImage(img_display)

                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo

                self.generated_images.append(img)

                self.log_message(f"Generated training sample at epoch {self.current_epoch + 1}")

        except Exception as e:
            self.log_message(f"Error generating samples: {str(e)}")

    def tensor_to_pil(self, tensor):
        img = (tensor + 1) / 2
        img = img.clamp(0, 1)
        img = transforms.ToPILImage()(img)
        return img

    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def generate_sample(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return

        try:
            with torch.no_grad():
                noise = torch.randn(1, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()
                img = self.tensor_to_pil(generated[0])

                img_display = img.resize((200, 200), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(img_display)

                self.single_image_label.config(image=photo, text="")
                self.single_image_label.image = photo

                self.generated_images.append(img)

                self.log_message("Generated single sample")

        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")

    def save_model(self):
        if not self.gan:
            self.log_message("Error: No model to save!")
            return

        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )

        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'generator_state_dict': self.gan.generator.state_dict(),
                    'discriminator_state_dict': self.gan.discriminator.state_dict(),
                    'optimizerG_state_dict': self.gan.optimizerG.state_dict(),
                    'optimizerD_state_dict': self.gan.optimizerD.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'latent_dim': self.settings['latent_dim'].get(),
                    'ngf': self.settings['ngf'].get(),
                    'ndf': self.settings['ndf'].get(),
                }, filename)

                self.log_message(f"Model manually saved to {filename}")

            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_generator(self):
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )

        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')

                if 'image_size' in checkpoint:
                    self.settings['image_size'].set(checkpoint['image_size'])
                    self.update_size_display()

                if 'latent_dim' in checkpoint:
                    self.settings['latent_dim'].set(checkpoint['latent_dim'])

                if 'ngf' in checkpoint:
                    self.settings['ngf'].set(checkpoint['ngf'])

                if 'ndf' in checkpoint:
                    self.settings['ndf'].set(checkpoint['ndf'])

                self.initialize_gan()

                self.gan.generator.load_state_dict(checkpoint['generator_state_dict'])
                if 'discriminator_state_dict' in checkpoint:
                    self.gan.discriminator.load_state_dict(checkpoint['discriminator_state_dict'])

                self.log_message(f"Loaded model from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")

            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def generate_grid(self):
        if not self.gan:
            self.log_message("Error: GAN not initialized!")
            return

        try:
            num_images = self.num_gen_var.get()

            with torch.no_grad():
                noise = torch.randn(num_images, self.gan.latent_dim, 1, 1).to(self.gan.device)
                generated = self.gan.generator(noise).cpu()

            for widget in self.gen_scroll_frame.winfo_children():
                widget.destroy()

            cols = 4
            rows = (num_images + cols - 1) // cols

            for i in range(rows):
                row_frame = tk.Frame(self.gen_scroll_frame)
                row_frame.pack(pady=5)

                for j in range(cols):
                    idx = i * cols + j
                    if idx < num_images:
                        img_tensor = generated[idx]
                        img = self.tensor_to_pil(img_tensor)

                        img_display = img.resize((128, 128), Image.Resampling.NEAREST)

                        photo = ImageTk.PhotoImage(img_display)

                        label = tk.Label(row_frame, image=photo)
                        label.image = photo
                        label.pack(side=tk.LEFT, padx=5)

            self.log_message(f"Generated {num_images} images in grid")

        except Exception as e:
            self.log_message(f"Error generating grid: {str(e)}")

    def save_defaults(self):
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('fastgan_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        try:
            import json
            if os.path.exists('fastgan_defaults.json'):
                with open('fastgan_defaults.json', 'r') as f:
                    defaults = json.load(f)

                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)

                self.update_size_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

    def reset_to_paper(self):
        paper_settings = {
            'image_size': 32,
            'latent_dim': 100,
            'ngf': 64,
            'ndf': 64,
            'batch_size': 4,
            'learning_rate': 0.0002,
            'beta1': 0.5,
            'reconstruction_weight': 10.0,
            'num_workers': min(2, multiprocessing.cpu_count()),
            'save_interval': 10,
            'generate_interval': 5
        }

        for key, value in paper_settings.items():
            if key in self.settings:
                self.settings[key].set(value)

        self.update_size_display()
        self.log_message("Reset to recommended FastGAN settings")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting FastGAN Trainer (Full Implementation)...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")

    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass

    root = tk.Tk()
    app = FastGANApp(root)
    root.mainloop()