import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
import torchvision.transforms.functional as TF
from PIL import Image, ImageTk, ImageDraw, ImageFilter
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import os
import numpy as np
from pathlib import Path
import threading
import time
import random
import traceback
import sys

# Enable multi-core processing
torch.set_num_threads(2)  # Use 2 CPU cores
print(f"PyTorch using {torch.get_num_threads()} CPU cores")

# Simple CNN Model with selectable kernel sizes
class SimpleCNN(nn.Module):
    def __init__(self, num_classes=2, kernel_size=3):
        super(SimpleCNN, self).__init__()
        self.kernel_size = kernel_size
        padding = kernel_size // 2  # Same padding
        
        print(f"DEBUG: Creating model with kernel_size={kernel_size}, padding={padding}")
        
        self.conv1 = nn.Conv2d(3, 16, kernel_size=kernel_size, stride=1, padding=padding)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=kernel_size, stride=1, padding=padding)
        self.conv3 = nn.Conv2d(32, 64, kernel_size=kernel_size, stride=1, padding=padding)
        self.conv4 = nn.Conv2d(64, 128, kernel_size=kernel_size, stride=1, padding=padding)
        self.conv5 = nn.Conv2d(128, 256, kernel_size=kernel_size, stride=1, padding=padding)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        
        # Calculate the correct input size for fc1
        # Input image: 64x64
        # After 5 pooling layers: 64 -> 32 -> 16 -> 8 -> 4 -> 2
        # So final spatial size is 2x2
        # conv5 has 256 channels, so: 256 * 2 * 2 = 1024
        self.fc1 = nn.Linear(256 * 2 * 2, 512)
        self.fc2 = nn.Linear(512, num_classes)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.5)
        
    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = self.pool(self.relu(self.conv2(x)))
        x = self.pool(self.relu(self.conv3(x)))
        x = self.pool(self.relu(self.conv4(x)))
        x = self.pool(self.relu(self.conv5(x)))
        
        x = x.view(-1, 256 * 2 * 2)
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        return x

    # Method to get intermediate activations for DeepDream
    def get_activations(self, x, layer_idx=4):
        # Pass through conv layers
        x = self.relu(self.conv1(x))
        if layer_idx == 0:
            return x
        
        x = self.pool(x)
        x = self.relu(self.conv2(x))
        if layer_idx == 1:
            return x
        
        x = self.pool(x)
        x = self.relu(self.conv3(x))
        if layer_idx == 2:
            return x
        
        x = self.pool(x)
        x = self.relu(self.conv4(x))
        if layer_idx == 3:
            return x
        
        x = self.pool(x)
        x = self.relu(self.conv5(x))
        if layer_idx == 4:
            return x
        
        x = self.pool(x)
        return x
    
    # Method to get features before classification
    def get_pre_classifier_features(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = self.pool(self.relu(self.conv2(x)))
        x = self.pool(self.relu(self.conv3(x)))
        x = self.pool(self.relu(self.conv4(x)))
        x = self.pool(self.relu(self.conv5(x)))
        x = x.view(-1, 256 * 2 * 2)
        x = self.relu(self.fc1(x))
        return x

# Custom Dataset for user images with intelligent resizing
class UserImageDataset(Dataset):
    def __init__(self, class0_images, class1_images):
        # We'll use a custom transform that chooses resizing method based on image size
        self.class0_images = class0_images
        self.class1_images = class1_images
        
        self.images = []
        self.labels = []
        
        # Process class 0 images
        for img_path in class0_images:
            try:
                image = Image.open(img_path).convert('RGB')
                # Apply intelligent resizing
                resized_image = self.intelligent_resize(image, target_size=64)
                # Apply the rest of the transforms
                tensor_image = self.image_to_tensor(resized_image)
                self.images.append(tensor_image)
                self.labels.append(0)
            except Exception as e:
                print(f"ERROR loading image {img_path}: {e}")
                print(traceback.format_exc())
        
        # Process class 1 images
        for img_path in class1_images:
            try:
                image = Image.open(img_path).convert('RGB')
                # Apply intelligent resizing
                resized_image = self.intelligent_resize(image, target_size=64)
                # Apply the rest of the transforms
                tensor_image = self.image_to_tensor(resized_image)
                self.images.append(tensor_image)
                self.labels.append(1)
            except Exception as e:
                print(f"ERROR loading image {img_path}: {e}")
                print(traceback.format_exc())
    
    def intelligent_resize(self, image, target_size=64):
        """
        Intelligently resize image:
        - Use nearest neighbor for upscaling (crispy pixels!)
        - Use LANCZOS for downscaling (preserves quality)
        """
        width, height = image.size
        
        # Check if we need to upscale or downscale
        if width < target_size or height < target_size:
            # UPSCALING: Use nearest neighbor for crispy pixels
            print(f"UPSCALING: {width}x{height} -> {target_size}x{target_size} (NEAREST)")
            return image.resize((target_size, target_size), Image.Resampling.NEAREST)
        else:
            # DOWNSCALING: Use LANCZOS for high quality
            print(f"DOWNSCALING: {width}x{height} -> {target_size}x{target_size} (LANCZOS)")
            return image.resize((target_size, target_size), Image.Resampling.LANCZOS)
    
    def image_to_tensor(self, image):
        """Convert PIL Image to normalized tensor"""
        # Convert to tensor
        tensor = transforms.ToTensor()(image)
        # Normalize
        tensor = transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))(tensor)
        return tensor
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        return self.images[idx], self.labels[idx]

# Main Application
class CNNTrainingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("CNN Training with DeepDream - Kernel Size Test")
        self.root.geometry("1200x800")
        
        # Redirect stdout to capture all prints
        self.original_stdout = sys.stdout
        self.setup_console_logging()
        
        # Model and data
        self.model = None
        self.class0_images = []
        self.class1_images = []
        self.training = False
        self.current_epoch = 0
        self.total_epochs = 50
        self.kernel_size = 3  # Default kernel size
        
        # For DeepDream
        self.input_image = None
        self.deepdream_active = False
        
        # Setup GUI
        self.setup_gui()
        
    def setup_console_logging(self):
        """Redirect prints to both console and a file"""
        # Create a class that writes to both console and file
        class Tee:
            def __init__(self, *files):
                self.files = files
            def write(self, obj):
                for f in self.files:
                    f.write(obj)
            def flush(self):
                for f in self.files:
                    f.flush()

        print(f"PyTorch version: {torch.__version__}")
        print(f"Python version: {sys.version}")
        
    def __del__(self):
        """Cleanup when object is destroyed"""
        if hasattr(self, 'log_fp'):
            self.log_fp.close()
        sys.stdout = self.original_stdout
    
    def setup_gui(self):
        # Notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        
        # Tab 1: Training
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text="Training")
        self.setup_training_tab()
        
        # Tab 2: DeepDream
        self.deepdream_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.deepdream_tab, text="DeepDream")
        self.setup_deepdream_tab()
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
    
    def setup_training_tab(self):
        # Training Controls
        left_frame = ttk.LabelFrame(self.training_tab, text="Training Controls", padding=10)
        left_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        
        # Class 0 images
        ttk.Label(left_frame, text="Class 0 Images:").grid(row=0, column=0, sticky="w")
        self.class0_listbox = tk.Listbox(left_frame, height=5, width=40)
        self.class0_listbox.grid(row=1, column=0, columnspan=2, pady=5)
        ttk.Button(left_frame, text="Add Class 0 Images", 
                  command=lambda: self.add_images(0)).grid(row=2, column=0, pady=5)
        ttk.Button(left_frame, text="Clear Class 0", 
                  command=lambda: self.clear_images(0)).grid(row=2, column=1, pady=5)
        
        # Class 1 images
        ttk.Label(left_frame, text="Class 1 Images:").grid(row=3, column=0, sticky="w", pady=(10,0))
        self.class1_listbox = tk.Listbox(left_frame, height=5, width=40)
        self.class1_listbox.grid(row=4, column=0, columnspan=2, pady=5)
        ttk.Button(left_frame, text="Add Class 1 Images", 
                  command=lambda: self.add_images(1)).grid(row=5, column=0, pady=5)
        ttk.Button(left_frame, text="Clear Class 1", 
                  command=lambda: self.clear_images(1)).grid(row=5, column=1, pady=5)
        
        # Training parameters
        ttk.Label(left_frame, text="Training Parameters", font=('Arial', 10, 'bold')).grid(
            row=6, column=0, columnspan=2, pady=(20,5))
        
        ttk.Label(left_frame, text="Kernel Size:").grid(row=7, column=0, sticky="w")
        self.kernel_var = tk.StringVar(value="3")
        kernel_combo = ttk.Combobox(left_frame, textvariable=self.kernel_var, 
                                   values=["3", "5", "7"], 
                                   state="readonly", width=10)
        kernel_combo.grid(row=7, column=1, sticky="w")
        ttk.Label(left_frame, text="(3x3, 5x5, or 7x7)", 
                 font=('Arial', 8), foreground="gray").grid(row=8, column=0, columnspan=2, sticky="w")
        
        ttk.Label(left_frame, text="Epochs:").grid(row=9, column=0, sticky="w")
        self.epochs_var = tk.StringVar(value="50")
        epochs_entry = ttk.Entry(left_frame, textvariable=self.epochs_var, width=10)
        epochs_entry.grid(row=9, column=1, sticky="w")
        
        ttk.Label(left_frame, text="Learning Rate:").grid(row=10, column=0, sticky="w")
        self.lr_var = tk.StringVar(value="0.001")
        lr_entry = ttk.Entry(left_frame, textvariable=self.lr_var, width=10)
        lr_entry.grid(row=10, column=1, sticky="w")
        
        ttk.Label(left_frame, text="Batch Size:").grid(row=11, column=0, sticky="w")
        self.batch_size_var = tk.StringVar(value="8")
        batch_entry = ttk.Entry(left_frame, textvariable=self.batch_size_var, width=10)
        batch_entry.grid(row=11, column=1, sticky="w")
        
        # Train button
        self.train_btn = ttk.Button(left_frame, text="Start Training", 
                                   command=self.start_training_thread)
        self.train_btn.grid(row=12, column=0, columnspan=2, pady=20)
        
        # Training progress
        self.progress = ttk.Progressbar(left_frame, length=200, mode='determinate')
        self.progress.grid(row=13, column=0, columnspan=2, pady=5)
        
        self.status_label = ttk.Label(left_frame, text="Ready to train", foreground="blue")
        self.status_label.grid(row=14, column=0, columnspan=2, pady=5)
        
        # Training Visualization
        right_frame = ttk.LabelFrame(self.training_tab, text="Training Output", padding=10)
        right_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        
        # Kernel info display
        ttk.Label(right_frame, text="Current Kernel:", font=('Arial', 10, 'bold')).grid(
            row=0, column=0, sticky="w")
        self.kernel_label = ttk.Label(right_frame, text="3x3", font=('Arial', 14))
        self.kernel_label.grid(row=1, column=0, pady=5)
        
        # Loss display
        ttk.Label(right_frame, text="Training Loss:", font=('Arial', 10, 'bold')).grid(
            row=2, column=0, sticky="w", pady=(10,0))
        self.loss_label = ttk.Label(right_frame, text="0.0000", font=('Arial', 14))
        self.loss_label.grid(row=3, column=0, pady=5)
        
        # Accuracy display
        ttk.Label(right_frame, text="Accuracy:", font=('Arial', 10, 'bold')).grid(
            row=4, column=0, sticky="w", pady=(10,0))
        self.acc_label = ttk.Label(right_frame, text="0%", font=('Arial', 14))
        self.acc_label.grid(row=5, column=0, pady=5)
        
        # Current epoch
        ttk.Label(right_frame, text="Epoch:", font=('Arial', 10, 'bold')).grid(
            row=6, column=0, sticky="w", pady=(10,0))
        self.epoch_label = ttk.Label(right_frame, text="0/0", font=('Arial', 12))
        self.epoch_label.grid(row=7, column=0, pady=5)
        
        # Info about kernel sizes
        info_text = """Kernel Size Guide:
• 3x3: Small details (edges, textures)
• 5x5: Medium features (eyes, ears)
• 7x7: Large patterns (face shape, posture)
        
For cat breeds, try 5x5 or 7x7 to capture ear shape and face structure."""
        ttk.Label(right_frame, text=info_text, font=('Arial', 9), 
                 justify=tk.LEFT, wraplength=250).grid(row=8, column=0, pady=20, sticky="w")
        
        self.training_tab.columnconfigure(0, weight=1)
        self.training_tab.columnconfigure(1, weight=1)
        self.training_tab.rowconfigure(0, weight=1)
    
    def setup_deepdream_tab(self):
        # DeepDream Controls
        left_frame = ttk.LabelFrame(self.deepdream_tab, text="DeepDream Controls", padding=10)
        left_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        
        # Load image for DeepDream
        ttk.Label(left_frame, text="Select image for DeepDream:").grid(row=0, column=0, sticky="w", columnspan=2)
        self.input_btn = ttk.Button(left_frame, text="Load Image", 
                                         command=self.load_input_image)
        self.input_btn.grid(row=1, column=0, columnspan=2, pady=5)
        
        self.path_label = ttk.Label(left_frame, text="No image loaded", foreground="gray")
        self.path_label.grid(row=2, column=0, columnspan=2, pady=5)
        
        # Kernel size info
        ttk.Label(left_frame, text="Current Model Kernel:", font=('Arial', 9, 'bold')).grid(
            row=3, column=0, sticky="w", columnspan=2)
        self.kernel_info_label = ttk.Label(left_frame, text="3x3", foreground="blue")
        self.kernel_info_label.grid(row=4, column=0, columnspan=2, pady=(0,10))
        
        # NEW: Optimization Mode Selection
        ttk.Label(left_frame, text="--- Optimization Mode ---", 
                 font=('Arial', 9, 'bold')).grid(row=5, column=0, columnspan=2, pady=(10,5), sticky="w")
        
        # Layer optimization checkbox
        self.use_layer_var = tk.BooleanVar(value=True)
        self.layer_check = ttk.Checkbutton(left_frame, text="Optimize Layer", 
                                          variable=self.use_layer_var)
        self.layer_check.grid(row=6, column=0, columnspan=2, sticky="w")
        
        # Layer selection (only if checkbox is checked)
        ttk.Label(left_frame, text="Layer:").grid(row=7, column=0, sticky="w", pady=(5,0))
        self.layer_var = tk.StringVar(value="conv5")
        layer_combo = ttk.Combobox(left_frame, textvariable=self.layer_var, 
                                  values=["conv1", "conv2", "conv3", "conv4", "conv5"], 
                                  state="readonly", width=15)
        layer_combo.grid(row=7, column=1, sticky="w", pady=(5,0))
        
        # Channel selection
        ttk.Label(left_frame, text="Channel (or -1 for all):").grid(row=8, column=0, sticky="w", pady=(5,0))
        self.channel_var = tk.StringVar(value="-1")
        ttk.Entry(left_frame, textvariable=self.channel_var, width=10).grid(row=8, column=1, sticky="w", pady=(5,0))
        
        # NEW: Class Optimization Sliders
        ttk.Label(left_frame, text="--- Class Optimization ---", 
                 font=('Arial', 9, 'bold')).grid(row=9, column=0, columnspan=2, pady=(10,5), sticky="w")
        
        # Class 0 slider (-1 to 1)
        ttk.Label(left_frame, text="Class 0 weight (-1 to 1):").grid(row=10, column=0, sticky="w", pady=(5,0))
        self.class0_weight_var = tk.StringVar(value="0")
        class0_entry = ttk.Entry(left_frame, textvariable=self.class0_weight_var, width=10)
        class0_entry.grid(row=10, column=1, sticky="w", pady=(5,0))
        ttk.Label(left_frame, text="-1=minimize, 0=ignore, 1=maximize", 
                 font=('Arial', 8), foreground="gray").grid(row=11, column=0, columnspan=2, sticky="w")
        
        # Class 1 slider (-1 to 1)
        ttk.Label(left_frame, text="Class 1 weight (-1 to 1):").grid(row=12, column=0, sticky="w", pady=(5,0))
        self.class1_weight_var = tk.StringVar(value="0")
        class1_entry = ttk.Entry(left_frame, textvariable=self.class1_weight_var, width=10)
        class1_entry.grid(row=12, column=1, sticky="w", pady=(5,0))
        ttk.Label(left_frame, text="-1=minimize, 0=ignore, 1=maximize", 
                 font=('Arial', 8), foreground="gray").grid(row=13, column=0, columnspan=2, sticky="w")
        
        # Basic parameters
        ttk.Label(left_frame, text="--- Basic Parameters ---", 
                 font=('Arial', 9, 'bold')).grid(row=14, column=0, columnspan=2, pady=(10,5), sticky="w")
        
        ttk.Label(left_frame, text="Steps:").grid(row=15, column=0, sticky="w", pady=(5,0))
        self.steps_var = tk.StringVar(value="50")
        ttk.Entry(left_frame, textvariable=self.steps_var, width=10).grid(row=15, column=1, sticky="w", pady=(5,0))
        
        ttk.Label(left_frame, text="LR:").grid(row=16, column=0, sticky="w", pady=(5,0))
        self.lr_deepdream_var = tk.StringVar(value="0.05")
        ttk.Entry(left_frame, textvariable=self.lr_deepdream_var, width=10).grid(row=16, column=1, sticky="w", pady=(5,0))
        
        # Augmentation settings - with SCALE and BLUR!
        ttk.Label(left_frame, text="--- Augmentation Settings ---", 
                 font=('Arial', 9, 'bold')).grid(row=17, column=0, columnspan=2, pady=(10,5), sticky="w")
        
        ttk.Label(left_frame, text="Jitter:").grid(row=18, column=0, sticky="w")
        self.jitter_var = tk.DoubleVar(value=0.03)
        self.jitter_scale = ttk.Scale(left_frame, from_=0, to=0.1, orient=tk.HORIZONTAL,
                                           variable=self.jitter_var, length=150)
        self.jitter_scale.grid(row=18, column=1, sticky="w")
        
        ttk.Label(left_frame, text="Rotation:").grid(row=19, column=0, sticky="w", pady=(5,0))
        self.rotation_var = tk.DoubleVar(value=8.0)
        self.rotation_scale = ttk.Scale(left_frame, from_=0, to=30, orient=tk.HORIZONTAL,
                                             variable=self.rotation_var, length=150)
        self.rotation_scale.grid(row=19, column=1, sticky="w", pady=(5,0))
        
        # SCALE augmentation - NEW!
        ttk.Label(left_frame, text="Scale (±%):").grid(row=20, column=0, sticky="w", pady=(5,0))
        self.scale_var = tk.DoubleVar(value=10.0)
        self.scale_scale = ttk.Scale(left_frame, from_=0, to=30, orient=tk.HORIZONTAL,
                                          variable=self.scale_var, length=150)
        self.scale_scale.grid(row=20, column=1, sticky="w", pady=(5,0))
        
        # BLUR AUGMENTATION
        ttk.Label(left_frame, text="Blur Radius:").grid(row=21, column=0, sticky="w", pady=(5,0))
        self.blur_var = tk.DoubleVar(value=0.5)
        self.blur_scale = ttk.Scale(left_frame, from_=0, to=2, orient=tk.HORIZONTAL,
                                          variable=self.blur_var, length=150)
        self.blur_scale.grid(row=21, column=1, sticky="w", pady=(5,0))
        
        ttk.Label(left_frame, text="Aug Probability:").grid(row=22, column=0, sticky="w", pady=(5,0))
        self.aug_prob_var = tk.DoubleVar(value=0.5)
        self.aug_prob_scale = ttk.Scale(left_frame, from_=0, to=1, orient=tk.HORIZONTAL,
                                             variable=self.aug_prob_var, length=150)
        self.aug_prob_scale.grid(row=22, column=1, sticky="w", pady=(5,0))
        
        # Octave settings
        ttk.Label(left_frame, text="Octave Scale:").grid(row=23, column=0, sticky="w", pady=(5,0))
        self.octave_scale_var = tk.StringVar(value="1.2")
        ttk.Entry(left_frame, textvariable=self.octave_scale_var, width=10).grid(row=23, column=1, sticky="w", pady=(5,0))
        
        ttk.Label(left_frame, text="Octaves:").grid(row=24, column=0, sticky="w", pady=(5,0))
        self.octaves_var = tk.StringVar(value="2")
        ttk.Entry(left_frame, textvariable=self.octaves_var, width=10).grid(row=24, column=1, sticky="w", pady=(5,0))
        
        # Start button
        self.start_btn = ttk.Button(left_frame, text="Start Dreaming", 
                                   command=self.start_dreaming_thread, state="disabled")
        self.start_btn.grid(row=25, column=0, columnspan=2, pady=20)
        
        # Progress
        self.progress_deepdream = ttk.Progressbar(left_frame, length=200, mode='determinate')
        self.progress_deepdream.grid(row=26, column=0, columnspan=2, pady=5)
        
        # Status
        self.status_deepdream = ttk.Label(left_frame, text="Load image and train model first", foreground="red")
        self.status_deepdream.grid(row=27, column=0, columnspan=2, pady=5)
        
        # Image display
        right_frame = ttk.LabelFrame(self.deepdream_tab, text="DeepDream Results", padding=10)
        right_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        
        # Original image
        ttk.Label(right_frame, text="Original Image:").grid(row=0, column=0, sticky="w")
        self.original_canvas = tk.Canvas(right_frame, width=128, height=128, bg="gray")
        self.original_canvas.grid(row=1, column=0, pady=5)
        
        # DeepDream image
        ttk.Label(right_frame, text="DeepDream Image:").grid(row=0, column=1, sticky="w")
        self.deepdream_canvas = tk.Canvas(right_frame, width=128, height=128, bg="gray")
        self.deepdream_canvas.grid(row=1, column=1, pady=5)
        
        # Comparison canvas (side by side)
        ttk.Label(right_frame, text="Comparison:").grid(row=2, column=0, columnspan=2, sticky="w", pady=(10,0))
        self.comparison_canvas = tk.Canvas(right_frame, width=256, height=128, bg="gray")
        self.comparison_canvas.grid(row=3, column=0, columnspan=2, pady=5)
        
        # Save buttons
        self.save_btn = ttk.Button(right_frame, text="Save DeepDream", 
                                        command=self.save_deepdream_image, state="disabled")
        self.save_btn.grid(row=4, column=0, columnspan=2, pady=10)
        
        self.deepdream_tab.columnconfigure(0, weight=1)
        self.deepdream_tab.columnconfigure(1, weight=2)
        self.deepdream_tab.rowconfigure(0, weight=1)
    
    # ===== DEEPDREAM METHODS =====
    
    def load_input_image(self):
        file = filedialog.askopenfilename(
            title="Select image for DeepDream",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        if file:
            try:
                # Load image
                img = Image.open(file).convert('RGB')
                self.input_image = img.copy()
                
                # Display original - USE NEAREST NEIGHBOR FOR DISPLAY (CRISPY!)
                display_img = img.resize((128, 128), Image.Resampling.NEAREST)
                photo = ImageTk.PhotoImage(display_img)
                self.original_canvas.delete("all")
                self.original_canvas.create_image(64, 64, image=photo)
                self.original_canvas.image = photo
                
                # Update label
                self.path_label.config(text=os.path.basename(file)[:30] + "...")
                
                # Enable button if model is trained
                if self.model is not None:
                    self.start_btn.config(state="normal")
                    self.status_deepdream.config(text="Ready to dream", foreground="green")
                else:
                    self.status_deepdream.config(text="Train model first", foreground="red")
                
                print(f"DEBUG: Loaded image: {file}")
                
            except Exception as e:
                print(f"ERROR loading image: {e}")
                messagebox.showerror("Error", f"Failed to load image: {str(e)}")
    
    def start_dreaming_thread(self):
        if self.input_image is None:
            messagebox.showerror("Error", "No image loaded")
            return
        
        if self.model is None:
            messagebox.showerror("Error", "Model not trained yet")
            return
        
        print("=" * 60)
        print("DEBUG: Starting DeepDream thread")
        
        # Disable button during processing
        self.start_btn.config(state="disabled")
        self.deepdream_active = True
        
        # Get optimization mode
        use_layer = self.use_layer_var.get()
        
        # Get parameters
        layer_name = self.layer_var.get()
        layer_map = {"conv1": 0, "conv2": 1, "conv3": 2, "conv4": 3, "conv5": 4}
        layer_idx = layer_map[layer_name]
        
        # Get channel
        try:
            channel = int(self.channel_var.get())
        except:
            channel = -1
            
        # Get class weights - parse with validation
        class0_weight = 0.0
        class1_weight = 0.0
        
        try:
            class0_str = self.class0_weight_var.get().strip()
            if class0_str:  # Only parse if not empty
                class0_weight = float(class0_str)
                # Clamp to [-1, 1]
                class0_weight = max(-1.0, min(1.0, class0_weight))
        except ValueError:
            class0_weight = 0.0  # Default to 0 if invalid
            
        try:
            class1_str = self.class1_weight_var.get().strip()
            if class1_str:  # Only parse if not empty
                class1_weight = float(class1_str)
                # Clamp to [-1, 1]
                class1_weight = max(-1.0, min(1.0, class1_weight))
        except ValueError:
            class1_weight = 0.0  # Default to 0 if invalid
        
        # Get other parameters
        steps = int(self.steps_var.get())
        lr = float(self.lr_deepdream_var.get())
        octave_scale = float(self.octave_scale_var.get())
        octaves = int(self.octaves_var.get())
        
        # Get augmentation parameters
        jitter = self.jitter_var.get()
        rotation = self.rotation_var.get()
        scale = self.scale_var.get() / 100.0  # Convert % to decimal
        blur = self.blur_var.get()
        aug_prob = self.aug_prob_var.get()
        
        print(f"DEBUG: DeepDream parameters:")
        print(f"  - Kernel size: {self.kernel_size}x{self.kernel_size}")
        print(f"  - Use layer optimization: {use_layer}")
        print(f"  - Layer: {layer_name} (index: {layer_idx})")
        print(f"  - Channel: {channel}")
        print(f"  - Class 0 weight: {class0_weight} (0 = ignored)")
        print(f"  - Class 1 weight: {class1_weight} (0 = ignored)")
        print(f"  - Steps: {steps}")
        print(f"  - Learning rate: {lr}")
        print(f"  - Jitter: {jitter:.3f}")
        print(f"  - Rotation: {rotation:.1f}")
        print(f"  - Scale: ±{scale:.3f}")
        print(f"  - Blur: {blur:.3f}")
        print(f"  - Aug probability: {aug_prob:.2f}")
        print(f"  - Octave scale: {octave_scale}")
        print(f"  - Octaves: {octaves}")
        
        # Validate at least one optimization is active
        if not use_layer and class0_weight == 0 and class1_weight == 0:
            messagebox.showerror("Error", "At least one optimization must be active!")
            self.start_btn.config(state="normal")
            return
        
        # Start in separate thread
        thread = threading.Thread(target=self.run_deepdream, 
                                 args=(use_layer, layer_idx, channel, 
                                       class0_weight, class1_weight,
                                       steps, lr, 
                                       jitter, rotation, scale, blur, aug_prob,
                                       octave_scale, octaves))
        thread.daemon = True
        thread.start()
    
    def apply_augmentations(self, image_tensor, jitter, rotation, scale, blur, probability=0.5):
        """Apply augmentations during DeepDream with SCALE and BLUR!"""
        if random.random() > probability:
            return image_tensor
        
        batch_size = image_tensor.shape[0]
        augmented = image_tensor.clone()
        
        # Apply jitter (translation)
        if jitter > 0:
            max_jitter_x = int(image_tensor.shape[3] * jitter)
            max_jitter_y = int(image_tensor.shape[2] * jitter)
            
            if max_jitter_x > 0 and max_jitter_y > 0:
                jitter_x = random.randint(-max_jitter_x, max_jitter_x)
                jitter_y = random.randint(-max_jitter_y, max_jitter_y)
                
                theta = torch.zeros(batch_size, 2, 3)
                theta[:, 0, 0] = 1
                theta[:, 1, 1] = 1
                theta[:, 0, 2] = jitter_x / (image_tensor.shape[3] / 2)
                theta[:, 1, 2] = jitter_y / (image_tensor.shape[2] / 2)
                
                grid = torch.nn.functional.affine_grid(theta, image_tensor.size(), align_corners=False)
                augmented = torch.nn.functional.grid_sample(augmented, grid, 
                                                           mode='bilinear', 
                                                           padding_mode='reflection',
                                                           align_corners=False)
        
        # Apply rotation
        if rotation > 0:
            angle = random.uniform(-rotation, rotation) * (3.14159 / 180)
            
            cos_a = torch.cos(torch.tensor(angle))
            sin_a = torch.sin(torch.tensor(angle))
            
            theta = torch.zeros(batch_size, 2, 3)
            theta[:, 0, 0] = cos_a
            theta[:, 0, 1] = -sin_a
            theta[:, 1, 0] = sin_a
            theta[:, 1, 1] = cos_a
            
            grid = torch.nn.functional.affine_grid(theta, augmented.size(), align_corners=False)
            augmented = torch.nn.functional.grid_sample(augmented, grid, 
                                                       mode='bilinear', 
                                                       padding_mode='reflection',
                                                       align_corners=False)
        
        # Apply random scaling - NEW!
        if scale > 0 and random.random() < 0.3:
            # Random scale between (1-scale) and (1+scale)
            random_scale = 1.0 + random.uniform(-scale, scale)
            
            theta = torch.zeros(batch_size, 2, 3)
            theta[:, 0, 0] = random_scale
            theta[:, 1, 1] = random_scale
            
            grid = torch.nn.functional.affine_grid(theta, augmented.size(), align_corners=False)
            augmented = torch.nn.functional.grid_sample(augmented, grid, 
                                                       mode='bilinear', 
                                                       padding_mode='reflection',
                                                       align_corners=False)
        
        # Apply blur
        if blur > 0 and random.random() < 0.4:
            # Create simple blur kernel
            kernel_size = max(3, int(blur * 2) + 1)
            if kernel_size % 2 == 0:
                kernel_size += 1
            
            # Create kernel for each channel
            kernel = torch.ones(3, 1, kernel_size, kernel_size) / (kernel_size * kernel_size)
            
            # Apply convolution with groups=3 to process each channel independently
            padding = kernel_size // 2
            
            # Move kernel to same device as input
            kernel = kernel.to(augmented.device)
            
            # Apply convolution
            blurred = torch.nn.functional.conv2d(
                augmented, 
                kernel, 
                padding=padding,
                groups=3
            )
            
            augmented = blurred
        
        return augmented
    
    def run_deepdream(self, use_layer, layer_idx, channel, 
                     class0_weight, class1_weight,
                     steps, lr, 
                     jitter, rotation, scale, blur, aug_prob,
                     octave_scale, octaves):
        try:
            print(f"DEBUG: Starting DeepDream")
            print(f"  Kernel size: {self.kernel_size}x{self.kernel_size}")
            print(f"  Layer opt: {use_layer}, Class0: {class0_weight}, Class1: {class1_weight}")
            
            # Convert PIL image to tensor
            img = self.input_image.copy()
            
            # Resize to model input size (64x64) - use intelligent resizing
            width, height = img.size
            if width < 64 or height < 64:
                # Upscale with NEAREST for crispy pixels
                img = img.resize((64, 64), Image.Resampling.NEAREST)
                print(f"UPSCALING input: {width}x{height} -> 64x64 (NEAREST)")
            else:
                # Downscale with LANCZOS for quality
                img = img.resize((64, 64), Image.Resampling.LANCZOS)
                print(f"DOWNSCALING input: {width}x{height} -> 64x64 (LANCZOS)")
            
            # Convert to tensor
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            
            img_tensor = transform(img).unsqueeze(0)
            print(f"DEBUG: Input tensor shape: {img_tensor.shape}")
            
            # Store original image for display
            original_tensor = img_tensor.clone()
            
            # Add some noise to the input for better optimization
            noise = torch.randn_like(img_tensor) * 0.01
            processed = img_tensor.clone() + noise
            processed.requires_grad = True
            
            # Multi-scale processing (octaves)
            for octave in range(octaves):
                print(f"DEBUG: Processing octave {octave + 1}/{octaves}")
                
                if octave > 0:
                    # Upscale the image for this octave
                    new_size = int(64 * (octave_scale ** octave))
                    processed_np = self.tensor_to_image(processed)
                    processed_pil = Image.fromarray(processed_np)
                    # Use NEAREST for upscaling (crispy!)
                    processed_pil = processed_pil.resize((new_size, new_size), Image.Resampling.NEAREST)
                    
                    # Convert back to tensor
                    processed = transform(processed_pil).unsqueeze(0)
                    # Add fresh noise
                    noise = torch.randn_like(processed) * 0.01
                    processed = processed + noise
                    processed.requires_grad = True
                
                # Gradient ascent for this octave
                optimizer = optim.Adam([processed], lr=lr)
                
                for step in range(steps):
                    try:
                        if step % 10 == 0:
                            print(f"DEBUG: Octave {octave + 1}, Step {step}/{steps}")
                        
                        optimizer.zero_grad()
                        
                        # Apply augmentations
                        augmented = self.apply_augmentations(
                            processed, jitter, rotation, scale, blur, aug_prob
                        )
                        
                        # Initialize loss
                        loss = 0
                        loss_components = []
                        
                        # Layer optimization (if enabled)
                        if use_layer:
                            # Get activations from the chosen layer
                            activations = self.model.get_activations(augmented, layer_idx)
                            
                            # Print shape for debugging
                            if step == 0:
                                print(f"DEBUG: Layer {layer_idx} activations shape: {activations.shape}")
                            
                            if channel == -1:
                                # Maximize all channels (L2 norm)
                                layer_loss = -activations.norm()
                            else:
                                # Maximize specific channel
                                if channel >= activations.shape[1]:
                                    channel = activations.shape[1] - 1
                                    print(f"WARNING: Channel adjusted to {channel}")
                                # Use mean instead of norm for single channel
                                layer_loss = -activations[0, channel].mean()
                            
                            loss += layer_loss
                            loss_components.append(f"Layer: {layer_loss.item():.4f}")
                        
                        # Class optimization (if weight != 0)
                        if class0_weight != 0 or class1_weight != 0:
                            # Get pre-classifier features (the layer before final classification)
                            features = self.model.get_pre_classifier_features(augmented)
                            
                            if step == 0:
                                print(f"DEBUG: Pre-classifier features shape: {features.shape}")
                                print(f"DEBUG: FC2 weight shape: {self.model.fc2.weight.shape}")
                            
                            if class0_weight != 0:
                                # Get weights for class 0
                                class0_weights = self.model.fc2.weight[0:1, :]  # Shape: [1, 512]
                                
                                # Calculate activation for class 0
                                class0_activation = torch.matmul(features, class0_weights.t()).mean()
                                
                                # Apply weight (negative weight = minimize, positive = maximize)
                                class0_loss = -class0_activation * class0_weight
                                
                                loss += class0_loss
                                loss_components.append(f"Class0({class0_weight}): {class0_loss.item():.4f}")
                            
                            if class1_weight != 0:
                                # Get weights for class 1
                                class1_weights = self.model.fc2.weight[1:2, :]  # Shape: [1, 512]
                                
                                # Calculate activation for class 1
                                class1_activation = torch.matmul(features, class1_weights.t()).mean()
                                
                                # Apply weight (negative weight = minimize, positive = maximize)
                                class1_loss = -class1_activation * class1_weight
                                
                                loss += class1_loss
                                loss_components.append(f"Class1({class1_weight}): {class1_loss.item():.4f}")
                        
                        # Add regularization to prevent graying out
                        loss += 0.001 * torch.norm(processed)
                        
                        # Total variation regularization for smoothness
                        tv_loss = torch.sum(torch.abs(processed[:, :, :, :-1] - processed[:, :, :, 1:])) + \
                                 torch.sum(torch.abs(processed[:, :, :-1, :] - processed[:, :, 1:, :]))
                        loss += 0.0001 * tv_loss  # Smaller TV loss to preserve detail
                        
                        # Add color preservation term - encourages color variation
                        color_loss = -torch.std(processed) * 0.01
                        loss += color_loss
                        
                        # Backward
                        loss.backward()
                        
                        # Gradient clipping
                        torch.nn.utils.clip_grad_norm_([processed], 0.5)
                        
                        optimizer.step()
                        
                        # Clamp values to prevent explosion
                        with torch.no_grad():
                            processed.data = torch.clamp(processed.data, -1.5, 1.5)
                        
                        # Update progress
                        progress_value = ((octave * steps + step + 1) / (octaves * steps)) * 100
                        self.root.after(0, self.progress_deepdream.config, {"value": progress_value})
                        
                        # Update display every 10 steps
                        if step % 10 == 0:
                            self.root.after(0, self.update_deepdream_display, original_tensor, processed.detach())
                        
                        # Update status with loss components
                        if step % 20 == 0:
                            loss_str = " + ".join(loss_components) if loss_components else "No active optimization"
                            self.root.after(0, lambda: self.status_deepdream.config(
                                text=f"Octave {octave + 1}, Step {step}/{steps}\n{loss_str}",
                                foreground="blue"))
                        
                        time.sleep(0.01)
                        
                    except Exception as e:
                        print(f"ERROR in step {step}: {e}")
                        print(traceback.format_exc())
                        continue
            
            # Final update
            print("DEBUG: DeepDream completed")
            self.root.after(0, self.update_deepdream_display, original_tensor, processed.detach())
            self.root.after(0, self.deepdream_complete, processed.detach())
            
        except Exception as e:
            error_msg = f"DeepDream error: {str(e)}\n{traceback.format_exc()}"
            print(f"ERROR: {error_msg}")
            self.root.after(0, lambda: messagebox.showerror("DeepDream Error", str(e)))
            self.root.after(0, self.reset_deepdream_button)
    
    def tensor_to_image(self, tensor):
        """Convert tensor to numpy image"""
        img_tensor = tensor.squeeze(0)
        img_tensor = img_tensor * 0.5 + 0.5  # Denormalize
        img_tensor = torch.clamp(img_tensor, 0, 1)
        img_np = img_tensor.permute(1, 2, 0).detach().numpy()
        img_np = (img_np * 255).astype(np.uint8)
        return img_np
    
    def update_deepdream_display(self, original, processed):
        try:
            # Convert tensors to images
            original_np = self.tensor_to_image(original)
            processed_np = self.tensor_to_image(processed)
            
            # Create PIL images
            original_pil = Image.fromarray(original_np)
            processed_pil = Image.fromarray(processed_np)
            
            # Resize for display - USE NEAREST NEIGHBOR FOR CRISPY PIXELS!
            original_display = original_pil.resize((128, 128), Image.Resampling.NEAREST)
            processed_display = processed_pil.resize((128, 128), Image.Resampling.NEAREST)
            
            # Convert to PhotoImage
            original_photo = ImageTk.PhotoImage(original_display)
            processed_photo = ImageTk.PhotoImage(processed_display)
            
            # Update canvases
            self.original_canvas.delete("all")
            self.original_canvas.create_image(64, 64, image=original_photo)
            self.original_canvas.image = original_photo
            
            self.deepdream_canvas.delete("all")
            self.deepdream_canvas.create_image(64, 64, image=processed_photo)
            self.deepdream_canvas.image = processed_photo
            
            # Create comparison image (side by side) - also use NEAREST!
            comparison = Image.new('RGB', (256, 128))
            comparison.paste(original_display, (0, 0))
            comparison.paste(processed_display, (128, 0))
            
            comparison_photo = ImageTk.PhotoImage(comparison)
            self.comparison_canvas.delete("all")
            self.comparison_canvas.create_image(128, 64, image=comparison_photo)
            self.comparison_canvas.image = comparison_photo
            
        except Exception as e:
            print(f"ERROR updating display: {e}")
            print(traceback.format_exc())
    
    def deepdream_complete(self, processed_tensor):
        try:
            self.start_btn.config(state="normal")
            self.progress_deepdream.config(value=0)
            self.save_btn.config(state="normal")
            self.status_deepdream.config(text="DeepDream Complete!", foreground="green")
            
            # Store the final image
            self.final_processed = processed_tensor
            
            print("DEBUG: DeepDream complete")
            
        except Exception as e:
            print(f"ERROR in deepdream_complete: {e}")
    
    def reset_deepdream_button(self):
        try:
            self.start_btn.config(state="normal")
            self.deepdream_active = False
        except Exception as e:
            print(f"ERROR in reset_deepdream_button: {e}")
    
    def save_deepdream_image(self):
        if hasattr(self, 'final_processed') and self.final_processed is not None:
            try:
                file = filedialog.asksaveasfilename(
                    defaultextension=".png",
                    filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg"), ("All files", "*.*")]
                )
                
                if file:
                    # Convert tensor to image
                    img_np = self.tensor_to_image(self.final_processed)
                    img_pil = Image.fromarray(img_np)
                    
                    # Upscale before saving for better quality
                    img_pil = img_pil.resize((256, 256), Image.Resampling.LANCZOS)
                    
                    # Save
                    img_pil.save(file, quality=95)
                    print(f"DEBUG: Saved DeepDream image to {file}")
                    messagebox.showinfo("Success", f"Image saved to {file}")
                    
            except Exception as e:
                print(f"ERROR saving image: {e}")
                messagebox.showerror("Error", f"Failed to save image: {str(e)}")
    
    # ===== ORIGINAL METHODS =====
    
    def add_images(self, class_idx):
        files = filedialog.askopenfilenames(
            title=f"Select images for Class {class_idx}",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        if files:
            for file in files:
                if class_idx == 0:
                    self.class0_images.append(file)
                    self.class0_listbox.insert(tk.END, os.path.basename(file))
                else:
                    self.class1_images.append(file)
                    self.class1_listbox.insert(tk.END, os.path.basename(file))
            print(f"DEBUG: Added {len(files)} images to class {class_idx}")
            
            # Update button if model is trained
            if self.model is not None and self.input_image is not None:
                self.start_btn.config(state="normal")
    
    def clear_images(self, class_idx):
        if class_idx == 0:
            self.class0_images.clear()
            self.class0_listbox.delete(0, tk.END)
        else:
            self.class1_images.clear()
            self.class1_listbox.delete(0, tk.END)
        print(f"DEBUG: Cleared class {class_idx} images")
    
    def start_training_thread(self):
        print("=" * 60)
        print("DEBUG: Starting training thread")
        if len(self.class0_images) < 2 or len(self.class1_images) < 2:
            error_msg = f"Need at least 2 images for each class! Current: Class0={len(self.class0_images)}, Class1={len(self.class1_images)}"
            print(f"ERROR: {error_msg}")
            messagebox.showerror("Error", error_msg)
            return
        
        # Disable button during training
        self.train_btn.config(state="disabled")
        self.start_btn.config(state="disabled")
        self.training = True
        
        # Get selected kernel size
        try:
            self.kernel_size = int(self.kernel_var.get())
            print(f"DEBUG: Selected kernel size: {self.kernel_size}x{self.kernel_size}")
            
            # Update kernel labels
            kernel_text = f"{self.kernel_size}x{self.kernel_size}"
            self.root.after(0, self.kernel_label.config, {"text": kernel_text})
            self.root.after(0, self.kernel_info_label.config, {"text": kernel_text})
        except:
            self.kernel_size = 3  # Default fallback
        
        # Start training in separate thread
        thread = threading.Thread(target=self.train_model)
        thread.daemon = True
        thread.start()
    
    def train_model(self):
        try:
            print("DEBUG: Starting model training...")
            print(f"DEBUG: Using kernel size: {self.kernel_size}x{self.kernel_size}")
            
            # Create dataset and dataloader
            dataset = UserImageDataset(self.class0_images, self.class1_images)
            
            print(f"DEBUG: Dataset created with {len(dataset)} images")
            
            if len(dataset) == 0:
                error_msg = "No valid images loaded! Check file formats."
                print(f"ERROR: {error_msg}")
                self.root.after(0, lambda: messagebox.showerror("Error", error_msg))
                return
            
            batch_size = int(self.batch_size_var.get())
            dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=0)
            
            # Initialize model with selected kernel size
            self.model = SimpleCNN(num_classes=2, kernel_size=self.kernel_size)
            print(f"DEBUG: Model initialized with {self.kernel_size}x{self.kernel_size} kernels")
            print(f"DEBUG: Model parameters: {sum(p.numel() for p in self.model.parameters()):,}")
            
            criterion = nn.CrossEntropyLoss()
            optimizer = optim.Adam(self.model.parameters(), lr=float(self.lr_var.get()))
            
            total_epochs = int(self.epochs_var.get())
            self.total_epochs = total_epochs
            
            print(f"DEBUG: Training for {total_epochs} epochs, batch size {batch_size}, lr {float(self.lr_var.get())}")
            
            # Training loop
            for epoch in range(total_epochs):
                self.current_epoch = epoch + 1
                running_loss = 0.0
                correct = 0
                total = 0
                
                for batch_idx, (inputs, labels) in enumerate(dataloader):
                    optimizer.zero_grad()
                    outputs = self.model(inputs)
                    loss = criterion(outputs, labels)
                    loss.backward()
                    optimizer.step()
                    
                    running_loss += loss.item()
                    
                    # Calculate accuracy
                    _, predicted = torch.max(outputs.data, 1)
                    total += labels.size(0)
                    correct += (predicted == labels).sum().item()
                
                avg_loss = running_loss / len(dataloader)
                accuracy = 100 * correct / total
                
                print(f"DEBUG: Epoch {epoch+1}/{total_epochs}, Loss: {avg_loss:.4f}, Accuracy: {accuracy:.1f}%")
                
                # Update GUI
                self.root.after(0, self.update_training_display, 
                              epoch + 1, avg_loss, accuracy)
                
                # Update progress bar
                progress_value = (epoch + 1) / total_epochs * 100
                self.root.after(0, self.progress.config, {"value": progress_value})
                
                time.sleep(0.1)
            
            # Training complete
            print("DEBUG: Training completed successfully")
            self.root.after(0, self.training_complete)
            
        except Exception as e:
            error_msg = f"Training error: {str(e)}\n{traceback.format_exc()}"
            print(f"ERROR: {error_msg}")
            self.root.after(0, lambda: messagebox.showerror("Training Error", str(e)))
            self.root.after(0, self.reset_training_buttons)
    
    def update_training_display(self, epoch, loss, accuracy):
        try:
            self.loss_label.config(text=f"{loss:.4f}")
            self.acc_label.config(text=f"{accuracy:.1f}%")
            self.epoch_label.config(text=f"{epoch}/{self.total_epochs}")
            self.status_label.config(text=f"Training Epoch {epoch}", foreground="green")
            
        except Exception as e:
            print(f"ERROR in update_training_display: {e}")
    
    def training_complete(self):
        try:
            self.train_btn.config(state="normal")
            if self.input_image is not None:
                self.start_btn.config(state="normal")
            self.status_label.config(text="Training Complete!", foreground="green")
            self.status_deepdream.config(text="Ready to dream", foreground="green")
            print("DEBUG: Training complete, all buttons re-enabled")
        except Exception as e:
            print(f"ERROR in training_complete: {e}")
    
    def reset_training_buttons(self):
        try:
            self.train_btn.config(state="normal")
            self.training = False
        except Exception as e:
            print(f"ERROR in reset_training_buttons: {e}")

def main():
    try:
        print("=" * 60)
        print("Starting CNN Training with Kernel Size Testing...")
        print("=" * 60)
        
        root = tk.Tk()
        app = CNNTrainingApp(root)
        
        def on_closing():
            print("Application closing...")
            root.destroy()
        
        root.protocol("WM_DELETE_WINDOW", on_closing)
        root.mainloop()
        
    except Exception as e:
        print(f"FATAL ERROR: {str(e)}\n{traceback.format_exc()}")

if __name__ == "__main__":
    main()