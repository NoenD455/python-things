import tkinter as tk
from tkinter import filedialog, ttk, messagebox
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import librosa
import soundfile as sf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import traceback
import sys
import io
import warnings
warnings.filterwarnings('ignore')

# ============================================================================
# CONSTANTS - Match the video specs
# ============================================================================
SAMPLE_RATE = 8000           # Changed to 8000Hz (SimpleAudio compatible!)
BIT_DEPTH = 8                # 8-bit audio
SEGMENT_LENGTH = int(1.5 * SAMPLE_RATE)  # 1.5 seconds = 12000 samples
SEGMENTS_PER_FILE = 100      # Max segments per file for memory

# ============================================================================
# AUDIO PROCESSOR - Direct audio handling, no spectrograms
# ============================================================================
class AudioProcessor:
    def __init__(self, sr=SAMPLE_RATE):
        self.sr = sr
        self.segment_length = SEGMENT_LENGTH
        
    def load_audio(self, file_path, max_segments=SEGMENTS_PER_FILE):
        """Load audio and split into segments of raw 8-bit samples"""
        try:
            # Load with target sample rate - resample if needed
            audio, original_sr = librosa.load(file_path, sr=None, mono=True)
            
            # Resample to our target rate if needed
            if original_sr != self.sr:
                audio = librosa.resample(audio, orig_sr=original_sr, target_sr=self.sr)
            
            # Normalize to prevent clipping
            if np.max(np.abs(audio)) > 0:
                audio = audio / np.max(np.abs(audio)) * 0.9
            
            # Apply simple fade in/out to prevent clicks
            fade_samples = min(100, len(audio) // 10)
            if fade_samples > 0:
                fade_in = np.linspace(0, 1, fade_samples)
                fade_out = np.linspace(1, 0, fade_samples)
                audio[:fade_samples] *= fade_in
                audio[-fade_samples:] *= fade_out
            
            # Convert to 8-bit [-1, 1] -> [0, 255]
            audio = np.clip(audio, -1, 1)
            audio_8bit = ((audio + 1) / 2 * 255).astype(np.uint8)
            
            # Split into segments
            num_segments = len(audio_8bit) // self.segment_length
            if num_segments == 0:
                num_segments = 1
                
            if max_segments and num_segments > max_segments:
                num_segments = max_segments
            
            segments = []
            segment_positions = []
            
            for i in range(num_segments):
                start = i * self.segment_length
                end = start + self.segment_length
                
                if end > len(audio_8bit):
                    # Pad last segment with fade out
                    segment = np.zeros(self.segment_length, dtype=np.uint8)
                    available = len(audio_8bit) - start
                    segment[:available] = audio_8bit[start:start+available]
                    # Apply fade out to padded part
                    if available > 0:
                        fade_start = max(0, available - 100)
                        fade_len = available - fade_start
                        fade_out = np.linspace(1, 0, fade_len)
                        segment[fade_start:available] = segment[fade_start:available].astype(np.float32) * fade_out
                        segment[fade_start:available] = segment[fade_start:available].astype(np.uint8)
                else:
                    segment = audio_8bit[start:end]
                
                segments.append(segment)
                segment_positions.append((start, end))
            
            return segments, segment_positions, audio_8bit
            
        except Exception as e:
            print(f"Error loading {file_path}: {str(e)}")
            return [], [], np.zeros(self.segment_length, dtype=np.uint8)
    
    def segments_to_tensor(self, segments):
        """Convert list of 8-bit segments to normalized tensor"""
        # Convert to float and normalize to [-1, 1]
        segments_float = [seg.astype(np.float32) / 127.5 - 1.0 for seg in segments]
        # Stack and add sequence dimension
        tensor = torch.FloatTensor(np.stack(segments_float)).unsqueeze(-1)  # [batch, seq_len, 1]
        return tensor
    
    def tensor_to_audio(self, tensor):
        """Convert model output tensor back to 8-bit audio with click prevention"""
        # tensor shape: [batch, seq_len, 1] or [seq_len, 1]
        if len(tensor.shape) == 3:
            tensor = tensor.squeeze(-1)  # Remove last dim
        elif len(tensor.shape) == 2:
            # Already correct shape
            pass
        
        # Convert to numpy and denormalize
        audio_norm = tensor.detach().cpu().numpy()
        audio_8bit = ((audio_norm + 1) * 127.5).clip(0, 255).astype(np.uint8)
        
        # Apply fade in/out to prevent clicks
        if len(audio_8bit) > 200:
            fade_samples = min(100, len(audio_8bit) // 10)
            fade_in = np.linspace(0, 1, fade_samples)
            fade_out = np.linspace(1, 0, fade_samples)
            audio_8bit = audio_8bit.astype(np.float32)
            audio_8bit[:fade_samples] *= fade_in
            audio_8bit[-fade_samples:] *= fade_out
            audio_8bit = audio_8bit.astype(np.uint8)
        
        return audio_8bit
    
    def save_audio(self, audio_8bit, filename):
        """Save 8-bit audio to WAV file"""
        try:
            # Convert back to float
            audio_float = (audio_8bit.astype(np.float32) / 127.5) - 1.0
            
            # Save at our sample rate
            sf.write(filename, audio_float, self.sr, subtype='PCM_16')
            
        except Exception as e:
            print(f"Error saving audio: {str(e)}")
            raise
    
    def play_audio(self, audio_8bit):
        """Play audio using simpleaudio"""
        try:
            import simpleaudio as sa
            
            # Convert to float first
            audio_float = (audio_8bit.astype(np.float32) / 127.5) - 1.0
            
            # Apply additional fade in/out for playback
            if len(audio_float) > 200:
                fade_samples = min(200, len(audio_float) // 20)
                fade_in = np.linspace(0, 1, fade_samples)
                fade_out = np.linspace(1, 0, fade_samples)
                audio_float[:fade_samples] *= fade_in
                audio_float[-fade_samples:] *= fade_out
            
            # Convert to 16-bit for playback
            audio_16bit = (audio_float * 32767).astype(np.int16)
            
            # Start playback
            play_obj = sa.play_buffer(audio_16bit, 1, 2, self.sr)
            return play_obj
            
        except ImportError:
            # Fallback: save and play with system
            temp_file = "temp_playback.wav"
            self.save_audio(audio_8bit, temp_file)
            if os.name == 'nt':
                os.system(f'start wmplayer "{temp_file}"')
            elif sys.platform == 'darwin':
                os.system(f'afplay "{temp_file}"')
            else:
                os.system(f'aplay "{temp_file}" 2>/dev/null || play "{temp_file}" 2>/dev/null')
            return None
        except Exception as e:
            print(f"Playback error: {str(e)}")
            return None

# ============================================================================
# RNN/LSTM MODEL - Direct audio prediction
# ============================================================================
class AudioRNN(nn.Module):
    def __init__(self, input_size=1, hidden_size=256, num_layers=2, dropout=0.2):
        """
        LSTM model - reduced from 680 to 256 for CPU training
        """
        super().__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        # LSTM layers
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0,
            bidirectional=False
        )
        
        # Output layer - predict next sample
        self.fc = nn.Sequential(
            nn.Linear(hidden_size, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1),
            nn.Tanh()  # Output in [-1, 1] range
        )
        
    def forward(self, x, hidden=None):
        """
        x: [batch, seq_len, 1] or [seq_len, 1]
        Returns: predicted next samples [batch, seq_len, 1]
        """
        # Forward through LSTM
        lstm_out, hidden = self.lstm(x, hidden)
        
        # Predict next samples
        output = self.fc(lstm_out)
        
        return output, hidden
    
    def init_hidden(self, batch_size=1):
        """Initialize hidden state"""
        return (torch.zeros(self.num_layers, batch_size, self.hidden_size),
                torch.zeros(self.num_layers, batch_size, self.hidden_size))

# ============================================================================
# TRAINER - Teacher forcing training
# ============================================================================
class AudioRNNTrainer:
    def __init__(self, model, learning_rate=0.001, teacher_forcing_ratio=0.5):
        self.model = model
        self.criterion = nn.MSELoss()  # Mean squared error for audio
        self.optimizer = optim.Adam(model.parameters(), lr=learning_rate)
        self.teacher_forcing_ratio = teacher_forcing_ratio
        self.device = torch.device("cpu")
        self.model.to(self.device)
        
    def train_epoch(self, dataloader, seq_len=200):
        """Train for one epoch with teacher forcing"""
        self.model.train()
        total_loss = 0
        batch_count = 0
        
        for batch_idx, batch in enumerate(dataloader):
            # batch shape: [batch_size, segment_length, 1]
            batch = batch.to(self.device)
            batch_size = batch.size(0)
            
            # Initialize hidden state
            hidden = self.model.init_hidden(batch_size)
            
            # Train with sequences within each segment
            segment_loss = 0
            seq_count = 0
            
            # Process each sequence in the segment
            for start in range(0, SEGMENT_LENGTH - seq_len, seq_len // 4):
                end = start + seq_len
                if end > SEGMENT_LENGTH:
                    break
                    
                # Input: current sequence
                # Target: next sequence (shifted by 1)
                input_seq = batch[:, start:end, :]
                target_seq = batch[:, start+1:end+1, :]
                
                # Forward pass
                self.optimizer.zero_grad()
                output, hidden = self.model(input_seq, hidden)
                
                # Detach hidden state to prevent backprop through entire segment
                hidden = tuple(h.detach() for h in hidden)
                
                # Calculate loss
                loss = self.criterion(output, target_seq)
                loss.backward()
                
                # Gradient clipping
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 0.5)
                self.optimizer.step()
                
                segment_loss += loss.item()
                seq_count += 1
            
            if seq_count > 0:
                total_loss += segment_loss / seq_count
                batch_count += 1
        
        return total_loss / batch_count if batch_count > 0 else 0
    
    def generate(self, seed_seq, length=SEGMENT_LENGTH, temperature=1.0):
        """Generate audio from seed sequence - FIXED DIMENSIONS"""
        self.model.eval()
        with torch.no_grad():
            # Ensure seed_seq has correct dimensions: [1, seq_len, 1]
            if len(seed_seq.shape) == 1:
                # [seq_len] -> [1, seq_len, 1]
                seed_seq = seed_seq.unsqueeze(0).unsqueeze(-1)
            elif len(seed_seq.shape) == 2:
                # [batch, seq_len] or [seq_len, 1]
                if seed_seq.shape[0] == seed_seq.shape[1]:
                    # Probably [seq_len, 1] -> [1, seq_len, 1]
                    seed_seq = seed_seq.unsqueeze(0)
                else:
                    # [batch, seq_len] -> [batch, seq_len, 1]
                    seed_seq = seed_seq.unsqueeze(-1)
            
            seed_seq = seed_seq.to(self.device)
            
            generated = seed_seq.clone()
            hidden = self.model.init_hidden(seed_seq.size(0))
            
            # Process seed to get initial hidden state
            _, hidden = self.model(seed_seq, hidden)
            
            # Generate new samples
            last_sample = seed_seq[:, -1:, :]
            
            for i in range(length - seed_seq.size(1)):
                # Predict next sample
                output, hidden = self.model(last_sample, hidden)
                
                # Apply temperature
                if temperature != 1.0:
                    output = output / temperature
                
                # Add small noise for diversity
                noise = torch.randn_like(output) * 0.005
                next_sample = output + noise
                next_sample = torch.tanh(next_sample)  # Keep in [-1, 1]
                
                generated = torch.cat([generated, next_sample], dim=1)
                last_sample = next_sample
            
            # Return as [seq_len] for audio conversion
            return generated.squeeze()

# ============================================================================
# DATASET - Raw audio segments (NO Tkinter references!)
# ============================================================================
class AudioDataset(Dataset):
    def __init__(self, audio_paths, max_segments=SEGMENTS_PER_FILE):
        self.audio_paths = audio_paths
        self.audio_processor = AudioProcessor()
        self.segments = []
        
        print(f"Loading audio from {len(audio_paths)} files...")
        
        for audio_path in audio_paths:
            try:
                segments, _, _ = self.audio_processor.load_audio(audio_path, max_segments)
                if segments:
                    self.segments.extend(segments)
                    print(f"  {os.path.basename(audio_path)}: {len(segments)} segments")
            except Exception as e:
                print(f"Error loading {audio_path}: {e}")
        
        print(f"Total: {len(self.segments)} audio segments")
        
    def __len__(self):
        return len(self.segments)
    
    def __getitem__(self, idx):
        segment = self.segments[idx]
        # Convert to float tensor and normalize
        tensor = torch.FloatTensor(segment.astype(np.float32) / 127.5 - 1.0)
        return tensor.unsqueeze(-1)  # Add channel dim: [seq_len, 1]

# ============================================================================
# MAIN APPLICATION
# ============================================================================
class AudioRNNApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Audio RNN/LSTM Trainer - Direct Audio Prediction")
        self.root.geometry("1200x800")
        
        self.audio_paths = []
        self.training = False
        self.model = None
        self.trainer = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        self.current_audio = None
        self.generated_audio = None
        
        self.audio_processor = AudioProcessor()
        
        # Store loaded segments for preview
        self.loaded_segments = {}
        
        # Training settings
        self.settings = {
            'hidden_size': tk.IntVar(value=256),  # Reduced from 680
            'num_layers': tk.IntVar(value=2),     # Reduced from 3
            'learning_rate': tk.DoubleVar(value=0.001),
            'teacher_forcing': tk.DoubleVar(value=0.7),
            'batch_size': tk.IntVar(value=8),     # Increased for better training
            'sequence_length': tk.IntVar(value=200),
            'dropout': tk.DoubleVar(value=0.2),
            'temperature': tk.DoubleVar(value=1.0),
            'max_segments': tk.IntVar(value=SEGMENTS_PER_FILE),
        }
        
        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create main container
        main_container = tk.Frame(self.root)
        main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create notebook with tabs
        self.notebook = ttk.Notebook(main_container)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Create tabs
        self.training_tab = ttk.Frame(self.notebook)
        self.preview_tab = ttk.Frame(self.notebook)
        self.generate_tab = ttk.Frame(self.notebook)
        self.visualize_tab = ttk.Frame(self.notebook)
        
        self.notebook.add(self.training_tab, text='Training')
        self.notebook.add(self.preview_tab, text='Preview')
        self.notebook.add(self.generate_tab, text='Generate')
        self.notebook.add(self.visualize_tab, text='Visualize')
        
        self.setup_training_tab()
        self.setup_preview_tab()
        self.setup_generate_tab()
        self.setup_visualize_tab()
        
        # Status bar
        self.status_label = tk.Label(self.root, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_training_tab(self):
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_frame.pack_propagate(False)
        
        tk.Label(left_frame, text="Audio RNN Trainer", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Audio file management
        audio_frame = tk.LabelFrame(left_frame, text="Audio Files", padx=10, pady=10)
        audio_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(audio_frame, text="Add Audio Files", 
                 command=self.add_audio_files, width=20).pack(pady=5)
        tk.Button(audio_frame, text="Clear All", 
                 command=self.clear_audio, width=20).pack(pady=5)
        
        list_frame = tk.Frame(audio_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.audio_listbox = tk.Listbox(list_frame, height=8)
        scrollbar = tk.Scrollbar(list_frame)
        self.audio_listbox.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.audio_listbox.yview)
        
        self.audio_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        tk.Button(audio_frame, text="Preview Selected", 
                 command=self.preview_selected_audio, width=20).pack(pady=5)
        
        # Model controls
        model_frame = tk.LabelFrame(left_frame, text="Model Controls", padx=10, pady=10)
        model_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(model_frame, text="Initialize Model", 
                 command=self.initialize_model, width=20).pack(pady=5)
        
        # Model info
        info_frame = tk.Frame(model_frame)
        info_frame.pack(fill=tk.X, pady=5)
        tk.Label(info_frame, text="Layers:", anchor='w').pack(fill=tk.X)
        self.layers_label = tk.Label(info_frame, text="2", anchor='w')
        self.layers_label.pack(fill=tk.X)
        
        tk.Label(info_frame, text="Neurons/layer:", anchor='w').pack(fill=tk.X)
        self.neurons_label = tk.Label(info_frame, text="256", anchor='w')
        self.neurons_label.pack(fill=tk.X)
        
        tk.Label(info_frame, text="Sample rate:", anchor='w').pack(fill=tk.X)
        self.sr_label = tk.Label(info_frame, text="8000Hz", anchor='w')
        self.sr_label.pack(fill=tk.X)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(train_frame, text="Epochs:").pack(anchor='w')
        self.epoch_var = tk.StringVar(value="20")  # Reduced from 50
        tk.Entry(train_frame, textvariable=self.epoch_var, width=10).pack(pady=2, anchor='w')
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Stats
        stats_frame = tk.LabelFrame(left_frame, text="Statistics", padx=10, pady=10)
        stats_frame.pack(fill=tk.X)
        
        self.stats_label = tk.Label(stats_frame, text="Ready\nFiles: 0\nSegments: 0", 
                                   justify=tk.LEFT, anchor='w')
        self.stats_label.pack(fill=tk.X)
        
        # Right panel - Log and preview
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Audio waveform display
        wave_frame = tk.LabelFrame(right_frame, text="Generated Audio", padx=10, pady=10)
        wave_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.figure = Figure(figsize=(6, 2), dpi=100)
        self.wave_ax = self.figure.add_subplot(111)
        self.wave_ax.set_xlabel("Samples")
        self.wave_ax.set_ylabel("Amplitude")
        self.wave_ax.grid(True, alpha=0.3)
        
        self.canvas = FigureCanvasTkAgg(self.figure, wave_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Audio controls
        audio_controls = tk.Frame(wave_frame)
        audio_controls.pack(pady=5)
        
        tk.Button(audio_controls, text="Play", 
                 command=self.play_generated, width=10).pack(side=tk.LEFT, padx=5)
        tk.Button(audio_controls, text="Stop", 
                 command=self.stop_audio, width=10).pack(side=tk.LEFT, padx=5)
        tk.Button(audio_controls, text="Save", 
                 command=self.save_generated, width=10).pack(side=tk.LEFT, padx=5)
        
        # Log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=10, font=("Courier", 9))
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_preview_tab(self):
        main_frame = tk.Frame(self.preview_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Audio Segment Preview", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # File selection
        file_frame = tk.LabelFrame(main_frame, text="Select File", padx=10, pady=10)
        file_frame.pack(fill=tk.X, pady=(0, 20))
        
        self.preview_file_var = tk.StringVar()
        self.preview_combo = ttk.Combobox(file_frame, textvariable=self.preview_file_var, 
                                         state="readonly", width=50)
        self.preview_combo.pack(side=tk.LEFT, padx=5)
        tk.Button(file_frame, text="Load", 
                 command=self.load_file_for_preview, width=10).pack(side=tk.LEFT, padx=5)
        
        # Segment navigation
        nav_frame = tk.LabelFrame(main_frame, text="Segment Navigation", padx=10, pady=10)
        nav_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(nav_frame, text="Segment:").pack(side=tk.LEFT, padx=5)
        self.segment_var = tk.IntVar(value=0)
        self.segment_spin = tk.Spinbox(nav_frame, from_=0, to=0, 
                                      textvariable=self.segment_var, width=10,
                                      command=self.update_preview_display)
        self.segment_spin.pack(side=tk.LEFT, padx=5)
        self.segment_total_label = tk.Label(nav_frame, text="of 0")
        self.segment_total_label.pack(side=tk.LEFT, padx=5)
        
        tk.Button(nav_frame, text="◀", 
                 command=self.prev_segment_preview, width=5).pack(side=tk.LEFT, padx=5)
        tk.Button(nav_frame, text="▶", 
                 command=self.next_segment_preview, width=5).pack(side=tk.LEFT, padx=5)
        
        # Waveform display
        display_frame = tk.LabelFrame(main_frame, text="Audio Waveform", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.preview_figure = Figure(figsize=(8, 3), dpi=100)
        self.preview_ax = self.preview_figure.add_subplot(111)
        self.preview_ax.set_xlabel("Samples")
        self.preview_ax.set_ylabel("Amplitude")
        self.preview_ax.grid(True, alpha=0.3)
        
        self.preview_canvas = FigureCanvasTkAgg(self.preview_figure, display_frame)
        self.preview_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Controls
        controls_frame = tk.Frame(display_frame)
        controls_frame.pack(pady=10)
        
        tk.Button(controls_frame, text="Play Segment", 
                 command=self.play_current_segment, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(controls_frame, text="Play Full", 
                 command=self.play_full_preview, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(controls_frame, text="Stop", 
                 command=self.stop_audio, width=10).pack(side=tk.LEFT, padx=5)

    def setup_generate_tab(self):
        main_frame = tk.Frame(self.generate_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Audio Generation", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Generation controls
        ctrl_frame = tk.LabelFrame(main_frame, text="Generation Controls", padx=10, pady=10)
        ctrl_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Seed selection
        seed_frame = tk.Frame(ctrl_frame)
        seed_frame.pack(fill=tk.X, pady=5)
        tk.Label(seed_frame, text="Seed from:").pack(side=tk.LEFT, padx=5)
        self.seed_var = tk.StringVar()
        self.seed_combo = ttk.Combobox(seed_frame, textvariable=self.seed_var, 
                                      state="readonly", width=30)
        self.seed_combo.pack(side=tk.LEFT, padx=5)
        tk.Button(seed_frame, text="Random Seed", 
                 command=self.use_random_seed, width=15).pack(side=tk.LEFT, padx=5)
        
        # Generation parameters
        param_frame = tk.Frame(ctrl_frame)
        param_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(param_frame, text="Length (seconds):").pack(side=tk.LEFT, padx=5)
        self.gen_length = tk.DoubleVar(value=1.5)
        tk.Scale(param_frame, from_=0.5, to=10.0, variable=self.gen_length,
                orient=tk.HORIZONTAL, length=200).pack(side=tk.LEFT, padx=5)
        tk.Label(param_frame, textvariable=self.gen_length).pack(side=tk.LEFT)
        
        param_frame2 = tk.Frame(ctrl_frame)
        param_frame2.pack(fill=tk.X, pady=5)
        
        tk.Label(param_frame2, text="Temperature:").pack(side=tk.LEFT, padx=5)
        self.gen_temp = tk.DoubleVar(value=1.0)
        tk.Scale(param_frame2, from_=0.1, to=2.0, variable=self.gen_temp,
                orient=tk.HORIZONTAL, length=150).pack(side=tk.LEFT, padx=5)
        tk.Label(param_frame2, textvariable=self.gen_temp).pack(side=tk.LEFT)
        
        # Generate button
        tk.Button(ctrl_frame, text="Generate Audio", 
                 command=self.generate_audio, width=20, bg="lightblue").pack(pady=10)
        
        # Generated audio display
        gen_frame = tk.LabelFrame(main_frame, text="Generated Audio", padx=10, pady=10)
        gen_frame.pack(fill=tk.BOTH, expand=True)
        
        self.gen_figure = Figure(figsize=(8, 3), dpi=100)
        self.gen_ax = self.gen_figure.add_subplot(111)
        self.gen_ax.set_xlabel("Samples")
        self.gen_ax.set_ylabel("Amplitude")
        self.gen_ax.grid(True, alpha=0.3)
        
        self.gen_canvas = FigureCanvasTkAgg(self.gen_figure, gen_frame)
        self.gen_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Playback controls
        play_frame = tk.Frame(gen_frame)
        play_frame.pack(pady=10)
        
        tk.Button(play_frame, text="Play", 
                 command=self.play_generated_tab, width=10).pack(side=tk.LEFT, padx=5)
        tk.Button(play_frame, text="Stop", 
                 command=self.stop_audio, width=10).pack(side=tk.LEFT, padx=5)
        tk.Button(play_frame, text="Save", 
                 command=self.save_generated_tab, width=10).pack(side=tk.LEFT, padx=5)

    def setup_visualize_tab(self):
        main_frame = tk.Frame(self.visualize_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Audio Visualization", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # Visualization controls
        vis_frame = tk.LabelFrame(main_frame, text="Visualization", padx=10, pady=10)
        vis_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Type selection
        type_frame = tk.Frame(vis_frame)
        type_frame.pack(fill=tk.X, pady=5)
        tk.Label(type_frame, text="Type:").pack(side=tk.LEFT, padx=5)
        
        self.vis_type = tk.StringVar(value="waveform")
        tk.Radiobutton(type_frame, text="Waveform", variable=self.vis_type,
                      value="waveform").pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(type_frame, text="Spectrogram", variable=self.vis_type,
                      value="spectrogram").pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(type_frame, text="Both", variable=self.vis_type,
                      value="both").pack(side=tk.LEFT, padx=5)
        
        # File selection
        file_frame = tk.Frame(vis_frame)
        file_frame.pack(fill=tk.X, pady=5)
        tk.Label(file_frame, text="Audio:").pack(side=tk.LEFT, padx=5)
        
        self.vis_file_var = tk.StringVar()
        self.vis_combo = ttk.Combobox(file_frame, textvariable=self.vis_file_var,
                                     state="readonly", width=40)
        self.vis_combo.pack(side=tk.LEFT, padx=5)
        tk.Button(file_frame, text="Update", 
                 command=self.update_visualization, width=10).pack(side=tk.LEFT, padx=5)
        
        # Visualization display
        display_frame = tk.LabelFrame(main_frame, text="Visualization", padx=10, pady=10)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        self.vis_figure = Figure(figsize=(8, 6), dpi=100)
        self.vis_canvas = FigureCanvasTkAgg(self.vis_figure, display_frame)
        self.vis_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    # ============================================================================
    # CORE FUNCTIONALITY
    # ============================================================================
    
    def add_audio_files(self):
        files = filedialog.askopenfilenames(
            title="Select audio files",
            filetypes=[
                ("Audio files", "*.wav *.mp3 *.ogg *.flac *.m4a"),
                ("All files", "*.*")
            ]
        )
        
        for file in files:
            if file not in self.audio_paths:
                self.audio_paths.append(file)
                self.audio_listbox.insert(tk.END, os.path.basename(file))
        
        self.update_combo_boxes()
        self.update_stats()
        self.log_message(f"Added {len(files)} audio files")
    
    def clear_audio(self):
        self.audio_paths = []
        self.audio_listbox.delete(0, tk.END)
        self.loaded_segments = {}
        self.update_combo_boxes()
        self.update_stats()
        self.log_message("Cleared all audio files")
    
    def update_combo_boxes(self):
        # Update all combo boxes with current file list
        files = [os.path.basename(p) for p in self.audio_paths]
        self.preview_combo['values'] = files
        self.seed_combo['values'] = files
        self.vis_combo['values'] = files
        
        if files:
            self.preview_combo.current(0)
            self.seed_combo.current(0)
            self.vis_combo.current(0)
    
    def update_stats(self):
        """Update statistics display"""
        if self.audio_paths:
            self.stats_label.config(
                text=f"Ready\nFiles: {len(self.audio_paths)}\nSegments: {len(self.loaded_segments) if self.loaded_segments else 0}"
            )
        else:
            self.stats_label.config(text="Ready\nFiles: 0\nSegments: 0")
    
    def initialize_model(self):
        try:
            hidden_size = self.settings['hidden_size'].get()
            num_layers = self.settings['num_layers'].get()
            dropout = self.settings['dropout'].get()
            
            self.model = AudioRNN(
                hidden_size=hidden_size,
                num_layers=num_layers,
                dropout=dropout
            )
            
            learning_rate = self.settings['learning_rate'].get()
            teacher_forcing = self.settings['teacher_forcing'].get()
            
            self.trainer = AudioRNNTrainer(
                self.model,
                learning_rate=learning_rate,
                teacher_forcing_ratio=teacher_forcing
            )
            
            # Update UI labels
            self.layers_label.config(text=str(num_layers))
            self.neurons_label.config(text=str(hidden_size))
            self.sr_label.config(text=f"{SAMPLE_RATE}Hz")
            
            self.log_message(f"Initialized RNN with {num_layers} layers of {hidden_size} neurons")
            self.log_message(f"Sample rate: {SAMPLE_RATE}Hz")
            self.log_message(f"Segment length: {SEGMENT_LENGTH} samples ({SEGMENT_LENGTH/SAMPLE_RATE:.1f}s)")
            
        except Exception as e:
            self.log_message(f"Error initializing model: {str(e)}")
    
    def start_training(self):
        if not self.audio_paths:
            self.log_message("Error: No audio files loaded!")
            return
        
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            
            thread = threading.Thread(
                target=self.train_model,
                args=(epochs,),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")
    
    def train_model(self, epochs):
        try:
            batch_size = self.settings['batch_size'].get()
            max_segments = self.settings['max_segments'].get()
            seq_len = self.settings['sequence_length'].get()
            
            self.log_message(f"Creating dataset...")
            
            # Create dataset - NO Tkinter callbacks!
            dataset = AudioDataset(self.audio_paths, max_segments)
            
            if len(dataset) == 0:
                self.log_message("Error: No audio segments loaded!")
                self.training = False
                return
            
            self.log_message(f"Dataset created with {len(dataset)} segments")
            
            # Use num_workers=0 to avoid multiprocessing pickle issues
            dataloader = DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=True,
                num_workers=0  # CRITICAL: No multiprocessing to avoid pickle errors
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                start_time = time.time()
                
                loss = self.trainer.train_epoch(dataloader, seq_len)
                epoch_time = time.time() - start_time
                
                self.log_message(f"Epoch {epoch+1}/{epochs} - Loss: {loss:.6f} - Time: {epoch_time:.1f}s")
                
                # Generate sample every 3 epochs
                if (epoch + 1) % 3 == 0:
                    self.generate_training_sample()
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
    
    def generate_training_sample(self):
        if not self.model or not self.audio_paths:
            return
        
        try:
            # Use first audio file as seed
            segments, _, _ = self.audio_processor.load_audio(self.audio_paths[0], max_segments=1)
            if not segments:
                return
            
            # Convert to tensor - CORRECT DIMENSIONS
            seed_audio = segments[0]
            seed_tensor = torch.FloatTensor(seed_audio[:500].astype(np.float32) / 127.5 - 1.0)
            seed_tensor = seed_tensor.unsqueeze(0).unsqueeze(-1)  # [1, 500, 1]
            
            # Generate
            with torch.no_grad():
                generated = self.trainer.generate(seed_tensor, length=SEGMENT_LENGTH)
                generated_audio = self.audio_processor.tensor_to_audio(generated)
            
            self.generated_audio = generated_audio
            
            # Update display
            self.update_waveform_display(generated_audio, self.wave_ax, self.canvas)
            self.log_message(f"Generated training sample at epoch {self.current_epoch + 1}")
            
        except Exception as e:
            self.log_message(f"Error generating sample: {str(e)}")
    
    def generate_audio(self):
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        try:
            seed_source = self.seed_var.get()
            length_samples = int(self.gen_length.get() * SAMPLE_RATE)
            temperature = self.gen_temp.get()
            
            self.log_message(f"Generating {length_samples/SAMPLE_RATE:.1f}s of audio...")
            
            seed_tensor = None
            
            if seed_source and seed_source != "Random":
                # Find the file
                for path in self.audio_paths:
                    if os.path.basename(path) == seed_source:
                        segments, _, _ = self.audio_processor.load_audio(path, max_segments=1)
                        if segments:
                            seed_audio = segments[0]
                            # Use first 250ms as seed
                            seed_len = min(int(0.25 * SAMPLE_RATE), len(seed_audio))
                            seed_tensor = torch.FloatTensor(
                                seed_audio[:seed_len].astype(np.float32) / 127.5 - 1.0
                            )
                            seed_tensor = seed_tensor.unsqueeze(0).unsqueeze(-1)  # [1, seed_len, 1]
                            self.log_message(f"Using {seed_len/SAMPLE_RATE:.2f}s seed from {seed_source}")
                            break
            else:
                # Random seed - random noise
                seed_len = 100
                seed_tensor = torch.randn(1, seed_len, 1) * 0.1
                self.log_message(f"Using random noise seed ({seed_len} samples)")
            
            if seed_tensor is None:
                seed_len = 100
                seed_tensor = torch.randn(1, seed_len, 1) * 0.1
                self.log_message(f"Using random noise seed ({seed_len} samples)")
            
            # Generate
            with torch.no_grad():
                generated = self.trainer.generate(seed_tensor, length=length_samples, temperature=temperature)
                generated_audio = self.audio_processor.tensor_to_audio(generated)
            
            self.generated_audio = generated_audio
            
            # Update display
            self.update_waveform_display(generated_audio, self.gen_ax, self.gen_canvas)
            self.log_message(f"Generated {length_samples} samples ({length_samples/SAMPLE_RATE:.1f}s) successfully")
            
        except Exception as e:
            self.log_message(f"Error generating audio: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def update_waveform_display(self, audio_8bit, ax, canvas):
        """Update waveform plot"""
        ax.clear()
        
        try:
            # Convert to float for plotting
            audio_float = (audio_8bit.astype(np.float32) / 127.5) - 1.0
            
            # Plot first 4000 samples or all if shorter
            plot_len = min(4000, len(audio_float))
            ax.plot(audio_float[:plot_len], linewidth=0.5, color='blue')
            ax.set_xlabel("Samples")
            ax.set_ylabel("Amplitude")
            ax.set_ylim(-1.1, 1.1)
            ax.grid(True, alpha=0.3)
            ax.set_title(f"Audio ({len(audio_float)} samples, {len(audio_float)/SAMPLE_RATE:.2f}s)")
            
            canvas.draw()
            
        except Exception as e:
            self.log_message(f"Error updating waveform: {str(e)}")
    
    # ============================================================================
    # PREVIEW TAB FUNCTIONS
    # ============================================================================
    
    def load_file_for_preview(self):
        filename = self.preview_file_var.get()
        if not filename:
            return
        
        # Find the file path
        for path in self.audio_paths:
            if os.path.basename(path) == filename:
                self.load_preview_segments(path)
                break
    
    def load_preview_segments(self, file_path):
        try:
            max_segments = self.settings['max_segments'].get()
            self.log_message(f"Loading preview segments from {os.path.basename(file_path)}...")
            
            segments, positions, full_audio = self.audio_processor.load_audio(file_path, max_segments)
            
            self.loaded_segments[os.path.basename(file_path)] = {
                'segments': segments,
                'positions': positions,
                'full_audio': full_audio
            }
            
            # Update UI
            num_segments = len(segments)
            self.segment_var.set(0)
            self.segment_spin.config(from_=0, to=max(0, num_segments-1))
            self.segment_total_label.config(text=f"of {max(0, num_segments-1)}")
            
            self.update_preview_display()
            self.update_stats()
            self.log_message(f"Loaded {num_segments} segments from {os.path.basename(file_path)}")
            
        except Exception as e:
            self.log_message(f"Error loading preview: {str(e)}")
    
    def update_preview_display(self):
        filename = self.preview_file_var.get()
        if not filename or filename not in self.loaded_segments:
            return
        
        segment_idx = self.segment_var.get()
        data = self.loaded_segments[filename]
        
        if segment_idx >= len(data['segments']):
            return
        
        segment = data['segments'][segment_idx]
        
        # Update waveform plot
        self.preview_ax.clear()
        
        try:
            # Convert to float for plotting
            audio_float = (segment.astype(np.float32) / 127.5) - 1.0
            
            # Plot
            self.preview_ax.plot(audio_float, linewidth=0.5, color='green')
            self.preview_ax.set_xlabel("Samples")
            self.preview_ax.set_ylabel("Amplitude")
            self.preview_ax.set_ylim(-1.1, 1.1)
            self.preview_ax.grid(True, alpha=0.3)
            
            position = data['positions'][segment_idx]
            duration = len(segment) / SAMPLE_RATE
            self.preview_ax.set_title(f"Segment {segment_idx+1} - {duration:.2f}s ({position[0]}-{position[1]})")
            
            self.preview_canvas.draw()
            
        except Exception as e:
            self.log_message(f"Error updating preview: {str(e)}")
    
    def prev_segment_preview(self):
        current = self.segment_var.get()
        if current > 0:
            self.segment_var.set(current - 1)
            self.update_preview_display()
    
    def next_segment_preview(self):
        filename = self.preview_file_var.get()
        if filename in self.loaded_segments:
            data = self.loaded_segments[filename]
            current = self.segment_var.get()
            if current < len(data['segments']) - 1:
                self.segment_var.set(current + 1)
                self.update_preview_display()
    
    def play_current_segment(self):
        filename = self.preview_file_var.get()
        if filename not in self.loaded_segments:
            self.log_message("No segments loaded for playback")
            return
        
        segment_idx = self.segment_var.get()
        if segment_idx >= len(self.loaded_segments[filename]['segments']):
            self.log_message("Invalid segment index")
            return
        
        segment = self.loaded_segments[filename]['segments'][segment_idx]
        
        try:
            self.log_message(f"Playing segment {segment_idx+1}...")
            self.current_audio = self.audio_processor.play_audio(segment)
        except Exception as e:
            self.log_message(f"Error playing segment: {str(e)}")
    
    def play_full_preview(self):
        filename = self.preview_file_var.get()
        if filename not in self.loaded_segments:
            self.log_message("No audio loaded for playback")
            return
        
        full_audio = self.loaded_segments[filename]['full_audio']
        
        try:
            self.log_message(f"Playing full audio: {filename}...")
            self.current_audio = self.audio_processor.play_audio(full_audio)
        except Exception as e:
            self.log_message(f"Error playing full audio: {str(e)}")
    
    def preview_selected_audio(self):
        selection = self.audio_listbox.curselection()
        if not selection:
            self.log_message("No audio file selected!")
            return
        
        idx = selection[0]
        audio_path = self.audio_paths[idx]
        
        try:
            self.log_message(f"Loading and previewing: {os.path.basename(audio_path)}...")
            
            # Load first segment
            segments, _, _ = self.audio_processor.load_audio(audio_path, max_segments=1)
            if segments:
                # Play the segment
                self.current_audio = self.audio_processor.play_audio(segments[0])
                self.log_message(f"Playing: {os.path.basename(audio_path)}")
                
                # Also update preview tab
                self.preview_file_var.set(os.path.basename(audio_path))
                self.load_preview_segments(audio_path)
            else:
                self.log_message(f"No segments in {os.path.basename(audio_path)}")
                
        except Exception as e:
            self.log_message(f"Error playing audio: {str(e)}")
    
    # ============================================================================
    # VISUALIZATION TAB FUNCTIONS
    # ============================================================================
    
    def update_visualization(self):
        vis_type = self.vis_type.get()
        filename = self.vis_file_var.get()
        
        if not filename:
            return
        
        # Find the file
        for path in self.audio_paths:
            if os.path.basename(path) == filename:
                self.create_visualization(path, vis_type)
                break
    
    def create_visualization(self, file_path, vis_type):
        try:
            # Load audio (use a short segment for visualization)
            audio, _ = librosa.load(file_path, sr=SAMPLE_RATE, mono=True, duration=3.0)
            
            self.vis_figure.clear()
            
            if vis_type == "waveform":
                ax = self.vis_figure.add_subplot(111)
                ax.plot(audio, linewidth=0.5, color='purple')
                ax.set_xlabel("Samples")
                ax.set_ylabel("Amplitude")
                ax.set_title(f"Waveform - {os.path.basename(file_path)}")
                ax.grid(True, alpha=0.3)
                
            elif vis_type == "spectrogram":
                # Create mel spectrogram
                D = librosa.stft(audio, n_fft=256, hop_length=64)
                S_db = librosa.amplitude_to_db(np.abs(D), ref=np.max)
                
                ax = self.vis_figure.add_subplot(111)
                img = librosa.display.specshow(S_db, sr=SAMPLE_RATE, 
                                              hop_length=64, x_axis='time', y_axis='log', ax=ax)
                self.vis_figure.colorbar(img, ax=ax, format="%+2.0f dB")
                ax.set_title(f"Mel Spectrogram - {os.path.basename(file_path)}")
                
            elif vis_type == "both":
                # Waveform
                ax1 = self.vis_figure.add_subplot(211)
                ax1.plot(audio, linewidth=0.5, color='purple')
                ax1.set_ylabel("Amplitude")
                ax1.set_title(f"Waveform - {os.path.basename(file_path)}")
                ax1.grid(True, alpha=0.3)
                
                # Spectrogram
                D = librosa.stft(audio, n_fft=256, hop_length=64)
                S_db = librosa.amplitude_to_db(np.abs(D), ref=np.max)
                
                ax2 = self.vis_figure.add_subplot(212)
                img = librosa.display.specshow(S_db, sr=SAMPLE_RATE, 
                                              hop_length=64, x_axis='time', y_axis='log', ax=ax2)
                self.vis_figure.colorbar(img, ax=ax2, format="%+2.0f dB")
                ax2.set_title("Mel Spectrogram")
            
            self.vis_figure.tight_layout()
            self.vis_canvas.draw()
            self.log_message(f"Created {vis_type} visualization for {os.path.basename(file_path)}")
            
        except Exception as e:
            self.log_message(f"Error creating visualization: {str(e)}")
    
    # ============================================================================
    # AUDIO PLAYBACK CONTROL
    # ============================================================================
    
    def play_generated(self):
        if self.generated_audio is not None:
            try:
                self.log_message("Playing generated audio...")
                self.current_audio = self.audio_processor.play_audio(self.generated_audio)
            except Exception as e:
                self.log_message(f"Error playing generated audio: {str(e)}")
        else:
            self.log_message("No audio generated yet!")
    
    def play_generated_tab(self):
        # Same as play_generated but for generate tab
        self.play_generated()
    
    def stop_audio(self):
        try:
            if self.current_audio:
                import simpleaudio as sa
                if hasattr(self.current_audio, 'stop'):
                    self.current_audio.stop()
                self.current_audio = None
            self.log_message("Audio stopped")
        except Exception as e:
            self.log_message(f"Error stopping audio: {str(e)}")
    
    # ============================================================================
    # SAVE FUNCTIONS
    # ============================================================================
    
    def save_generated(self):
        if self.generated_audio is None:
            self.log_message("No audio to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".wav",
            filetypes=[("WAV files", "*.wav"), ("All files", "*.*")],
            initialfile=f"generated_{time.strftime('%Y%m%d_%H%M%S')}.wav"
        )
        
        if filename:
            try:
                self.audio_processor.save_audio(self.generated_audio, filename)
                self.log_message(f"Audio saved to {filename}")
            except Exception as e:
                self.log_message(f"Error saving audio: {str(e)}")
    
    def save_generated_tab(self):
        # Same as save_generated but for generate tab
        self.save_generated()
    
    def save_model(self):
        if not self.model:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")],
            initialfile=f"model_{time.strftime('%Y%m%d_%H%M%S')}.pth"
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'model_state_dict': self.model.state_dict(),
                    'hidden_size': self.settings['hidden_size'].get(),
                    'num_layers': self.settings['num_layers'].get(),
                    'sample_rate': SAMPLE_RATE,
                    'segment_length': SEGMENT_LENGTH,
                    'settings': {k: v.get() for k, v in self.settings.items()}
                }, filename)
                self.log_message(f"Model saved to {filename}")
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")
    
    # ============================================================================
    # UTILITY FUNCTIONS
    # ============================================================================
    
    def use_random_seed(self):
        self.seed_var.set("Random")
        self.log_message("Using random seed for generation")
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                timestamp = time.strftime('%H:%M:%S')
                self.log_text.insert(tk.END, f"{timestamp} - {message}\n")
                self.log_text.see(tk.END)
                
                # Update status with first line
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:80])
                
                # Also print to console for debugging
                print(f"{timestamp} - {message}")
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

# ============================================================================
# MAIN
# ============================================================================
if __name__ == "__main__":
    print("=" * 60)
    print("Audio RNN/LSTM Trainer - Direct Audio Prediction")
    print("=" * 60)
    print(f"Sample rate: {SAMPLE_RATE}Hz (SimpleAudio compatible)")
    print(f"Bit depth: {BIT_DEPTH}-bit")
    print(f"Segment length: {SEGMENT_LENGTH} samples ({SEGMENT_LENGTH/SAMPLE_RATE:.1f}s)")
    print(f"CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch threads: {torch.get_num_threads()}")
    print("=" * 60)
    print("Note: For best results, install simpleaudio for playback:")
    print("      pip install simpleaudio")
    print("=" * 60)
    
    # Create and run the application
    root = tk.Tk()
    app = AudioRNNApp(root)
    
    # Center window
    root.update_idletasks()
    width = root.winfo_width()
    height = root.winfo_height()
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry(f'{width}x{height}+{x}+{y}')
    
    root.mainloop()