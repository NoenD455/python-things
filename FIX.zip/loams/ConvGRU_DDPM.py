import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F_vision
import torch.nn.functional as F_nn
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
import math

# ==================== Helper ====================

def load_image_as_rgb(path):
    """Load an image and convert to RGB (handle transparency)."""
    img = Image.open(path)
    if img.mode == 'RGBA':
        bg = Image.new('RGB', img.size, (0, 0, 0))
        bg.paste(img, mask=img.split()[3])
        return bg
    else:
        return img.convert('RGB')

def load_image_as_grayscale(path):
    """Load an image and convert to grayscale."""
    return Image.open(path).convert('L')

# ==================== Sinusoidal Embeddings ====================

class SinusoidalPositionEmbeddings(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, time):
        device = time.device
        half_dim = self.dim // 2
        embeddings = math.log(10000) / (half_dim - 1)
        embeddings = torch.exp(torch.arange(half_dim, device=device) * -embeddings)
        embeddings = time[:, None] * embeddings[None, :]
        embeddings = torch.cat((embeddings.sin(), embeddings.cos()), dim=-1)
        return embeddings

# ==================== ConvGRU Components ====================

class ConvGRUCell(nn.Module):
    """
    Convolutional GRU cell.
    Input:  (batch, in_channels, H, W)
    Hidden: (batch, hidden_channels, H, W)
    Output: (batch, hidden_channels, H, W)  (new hidden state)
    """
    def __init__(self, in_channels, hidden_channels, kernel_size=3):
        super().__init__()
        self.hidden_channels = hidden_channels
        self.padding = kernel_size // 2

        # Combined convolution for reset and update gates
        self.conv_gates = nn.Conv2d(in_channels + hidden_channels,
                                     2 * hidden_channels,
                                     kernel_size, padding=self.padding)
        # Convolution for candidate hidden state
        self.conv_candidate = nn.Conv2d(in_channels + hidden_channels,
                                        hidden_channels,
                                        kernel_size, padding=self.padding)

    def forward(self, x, h_prev):
        """
        x      : (B, C_in, H, W)
        h_prev : (B, C_hidden, H, W)
        returns: (B, C_hidden, H, W) new hidden state
        """
        combined = torch.cat([x, h_prev], dim=1)                # (B, C_in+C_hidden, H, W)
        gates = self.conv_gates(combined)                       # (B, 2*C_hidden, H, W)
        reset_gate, update_gate = torch.chunk(gates, 2, dim=1)  # each (B, C_hidden, H, W)
        reset_gate = torch.sigmoid(reset_gate)
        update_gate = torch.sigmoid(update_gate)

        # Candidate hidden state
        candidate_input = torch.cat([x, reset_gate * h_prev], dim=1)
        candidate = self.conv_candidate(candidate_input)        # (B, C_hidden, H, W)
        candidate = torch.tanh(candidate)

        # New hidden state
        h_new = update_gate * h_prev + (1 - update_gate) * candidate
        return h_new


class ConvGRUDenoiser(nn.Module):
    """
    Reversible denoiser using a ConvGRU.
    At each timestep it takes the noisy image x_t and a hidden state,
    and outputs the predicted noise (or clean image).
    Time information is injected via an embedding added to the input.
    """
    def __init__(self, in_channels=3, hidden_channels=32, time_emb_dim=32):
        super().__init__()
        self.hidden_channels = hidden_channels
        self.time_emb_dim = time_emb_dim

        # Time embedding MLP
        self.time_mlp = nn.Sequential(
            SinusoidalPositionEmbeddings(time_emb_dim),
            nn.Linear(time_emb_dim, time_emb_dim),
            nn.LeakyReLU(0.2)
        )

        # A small projection to mix time embedding with the image
        self.in_proj = nn.Conv2d(in_channels + time_emb_dim, hidden_channels, 1)

        # ConvGRU cell
        self.gru_cell = ConvGRUCell(hidden_channels, hidden_channels, kernel_size=3)

        # Output layer: from hidden state to noise prediction
        self.out_proj = nn.Conv2d(hidden_channels, in_channels, 3, padding=1)

    def forward(self, x, t, h=None):
        """
        x : noisy image (B, C, H, W)
        t : timestep (B,)  (normalised between 0 and 1)
        h : previous hidden state (B, hidden_channels, H, W) or None
        returns:
            noise_pred : predicted noise (B, C, H, W)
            h_new      : new hidden state
        """
        batch_size, _, H, W = x.shape
        device = x.device

        # Time embedding
        t_emb = self.time_mlp(t)                     # (B, time_emb_dim)
        t_emb = t_emb[:, :, None, None].expand(-1, -1, H, W)   # (B, time_emb_dim, H, W)

        # Concatenate image and time embedding
        x_t = torch.cat([x, t_emb], dim=1)            # (B, C+time_emb_dim, H, W)

        # Project to hidden dimension
        x_proj = self.in_proj(x_t)                    # (B, hidden_channels, H, W)

        # Initialise hidden state if not given
        if h is None:
            h = torch.zeros(batch_size, self.hidden_channels, H, W, device=device)

        # One GRU step
        h_new = self.gru_cell(x_proj, h)

        # Predict noise
        noise_pred = self.out_proj(h_new)

        return noise_pred, h_new

# ==================== Pixel DDPM (with ConvGRU) ====================

class PixelDDPM:
    def __init__(self, in_channels=3, img_size=32, hidden_channels=32,
                 T=200, beta_start=1e-4, beta_end=0.02, device=None,
                 unroll_length=5):
        """
        unroll_length : number of consecutive timesteps to unroll during training (BPTT)
        """
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.img_size = img_size
        self.in_channels = in_channels
        self.T = T
        self.beta_start = beta_start
        self.beta_end = beta_end
        self.unroll_length = unroll_length

        # Diffusion schedule
        self.betas = torch.linspace(beta_start, beta_end, T, device=self.device)
        self.alphas = 1 - self.betas
        self.alpha_bars = torch.cumprod(self.alphas, dim=0)

        # ConvGRU denoiser
        self.model = ConvGRUDenoiser(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            time_emb_dim=32
        ).to(self.device)

        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=2e-4)

    # ---------- Helper to get noisy images for a range of timesteps ----------
    def get_noisy_batch(self, x0, t_start, length):
        """
        For a batch of clean images x0, generate noisy images for timesteps
        t_start, t_start-1, ..., t_start-length+1.
        Returns a list of (x_t, noise, t) for each step in that range.
        """
        x0 = x0.to(self.device)
        batch_size = x0.size(0)
        steps = []

        for step in range(length):
            t = t_start - step
            if t < 1:
                break
            # Compute alpha_bar for this t
            alpha_bar_t = self.alpha_bars[t-1].view(-1, 1, 1, 1)
            noise = torch.randn_like(x0)
            xt = torch.sqrt(alpha_bar_t) * x0 + torch.sqrt(1 - alpha_bar_t) * noise
            # Normalised time (0..1) for the model
            t_norm = torch.full((batch_size,), t, device=self.device, dtype=torch.float) / self.T
            steps.append((xt, noise, t_norm))

        return steps

    # ---------- Training step (BPTT over a short sequence) ----------
    def train_step(self, x0):
        """
        Unroll the GRU over a random contiguous subsequence of timesteps.
        """
        x0 = x0.to(self.device)
        batch_size = x0.size(0)

        # Random starting timestep (at least self.unroll_length steps from T)
        max_start = self.T - self.unroll_length + 1
        if max_start < 1:
            t_start = self.T
        else:
            t_start = random.randint(self.unroll_length, self.T)

        # Get the noisy images and true noise for the sequence
        steps = self.get_noisy_batch(x0, t_start, self.unroll_length)
        if len(steps) == 0:
            return 0.0   # should not happen

        # Initial hidden state is zero
        h = None
        total_loss = 0.0

        # Process in reverse order (from highest t to lowest)
        for xt, true_noise, t_norm in steps:
            pred_noise, h = self.model(xt, t_norm, h)
            loss = self.criterion(pred_noise, true_noise)
            total_loss += loss

        # Backward pass
        self.optimizer.zero_grad()
        total_loss.backward()
        self.optimizer.step()

        return total_loss.item() / len(steps)

    # ---------- Sampling (standard DDPM/DDIM) ----------
    @torch.no_grad()
    def sample(self, n_samples=16, steps=None, method='ddpm'):
        if method.lower() == 'ddpm':
            return self._sample_ddpm(n_samples, steps)
        elif method.lower() == 'ddim':
            return self._sample_ddim(n_samples, steps)
        else:
            raise ValueError("method must be 'ddpm' or 'ddim'")

    def _sample_ddpm(self, n_samples=16, steps=None):
        if steps is None:
            steps = self.T
        self.model.eval()
        x = torch.randn(n_samples, self.in_channels, self.img_size, self.img_size, device=self.device)
        h = None  # hidden state will be maintained across steps
        if steps < self.T:
            timesteps = torch.linspace(self.T, 1, steps).round().long().unique()
        else:
            timesteps = torch.arange(self.T, 0, -1)

        for t in timesteps:
            t_tensor = torch.full((n_samples,), t, device=self.device, dtype=torch.float) / self.T
            # At the last step we don't add noise
            noise = torch.randn_like(x) if t > 1 else torch.zeros_like(x)
            pred_noise, h = self.model(x, t_tensor, h)
            alpha = self.alphas[t-1]
            alpha_bar = self.alpha_bars[t-1]
            beta = self.betas[t-1]
            coef1 = 1 / torch.sqrt(alpha)
            coef2 = (1 - alpha) / torch.sqrt(1 - alpha_bar)
            x = coef1 * (x - coef2 * pred_noise) + torch.sqrt(beta) * noise

        self.model.train()
        return x

    def _sample_ddim(self, n_samples=16, steps=50, eta=0.0):
        self.model.eval()
        timesteps = torch.linspace(self.T, 1, steps).round().long().unique().to(self.device)
        alpha_bars = self.alpha_bars[timesteps - 1]
        x = torch.randn(n_samples, self.in_channels, self.img_size, self.img_size, device=self.device)
        h = None

        for i in range(len(timesteps) - 1):
            t = timesteps[i]
            t_next = timesteps[i + 1]
            t_tensor = torch.full((n_samples,), t, device=self.device, dtype=torch.float) / self.T
            pred_noise, h = self.model(x, t_tensor, h)

            alpha_bar_t = alpha_bars[i]
            alpha_bar_next = alpha_bars[i + 1]

            if eta > 0:
                arg = (1 - alpha_bar_next) / (1 - alpha_bar_t) * (1 - alpha_bar_t / alpha_bar_next)
                arg = arg.clamp(min=1e-8)
                sigma = eta * torch.sqrt(arg)
            else:
                sigma = 0.0

            c1 = torch.sqrt(alpha_bar_next / alpha_bar_t)
            c2 = torch.sqrt(1 - alpha_bar_next - sigma**2) - torch.sqrt(1 - alpha_bar_t) * c1
            x = c1 * x + c2 * pred_noise
            if eta > 0:
                x += sigma * torch.randn_like(x)

        self.model.train()
        return x

    # ---------- Step‑by‑step sampling for progressive display ----------
    @torch.no_grad()
    def sample_step_by_step(self, n_samples=16, steps=None, method='ddpm'):
        if method.lower() == 'ddpm':
            yield from self._sample_step_by_step_ddpm(n_samples, steps)
        elif method.lower() == 'ddim':
            yield from self._sample_step_by_step_ddim(n_samples, steps)
        else:
            raise ValueError("method must be 'ddpm' or 'ddim'")

    def _sample_step_by_step_ddpm(self, n_samples=16, steps=None):
        if steps is None:
            steps = self.T
        self.model.eval()
        x = torch.randn(n_samples, self.in_channels, self.img_size, self.img_size, device=self.device)
        h = None
        if steps < self.T:
            timesteps = torch.linspace(self.T, 1, steps).round().long().unique()
        else:
            timesteps = torch.arange(self.T, 0, -1)
        for t in timesteps:
            t_tensor = torch.full((n_samples,), t, device=self.device, dtype=torch.float) / self.T
            noise = torch.randn_like(x) if t > 1 else torch.zeros_like(x)
            pred_noise, h = self.model(x, t_tensor, h)
            alpha = self.alphas[t-1]
            alpha_bar = self.alpha_bars[t-1]
            beta = self.betas[t-1]
            coef1 = 1 / torch.sqrt(alpha)
            coef2 = (1 - alpha) / torch.sqrt(1 - alpha_bar)
            x = coef1 * (x - coef2 * pred_noise) + torch.sqrt(beta) * noise
            yield t, x.clone()
        self.model.train()

    def _sample_step_by_step_ddim(self, n_samples=16, steps=50, eta=0.0):
        self.model.eval()
        timesteps = torch.linspace(self.T, 1, steps).round().long().unique().to(self.device)
        alpha_bars = self.alpha_bars[timesteps - 1]
        x = torch.randn(n_samples, self.in_channels, self.img_size, self.img_size, device=self.device)
        h = None

        for i in range(len(timesteps) - 1):
            t = timesteps[i]
            t_next = timesteps[i + 1]
            t_tensor = torch.full((n_samples,), t, device=self.device, dtype=torch.float) / self.T
            pred_noise, h = self.model(x, t_tensor, h)

            alpha_bar_t = alpha_bars[i]
            alpha_bar_next = alpha_bars[i + 1]

            if eta > 0:
                arg = (1 - alpha_bar_next) / (1 - alpha_bar_t) * (1 - alpha_bar_t / alpha_bar_next)
                arg = arg.clamp(min=1e-8)
                sigma = eta * torch.sqrt(arg)
            else:
                sigma = 0.0

            c1 = torch.sqrt(alpha_bar_next / alpha_bar_t)
            c2 = torch.sqrt(1 - alpha_bar_next - sigma**2) - torch.sqrt(1 - alpha_bar_t) * c1
            x = c1 * x + c2 * pred_noise
            if eta > 0:
                x += sigma * torch.randn_like(x)

            yield t, x.clone()
        self.model.train()


# ==================== Unconditional Dataset ====================

class UnconditionalImageDataset(Dataset):
    def __init__(self, image_paths, img_size=32, color_mode='rgb', aug_settings=None):
        self.image_paths = image_paths
        self.img_size = img_size
        self.color_mode = color_mode.lower()
        self.aug_settings = aug_settings or {}

        if self.color_mode == 'rgb':
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:  # grayscale
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.5,))
            ])

    def __len__(self):
        return len(self.image_paths)

    def apply_augmentations(self, pil_img):
        img = pil_img.copy()
        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F_vision.hflip(img)
        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F_vision.rotate(img, angle, interpolation=Image.BICUBIC)
        return img

    def __getitem__(self, idx):
        try:
            if self.color_mode == 'rgb':
                pil_img = load_image_as_rgb(self.image_paths[idx])
            else:
                pil_img = load_image_as_grayscale(self.image_paths[idx])
            pil_img = self.apply_augmentations(pil_img)
            img_tensor = self.transform(pil_img)
            return img_tensor
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            if self.color_mode == 'rgb':
                return torch.zeros(3, self.img_size, self.img_size)
            else:
                return torch.zeros(1, self.img_size, self.img_size)


# ==================== GUI Application ====================

class DDPMApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ConvGRU DDPM - Fast CPU Training")
        self.root.geometry("1200x800")

        self.image_paths = []
        self.training = False
        self.ddpm_model = None

        self.current_epoch = 0
        self.message_queue = queue.Queue()
        self.progressive_active = False

        # Settings variables
        self.settings = {
            # Image
            'img_size': tk.IntVar(value=32),
            'color_mode': tk.StringVar(value='rgb'),

            # DDPM (ConvGRU specific)
            'hidden_channels': tk.IntVar(value=32),
            'T': tk.IntVar(value=200),
            'beta_start': tk.DoubleVar(value=1e-4),
            'beta_end': tk.DoubleVar(value=0.02),
            'batch_size': tk.IntVar(value=8),
            'lr': tk.DoubleVar(value=2e-4),
            'unroll_length': tk.IntVar(value=5),   # new parameter
        }

        # Augmentation settings
        self.aug_settings = {
            'flip_horizontal': tk.BooleanVar(value=True),
            'rotation': tk.BooleanVar(value=False),
        }

        # Generation sampler choice
        self.sampler_method = tk.StringVar(value='ddpm')

        self.thumbnail_size = 128

        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Tab 1: DDPM Training
        self.train_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.train_tab, text='DDPM Training')
        self.setup_train_tab()

        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        # Tab 3: Generation
        self.generation_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generation_tab, text='Generation')
        self.setup_generation_tab()

        self.status_label = tk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    # ------------------------------------------------------------------
    # Training Tab
    # ------------------------------------------------------------------
    def setup_train_tab(self):
        main_frame = tk.Frame(self.train_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="DDPM Training", font=("Arial",12,"bold")).pack(pady=(0,10))

        # Image selection
        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=5, pady=5)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=2)
        tk.Button(img_frame, text="Add Folder (recursive)", command=self.add_folder, width=20).pack(pady=2)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=2)
        self.image_listbox = tk.Listbox(img_frame, height=5)
        self.image_listbox.pack(fill=tk.X, pady=2)

        # Model controls
        tk.Button(left_frame, text="Initialize Model", command=self.initialize_model, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start Training", command=self.start_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop Training", command=self.stop_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load Model", command=self.load_model, width=20).pack(pady=5)

        # Right panel - preview and log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Samples", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=256)
        self.preview_canvas.pack()

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

    # ------------------------------------------------------------------
    # Settings Tab (modified for ConvGRU)
    # ------------------------------------------------------------------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Model Settings", font=("Arial",14,"bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # ----- Image Settings -----
        img_frame = tk.LabelFrame(scrollable_frame, text="Image", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=5)

        f = tk.Frame(img_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Color mode:", width=20, anchor='w').pack(side=tk.LEFT)
        om = ttk.Combobox(f, textvariable=self.settings['color_mode'], values=['rgb', 'grayscale'], state='readonly', width=10)
        om.pack(side=tk.RIGHT)

        f = tk.Frame(img_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Image size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=16, to=64, variable=self.settings['img_size'],
                 orient=tk.HORIZONTAL, length=200, resolution=1).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['img_size'], width=5).pack(side=tk.RIGHT)

        # ----- DDPM Settings (ConvGRU) -----
        ddpm_frame = tk.LabelFrame(scrollable_frame, text="DDPM (ConvGRU)", padx=10, pady=10)
        ddpm_frame.pack(fill=tk.X, pady=5)

        ddpm_params = [
            ("Hidden channels:", 'hidden_channels', 8, 128),
            ("Timesteps (T):", 'T', 50, 500),
            ("Beta start:", 'beta_start', 1e-5, 1e-2),
            ("Beta end:", 'beta_end', 0.001, 0.1),
            ("Batch size:", 'batch_size', 1, 32),
            ("Learning rate:", 'lr', 1e-5, 1e-2),
            ("Unroll length (BPTT):", 'unroll_length', 1, 20),
        ]
        for label, key, low, high in ddpm_params:
            f = tk.Frame(ddpm_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            res = 0.0001 if 'beta' in key else (0.00001 if 'lr' in key else 1)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # ----- Augmentations -----
        aug_frame = tk.LabelFrame(scrollable_frame, text="Augmentations", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)

        for label, key in [("Horizontal Flip", 'flip_horizontal'), ("Rotation (±30°)", 'rotation')]:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        # ----- System Info -----
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=5)
        cpu = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU cores: {cpu}").pack(anchor='w')
        tk.Label(sys_frame, text=f"PyTorch threads: {torch.get_num_threads()}").pack(anchor='w')
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}").pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ------------------------------------------------------------------
    # Generation Tab
    # ------------------------------------------------------------------
    def setup_generation_tab(self):
        main_frame = tk.Frame(self.generation_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        tk.Label(main_frame, text="Generate Images", font=("Arial",14,"bold")).pack(pady=(0,10))

        ctrl_frame = tk.Frame(main_frame)
        ctrl_frame.pack(pady=5)

        tk.Label(ctrl_frame, text="Number of images:").pack(side=tk.LEFT)
        self.gen_count = tk.IntVar(value=16)
        tk.Spinbox(ctrl_frame, from_=1, to=64, textvariable=self.gen_count, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="Sampling steps:").pack(side=tk.LEFT, padx=(10,0))
        self.sampling_steps = tk.IntVar(value=self.settings['T'].get())
        tk.Spinbox(ctrl_frame, from_=1, to=self.settings['T'].get(), textvariable=self.sampling_steps, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="Sampler:").pack(side=tk.LEFT, padx=(10,0))
        sampler_combo = ttk.Combobox(ctrl_frame, textvariable=self.sampler_method,
                                      values=['ddpm', 'ddim'], state='readonly', width=6)
        sampler_combo.pack(side=tk.LEFT, padx=5)

        self.progressive_grid = tk.BooleanVar(value=False)
        prog_check = tk.Checkbutton(ctrl_frame, text="Progressive grid", variable=self.progressive_grid)
        prog_check.pack(side=tk.LEFT, padx=10)

        tk.Label(ctrl_frame, text="Update interval:").pack(side=tk.LEFT)
        self.prog_interval = tk.IntVar(value=10)
        tk.Spinbox(ctrl_frame, from_=1, to=50, textvariable=self.prog_interval, width=5).pack(side=tk.LEFT, padx=5)

        self.generate_btn = tk.Button(ctrl_frame, text="Generate", command=self.generate_samples, bg="lightgreen")
        self.generate_btn.pack(side=tk.LEFT, padx=5)
        self.stop_prog_btn = tk.Button(ctrl_frame, text="Stop", command=self.stop_progressive, state=tk.DISABLED, bg="salmon")
        self.stop_prog_btn.pack(side=tk.LEFT, padx=5)

        scroll_frame = tk.LabelFrame(main_frame, text="Results", padx=5, pady=5)
        scroll_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        canvas_frame = tk.Frame(scroll_frame)
        canvas_frame.pack(fill=tk.BOTH, expand=True)

        self.gen_canvas = tk.Canvas(canvas_frame, bg='lightgray')
        self.v_scroll = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.gen_canvas.yview)
        self.h_scroll = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.gen_canvas.xview)
        self.gen_canvas.configure(yscrollcommand=self.v_scroll.set, xscrollcommand=self.h_scroll.set)

        self.v_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.h_scroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.inner_frame = tk.Frame(self.gen_canvas)
        self.canvas_window = self.gen_canvas.create_window((0,0), window=self.inner_frame, anchor='nw')

        def configure_inner(event):
            self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.inner_frame.bind('<Configure>', configure_inner)

        self.gen_info = tk.Label(main_frame, text="", fg="blue")
        self.gen_info.pack()

    # ------------------------------------------------------------------
    # Core functions
    # ------------------------------------------------------------------
    def log(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(f"LOG: {msg}")
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(
            filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp")]
        )
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def add_folder(self):
        folder = filedialog.askdirectory()
        if not folder:
            return
        count = 0
        for root_dir, _, files in os.walk(folder):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg', '.jfif', '.webp', '.bmp')):
                    full_path = os.path.join(root_dir, file)
                    if full_path not in self.image_paths:
                        self.image_paths.append(full_path)
                        self.image_listbox.insert(tk.END, os.path.basename(full_path))
                        count += 1
        self.log(f"Added {count} images from folder. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log("Cleared all images")

    # ========== DDPM Methods ==========
    def initialize_model(self):
        try:
            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            self.ddpm_model = PixelDDPM(
                in_channels=in_channels,
                img_size=self.settings['img_size'].get(),
                hidden_channels=self.settings['hidden_channels'].get(),   # changed
                T=self.settings['T'].get(),
                beta_start=self.settings['beta_start'].get(),
                beta_end=self.settings['beta_end'].get(),
                unroll_length=self.settings['unroll_length'].get()        # new
            )
            # Update optimizer LR
            for pg in self.ddpm_model.optimizer.param_groups:
                pg['lr'] = self.settings['lr'].get()
            self.log("ConvGRU model initialized.")
        except Exception as e:
            self.log(f"Error initializing model: {e}")

    def start_training(self):
        if not self.image_paths:
            self.log("No images!")
            return
        if not self.ddpm_model:
            self.log("Model not initialized!")
            return
        if self.training:
            self.log("Already training.")
            return

        try:
            epochs = int(self.epoch_var.get())
        except:
            self.log("Invalid epochs")
            return

        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()

        thread = threading.Thread(target=self.train_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log(f"Training started for {epochs} epochs.")

    def train_loop(self, epochs):
        try:
            batch_size = self.settings['batch_size'].get()
            num_workers = 0  # CPU training, avoid multiprocessing overhead
            img_size = self.settings['img_size'].get()
            color_mode = self.settings['color_mode'].get()

            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}
            dataset = UnconditionalImageDataset(self.image_paths, img_size, color_mode, aug_settings=aug_dict)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=False)

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                epoch_loss = 0.0
                batches = 0

                for images in loader:
                    if not self.training:
                        break
                    loss = self.ddpm_model.train_step(images)
                    epoch_loss += loss
                    batches += 1

                avg_loss = epoch_loss / batches if batches else 0
                elapsed = time.time() - self.start_time
                self.log(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s")

                if (epoch+1) % 5 == 0:
                    self.show_preview()

            self.training = False
            self.log("Training finished.")
        except Exception as e:
            self.log(f"Training error: {e}")
            import traceback
            traceback.print_exc()
            self.training = False

    def show_preview(self):
        if not self.ddpm_model:
            return
        try:
            samples = self.ddpm_model.sample(n_samples=16, steps=50, method='ddpm')
            samples = (samples + 1) / 2
            samples = samples.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size
            grid = Image.new('RGB', (4*thumb, 4*thumb))
            for i in range(4):
                for j in range(4):
                    idx = i*4 + j
                    if idx < len(samples):
                        if samples[idx].shape[0] == 1:
                            img = samples[idx][0] * 255
                            img = np.stack([img, img, img], axis=-1).astype(np.uint8)
                        else:
                            img = samples[idx].transpose(1,2,0) * 255
                            img = img.astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img, (j*thumb, i*thumb))
            grid = grid.resize((256,256), Image.NEAREST)
            self.preview_photo = ImageTk.PhotoImage(grid)
            self.preview_canvas.delete("all")
            self.preview_canvas.create_image(128,128, image=self.preview_photo)
        except Exception as e:
            self.log(f"Preview error: {e}")

    def stop_training(self):
        self.training = False
        self.log("Training stopped.")

    def save_model(self):
        if not self.ddpm_model:
            self.log("No model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth",
                                              filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'model_state': self.ddpm_model.model.state_dict(),
                'optimizer_state': self.ddpm_model.optimizer.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items()},
                'T': self.ddpm_model.T,
                'betas': self.ddpm_model.betas.cpu(),
                'alphas': self.ddpm_model.alphas.cpu(),
                'alpha_bars': self.ddpm_model.alpha_bars.cpu()
            }, fname)
            self.log(f"Model saved to {fname}")

    def load_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            if 'settings' in ckpt:
                s = ckpt['settings']
                for k, v in s.items():
                    if k in self.settings:
                        self.settings[k].set(v)

            self.initialize_model()
            self.ddpm_model.model.load_state_dict(ckpt['model_state'])
            self.ddpm_model.optimizer.load_state_dict(ckpt['optimizer_state'])
            self.ddpm_model.betas = ckpt['betas'].to(self.ddpm_model.device)
            self.ddpm_model.alphas = ckpt['alphas'].to(self.ddpm_model.device)
            self.ddpm_model.alpha_bars = ckpt['alpha_bars'].to(self.ddpm_model.device)
            self.ddpm_model.T = ckpt['T']
            self.log(f"Model loaded from {fname}")
        except Exception as e:
            self.log(f"Load error: {e}")

    # ========== Generation Methods ==========
    def generate_samples(self):
        if not self.ddpm_model:
            self.gen_info.config(text="Model not loaded!")
            return
        n = self.gen_count.get()
        steps = self.sampling_steps.get()
        method = self.sampler_method.get()
        if self.progressive_grid.get():
            self.start_progressive(n, steps, method)
        else:
            self.generate_btn.config(state=tk.DISABLED)
            self.gen_info.config(text="Generating...")
            self.root.update()
            thread = threading.Thread(target=self._generate_thread, args=(n, steps, method), daemon=True)
            thread.start()

    def stop_progressive(self):
        self.progressive_active = False
        self.stop_prog_btn.config(state=tk.DISABLED)
        self.generate_btn.config(state=tk.NORMAL)
        self.gen_info.config(text="Progressive generation stopped.")

    def start_progressive(self, n, steps, method):
        self.progressive_active = True
        self.generate_btn.config(state=tk.DISABLED)
        self.stop_prog_btn.config(state=tk.NORMAL)
        self.gen_info.config(text="Progressive generation...")
        thread = threading.Thread(target=self._progressive_thread, args=(n, steps, method), daemon=True)
        thread.start()

    def _generate_thread(self, n, steps, method):
        try:
            samples = self.ddpm_model.sample(n_samples=n, steps=steps, method=method)
            samples = (samples + 1) / 2
            samples = samples.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size
            grid_size = int(math.ceil(math.sqrt(n)))
            total_width = grid_size * thumb
            total_height = grid_size * thumb
            grid_img = Image.new('RGB', (total_width, total_height), color=(128,128,128))
            for i in range(n):
                row = i // grid_size
                col = i % grid_size
                if samples[i].shape[0] == 1:
                    img = samples[i][0] * 255
                    img = np.stack([img, img, img], axis=-1).astype(np.uint8)
                else:
                    img = samples[i].transpose(1,2,0) * 255
                    img = img.astype(np.uint8)
                pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                grid_img.paste(pil_img, (col*thumb, row*thumb))
            self.root.after(0, lambda: self._display_generated(grid_img))
        except Exception as e:
            self.root.after(0, lambda: self.gen_info.config(text=f"Error: {e}"))
        finally:
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))

    def _progressive_thread(self, n, steps, method):
        try:
            thumb = self.thumbnail_size
            interval = self.prog_interval.get()
            generator = self.ddpm_model.sample_step_by_step(n_samples=n, steps=steps, method=method)
            step_count = 0
            for t, x in generator:
                if not self.progressive_active:
                    break
                step_count += 1
                if step_count % interval == 0 or t == 1:
                    samples = (x + 1) / 2
                    samples = samples.clamp(0,1).cpu().numpy()
                    grid_size = int(math.ceil(math.sqrt(n)))
                    total_width = grid_size * thumb
                    total_height = grid_size * thumb
                    grid_img = Image.new('RGB', (total_width, total_height), color=(128,128,128))
                    for i in range(n):
                        row = i // grid_size
                        col = i % grid_size
                        if i < len(samples):
                            if samples[i].shape[0] == 1:
                                img = samples[i][0] * 255
                                img = np.stack([img, img, img], axis=-1).astype(np.uint8)
                            else:
                                img = samples[i].transpose(1,2,0) * 255
                                img = img.astype(np.uint8)
                            pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                            grid_img.paste(pil_img, (col*thumb, row*thumb))
                    self.root.after(0, lambda g=grid_img, t=t: self._update_progressive(g, t))
                    time.sleep(0.05)
            if not self.progressive_active:
                self.root.after(0, lambda: self.gen_info.config(text="Progressive stopped."))
            else:
                self.root.after(0, lambda: self.gen_info.config(text="Progressive finished."))
        except Exception as e:
            self.root.after(0, lambda: self.gen_info.config(text=f"Error: {e}"))
        finally:
            self.progressive_active = False
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_prog_btn.config(state=tk.DISABLED))

    def _display_generated(self, grid_img):
        for widget in self.inner_frame.winfo_children():
            widget.destroy()
        self.gen_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.gen_photo)
        label.image = self.gen_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text="Generation complete.")

    def _update_progressive(self, grid_img, t):
        for widget in self.inner_frame.winfo_children():
            widget.destroy()
        self.prog_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.prog_photo)
        label.image = self.prog_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text=f"Step {t}/{self.ddpm_model.T}")

# ==================== Main ====================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = DDPMApp(root)
    root.mainloop()