import tkinter as tk
from tkinter import filedialog
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np

# ==================== Simplified PixelCNN ====================

class SimplePixelCNN:
    def __init__(self, image_size=32, colors=3):
        self.image_size = image_size
        self.colors = colors
        
        print(f"Initializing PixelCNN for {image_size}x{image_size} images")
        
        # Use CPU with minimal threads for compatibility
        torch.set_num_threads(2)
        
        # Very simple PixelCNN model
        class PixelCNN(nn.Module):
            def __init__(self, image_size, colors):
                super().__init__()
                self.image_size = image_size
                self.colors = colors
                
                # Simple masked convolutional layers
                self.masked_conv1 = self._masked_conv(colors, 32, mask_type='A')
                self.masked_conv2 = self._masked_conv(32, 32, mask_type='B')
                self.masked_conv3 = self._masked_conv(32, 32, mask_type='B')
                
                # Output layer
                self.output_conv = nn.Conv2d(32, colors * 256, 1)
                
                # Activations
                self.relu = nn.ReLU()
                
            def _masked_conv(self, in_c, out_c, mask_type='B'):
                """Create a masked convolution layer"""
                conv = nn.Conv2d(in_c, out_c, 3, padding=1)
                
                # Create a simple mask
                with torch.no_grad():
                    mask = torch.ones_like(conv.weight)
                    # Zero out future pixels in the receptive field
                    mask[:, :, 1:, :] = 0  # Only keep first row
                    if mask_type == 'A':
                        mask[:, :, 0, 1:] = 0  # Type A also zeros current row except center
                    else:
                        mask[:, :, 0, 2:] = 0  # Type B allows center pixel
                    conv.weight *= mask
                return conv
            
            def forward(self, x):
                # Normalize input
                x = x * 2 - 1
                
                # Apply masked convolutions
                x = self.relu(self.masked_conv1(x))
                x = self.relu(self.masked_conv2(x))
                x = self.relu(self.masked_conv3(x))
                
                # Output layer
                x = self.output_conv(x)
                
                # Reshape for classification
                batch_size = x.shape[0]
                x = x.view(batch_size, self.colors, 256, self.image_size, self.image_size)
                
                return x
            
            def generate(self, num_samples=1, device='cpu'):
                """Fast approximate generation"""
                self.eval()
                with torch.no_grad():
                    # Start with noise
                    samples = torch.rand(num_samples, self.colors, 
                                        self.image_size, self.image_size).to(device)
                    
                    # Fast generation - not truly autoregressive but works for demo
                    for _ in range(3):  # Few iterations for speed
                        output = self.forward(samples)
                        # Take most likely pixel value
                        for c in range(self.colors):
                            probs = torch.softmax(output[:, c], dim=1)
                            samples[:, c] = torch.argmax(probs, dim=1).float() / 255.0
                    
                    return samples
        
        self.model = PixelCNN(image_size, colors)
        
        # Loss and optimizer
        self.criterion = nn.CrossEntropyLoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001)
        
        # Use CPU only for compatibility
        self.device = torch.device("cpu")
        print(f"Using device: {self.device}")
        self.model.to(self.device)

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        # Simple transform
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size), Image.NEAREST),
            transforms.ToTensor(),
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            img_tensor = self.transform(img)
            return img_tensor
        except:
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== GUI Application ====================

class PixelCNNApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Simple PixelCNN - Works on Any Laptop")
        self.root.geometry("800x600")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.model = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)
        
        print("PixelCNN App initialized successfully")
    
    def setup_gui(self):
        # Create main container
        main_frame = tk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel for controls
        left_frame = tk.Frame(main_frame, width=250)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        title = tk.Label(left_frame, text="PixelCNN Trainer", 
                        font=("Arial", 12, "bold"))
        title.pack(pady=(0, 10))
        
        # Image size selection
        tk.Label(left_frame, text="Image Size:").pack(anchor="w")
        self.size_var = tk.StringVar(value="32")
        size_frame = tk.Frame(left_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Radiobutton(size_frame, text="32x32", variable=self.size_var, 
                      value="32").pack(side=tk.LEFT)
        tk.Radiobutton(size_frame, text="64x64", variable=self.size_var, 
                      value="64").pack(side=tk.LEFT)
        
        # Add images button
        tk.Button(left_frame, text="Add Training Images", 
                 command=self.add_images, height=2).pack(fill=tk.X, pady=5)
        
        # Image list
        tk.Label(left_frame, text="Training Images:").pack(anchor="w", pady=(10, 0))
        list_frame = tk.Frame(left_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.image_listbox = tk.Listbox(list_frame, height=8, yscrollcommand=scrollbar.set)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.image_listbox.yview)
        
        # Clear button
        tk.Button(left_frame, text="Clear All Images", 
                 command=self.clear_images).pack(fill=tk.X, pady=5)
        
        # Initialize model
        tk.Button(left_frame, text="Initialize Model", 
                 command=self.initialize_model, height=2).pack(fill=tk.X, pady=5)
        
        # Epochs
        tk.Label(left_frame, text="Training Epochs:").pack(anchor="w", pady=(10, 0))
        self.epoch_var = tk.StringVar(value="10")
        tk.Entry(left_frame, textvariable=self.epoch_var).pack(fill=tk.X, pady=5)
        
        # Training controls
        tk.Button(left_frame, text="Start Training", 
                 command=self.start_training, height=2, 
                 bg="lightgreen").pack(fill=tk.X, pady=5)
        
        tk.Button(left_frame, text="Stop Training", 
                 command=self.stop_training, height=2, 
                 bg="salmon").pack(fill=tk.X, pady=5)
        
        tk.Button(left_frame, text="Generate Image", 
                 command=self.generate_sample, height=2).pack(fill=tk.X, pady=5)
        
        # Status
        self.status_label = tk.Label(left_frame, text="Ready", 
                                    relief=tk.SUNKEN, height=2,
                                    anchor="w", padx=5)
        self.status_label.pack(fill=tk.X, pady=(10, 0))
        
        # Right panel for preview
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Generated image display
        tk.Label(right_frame, text="Generated Image:").pack(anchor="w")
        
        self.image_canvas = tk.Canvas(right_frame, width=256, height=256, 
                                     bg="gray", relief=tk.SUNKEN)
        self.image_canvas.pack(pady=10)
        
        # Training log
        tk.Label(right_frame, text="Training Log:").pack(anchor="w")
        
        log_frame = tk.Frame(right_frame)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        scrollbar2 = tk.Scrollbar(log_frame)
        scrollbar2.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.log_text = tk.Text(log_frame, height=15, font=("Courier", 9),
                               yscrollcommand=scrollbar2.set)
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar2.config(command=self.log_text.yview)
    
    def log_message(self, message):
        self.message_queue.put(message)
    
    def process_messages(self):
        try:
            while True:
                message = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, message + "\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=message[:30])
                self.root.update_idletasks()
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)
    
    def add_images(self):
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        self.log_message(f"Added {len(files)} images. Total: {len(self.image_paths)}")
    
    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all images")
    
    def initialize_model(self):
        try:
            image_size = int(self.size_var.get())
            self.model = SimplePixelCNN(image_size=image_size)
            self.log_message(f"Model initialized for {image_size}x{image_size}")
            self.log_message("Ready to train!")
        except Exception as e:
            self.log_message(f"Error: {str(e)}")
    
    def start_training(self):
        if not self.image_paths:
            self.log_message("Error: No images added!")
            return
        
        if not self.model:
            self.log_message("Error: Model not initialized!")
            return
        
        if self.training:
            self.log_message("Already training!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            image_size = int(self.size_var.get())
            
            self.training = True
            
            # Start training in separate thread
            thread = threading.Thread(
                target=self.train_model,
                args=(epochs, image_size),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Training started for {epochs} epochs")
        except ValueError:
            self.log_message("Error: Invalid epochs value!")
    
    def train_model(self, epochs, image_size):
        try:
            # Simple dataset without multiprocessing
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(dataset, batch_size=4, shuffle=True)
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                total_loss = 0
                batch_count = 0
                
                for images in dataloader:
                    if not self.training:
                        break
                    
                    images = images.to(self.model.device)
                    
                    # Forward pass
                    self.model.optimizer.zero_grad()
                    output = self.model.model(images)
                    
                    # Simple loss calculation
                    target = (images * 255).long().clamp(0, 255)
                    
                    loss = 0
                    for c in range(3):
                        output_reshaped = output[:, c].reshape(-1, 256)
                        target_reshaped = target[:, c].reshape(-1)
                        loss += self.model.criterion(output_reshaped, target_reshaped)
                    
                    # Backward pass
                    loss.backward()
                    self.model.optimizer.step()
                    
                    total_loss += loss.item()
                    batch_count += 1
                
                if batch_count > 0:
                    avg_loss = total_loss / batch_count
                    self.log_message(f"Epoch {epoch+1}/{epochs} - Loss: {avg_loss:.4f}")
                    
                    # Show progress image every 2 epochs
                    if (epoch + 1) % 2 == 0:
                        self.generate_sample_internal()
                
                # Small delay to keep UI responsive
                threading.Event().wait(0.1)
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
    
    def stop_training(self):
        if self.training:
            self.training = False
            self.log_message("Training stopped")
    
    def generate_sample_internal(self):
        if not self.model:
            return
        
        try:
            # Fast generation
            self.model.model.eval()
            with torch.no_grad():
                # Generate image
                generated = self.model.model.generate(num_samples=1, 
                                                     device=self.model.device)
                
                # Convert to PIL
                img_tensor = generated[0].cpu()
                img = transforms.ToPILImage()(img_tensor)
                
                # Resize for display
                img = img.resize((256, 256), Image.NEAREST)
                
                # Display
                photo = ImageTk.PhotoImage(img)
                self.image_canvas.create_image(128, 128, image=photo, anchor=tk.CENTER)
                self.image_canvas.image = photo
                
                return img
        except Exception as e:
            self.log_message(f"Generation error: {str(e)}")
            return None
    
    def generate_sample(self):
        self.log_message("Generating image...")
        img = self.generate_sample_internal()
        if img:
            self.log_message("Image generated!")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting PixelCNN Trainer...")
    print("This version is optimized to work on any laptop")
    
    # Create main window
    root = tk.Tk()
    
    # Create app
    app = PixelCNNApp(root)
    
    # Run main loop
    root.mainloop()