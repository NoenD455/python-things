import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from PIL import Image, ImageTk, ImageFilter
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
from pathlib import Path

# ==================== Neural Network ====================

class DiffusionDenoiser:
    def __init__(self, image_size=32, base_channels=64):
        self.image_size = image_size
        
        # Set PyTorch to use multiple cores
        torch.set_num_threads(multiprocessing.cpu_count())
        if torch.cuda.is_available():
            print("Using CUDA for acceleration")
        else:
            print(f"Using CPU with {torch.get_num_threads()} threads")
        
        # U-Net style denoiser
        class Denoiser(nn.Module):
            def __init__(self, in_channels=3, base_channels=64):
                super().__init__()
                
                # Encoder
                self.enc1 = nn.Sequential(
                    nn.Conv2d(in_channels, base_channels, 3, padding=1),
                    nn.BatchNorm2d(base_channels),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(base_channels, base_channels, 3, padding=1),
                    nn.BatchNorm2d(base_channels),
                    nn.ReLU(inplace=True)
                )
                self.pool1 = nn.MaxPool2d(2)
                
                self.enc2 = nn.Sequential(
                    nn.Conv2d(base_channels, base_channels*2, 3, padding=1),
                    nn.BatchNorm2d(base_channels*2),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(base_channels*2, base_channels*2, 3, padding=1),
                    nn.BatchNorm2d(base_channels*2),
                    nn.ReLU(inplace=True)
                )
                self.pool2 = nn.MaxPool2d(2)
                
                # Bridge (for 32x32: 32 -> 16 -> 8 -> 4)
                self.bridge = nn.Sequential(
                    nn.Conv2d(base_channels*2, base_channels*4, 3, padding=1),
                    nn.BatchNorm2d(base_channels*4),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(base_channels*4, base_channels*4, 3, padding=1),
                    nn.BatchNorm2d(base_channels*4),
                    nn.ReLU(inplace=True)
                )
                
                # Decoder
                self.up2 = nn.ConvTranspose2d(base_channels*4, base_channels*2, 2, stride=2)
                self.dec2 = nn.Sequential(
                    nn.Conv2d(base_channels*4, base_channels*2, 3, padding=1),
                    nn.BatchNorm2d(base_channels*2),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(base_channels*2, base_channels*2, 3, padding=1),
                    nn.BatchNorm2d(base_channels*2),
                    nn.ReLU(inplace=True)
                )
                
                self.up1 = nn.ConvTranspose2d(base_channels*2, base_channels, 2, stride=2)
                self.dec1 = nn.Sequential(
                    nn.Conv2d(base_channels*2, base_channels, 3, padding=1),
                    nn.BatchNorm2d(base_channels),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(base_channels, base_channels, 3, padding=1),
                    nn.BatchNorm2d(base_channels),
                    nn.ReLU(inplace=True)
                )
                
                # Output layer - outputs correction map in pixel space (-255 to 255)
                # We'll scale this appropriately in forward pass
                self.output = nn.Conv2d(base_channels, 3, 3, padding=1)
                
            def forward(self, x):
                # x is normalized to [-1, 1]
                # Encoder
                enc1 = self.enc1(x)
                enc1_pool = self.pool1(enc1)
                
                enc2 = self.enc2(enc1_pool)
                enc2_pool = self.pool2(enc2)
                
                # Bridge
                bridge = self.bridge(enc2_pool)
                
                # Decoder with skip connections
                up2 = self.up2(bridge)
                up2 = torch.cat([up2, enc2], dim=1)
                dec2 = self.dec2(up2)
                
                up1 = self.up1(dec2)
                up1 = torch.cat([up1, enc1], dim=1)
                dec1 = self.dec1(up1)
                
                # Output correction map
                correction = self.output(dec1)
                
                # Scale to pixel space: [-255, 255] for RGB values
                # The model outputs values roughly in [-1, 1], so scale by 255
                return correction * 255.0
        
        self.denoiser = Denoiser(base_channels=base_channels)
        
        # Loss and optimizer
        # We'll use MSE on the denoised image (not directly on correction map)
        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(self.denoiser.parameters(), lr=0.0002, betas=(0.9, 0.999))
        
        # Device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        self.denoiser.to(self.device)

# ==================== Dataset ====================

class ImageDataset(Dataset):
    def __init__(self, image_paths, image_size=32):
        self.image_paths = image_paths
        self.image_size = image_size
        
        # Simple transform: resize and convert to tensor
        # We'll handle normalization separately
        self.transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
        ])
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        try:
            img = Image.open(self.image_paths[idx]).convert('RGB')
            # Get tensor in [0, 1] range
            img_tensor = self.transform(img)
            return img_tensor
        except Exception as e:
            print(f"Error loading image {self.image_paths[idx]}: {e}")
            # Return a black image as fallback
            return torch.zeros(3, self.image_size, self.image_size)

# ==================== Noise/Blur Utilities ====================

def normalize_to_minus_one_one(tensor):
    """Convert tensor from [0, 1] to [-1, 1]"""
    return tensor * 2 - 1

def denormalize_to_zero_one(tensor):
    """Convert tensor from [-1, 1] to [0, 1]"""
    return (tensor + 1) / 2

def add_gaussian_noise_pixel_space(image_tensor, noise_level):
    """
    Add Gaussian noise in pixel space (0-255)
    image_tensor: [0, 1] range
    noise_level: 0.1 to 0.9 (10% to 90% noise)
    Returns: noisy tensor in [0, 1] range
    """
    if noise_level <= 0:
        return image_tensor
    
    # Convert to pixel space [0, 255]
    pixel_image = image_tensor * 255.0
    
    # Add noise: std = noise_level * 127.5 (so 0.5 = 63.75 std)
    std = noise_level * 127.5
    noise = torch.randn_like(pixel_image) * std
    
    # Add noise and clip to valid pixel range
    noisy_pixel = torch.clamp(pixel_image + noise, 0, 255)
    
    # Convert back to [0, 1]
    return noisy_pixel / 255.0

def apply_gaussian_blur_pil(image_pil, sigma):
    """Apply Gaussian blur using PIL"""
    if sigma <= 0:
        return image_pil
    return image_pil.filter(ImageFilter.GaussianBlur(radius=sigma))

def tensor_to_pil_zero_one(tensor):
    """Convert tensor in [0, 1] range to PIL Image"""
    img = tensor.clamp(0, 1)
    img = transforms.ToPILImage()(img)
    return img

def pil_to_tensor_zero_one(pil_img):
    """Convert PIL Image to tensor in [0, 1] range"""
    transform = transforms.Compose([
        transforms.ToTensor(),
    ])
    return transform(pil_img).unsqueeze(0)  # Add batch dimension

# ==================== GUI Application ====================

class DiffusionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Diffusion Denoiser - Pixel Space")
        self.root.geometry("1200x800")
        
        # Training parameters
        self.image_paths = []
        self.training = False
        self.denoiser = None
        self.current_epoch = 0
        self.message_queue = queue.Queue()
        
        # Settings - all in settings tab
        self.settings = {
            'image_size': tk.IntVar(value=32),
            'base_channels': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=16),
            'learning_rate': tk.DoubleVar(value=0.0002),
            'beta1': tk.DoubleVar(value=0.9),
            'num_workers': tk.IntVar(value=min(4, multiprocessing.cpu_count())),
            'train_noise_level': tk.DoubleVar(value=0.5),
            'train_blur_sigma': tk.DoubleVar(value=1.0),
            'train_blur_enabled': tk.BooleanVar(value=False),
            'train_noise_enabled': tk.BooleanVar(value=True),
            'denoise_noise_level': tk.DoubleVar(value=0.5),
            'denoise_blur_sigma': tk.DoubleVar(value=1.0),
            'denoise_blur_enabled': tk.BooleanVar(value=False),
            'denoise_noise_enabled': tk.BooleanVar(value=True)
        }
        
        # Current images for denoising tab
        self.current_input_image = None
        self.current_output_image = None
        self.current_image_tensor = None  # In [0, 1] range
        
        # GUI Setup
        self.setup_gui()
        
        # Start message handler
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        # Create notebook (tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Training (simplified - just images, epochs, start/stop)
        self.training_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.training_tab, text='Training')
        self.setup_training_tab()
        
        # Tab 2: Settings (all settings here)
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()
        
        # Tab 3: Denoise (simplified - just load, apply, denoise)
        self.denoise_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.denoise_tab, text='Denoise')
        self.setup_denoise_tab()

    def setup_training_tab(self):
        # Main container with grid layout
        main_frame = tk.Frame(self.training_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left panel - Controls
        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # Title
        tk.Label(left_frame, text="Training", 
                font=("Arial", 12, "bold")).pack(pady=(0, 10))
        
        # Image selection
        img_select_frame = tk.LabelFrame(left_frame, text="Training Images", padx=10, pady=10)
        img_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(img_select_frame, text="Add Images", 
                 command=self.add_images, width=20).pack(pady=5)
        tk.Button(img_select_frame, text="Clear All", 
                 command=self.clear_images, width=20).pack(pady=5)
        
        # Image list with scrollbar
        list_frame = tk.Frame(img_select_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.image_listbox = tk.Listbox(list_frame, height=10)
        self.image_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        list_scrollbar = tk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.image_listbox.yview)
        list_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.image_listbox.config(yscrollcommand=list_scrollbar.set)
        
        # Epochs input
        epoch_frame = tk.LabelFrame(left_frame, text="Training Epochs", padx=10, pady=10)
        epoch_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(epoch_frame, text="Number of Epochs:").pack(pady=5)
        self.epoch_var = tk.StringVar(value="50")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=20).pack(pady=5)
        
        # Training controls
        train_frame = tk.LabelFrame(left_frame, text="Training Controls", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Button(train_frame, text="Initialize Denoiser", 
                 command=self.initialize_denoiser, width=20).pack(pady=5)
        
        tk.Button(train_frame, text="Start Training", 
                 command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(train_frame, text="Stop Training", 
                 command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        
        # Right panel - Preview and Log
        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Training samples display
        preview_frame = tk.LabelFrame(right_frame, text="Training Progress", padx=10, pady=10)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create three image frames side by side
        sample_frame = tk.Frame(preview_frame)
        sample_frame.pack(pady=10)
        
        # Original
        orig_frame = tk.LabelFrame(sample_frame, text="Original", padx=5, pady=5)
        orig_frame.pack(side=tk.LEFT, padx=5)
        self.orig_image_label = tk.Label(orig_frame, text="Original", width=96, height=96, bg='gray')
        self.orig_image_label.pack()
        
        # Noisy
        noisy_frame = tk.LabelFrame(sample_frame, text="Noisy Input", padx=5, pady=5)
        noisy_frame.pack(side=tk.LEFT, padx=5)
        self.noisy_image_label = tk.Label(noisy_frame, text="Noisy", width=96, height=96, bg='gray')
        self.noisy_image_label.pack()
        
        # Denoised
        denoised_frame = tk.LabelFrame(sample_frame, text="Denoised", padx=5, pady=5)
        denoised_frame.pack(side=tk.LEFT, padx=5)
        self.denoised_image_label = tk.Label(denoised_frame, text="Denoised", width=96, height=96, bg='gray')
        self.denoised_image_label.pack()
        
        # Training log
        log_frame = tk.LabelFrame(right_frame, text="Training Log", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=12, font=("Courier", 9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        log_scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=log_scrollbar.set)
        
        # Bottom buttons (within the tab, not off-screen)
        bottom_frame = tk.Frame(right_frame)
        bottom_frame.pack(fill=tk.X, pady=(10, 0))
        
        tk.Button(bottom_frame, text="Test Denoise", 
                 command=self.test_denoise, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(bottom_frame, text="Save Model", 
                 command=self.save_model, width=15).pack(side=tk.LEFT, padx=5)
        
        # Status bar at bottom
        self.status_label = tk.Label(self.training_tab, text="Ready", 
                                    relief=tk.SUNKEN, anchor=tk.W, padx=10)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_settings_tab(self):
        # Main container
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create a canvas with scrollbar for many settings
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Title
        tk.Label(scrollable_frame, text="All Settings", 
                font=("Arial", 14, "bold")).pack(pady=(0, 20))
        
        # ========== NETWORK SETTINGS ==========
        net_frame = tk.LabelFrame(scrollable_frame, text="Network Architecture", padx=10, pady=10)
        net_frame.pack(fill=tk.X, pady=(0, 10))
        
        settings_list = [
            ("Base Channels:", 'base_channels', 32, 256),
            ("Batch Size:", 'batch_size', 1, 64),
        ]
        
        for label_text, var_name, min_val, max_val in settings_list:
            frame = tk.Frame(net_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name], 
                    orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # ========== TRAINING SETTINGS ==========
        train_frame = tk.LabelFrame(scrollable_frame, text="Training Parameters", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=(0, 10))
        
        train_settings = [
            ("Learning Rate:", 'learning_rate', 0.00001, 0.01),
            ("Beta1:", 'beta1', 0.0, 0.999),
            ("Number of Workers:", 'num_workers', 1, min(8, multiprocessing.cpu_count() * 2)),
        ]
        
        for label_text, var_name, min_val, max_val in train_settings:
            frame = tk.Frame(train_frame)
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label_text, width=25, anchor='w').pack(side=tk.LEFT)
            
            if var_name in ['learning_rate', 'beta1']:
                resolution = 0.00001 if var_name == 'learning_rate' else 0.001
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200, resolution=resolution).pack(side=tk.RIGHT)
            else:
                tk.Scale(frame, from_=min_val, to=max_val, variable=self.settings[var_name],
                        orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            
            tk.Label(frame, textvariable=self.settings[var_name], width=5).pack(side=tk.RIGHT, padx=5)
        
        # ========== TRAINING AUGMENTATION SETTINGS ==========
        train_aug_frame = tk.LabelFrame(scrollable_frame, text="Training Augmentation Settings", padx=10, pady=10)
        train_aug_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Training noise level
        train_noise_frame = tk.Frame(train_aug_frame)
        train_noise_frame.pack(fill=tk.X, pady=5)
        tk.Label(train_noise_frame, text="Training Noise Level (0.1-0.9):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(train_noise_frame, from_=0.1, to=0.9, variable=self.settings['train_noise_level'],
                orient=tk.HORIZONTAL, length=200, resolution=0.01).pack(side=tk.LEFT, padx=5)
        tk.Label(train_noise_frame, textvariable=self.settings['train_noise_level'], width=4).pack(side=tk.LEFT)
        
        # Training blur sigma
        train_blur_frame = tk.Frame(train_aug_frame)
        train_blur_frame.pack(fill=tk.X, pady=5)
        tk.Label(train_blur_frame, text="Training Blur σ (0-3):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(train_blur_frame, from_=0.0, to=3.0, variable=self.settings['train_blur_sigma'],
                orient=tk.HORIZONTAL, length=200, resolution=0.1).pack(side=tk.LEFT, padx=5)
        tk.Label(train_blur_frame, textvariable=self.settings['train_blur_sigma'], width=4).pack(side=tk.LEFT)
        
        # Training augmentation toggles
        train_toggles_frame = tk.Frame(train_aug_frame)
        train_toggles_frame.pack(fill=tk.X, pady=5)
        
        tk.Checkbutton(train_toggles_frame, text="Enable Blur During Training",
                      variable=self.settings['train_blur_enabled']).pack(side=tk.LEFT, padx=20)
        tk.Checkbutton(train_toggles_frame, text="Enable Noise During Training",
                      variable=self.settings['train_noise_enabled']).pack(side=tk.LEFT, padx=20)
        
        # ========== DENOISE SETTINGS ==========
        denoise_frame = tk.LabelFrame(scrollable_frame, text="Denoise Tab Settings", padx=10, pady=10)
        denoise_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Denoise noise level
        denoise_noise_frame = tk.Frame(denoise_frame)
        denoise_noise_frame.pack(fill=tk.X, pady=5)
        tk.Label(denoise_noise_frame, text="Default Denoise Noise (0.1-0.9):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(denoise_noise_frame, from_=0.1, to=0.9, variable=self.settings['denoise_noise_level'],
                orient=tk.HORIZONTAL, length=200, resolution=0.01).pack(side=tk.LEFT, padx=5)
        tk.Label(denoise_noise_frame, textvariable=self.settings['denoise_noise_level'], width=4).pack(side=tk.LEFT)
        
        # Denoise blur sigma
        denoise_blur_frame = tk.Frame(denoise_frame)
        denoise_blur_frame.pack(fill=tk.X, pady=5)
        tk.Label(denoise_blur_frame, text="Default Denoise Blur σ (0-3):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(denoise_blur_frame, from_=0.0, to=3.0, variable=self.settings['denoise_blur_sigma'],
                orient=tk.HORIZONTAL, length=200, resolution=0.1).pack(side=tk.LEFT, padx=5)
        tk.Label(denoise_blur_frame, textvariable=self.settings['denoise_blur_sigma'], width=4).pack(side=tk.LEFT)
        
        # Denoise augmentation toggles
        denoise_toggles_frame = tk.Frame(denoise_frame)
        denoise_toggles_frame.pack(fill=tk.X, pady=5)
        
        tk.Checkbutton(denoise_toggles_frame, text="Default Blur Enabled",
                      variable=self.settings['denoise_blur_enabled']).pack(side=tk.LEFT, padx=20)
        tk.Checkbutton(denoise_toggles_frame, text="Default Noise Enabled",
                      variable=self.settings['denoise_noise_enabled']).pack(side=tk.LEFT, padx=20)
        
        # ========== SYSTEM INFO ==========
        sys_frame = tk.LabelFrame(scrollable_frame, text="System Information", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=(0, 10))
        
        cpu_count = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU Cores: {cpu_count}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"PyTorch Threads: {torch.get_num_threads()}", anchor='w').pack(fill=tk.X, pady=2)
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}", 
                anchor='w').pack(fill=tk.X, pady=2)
        
        # ========== SAVE/LOAD DEFAULTS ==========
        btn_frame = tk.Frame(scrollable_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(btn_frame, text="Save as Default", 
                 command=self.save_defaults, width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Load Defaults", 
                 command=self.load_defaults, width=15).pack(side=tk.LEFT, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_denoise_tab(self):
        main_frame = tk.Frame(self.denoise_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # TOP ROW: ALL ACTION BUTTONS
        top_frame = tk.Frame(main_frame)
        top_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Left side: Load buttons
        left_buttons = tk.Frame(top_frame)
        left_buttons.pack(side=tk.LEFT)
        
        tk.Button(left_buttons, text="Load Image", 
                 command=self.load_denoise_image, width=15).pack(side=tk.LEFT, padx=2)
        tk.Button(left_buttons, text="Generate Random Noise", 
                 command=self.generate_random_noise, width=20).pack(side=tk.LEFT, padx=2)
        
        # Center: MAIN ACTION BUTTONS
        center_buttons = tk.Frame(top_frame)
        center_buttons.pack(side=tk.LEFT, padx=20)
        
        # DENOISE button (main feature)
        tk.Button(center_buttons, text="DENOISE", 
                 command=self.denoise_image, width=15, bg="lightblue",
                 font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=2)
        
        # Output → Input button
        tk.Button(center_buttons, text="Output → Input", 
                 command=self.swap_output_to_input, width=15).pack(side=tk.LEFT, padx=2)
        
        # Right side: Save and Load Model
        right_buttons = tk.Frame(top_frame)
        right_buttons.pack(side=tk.RIGHT)
        
        tk.Button(right_buttons, text="Save Output", 
                 command=self.save_output_image, width=15).pack(side=tk.LEFT, padx=2)
        tk.Button(right_buttons, text="Load Model", 
                 command=self.load_denoiser, width=15).pack(side=tk.LEFT, padx=2)
        
        # Denoising parameters frame
        params_frame = tk.LabelFrame(main_frame, text="Denoising Parameters", padx=10, pady=10)
        params_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Apply mode selection
        mode_frame = tk.Frame(params_frame)
        mode_frame.pack(fill=tk.X, pady=5)
        tk.Label(mode_frame, text="Apply:", width=10, anchor='w').pack(side=tk.LEFT)
        
        self.apply_mode = tk.StringVar(value="blur_then_noise")
        tk.Radiobutton(mode_frame, text="Blur then Noise", variable=self.apply_mode,
                      value="blur_then_noise").pack(side=tk.LEFT, padx=10)
        tk.Radiobutton(mode_frame, text="Noise Only", variable=self.apply_mode,
                      value="noise_only").pack(side=tk.LEFT, padx=10)
        tk.Radiobutton(mode_frame, text="Blur Only", variable=self.apply_mode,
                      value="blur_only").pack(side=tk.LEFT, padx=10)
        
        # Noise level (10-90%)
        noise_frame = tk.Frame(params_frame)
        noise_frame.pack(fill=tk.X, pady=5)
        tk.Label(noise_frame, text="Noise Level (0.1-0.9):", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(noise_frame, from_=0.1, to=0.9, variable=self.settings['denoise_noise_level'],
                orient=tk.HORIZONTAL, length=200, resolution=0.01).pack(side=tk.LEFT, padx=5)
        tk.Label(noise_frame, textvariable=self.settings['denoise_noise_level'], width=4).pack(side=tk.LEFT)
        
        # Blur sigma
        blur_frame = tk.Frame(params_frame)
        blur_frame.pack(fill=tk.X, pady=5)
        tk.Label(blur_frame, text="Blur σ (0-3):", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(blur_frame, from_=0.0, to=3.0, variable=self.settings['denoise_blur_sigma'],
                orient=tk.HORIZONTAL, length=200, resolution=0.1).pack(side=tk.LEFT, padx=5)
        tk.Label(blur_frame, textvariable=self.settings['denoise_blur_sigma'], width=4).pack(side=tk.LEFT)
        
        # Apply noise/blur button
        apply_frame = tk.Frame(params_frame)
        apply_frame.pack(fill=tk.X, pady=5)
        tk.Button(apply_frame, text="Apply Noise/Blur to Input", 
                 command=self.apply_noise_to_input, width=25).pack(side=tk.LEFT, padx=5)
        
        # Image display area
        display_frame = tk.Frame(main_frame)
        display_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Input image
        input_frame = tk.LabelFrame(display_frame, text="Input Image", padx=10, pady=10)
        input_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        self.input_image_label = tk.Label(input_frame, text="No image loaded", 
                                         width=128, height=128, bg='gray')
        self.input_image_label.pack(pady=10)
        
        # Output image
        output_frame = tk.LabelFrame(display_frame, text="Output Image", padx=10, pady=10)
        output_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0))
        
        self.output_image_label = tk.Label(output_frame, text="Denoised will appear here", 
                                          width=128, height=128, bg='gray')
        self.output_image_label.pack(pady=10)
        
        # Info label at bottom
        info_label = tk.Label(main_frame, 
                             text="1. Load Model → 2. Load Image/Generate Noise → 3. Apply Noise/Blur (optional) → 4. Click DENOISE",
                             font=("Arial", 9), fg="gray")
        info_label.pack(pady=(5, 0))

    def update_size_display(self):
        """Update image size display in training tab"""
        size = self.settings['image_size'].get()
        self.size_display.config(text=f"Image Size: {size}x{size}")

    def log_message(self, message):
        """Thread-safe logging"""
        self.message_queue.put(message)

    def process_messages(self):
        """Process messages from queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                # Add to log
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {message}\n")
                self.log_text.see(tk.END)
                
                # Update status with first line
                lines = message.split('\n')
                self.status_label.config(text=lines[0][:50])
                
                print(message)  # Also print to console
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        """Add multiple image files"""
        files = filedialog.askopenfilenames(
            title="Select training images",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        for file in files:
            if file not in self.image_paths:
                self.image_paths.append(file)
                filename = os.path.basename(file)
                self.image_listbox.insert(tk.END, filename)
        
        count = len(files)
        self.log_message(f"Added {count} image{'s' if count != 1 else ''}. Total: {len(self.image_paths)}")

    def clear_images(self):
        """Clear all selected images"""
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_message("Cleared all training images")

    def initialize_denoiser(self):
        """Initialize denoiser with current settings"""
        try:
            image_size = self.settings['image_size'].get()
            base_channels = self.settings['base_channels'].get()
            
            self.denoiser = DiffusionDenoiser(
                image_size=image_size,
                base_channels=base_channels
            )
            
            self.log_message(f"Initialized Pixel Space Denoiser for {image_size}x{image_size} images")
            self.log_message(f"Base channels: {base_channels}")
            self.log_message(f"Correction map range: [-255, 255] (pixel space)")
            self.log_message(f"Using {torch.get_num_threads()} CPU threads")
            
        except Exception as e:
            self.log_message(f"Error initializing denoiser: {str(e)}")
            import traceback
            traceback.print_exc()

    def start_training(self):
        """Start training thread"""
        if not self.image_paths:
            self.log_message("Error: No training images added!")
            return
        
        if not self.denoiser:
            self.log_message("Error: Denoiser not initialized!")
            return
        
        if self.training:
            self.log_message("Training already in progress!")
            return
        
        try:
            epochs = int(self.epoch_var.get())
            self.training = True
            self.current_epoch = 0
            self.start_time = time.time()
            
            # Get settings
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            lr = self.settings['learning_rate'].get()
            beta1 = self.settings['beta1'].get()
            train_noise = self.settings['train_noise_level'].get()
            train_blur = self.settings['train_blur_sigma'].get()
            use_blur = self.settings['train_blur_enabled'].get()
            use_noise = self.settings['train_noise_enabled'].get()
            
            # Update optimizer with new settings
            for param_group in self.denoiser.optimizer.param_groups:
                param_group['lr'] = lr
                param_group['betas'] = (beta1, 0.999)
            
            # Start training thread
            thread = threading.Thread(
                target=self.train_denoiser,
                args=(epochs, batch_size, num_workers, train_noise, train_blur, use_blur, use_noise),
                daemon=True
            )
            thread.start()
            
            self.log_message(f"Started training for {epochs} epochs")
            self.log_message(f"Batch size: {batch_size}, Workers: {num_workers}")
            self.log_message(f"Learning rate: {lr}, Beta1: {beta1}")
            self.log_message(f"Training: Blur={'Yes' if use_blur else 'No'} (σ={train_blur:.1f}), "
                           f"Noise={'Yes' if use_noise else 'No'} (level={train_noise:.2f})")
            
        except ValueError:
            self.log_message("Error: Invalid number of epochs!")
        except Exception as e:
            self.log_message(f"Error starting training: {str(e)}")

    def train_denoiser(self, epochs, batch_size, num_workers, train_noise, train_blur, use_blur, use_noise):
        """Training loop in separate thread"""
        try:
            image_size = self.settings['image_size'].get()
            
            # Create dataset and dataloader
            dataset = ImageDataset(self.image_paths, image_size)
            dataloader = DataLoader(
                dataset, 
                batch_size=batch_size, 
                shuffle=True,
                num_workers=min(num_workers, multiprocessing.cpu_count()),
                pin_memory=torch.cuda.is_available(),
                persistent_workers=True if num_workers > 0 else False
            )
            
            for epoch in range(epochs):
                if not self.training:
                    break
                
                self.current_epoch = epoch
                total_loss = 0
                batch_count = 0
                epoch_start = time.time()
                
                for batch_idx, clean_images in enumerate(dataloader):
                    if not self.training:
                        break
                    
                    batch_size_actual = clean_images.size(0)
                    # Clean images are in [0, 1] range
                    clean_images = clean_images.to(self.denoiser.device)
                    
                    # Start with clean images
                    noisy_images = clean_images.clone()
                    
                    # Apply blur if enabled (FIRST, as requested: blur then noise)
                    if use_blur and train_blur > 0:
                        # Process each image in batch
                        for i in range(batch_size_actual):
                            img_pil = tensor_to_pil_zero_one(noisy_images[i].cpu())
                            img_blurred = apply_gaussian_blur_pil(img_pil, train_blur)
                            img_tensor = pil_to_tensor_zero_one(img_blurred).squeeze(0)
                            noisy_images[i] = img_tensor.to(self.denoiser.device)
                    
                    # Apply noise if enabled (SECOND, after blur)
                    if use_noise and train_noise > 0:
                        noisy_images = add_gaussian_noise_pixel_space(noisy_images, train_noise)
                    
                    # Convert to [-1, 1] range for network input
                    noisy_input = normalize_to_minus_one_one(noisy_images)
                    
                    # Train denoiser
                    self.denoiser.optimizer.zero_grad()
                    
                    # Network outputs correction map in pixel space [-255, 255]
                    correction_map = self.denoiser.denoiser(noisy_input)
                    
                    # Apply correction: noisy (in pixel space) + correction = denoised
                    # Convert noisy images to pixel space [0, 255]
                    noisy_pixel = noisy_images * 255.0
                    denoised_pixel = noisy_pixel + correction_map
                    
                    # Clip to valid pixel range and convert back to [0, 1]
                    denoised = torch.clamp(denoised_pixel, 0, 255) / 255.0
                    
                    # Loss: difference between denoised and clean (both in [0, 1])
                    loss = self.denoiser.criterion(denoised, clean_images)
                    
                    loss.backward()
                    self.denoiser.optimizer.step()
                    
                    total_loss += loss.item()
                    batch_count += 1
                    
                    # Update training samples display every 10 batches
                    if batch_idx % 10 == 0 and batch_idx > 0:
                        self.update_training_samples(clean_images, noisy_images, denoised)
                
                if batch_count > 0:
                    avg_loss = total_loss / batch_count
                    epoch_time = time.time() - epoch_start
                    
                    # Log progress
                    elapsed = time.time() - self.start_time
                    self.log_message(f"Epoch {epoch+1}/{epochs} | "
                                   f"Loss: {avg_loss:.6f} | "
                                   f"Time: {epoch_time:.1f}s | "
                                   f"Total: {elapsed:.1f}s")
                    
                    # Update training samples at end of epoch
                    if epoch == 0 or (epoch + 1) % 5 == 0:
                        self.update_training_samples(clean_images, noisy_images, denoised, force=True)
                else:
                    self.log_message(f"Epoch {epoch+1}/{epochs} - No batches processed")
            
            self.training = False
            self.log_message("Training completed!")
            
        except Exception as e:
            self.log_message(f"Training error: {str(e)}")
            self.training = False
            import traceback
            traceback.print_exc()
        finally:
            self.training = False

    def update_training_samples(self, clean_images, noisy_images, denoised_images, force=False):
        """Update training sample display"""
        if not force and (self.current_epoch % 5 != 0):
            return
        
        try:
            # Get first image from batch
            clean_img = clean_images[0].cpu()
            noisy_img = noisy_images[0].cpu()
            denoised_img = denoised_images[0].cpu()
            
            # Convert to PIL (already in [0, 1] range)
            clean_pil = tensor_to_pil_zero_one(clean_img).resize((96, 96), Image.Resampling.LANCZOS)
            noisy_pil = tensor_to_pil_zero_one(noisy_img).resize((96, 96), Image.Resampling.LANCZOS)
            denoised_pil = tensor_to_pil_zero_one(denoised_img).resize((96, 96), Image.Resampling.LANCZOS)
            
            # Convert to PhotoImage
            clean_photo = ImageTk.PhotoImage(clean_pil)
            noisy_photo = ImageTk.PhotoImage(noisy_pil)
            denoised_photo = ImageTk.PhotoImage(denoised_pil)
            
            # Update labels
            self.orig_image_label.config(image=clean_photo, text="")
            self.orig_image_label.image = clean_photo
            
            self.noisy_image_label.config(image=noisy_photo, text="")
            self.noisy_image_label.image = noisy_photo
            
            self.denoised_image_label.config(image=denoised_photo, text="")
            self.denoised_image_label.image = denoised_photo
            
        except Exception as e:
            self.log_message(f"Error updating training samples: {str(e)}")

    def stop_training(self):
        """Stop training"""
        if self.training:
            self.training = False
            self.log_message("Training stopped by user")

    def test_denoise(self):
        """Test denoising on a random training image"""
        if not self.denoiser or not self.image_paths:
            self.log_message("Error: No model or images to test!")
            return
        
        try:
            # Load a random image
            random_idx = random.randint(0, len(self.image_paths) - 1)
            img = Image.open(self.image_paths[random_idx]).convert('RGB')
            
            # Resize and convert to tensor
            img = img.resize((self.settings['image_size'].get(), 
                            self.settings['image_size'].get()))
            img_tensor = pil_to_tensor_zero_one(img).to(self.denoiser.device)
            
            # Get training settings
            train_noise = self.settings['train_noise_level'].get()
            train_blur = self.settings['train_blur_sigma'].get()
            use_blur = self.settings['train_blur_enabled'].get()
            use_noise = self.settings['train_noise_enabled'].get()
            
            # Apply blur then noise (same as training)
            noisy_tensor = img_tensor.clone()
            
            if use_blur and train_blur > 0:
                img_pil = tensor_to_pil_zero_one(noisy_tensor.squeeze(0).cpu())
                img_blurred = apply_gaussian_blur_pil(img_pil, train_blur)
                noisy_tensor = pil_to_tensor_zero_one(img_blurred).to(self.denoiser.device)
            
            if use_noise and train_noise > 0:
                noisy_tensor = add_gaussian_noise_pixel_space(noisy_tensor, train_noise)
            
            # Convert to [-1, 1] for network
            noisy_input = normalize_to_minus_one_one(noisy_tensor)
            
            # Denoise
            with torch.no_grad():
                correction = self.denoiser.denoiser(noisy_input)
                # Apply correction in pixel space
                noisy_pixel = noisy_tensor * 255.0
                denoised_pixel = noisy_pixel + correction
                denoised = torch.clamp(denoised_pixel, 0, 255) / 255.0
            
            # Update display
            clean_pil = tensor_to_pil_zero_one(img_tensor.squeeze(0)).resize((96, 96), Image.Resampling.LANCZOS)
            noisy_pil = tensor_to_pil_zero_one(noisy_tensor.squeeze(0)).resize((96, 96), Image.Resampling.LANCZOS)
            denoised_pil = tensor_to_pil_zero_one(denoised.squeeze(0)).resize((96, 96), Image.Resampling.LANCZOS)
            
            clean_photo = ImageTk.PhotoImage(clean_pil)
            noisy_photo = ImageTk.PhotoImage(noisy_pil)
            denoised_photo = ImageTk.PhotoImage(denoised_pil)
            
            self.orig_image_label.config(image=clean_photo, text="")
            self.orig_image_label.image = clean_photo
            
            self.noisy_image_label.config(image=noisy_photo, text="")
            self.noisy_image_label.image = noisy_photo
            
            self.denoised_image_label.config(image=denoised_photo, text="")
            self.denoised_image_label.image = denoised_photo
            
            self.log_message(f"Test denoising on image {os.path.basename(self.image_paths[random_idx])}")
            
        except Exception as e:
            self.log_message(f"Error testing denoising: {str(e)}")

    def save_model(self):
        """Save current model"""
        if not self.denoiser:
            self.log_message("Error: No model to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".pth",
            filetypes=[("PyTorch models", "*.pth"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                torch.save({
                    'epoch': self.current_epoch,
                    'denoiser_state_dict': self.denoiser.denoiser.state_dict(),
                    'optimizer_state_dict': self.denoiser.optimizer.state_dict(),
                    'image_size': self.settings['image_size'].get(),
                    'base_channels': self.settings['base_channels'].get(),
                }, filename)
                
                self.log_message(f"Model saved to {filename}")
                
            except Exception as e:
                self.log_message(f"Error saving model: {str(e)}")

    def load_denoiser(self):
        """Load denoiser from file (for denoising tab)"""
        filename = filedialog.askopenfilename(
            filetypes=[("PyTorch models", "*.pth *.pt"), ("All files", "*.*")]
        )
        
        if filename and os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location='cpu')
                
                # Initialize denoiser with saved settings
                image_size = checkpoint.get('image_size', 32)
                base_channels = checkpoint.get('base_channels', 64)
                
                self.denoiser = DiffusionDenoiser(
                    image_size=image_size,
                    base_channels=base_channels
                )
                
                # Load state dict
                self.denoiser.denoiser.load_state_dict(checkpoint['denoiser_state_dict'])
                
                self.log_message(f"Loaded denoiser from {filename}")
                self.log_message(f"Model was trained for {checkpoint.get('epoch', 'unknown')} epochs")
                
            except Exception as e:
                self.log_message(f"Error loading model: {str(e)}")

    def load_denoise_image(self):
        """Load image for denoising tab"""
        filename = filedialog.askopenfilename(
            title="Select image to denoise",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tiff")]
        )
        
        if filename:
            try:
                img = Image.open(filename).convert('RGB')
                # Resize to model's expected size
                image_size = self.settings['image_size'].get()
                img = img.resize((image_size, image_size))
                
                # Store as tensor in [0, 1] range
                self.current_image_tensor = pil_to_tensor_zero_one(img)
                
                # Display
                display_img = img.resize((128, 128), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(display_img)
                
                self.input_image_label.config(image=photo, text="")
                self.input_image_label.image = photo
                
                # Store as PIL for later use
                self.current_input_image = img
                self.current_output_image = None
                
                self.log_message(f"Loaded image: {os.path.basename(filename)}")
                
            except Exception as e:
                self.log_message(f"Error loading image: {str(e)}")

    def generate_random_noise(self):
        """Generate random noise image"""
        try:
            image_size = self.settings['image_size'].get()
            # Create random noise in [0, 1] range
            noise = torch.rand(1, 3, image_size, image_size)
            
            # Store as tensor
            self.current_image_tensor = noise
            
            # Convert to PIL
            img = tensor_to_pil_zero_one(noise.squeeze(0))
            
            # Display
            display_img = img.resize((128, 128), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(display_img)
            
            self.input_image_label.config(image=photo, text="")
            self.input_image_label.image = photo
            
            # Store as PIL
            self.current_input_image = img
            self.current_output_image = None
            
            self.log_message("Generated random noise image")
            
        except Exception as e:
            self.log_message(f"Error generating noise: {str(e)}")

    def apply_noise_to_input(self):
        """Apply noise and/or blur to current input image based on selected mode"""
        if self.current_image_tensor is None:
            self.log_message("Error: No image loaded!")
            return
        
        try:
            # Get parameters from settings
            noise_level = self.settings['denoise_noise_level'].get()
            blur_sigma = self.settings['denoise_blur_sigma'].get()
            apply_mode = self.apply_mode.get()
            
            # Start with clean tensor
            noisy_tensor = self.current_image_tensor.clone().squeeze(0)  # Remove batch dim
            
            # Apply based on selected mode
            if apply_mode == "blur_then_noise":
                # Apply blur first, then noise
                if blur_sigma > 0:
                    img_pil = tensor_to_pil_zero_one(noisy_tensor)
                    img_blurred = apply_gaussian_blur_pil(img_pil, blur_sigma)
                    noisy_tensor = pil_to_tensor_zero_one(img_blurred).squeeze(0)
                if noise_level > 0:
                    noisy_tensor = add_gaussian_noise_pixel_space(noisy_tensor.unsqueeze(0), noise_level).squeeze(0)
                    
            elif apply_mode == "noise_only":
                # Apply noise only
                if noise_level > 0:
                    noisy_tensor = add_gaussian_noise_pixel_space(noisy_tensor.unsqueeze(0), noise_level).squeeze(0)
                    
            elif apply_mode == "blur_only":
                # Apply blur only
                if blur_sigma > 0:
                    img_pil = tensor_to_pil_zero_one(noisy_tensor)
                    img_blurred = apply_gaussian_blur_pil(img_pil, blur_sigma)
                    noisy_tensor = pil_to_tensor_zero_one(img_blurred).squeeze(0)
            
            # Convert to PIL for display
            noisy_pil = tensor_to_pil_zero_one(noisy_tensor)
            display_img = noisy_pil.resize((128, 128), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(display_img)
            
            self.input_image_label.config(image=photo, text="")
            self.input_image_label.image = photo
            
            # Update current tensor (add batch dim back)
            self.current_image_tensor = noisy_tensor.unsqueeze(0)
            self.current_input_image = noisy_pil
            
            self.log_message(f"Applied: {apply_mode.replace('_', ' ').title()} (noise={noise_level:.2f}, blur σ={blur_sigma:.1f})")
            
        except Exception as e:
            self.log_message(f"Error applying noise/blur: {str(e)}")

    def denoise_image(self):
        """Denoise current input image"""
        if not self.denoiser:
            self.log_message("Error: No denoiser model loaded!")
            return
        
        if self.current_image_tensor is None:
            self.log_message("Error: No image to denoise!")
            return
        
        try:
            # Move tensor to device
            input_tensor = self.current_image_tensor.to(self.denoiser.device)
            
            # Convert to [-1, 1] for network
            input_normalized = normalize_to_minus_one_one(input_tensor)
            
            # Denoise
            with torch.no_grad():
                correction = self.denoiser.denoiser(input_normalized)
                # Apply correction in pixel space
                input_pixel = input_tensor * 255.0
                output_pixel = input_pixel + correction
                output_tensor = torch.clamp(output_pixel, 0, 255) / 255.0
            
            # Convert to PIL
            output_pil = tensor_to_pil_zero_one(output_tensor.squeeze(0).cpu())
            
            # Display
            display_img = output_pil.resize((128, 128), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(display_img)
            
            self.output_image_label.config(image=photo, text="")
            self.output_image_label.image = photo
            
            # Store output
            self.current_output_image = output_pil
            
            self.log_message("Denoised image (pixel space correction)")
            
        except Exception as e:
            self.log_message(f"Error denoising: {str(e)}")

    def swap_output_to_input(self):
        """Swap output image to input for further processing"""
        if self.current_output_image is None:
            self.log_message("Error: No output image to swap!")
            return
        
        # Swap images
        self.current_input_image = self.current_output_image
        self.current_image_tensor = pil_to_tensor_zero_one(self.current_input_image)
        
        # Update input display
        display_img = self.current_input_image.resize((128, 128), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(display_img)
        
        self.input_image_label.config(image=photo, text="")
        self.input_image_label.image = photo
        
        # Clear output
        self.output_image_label.config(image="", text="Denoised will appear here", bg='gray')
        self.current_output_image = None
        
        self.log_message("Swapped output to input")

    def save_output_image(self):
        """Save output image to file"""
        if self.current_output_image is None:
            self.log_message("Error: No output image to save!")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                self.current_output_image.save(filename)
                self.log_message(f"Saved output to {filename}")
            except Exception as e:
                self.log_message(f"Error saving image: {str(e)}")

    def save_defaults(self):
        """Save current settings as defaults"""
        try:
            defaults = {k: v.get() for k, v in self.settings.items()}
            import json
            with open('denoiser_defaults.json', 'w') as f:
                json.dump(defaults, f, indent=2)
            self.log_message("Settings saved as defaults")
        except Exception as e:
            self.log_message(f"Error saving defaults: {str(e)}")

    def load_defaults(self):
        """Load saved defaults"""
        try:
            import json
            if os.path.exists('denoiser_defaults.json'):
                with open('denoiser_defaults.json', 'r') as f:
                    defaults = json.load(f)
                
                for key, value in defaults.items():
                    if key in self.settings:
                        self.settings[key].set(value)
                
                self.update_size_display()
                self.log_message("Loaded saved defaults")
            else:
                self.log_message("No defaults file found")
        except Exception as e:
            self.log_message(f"Error loading defaults: {str(e)}")

# ==================== Main ====================

if __name__ == "__main__":
    print("Starting Pixel Space Diffusion Denoiser...")
    print(f"Available CPU cores: {multiprocessing.cpu_count()}")
    print(f"PyTorch version: {torch.__version__}")
    
    # Set multiprocessing start method
    try:
        multiprocessing.set_start_method('spawn', force=True)
    except RuntimeError:
        pass
    
    root = tk.Tk()
    app = DiffusionApp(root)
    root.mainloop()