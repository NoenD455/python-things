import os
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

from PIL import Image, ImageTk

# ----------------------------------------------------------------------
# Helper functions
# ----------------------------------------------------------------------
SUPPORTED_IMG_EXT = {'.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tiff', '.webp'}


def is_image_file(filename: str) -> bool:
    """Return True if filename has a supported image extension."""
    return Path(filename).suffix.lower() in SUPPORTED_IMG_EXT


def get_images_recursive(root_dir: str, max_depth: int = 10) -> list:
    """
    Walk through root_dir up to max_depth (folder nesting level).
    Return list of absolute paths of all image files found.
    """
    images = []
    root_path = Path(root_dir).resolve()
    for dirpath, _, filenames in os.walk(root_path):
        # compute depth relative to root_dir
        rel_path = Path(dirpath).relative_to(root_path)
        depth = 0 if str(rel_path) == '.' else len(rel_path.parts)
        if depth > max_depth:
            continue
        for f in filenames:
            if is_image_file(f):
                images.append(os.path.join(dirpath, f))
    return images


def crop_to_1_1(image: Image.Image) -> Image.Image:
    """Crop the image to a centered square (1:1 aspect ratio)."""
    width, height = image.size
    side = min(width, height)
    left = (width - side) // 2
    top = (height - side) // 2
    return image.crop((left, top, left + side, top + side))


def resize_image(image: Image.Image, target_size: tuple, resample_filter) -> Image.Image:
    """Resize image to target_size using given resample filter."""
    return image.resize(target_size, resample_filter)


# ----------------------------------------------------------------------
# Single Processing Tab (Spritesheet Cutter)
# ----------------------------------------------------------------------
class SingleProcessingTab(ttk.Frame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.selected_image_path = None

        # --- UI elements ---
        # Image selection
        ttk.Label(self, text="Spritesheet Image:").grid(row=0, column=0, sticky='w', padx=5, pady=5)
        self.img_path_var = tk.StringVar()
        ttk.Entry(self, textvariable=self.img_path_var, width=50).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(self, text="Browse...", command=self.browse_image).grid(row=0, column=2, padx=5, pady=5)

        # Tiles configuration
        ttk.Label(self, text="Horizontal Tiles (columns):").grid(row=1, column=0, sticky='w', padx=5, pady=5)
        self.h_tiles_var = tk.IntVar(value=2)
        ttk.Spinbox(self, from_=1, to=100, textvariable=self.h_tiles_var, width=10).grid(row=1, column=1, sticky='w', padx=5, pady=5)

        ttk.Label(self, text="Vertical Tiles (rows):").grid(row=2, column=0, sticky='w', padx=5, pady=5)
        self.v_tiles_var = tk.IntVar(value=2)
        ttk.Spinbox(self, from_=1, to=100, textvariable=self.v_tiles_var, width=10).grid(row=2, column=1, sticky='w', padx=5, pady=5)

        # Info label
        self.info_label = ttk.Label(self, text="No image selected", foreground="gray")
        self.info_label.grid(row=3, column=0, columnspan=3, sticky='w', padx=5, pady=5)

        # Cut button
        self.cut_btn = ttk.Button(self, text="Cut Spritesheet", command=self.cut_spritesheet, state='disabled')
        self.cut_btn.grid(row=4, column=0, columnspan=3, pady=10)

        # Status text area
        self.status_text = tk.Text(self, height=12, width=80, wrap='word')
        self.status_text.grid(row=5, column=0, columnspan=3, padx=5, pady=5)
        scroll = ttk.Scrollbar(self, orient='vertical', command=self.status_text.yview)
        scroll.grid(row=5, column=3, sticky='ns')
        self.status_text.configure(yscrollcommand=scroll.set)

    def browse_image(self):
        filepath = filedialog.askopenfilename(
            title="Select Spritesheet Image",
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.gif *.tiff *.webp"),
                       ("All files", "*.*")]
        )
        if filepath:
            self.selected_image_path = filepath
            self.img_path_var.set(filepath)
            self.cut_btn.config(state='normal')
            # Show image dimensions
            try:
                with Image.open(filepath) as img:
                    w, h = img.size
                    self.info_label.config(text=f"Image size: {w} x {h} pixels", foreground="black")
            except Exception as e:
                self.info_label.config(text=f"Error reading image: {e}", foreground="red")

    def cut_spritesheet(self):
        if not self.selected_image_path or not os.path.isfile(self.selected_image_path):
            messagebox.showerror("Error", "Please select a valid image file.")
            return

        h_tiles = self.h_tiles_var.get()
        v_tiles = self.v_tiles_var.get()
        if h_tiles <= 0 or v_tiles <= 0:
            messagebox.showerror("Error", "Number of tiles must be positive.")
            return

        try:
            img = Image.open(self.selected_image_path)
            img_width, img_height = img.size

            tile_width = img_width // h_tiles
            tile_height = img_height // h_tiles  # wait, should be // v_tiles! Fix
            # Correction:
            tile_width = img_width // h_tiles
            tile_height = img_height // v_tiles

            if tile_width == 0 or tile_height == 0:
                messagebox.showerror("Error", "Tile size is zero. Increase number of tiles or use larger image.")
                return

            # Warn if division not exact
            if img_width % h_tiles != 0 or img_height % v_tiles != 0:
                msg = (f"Warning: Image dimensions not perfectly divisible by tile counts.\n"
                       f"Tile size will be {tile_width}x{tile_height} (floor).")
                if not messagebox.askyesno("Divisibility Warning", msg + "\n\nContinue anyway?"):
                    return

            # Create output directory: same folder as spritesheet, subfolder named after spritesheet (without extension)
            base_name = Path(self.selected_image_path).stem
            output_dir = Path(self.selected_image_path).parent / base_name
            output_dir.mkdir(exist_ok=True)

            self.status_text.insert(tk.END, f"Cutting spritesheet into {v_tiles}x{h_tiles} tiles...\n")
            self.status_text.see(tk.END)
            self.update_idletasks()

            # Cut tiles
            tile_index = 0
            for row in range(v_tiles):
                for col in range(h_tiles):
                    left = col * tile_width
                    top = row * tile_height
                    right = left + tile_width
                    bottom = top + tile_height
                    tile = img.crop((left, top, right, bottom))
                    tile_filename = output_dir / f"tile{tile_index:04d}.png"
                    tile.save(tile_filename, "PNG")
                    tile_index += 1

            self.status_text.insert(tk.END, f"Success! Saved {tile_index} tiles to:\n{output_dir}\n\n")
            self.status_text.see(tk.END)
            messagebox.showinfo("Complete", f"Spritesheet cut into {tile_index} tiles.\nSaved in: {output_dir}")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to cut spritesheet:\n{e}")
            self.status_text.insert(tk.END, f"ERROR: {e}\n\n")


# ----------------------------------------------------------------------
# Batch Processing Tab (Recursive Resizing)
# ----------------------------------------------------------------------
class BatchProcessingTab(ttk.Frame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.running = False
        self.cancel_flag = False

        # --- UI elements ---
        # Input folder
        ttk.Label(self, text="Input Folder (root):").grid(row=0, column=0, sticky='w', padx=5, pady=5)
        self.input_path_var = tk.StringVar()
        ttk.Entry(self, textvariable=self.input_path_var, width=50).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(self, text="Browse...", command=self.browse_input).grid(row=0, column=2, padx=5, pady=5)

        # Output folder
        ttk.Label(self, text="Output Folder:").grid(row=1, column=0, sticky='w', padx=5, pady=5)
        self.output_path_var = tk.StringVar()
        ttk.Entry(self, textvariable=self.output_path_var, width=50).grid(row=1, column=1, padx=5, pady=5)
        ttk.Button(self, text="Browse...", command=self.browse_output).grid(row=1, column=2, padx=5, pady=5)

        # Target size
        ttk.Label(self, text="Target Width (px):").grid(row=2, column=0, sticky='w', padx=5, pady=5)
        self.width_var = tk.IntVar(value=128)
        ttk.Spinbox(self, from_=1, to=5000, textvariable=self.width_var, width=10).grid(row=2, column=1, sticky='w', padx=5, pady=5)

        ttk.Label(self, text="Target Height (px):").grid(row=3, column=0, sticky='w', padx=5, pady=5)
        self.height_var = tk.IntVar(value=128)
        ttk.Spinbox(self, from_=1, to=5000, textvariable=self.height_var, width=10).grid(row=3, column=1, sticky='w', padx=5, pady=5)

        # Crop to 1:1 before resizing
        self.crop_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(self, text="Crop to 1:1 (centered square) before resizing", variable=self.crop_var).grid(row=4, column=0, columnspan=3, sticky='w', padx=5, pady=5)

        # Resampling method
        ttk.Label(self, text="Resampling Filter:").grid(row=5, column=0, sticky='w', padx=5, pady=5)
        self.resample_var = tk.StringVar(value="Bilinear")
        rb_bilinear = ttk.Radiobutton(self, text="Bilinear", variable=self.resample_var, value="Bilinear")
        rb_nearest = ttk.Radiobutton(self, text="Nearest", variable=self.resample_var, value="Nearest")
        rb_bilinear.grid(row=5, column=1, sticky='w')
        rb_nearest.grid(row=5, column=2, sticky='w')

        # Recursion depth limit (as requested: max 10)
        ttk.Label(self, text="Max recursion depth:").grid(row=6, column=0, sticky='w', padx=5, pady=5)
        self.depth_var = tk.IntVar(value=10)
        ttk.Spinbox(self, from_=1, to=20, textvariable=self.depth_var, width=5).grid(row=6, column=1, sticky='w', padx=5, pady=5)

        # Progress bar and status
        self.progress_var = tk.IntVar()
        self.progress_bar = ttk.Progressbar(self, variable=self.progress_var, maximum=100)
        self.progress_bar.grid(row=7, column=0, columnspan=3, sticky='ew', padx=5, pady=5)

        self.status_label = ttk.Label(self, text="Ready")
        self.status_label.grid(row=8, column=0, columnspan=3, sticky='w', padx=5, pady=2)

        self.start_btn = ttk.Button(self, text="Start Batch Resize", command=self.start_batch)
        self.start_btn.grid(row=9, column=0, pady=10)

        self.cancel_btn = ttk.Button(self, text="Cancel", command=self.cancel_batch, state='disabled')
        self.cancel_btn.grid(row=9, column=1, pady=10)

        # Log text area
        self.log_text = tk.Text(self, height=12, width=80, wrap='word')
        self.log_text.grid(row=10, column=0, columnspan=3, padx=5, pady=5)
        scroll = ttk.Scrollbar(self, orient='vertical', command=self.log_text.yview)
        scroll.grid(row=10, column=3, sticky='ns')
        self.log_text.configure(yscrollcommand=scroll.set)

    def browse_input(self):
        folder = filedialog.askdirectory(title="Select Input Root Folder")
        if folder:
            self.input_path_var.set(folder)

    def browse_output(self):
        folder = filedialog.askdirectory(title="Select Output Folder")
        if folder:
            self.output_path_var.set(folder)

    def log(self, message):
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.update_idletasks()

    def start_batch(self):
        input_dir = self.input_path_var.get().strip()
        output_dir = self.output_path_var.get().strip()
        if not input_dir or not os.path.isdir(input_dir):
            messagebox.showerror("Error", "Please select a valid input folder.")
            return
        if not output_dir:
            messagebox.showerror("Error", "Please select an output folder.")
            return
        if self.width_var.get() <= 0 or self.height_var.get() <= 0:
            messagebox.showerror("Error", "Target width and height must be positive.")
            return

        self.running = True
        self.cancel_flag = False
        self.start_btn.config(state='disabled')
        self.cancel_btn.config(state='normal')
        self.progress_var.set(0)
        self.log_text.delete(1.0, tk.END)
        self.log("Starting batch resize...")
        self.log(f"Input root: {input_dir}")
        self.log(f"Output root: {output_dir}")

        # Run processing in a separate thread
        thread = threading.Thread(target=self.process_batch, args=(input_dir, output_dir), daemon=True)
        thread.start()

    def cancel_batch(self):
        if self.running:
            self.cancel_flag = True
            self.log("Cancelling... (will stop after current image)")
            self.cancel_btn.config(state='disabled')

    def process_batch(self, input_root, output_root):
        try:
            max_depth = self.depth_var.get()
            self.log(f"Scanning for images (recursion depth limit = {max_depth})...")
            image_paths = get_images_recursive(input_root, max_depth)
            total = len(image_paths)
            if total == 0:
                self.log("No image files found.")
                messagebox.showinfo("Info", "No image files found.")
                return

            self.log(f"Found {total} image(s). Starting resize...")

            # Determine resample filter
            resample = Image.BILINEAR if self.resample_var.get() == "Bilinear" else Image.NEAREST
            target_size = (self.width_var.get(), self.height_var.get())
            crop_to_square = self.crop_var.get()

            processed = 0
            errors = 0

            for idx, img_path in enumerate(image_paths):
                if self.cancel_flag:
                    self.log("Batch cancelled by user.")
                    break

                # Compute relative path from input_root to preserve subfolder structure
                rel_path = os.path.relpath(img_path, input_root)
                out_path = os.path.join(output_root, rel_path)
                # Change extension to .png for consistency
                out_path = str(Path(out_path).with_suffix('.png'))
                os.makedirs(os.path.dirname(out_path), exist_ok=True)

                try:
                    with Image.open(img_path) as img:
                        # Optionally crop to 1:1
                        if crop_to_square:
                            img = crop_to_1_1(img)
                        # Resize
                        img = resize_image(img, target_size, resample)
                        # Save as PNG
                        img.save(out_path, "PNG")
                    processed += 1
                except Exception as e:
                    errors += 1
                    self.log(f"ERROR processing {img_path}: {e}")

                # Update progress
                progress = int((idx + 1) / total * 100)
                self.progress_var.set(progress)
                self.status_label.config(text=f"Processed {idx+1}/{total} (errors: {errors})")
                self.update_idletasks()

            self.log(f"\n=== Done ===")
            self.log(f"Successfully resized: {processed} images")
            self.log(f"Errors: {errors}")
            self.log(f"Output saved to: {output_root}")
            messagebox.showinfo("Batch Complete", f"Resized {processed} images.\nErrors: {errors}\nOutput folder: {output_root}")

        except Exception as e:
            self.log(f"FATAL ERROR: {e}")
            messagebox.showerror("Error", f"Batch processing failed:\n{e}")
        finally:
            self.running = False
            self.start_btn.config(state='normal')
            self.cancel_btn.config(state='disabled')
            self.progress_var.set(0)
            self.status_label.config(text="Ready")


# ----------------------------------------------------------------------
# Main Application
# ----------------------------------------------------------------------
class ImageApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Image Toolkit - Batch Resize & Spritesheet Cutter")
        self.geometry("750x650")
        self.resizable(True, True)

        # Notebook (tabs)
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=10)

        # Single processing tab (spritesheet cutter)
        self.single_tab = SingleProcessingTab(self.notebook)
        self.notebook.add(self.single_tab, text="Single: Cut Spritesheet")

        # Batch processing tab (resize)
        self.batch_tab = BatchProcessingTab(self.notebook)
        self.notebook.add(self.batch_tab, text="Batch: Resize Images")

        # Status bar
        self.status_bar = ttk.Label(self, text="Ready", relief='sunken', anchor='w')
        self.status_bar.pack(side='bottom', fill='x')


# ----------------------------------------------------------------------
if __name__ == "__main__":
    app = ImageApp()
    app.mainloop()