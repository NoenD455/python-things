import tkinter as tk
from tkinter import filedialog, ttk, messagebox
from PIL import Image, ImageTk, ImageDraw
import numpy as np
import random
import time
import queue
import threading
import os
from math import exp
import sys

# Optional numba for acceleration
try:
    from numba import jit, prange
    HAS_NUMBA = True
except ImportError:
    HAS_NUMBA = False
    print("Numba not installed. Install with: pip install numba")

# ==================== OPTIMIZED FUNCTIONS (with numba if available) ====================

if HAS_NUMBA:
    @jit(nopython=True, parallel=True, fastmath=True, cache=True)
    def compute_gaussian_weights_numba(window_size, sigma):
        half = window_size // 2
        weights = np.zeros((window_size, window_size), dtype=np.float32)
        for dy in prange(-half, half + 1):
            for dx in prange(-half, half + 1):
                d2 = dx*dx + dy*dy
                weights[dy+half, dx+half] = np.exp(-d2 / (2 * sigma * sigma))
        return weights

    @jit(nopython=True, fastmath=True, cache=True)
    def patch_distance_numba(output_patch, sample_patch, mask_patch, weights):
        total_weight = 0.0
        total_diff = 0.0
        for i in range(output_patch.shape[0]):
            for j in range(output_patch.shape[1]):
                if mask_patch[i, j]:
                    w = weights[i, j]
                    dr = output_patch[i, j, 0] - sample_patch[i, j, 0]
                    dg = output_patch[i, j, 1] - sample_patch[i, j, 1]
                    db = output_patch[i, j, 2] - sample_patch[i, j, 2]
                    total_diff += w * (dr*dr + dg*dg + db*db)
                    total_weight += w
        return total_diff / total_weight if total_weight > 0 else np.inf

    @jit(nopython=True, parallel=True, fastmath=True, cache=True)
    def batch_distances_numba(output_patch, sample_patches, mask_patch, weights):
        n = sample_patches.shape[0]
        distances = np.full(n, np.inf, dtype=np.float32)
        for i in prange(n):
            distances[i] = patch_distance_numba(output_patch, sample_patches[i], mask_patch, weights)
        return distances
else:
    # Fallback pure numpy versions
    def compute_gaussian_weights_numba(window_size, sigma):
        half = window_size // 2
        y, x = np.ogrid[-half:half+1, -half:half+1]
        weights = np.exp(-(x*x + y*y) / (2 * sigma * sigma)).astype(np.float32)
        return weights

    def patch_distance_numba(output_patch, sample_patch, mask_patch, weights):
        diff = output_patch - sample_patch
        sq_diff = diff[..., 0]**2 + diff[..., 1]**2 + diff[..., 2]**2
        weighted = sq_diff * weights * mask_patch
        total = np.sum(weighted)
        wsum = np.sum(weights * mask_patch)
        return total / wsum if wsum > 0 else np.inf

    def batch_distances_numba(output_patch, sample_patches, mask_patch, weights):
        distances = np.array([patch_distance_numba(output_patch, sp, mask_patch, weights) for sp in sample_patches])
        return distances

# ==================== SYNTHESIZER CLASS ====================

class EfrosLeungSynthesizer:
    def __init__(self):
        self.width = 64
        self.height = 64
        self.window_size = 9
        self.tolerance = 0.12
        self.sigma = 2.0
        self.search_limit = 1800
        self.generation_mode = "normal"
        self.seed_position = "center"
        
        self.sample_images = []      # list of (np.array, name, pil_image)
        self.sample_patches = []     # each: {'positions': list, 'patches': np.array}
        self.output_array = None
        self.mask = None
        self.pixel_queue = []
        self.spiral_order = None
        self.gaussian_weights = None
        
        self.current_step = 0
        self.start_time = 0
        self.total_pixels_synthesized = 0
        self.total_time_spent = 0.0
        
        self.on_update = None   # callback(progress, output_array, mask)
        
    def compute_gaussian_weights(self):
        self.gaussian_weights = compute_gaussian_weights_numba(self.window_size, self.sigma)
        
    def precompute_sample_patches(self, sample_idx):
        sample = self.sample_images[sample_idx]
        arr = sample['array']
        h, w, _ = arr.shape
        half = self.window_size // 2
        positions = []
        patches = []
        for y in range(half, h - half):
            for x in range(half, w - half):
                positions.append((x, y))
                patch = arr[y-half:y+half+1, x-half:x+half+1].astype(np.float32)
                patches.append(patch)
        self.sample_patches[sample_idx] = {
            'positions': positions,
            'patches': np.array(patches, dtype=np.float32)
        }
        
    def recompute_all_patches(self):
        self.sample_patches = [None] * len(self.sample_images)
        for i in range(len(self.sample_images)):
            self.precompute_sample_patches(i)
            
    def add_sample_image(self, path):
        try:
            img = Image.open(path).convert('RGB')
            arr = np.array(img, dtype=np.uint8)
            self.sample_images.append({
                'array': arr,
                'name': os.path.basename(path),
                'pil': img,
                'width': img.width,
                'height': img.height
            })
            self.recompute_all_patches()
            return True, f"Loaded {os.path.basename(path)} ({img.width}x{img.height})"
        except Exception as e:
            return False, str(e)
            
    def clear_samples(self):
        self.sample_images = []
        self.sample_patches = []
        
    def initialize_canvas(self, width, height, mode, seed_pos):
        self.width = width
        self.height = height
        self.generation_mode = mode
        self.seed_position = seed_pos
        
        # Gray canvas
        self.output_array = np.full((height, width, 3), 128, dtype=np.uint8)
        self.mask = np.zeros((height, width), dtype=bool)
        
        # Place 3x3 seed from a random sample
        if self.sample_images and width >= 3 and height >= 3:
            sample = random.choice(self.sample_images)
            arr = sample['array']
            sh, sw, _ = arr.shape
            if sw >= 3 and sh >= 3:
                sx = random.randint(0, sw - 3)
                sy = random.randint(0, sh - 3)
                if seed_pos == "center":
                    dx = (width - 3) // 2
                    dy = (height - 3) // 2
                elif seed_pos == "topleft":
                    dx, dy = 0, 0
                else:  # random
                    dx = random.randint(0, width - 3)
                    dy = random.randint(0, height - 3)
                dx = max(0, min(dx, width - 3))
                dy = max(0, min(dy, height - 3))
                seed_block = arr[sy:sy+3, sx:sx+3]
                self.output_array[dy:dy+3, dx:dx+3] = seed_block
                self.mask[dy:dy+3, dx:dx+3] = True
                
        self.total_pixels_synthesized = np.sum(self.mask)
        self.current_step = 0
        self.start_time = time.time()
        self.total_time_spent = 0.0
        self.spiral_order = None  # reset spiral cache
        self.update_pixel_queue()
        self._trigger_update()
        
    def generate_spiral_order(self):
        w, h = self.width, self.height
        cx, cy = w // 2, h // 2
        order = []
        dirs = [(1,0), (0,1), (-1,0), (0,-1)]
        x, y = cx, cy
        step = 1
        d = 0
        while len(order) < w * h:
            for _ in range(2):
                dx, dy = dirs[d % 4]
                for _ in range(step):
                    if 0 <= x < w and 0 <= y < h:
                        order.append((x, y))
                    x += dx
                    y += dy
                d += 1
            step += 1
        return order
        
    def update_pixel_queue(self):
        w, h = self.width, self.height
        queue = []
        if self.generation_mode == "normal":
            # boundary pixels (unfilled with at least one filled neighbor)
            candidates = []
            for y in range(h):
                for x in range(w):
                    if self.mask[y, x]:
                        continue
                    # count filled neighbors (8-connected)
                    cnt = 0
                    for ny in range(max(0, y-1), min(h, y+2)):
                        for nx in range(max(0, x-1), min(w, x+2)):
                            if (ny != y or nx != x) and self.mask[ny, nx]:
                                cnt += 1
                    if cnt > 0:
                        candidates.append((x, y, cnt))
            candidates.sort(key=lambda p: p[2], reverse=True)
            queue = [(x, y) for (x, y, _) in candidates]
        elif self.generation_mode == "raster":
            for y in range(h):
                for x in range(w):
                    if not self.mask[y, x]:
                        queue.append((x, y))
        elif self.generation_mode == "spiral":
            if self.spiral_order is None:
                self.spiral_order = self.generate_spiral_order()
            for (x, y) in self.spiral_order:
                if not self.mask[y, x]:
                    queue.append((x, y))
        elif self.generation_mode == "row":
            for y in range(h):
                for x in range(w):
                    if not self.mask[y, x]:
                        queue.append((x, y))
        elif self.generation_mode == "random":
            all_pixels = [(x, y) for y in range(h) for x in range(w) if not self.mask[y, x]]
            random.shuffle(all_pixels)
            queue = all_pixels
        self.pixel_queue = queue
        
    def force_recovery_random(self):
        """If synthesis stalls, fill queue with all unfilled pixels in random order."""
        w, h = self.width, self.height
        unfilled = [(x, y) for y in range(h) for x in range(w) if not self.mask[y, x]]
        if unfilled:
            random.shuffle(unfilled)
            self.pixel_queue = unfilled
            return True
        return False
        
    def get_output_patch(self, x, y, output_arr, mask_arr):
        half = self.window_size // 2
        win = self.window_size
        patch = np.zeros((win, win, 3), dtype=np.float32)
        mask_patch = np.zeros((win, win), dtype=bool)
        for dy in range(-half, half+1):
            ny = y + dy
            if 0 <= ny < self.height:
                for dx in range(-half, half+1):
                    nx = x + dx
                    if 0 <= nx < self.width and mask_arr[ny, nx]:
                        patch[dy+half, dx+half] = output_arr[ny, nx].astype(np.float32)
                        mask_patch[dy+half, dx+half] = True
        return patch, mask_patch
        
    def find_best_matches(self, x, y, output_arr, mask_arr):
        patch, mask_patch = self.get_output_patch(x, y, output_arr, mask_arr)
        if not np.any(mask_patch):
            return [], np.inf
            
        # Gather all sample patches
        all_patches = []
        all_meta = []
        for s_idx, sp in enumerate(self.sample_patches):
            if sp is None:
                continue
            patches = sp['patches']
            positions = sp['positions']
            n = len(patches)
            # Random sampling if too many
            if n > self.search_limit:
                indices = np.random.choice(n, self.search_limit, replace=False)
            else:
                indices = range(n)
            for idx in indices:
                all_patches.append(patches[idx])
                all_meta.append((s_idx, positions[idx][0], positions[idx][1]))
        if not all_patches:
            return [], np.inf
            
        all_patches = np.array(all_patches, dtype=np.float32)
        distances = batch_distances_numba(patch, all_patches, mask_patch, self.gaussian_weights)
        min_dist = np.min(distances)
        # Find matches within tolerance
        thresh = min_dist * (1 + self.tolerance)
        match_indices = np.where(distances <= thresh)[0]
        matches = [all_meta[i] for i in match_indices]
        return matches, min_dist
        
    def synthesize_pixel(self, x, y, output_arr, mask_arr):
        matches, _ = self.find_best_matches(x, y, output_arr, mask_arr)
        if not matches:
            return None
        s_idx, sx, sy = random.choice(matches)
        sample_arr = self.sample_images[s_idx]['array']
        return sample_arr[sy, sx].copy()
        
    def synthesize_batch(self, num_pixels):
        if not self.pixel_queue:
            self.update_pixel_queue()
            if not self.pixel_queue:
                return 0
        start_perf = time.perf_counter()
        synced = 0
        for _ in range(num_pixels):
            if not self.pixel_queue:
                break
            x, y = self.pixel_queue.pop(0)
            if self.mask[y, x]:
                continue
            color = self.synthesize_pixel(x, y, self.output_array, self.mask)
            if color is not None:
                self.output_array[y, x] = color
                self.mask[y, x] = True
                synced += 1
        elapsed = time.perf_counter() - start_perf
        if synced > 0:
            self.total_pixels_synthesized += synced
            self.total_time_spent += elapsed
        self.current_step += 1
        progress = self.get_progress()
        # Stall recovery
        if not self.pixel_queue and progress < 0.999:
            if self.force_recovery_random():
                if hasattr(self, '_log_callback'):
                    self._log_callback("Stall recovered: forced random order")
        self.update_pixel_queue()
        self._trigger_update()
        return synced
        
    def get_progress(self):
        if self.mask is None:
            return 0.0
        total = self.width * self.height
        filled = np.sum(self.mask)
        return filled / total if total > 0 else 0
        
    def render_to_image(self):
        return Image.fromarray(self.output_array)
        
    def _trigger_update(self):
        if self.on_update:
            self.on_update(self.get_progress(), self.output_array, self.mask)
            
    def reset_synthesis(self):
        self.initialize_canvas(self.width, self.height, self.generation_mode, self.seed_position)
        
    # ---------- Multipass refinement (progressive, row by row) ----------
    def start_progressive_refinement(self, pass_count, row_callback=None, finish_callback=None):
        """Run multiple refinement passes, each pass processes rows sequentially and updates UI."""
        if self.get_progress() < 0.999:
            if hasattr(self, '_log_callback'):
                self._log_callback("Refinement requires fully filled canvas. Run synthesis first.")
            return
        # Run in a thread to keep GUI responsive
        def refine_worker():
            w, h = self.width, self.height
            for p in range(1, pass_count + 1):
                # Create a new buffer (next state)
                new_output = self.output_array.copy()
                # Process row by row
                for y in range(h):
                    for x in range(w):
                        color = self.synthesize_pixel(x, y, self.output_array, self.mask)
                        if color is not None:
                            new_output[y, x] = color
                    # Update display after each row
                    self.output_array = new_output.copy()  # display updated progressively
                    if row_callback:
                        row_callback(p, pass_count, y, h)
                    self._trigger_update()
                    # Small sleep to let GUI breathe
                    time.sleep(0.001)
                # Pass finished: commit final buffer
                self.output_array = new_output
                self._trigger_update()
                if hasattr(self, '_log_callback'):
                    self._log_callback(f"Refinement pass {p}/{pass_count} completed")
            if finish_callback:
                finish_callback()
        threading.Thread(target=refine_worker, daemon=True).start()
        
# ==================== GUI APPLICATION ====================

class EfrosLeungApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Efros-Leung Texture Synthesis - Enhanced")
        self.root.geometry("1400x900")
        
        self.synth = EfrosLeungSynthesizer()
        self.synth._log_callback = self.log_message
        self.synth.on_update = self.on_synth_update
        
        self.auto_running = False
        self.auto_thread = None
        
        self.setup_gui()
        # Initialize default canvas so that stats have valid arrays
        self.synth.initialize_canvas(64, 64, "normal", "center")
        self.update_stats()
        
        # Load default settings
        self.apply_settings_from_ui()
        
    def setup_gui(self):
        # Notebook
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab 1: Synthesis
        self.synth_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.synth_tab, text="Synthesis")
        self.setup_synthesis_tab()
        
        # Tab 2: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text="Settings")
        self.setup_settings_tab()
        
        # Tab 3: Samples
        self.samples_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.samples_tab, text="Samples")
        self.setup_samples_tab()
        
    def setup_synthesis_tab(self):
        main = tk.Frame(self.synth_tab)
        main.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left controls
        left = tk.Frame(main, width=300)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left.pack_propagate(False)
        
        tk.Label(left, text="Texture Synthesis", font=("Arial",14,"bold")).pack(pady=(0,10))
        
        # Performance frame
        perf_frame = tk.LabelFrame(left, text="Performance", padx=10, pady=10)
        perf_frame.pack(fill=tk.X, pady=(0,10))
        self.speed_label = tk.Label(perf_frame, text="Speed: -- px/s")
        self.speed_label.pack()
        self.avg_label = tk.Label(perf_frame, text="Avg: -- ms/px")
        self.avg_label.pack()
        
        # Canvas init
        init_frame = tk.LabelFrame(left, text="Canvas", padx=10, pady=10)
        init_frame.pack(fill=tk.X, pady=(0,10))
        size_frame = tk.Frame(init_frame)
        size_frame.pack(fill=tk.X, pady=5)
        tk.Label(size_frame, text="Width:").pack(side=tk.LEFT)
        self.canvas_w = tk.IntVar(value=64)
        tk.Entry(size_frame, textvariable=self.canvas_w, width=6).pack(side=tk.LEFT, padx=5)
        tk.Label(size_frame, text="Height:").pack(side=tk.LEFT)
        self.canvas_h = tk.IntVar(value=64)
        tk.Entry(size_frame, textvariable=self.canvas_h, width=6).pack(side=tk.LEFT, padx=5)
        tk.Button(init_frame, text="Initialize Canvas", command=self.init_canvas).pack(pady=5)
        
        # Controls
        ctrl_frame = tk.LabelFrame(left, text="Synthesis Controls", padx=10, pady=10)
        ctrl_frame.pack(fill=tk.X, pady=(0,10))
        btn_frame = tk.Frame(ctrl_frame)
        btn_frame.pack()
        tk.Button(btn_frame, text="Single Step", command=self.single_step).grid(row=0, column=0, padx=2, pady=2)
        tk.Button(btn_frame, text="Start Auto", command=self.start_auto, bg="lightgreen").grid(row=0, column=1, padx=2, pady=2)
        tk.Button(btn_frame, text="Stop", command=self.stop_auto, bg="salmon").grid(row=1, column=0, padx=2, pady=2)
        tk.Button(btn_frame, text="Reset", command=self.reset_synth).grid(row=1, column=1, padx=2, pady=2)
        
        # Step size
        step_frame = tk.Frame(ctrl_frame)
        step_frame.pack(fill=tk.X, pady=5)
        tk.Label(step_frame, text="Pixels/step:").pack(side=tk.LEFT)
        self.step_pixels = tk.IntVar(value=80)
        tk.Scale(step_frame, from_=10, to=500, variable=self.step_pixels, orient=tk.HORIZONTAL, length=150).pack(side=tk.RIGHT)
        
        # Progress
        prog_frame = tk.LabelFrame(left, text="Progress", padx=10, pady=10)
        prog_frame.pack(fill=tk.X, pady=(0,10))
        self.progress_bar = ttk.Progressbar(prog_frame, length=250)
        self.progress_bar.pack(pady=2)
        self.progress_label = tk.Label(prog_frame, text="Progress: 0%")
        self.progress_label.pack()
        self.step_label = tk.Label(prog_frame, text="Step: 0")
        self.step_label.pack()
        
        # Multipass refine
        refine_frame = tk.LabelFrame(left, text="Multipass Refinement", padx=10, pady=10)
        refine_frame.pack(fill=tk.X, pady=(0,10))
        mp_row = tk.Frame(refine_frame)
        mp_row.pack(fill=tk.X)
        tk.Label(mp_row, text="Passes:").pack(side=tk.LEFT)
        self.multipass = tk.IntVar(value=0)
        tk.Scale(mp_row, from_=0, to=5, variable=self.multipass, orient=tk.HORIZONTAL, length=150).pack(side=tk.RIGHT)
        self.mp_label = tk.Label(refine_frame, text="0")
        self.mp_label.pack()
        tk.Button(refine_frame, text="Run Refinement (progressive)", command=self.run_refinement).pack(pady=5)
        
        # Save
        save_frame = tk.LabelFrame(left, text="Export", padx=10, pady=10)
        save_frame.pack(fill=tk.X)
        tk.Button(save_frame, text="Save Output", command=self.save_output).pack(pady=5)
        
        # Right side: output canvas (scaled with nearest neighbor)
        right = tk.Frame(main)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        self.canvas = tk.Canvas(right, bg='gray', width=512, height=512)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.output_photo = None
        
        # Status log
        log_frame = tk.LabelFrame(right, text="Log")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=(10,0))
        self.log_text = tk.Text(log_frame, height=8, font=("Courier",9))
        self.log_text.pack(fill=tk.BOTH, expand=True)
        scroll = tk.Scrollbar(self.log_text, command=self.log_text.yview)
        self.log_text.config(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
    def setup_settings_tab(self):
        frame = tk.Frame(self.settings_tab)
        frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(frame, text="Algorithm Parameters", font=("Arial",14,"bold")).pack(pady=(0,20))
        
        # Window size
        row = tk.Frame(frame)
        row.pack(fill=tk.X, pady=5)
        tk.Label(row, text="Window size (odd):").pack(side=tk.LEFT)
        self.win_size = tk.IntVar(value=9)
        tk.Scale(row, from_=3, to=21, variable=self.win_size, orient=tk.HORIZONTAL, length=200, resolution=2).pack(side=tk.RIGHT)
        
        # Tolerance
        row = tk.Frame(frame)
        row.pack(fill=tk.X, pady=5)
        tk.Label(row, text="Tolerance ε:").pack(side=tk.LEFT)
        self.tolerance = tk.DoubleVar(value=0.12)
        tk.Scale(row, from_=0.01, to=0.5, variable=self.tolerance, orient=tk.HORIZONTAL, length=200, resolution=0.01).pack(side=tk.RIGHT)
        
        # Sigma
        row = tk.Frame(frame)
        row.pack(fill=tk.X, pady=5)
        tk.Label(row, text="Gaussian σ:").pack(side=tk.LEFT)
        self.sigma = tk.DoubleVar(value=2.0)
        tk.Scale(row, from_=0.5, to=5.0, variable=self.sigma, orient=tk.HORIZONTAL, length=200, resolution=0.1).pack(side=tk.RIGHT)
        
        # Search limit
        row = tk.Frame(frame)
        row.pack(fill=tk.X, pady=5)
        tk.Label(row, text="Search limit:").pack(side=tk.LEFT)
        self.search_limit = tk.IntVar(value=1800)
        tk.Scale(row, from_=300, to=8000, variable=self.search_limit, orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        
        # Generation mode
        row = tk.Frame(frame)
        row.pack(fill=tk.X, pady=5)
        tk.Label(row, text="Generation mode:").pack(side=tk.LEFT)
        self.gen_mode = tk.StringVar(value="normal")
        modes = ["normal", "raster", "spiral", "row", "random"]
        tk.OptionMenu(row, self.gen_mode, *modes).pack(side=tk.RIGHT)
        
        # Seed position
        row = tk.Frame(frame)
        row.pack(fill=tk.X, pady=5)
        tk.Label(row, text="Seed position:").pack(side=tk.LEFT)
        self.seed_pos = tk.StringVar(value="center")
        seeds = ["center", "topleft", "random"]
        tk.OptionMenu(row, self.seed_pos, *seeds).pack(side=tk.RIGHT)
        
        # Apply button
        tk.Button(frame, text="Apply Settings & Reinitialize", command=self.apply_settings_from_ui, bg="#6c5ce7", fg="white").pack(pady=20)
        
        # Presets
        preset_frame = tk.LabelFrame(frame, text="Presets")
        preset_frame.pack(fill=tk.X, pady=10)
        tk.Button(preset_frame, text="Ultra Fast (w=5, limit=800)", command=self.preset_ultrafast).pack(side=tk.LEFT, padx=5)
        tk.Button(preset_frame, text="Balanced (w=9, limit=1800)", command=self.preset_balanced).pack(side=tk.LEFT, padx=5)
        
    def setup_samples_tab(self):
        frame = tk.Frame(self.samples_tab)
        frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        tk.Label(frame, text="Sample Textures", font=("Arial",14,"bold")).pack(pady=(0,20))
        
        btn_frame = tk.Frame(frame)
        btn_frame.pack(fill=tk.X)
        tk.Button(btn_frame, text="Add Images", command=self.add_samples).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Clear All", command=self.clear_samples).pack(side=tk.LEFT, padx=5)
        
        self.sample_count_label = tk.Label(frame, text="No samples loaded")
        self.sample_count_label.pack(pady=10)
        
        self.thumb_frame = tk.Frame(frame, bg='gray90')
        self.thumb_frame.pack(fill=tk.BOTH, expand=True)
        self.thumb_canvas = tk.Canvas(self.thumb_frame, bg='gray90')
        thumb_scroll = tk.Scrollbar(self.thumb_frame, orient=tk.VERTICAL, command=self.thumb_canvas.yview)
        self.thumb_inner = tk.Frame(self.thumb_canvas, bg='gray90')
        self.thumb_canvas.create_window((0,0), window=self.thumb_inner, anchor="nw")
        self.thumb_canvas.configure(yscrollcommand=thumb_scroll.set)
        self.thumb_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        thumb_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.update_thumbnails()
        
    # ---------- Event handlers ----------
    def log_message(self, msg):
        self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
        self.log_text.see(tk.END)
        
    def update_stats(self):
        if self.synth.total_time_spent > 0 and self.synth.total_pixels_synthesized > 0:
            speed = self.synth.total_pixels_synthesized / self.synth.total_time_spent
            ms = (self.synth.total_time_spent / self.synth.total_pixels_synthesized) * 1000
            self.speed_label.config(text=f"Speed: {speed:.1f} px/s")
            self.avg_label.config(text=f"Avg: {ms:.1f} ms/px")
        else:
            self.speed_label.config(text="Speed: -- px/s")
            self.avg_label.config(text="Avg: -- ms/px")
        prog = self.synth.get_progress() * 100
        self.progress_bar['value'] = prog
        self.progress_label.config(text=f"Progress: {prog:.1f}%")
        self.step_label.config(text=f"Step: {self.synth.current_step}")
        total_px = self.synth.width * self.synth.height
        filled = np.sum(self.synth.mask) if self.synth.mask is not None else 0
        self.sample_count_label.config(text=f"Samples: {len(self.synth.sample_images)}")
        
    def on_synth_update(self, progress, output_array, mask):
        self.update_stats()
        self.display_output()
        
    def display_output(self):
        if self.synth.output_array is not None:
            img = Image.fromarray(self.synth.output_array)
            # Get canvas dimensions
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            if canvas_width <= 10 or canvas_height <= 10:
                # Canvas not yet mapped, use a default fallback size
                canvas_width = 512
                canvas_height = 512
            
            # Preserve aspect ratio
            img_w, img_h = img.size
            scale = min(canvas_width / img_w, canvas_height / img_h)
            new_w = int(img_w * scale)
            new_h = int(img_h * scale)
            if new_w < 1: new_w = 1
            if new_h < 1: new_h = 1
        
            # Resize using nearest neighbor for crisp pixels
            img_resized = img.resize((new_w, new_h), Image.NEAREST)
        
            # Center the image on the canvas
            x_offset = (canvas_width - new_w) // 2
            y_offset = (canvas_height - new_h) // 2
        
            self.output_photo = ImageTk.PhotoImage(img_resized)
            self.canvas.delete("all")
            self.canvas.create_image(x_offset, y_offset, image=self.output_photo, anchor=tk.NW)
            self.canvas.image = self.output_photo
            
    def apply_settings_from_ui(self):
        self.synth.window_size = self.win_size.get()
        if self.synth.window_size % 2 == 0:
            self.synth.window_size += 1
            self.win_size.set(self.synth.window_size)
        self.synth.tolerance = self.tolerance.get()
        self.synth.sigma = self.sigma.get()
        self.synth.search_limit = self.search_limit.get()
        self.synth.generation_mode = self.gen_mode.get()
        self.synth.seed_position = self.seed_pos.get()
        self.synth.compute_gaussian_weights()
        self.synth.recompute_all_patches()
        self.init_canvas()
        self.log_message("Settings applied and canvas reinitialized.")
        
    def init_canvas(self):
        w = self.canvas_w.get()
        h = self.canvas_h.get()
        if w <= 0 or h <= 0:
            self.log_message("Invalid canvas dimensions")
            return
        self.synth.initialize_canvas(w, h, self.synth.generation_mode, self.synth.seed_position)
        self.display_output()
        self.update_stats()
        self.log_message(f"Canvas initialized: {w}x{h}")
        
    def single_step(self):
        if self.auto_running:
            self.stop_auto()
        step = self.step_pixels.get()
        synced = self.synth.synthesize_batch(step)
        self.log_message(f"Step {self.synth.current_step}: synthesized {synced} pixels")
        if self.synth.get_progress() >= 0.999:
            self.log_message("Synthesis complete!")
            
    def start_auto(self):
        if self.auto_running:
            return
        self.auto_running = True
        def auto_loop():
            while self.auto_running:
                step = self.step_pixels.get()
                synced = self.synth.synthesize_batch(step)
                if self.synth.get_progress() >= 0.999:
                    self.root.after(0, lambda: self.log_message("Auto synthesis finished"))
                    # Auto start refinement if multipass > 0
                    passes = self.multipass.get()
                    if passes > 0:
                        self.root.after(0, lambda: self.run_refinement())
                    break
                time.sleep(0.02)
            self.auto_running = False
        threading.Thread(target=auto_loop, daemon=True).start()
        
    def stop_auto(self):
        self.auto_running = False
        
    def reset_synth(self):
        self.stop_auto()
        self.synth.reset_synthesis()
        self.log_message("Synthesis reset")
        
    def save_output(self):
        if self.synth.output_array is None:
            self.log_message("No output to save")
            return
        path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg")])
        if path:
            img = Image.fromarray(self.synth.output_array)
            img.save(path)
            self.log_message(f"Saved to {os.path.basename(path)}")
            
    def run_refinement(self):
        passes = self.multipass.get()
        if passes <= 0:
            self.log_message("Set multipass count > 0")
            return
        if self.synth.get_progress() < 0.999:
            self.log_message("Finish synthesis first (100% filled)")
            return
        self.log_message(f"Starting {passes} progressive refinement pass(es)...")
        def row_callback(p, total, row, height):
            self.root.after(0, lambda: self.mp_label.config(text=f"Pass {p}/{total} row {row+1}/{height}"))
        def finish_callback():
            self.root.after(0, lambda: self.log_message("Refinement completed"))
            self.root.after(0, lambda: self.mp_label.config(text="Done"))
        self.synth.start_progressive_refinement(passes, row_callback, finish_callback)
        
    def add_samples(self):
        paths = filedialog.askopenfilenames(filetypes=[("Image files", "*.*")])
        for path in paths:
            success, msg = self.synth.add_sample_image(path)
            self.log_message(msg)
        self.update_thumbnails()
        
    def clear_samples(self):
        self.synth.clear_samples()
        self.update_thumbnails()
        self.log_message("All samples cleared")
        
    def update_thumbnails(self):
        for widget in self.thumb_inner.winfo_children():
            widget.destroy()
        for i, sample in enumerate(self.synth.sample_images):
            img = sample['pil'].copy()
            img.thumbnail((100,100))
            photo = ImageTk.PhotoImage(img)
            label = tk.Label(self.thumb_inner, image=photo, text=sample['name'][:15], compound=tk.TOP)
            label.image = photo
            label.pack(side=tk.LEFT, padx=5, pady=5)
            
    def preset_ultrafast(self):
        self.win_size.set(5)
        self.search_limit.set(800)
        self.tolerance.set(0.2)
        self.sigma.set(1.5)
        self.apply_settings_from_ui()
        
    def preset_balanced(self):
        self.win_size.set(9)
        self.search_limit.set(1800)
        self.tolerance.set(0.12)
        self.sigma.set(2.2)
        self.apply_settings_from_ui()
        
def main():
    root = tk.Tk()
    app = EfrosLeungApp(root)
    root.mainloop()
    
if __name__ == "__main__":
    main()
