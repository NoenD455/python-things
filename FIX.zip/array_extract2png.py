import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import numpy as np
from PIL import Image
import os

class ImageExtractorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("NPZ/NPY Image Extractor")
        self.root.geometry("600x400")

        # Variables
        self.input_files = []
        self.output_dir = ""

        # Create GUI elements
        self.create_widgets()

    def create_widgets(self):
        # Input file selection
        tk.Label(self.root, text="Select NPZ/NPY files:").pack(pady=(10,0))
        frame_input = tk.Frame(self.root)
        frame_input.pack(pady=5, padx=10, fill=tk.X)

        self.btn_select_files = tk.Button(frame_input, text="Browse Files", command=self.select_files)
        self.btn_select_files.pack(side=tk.LEFT, padx=5)

        self.lbl_files = tk.Label(frame_input, text="No files selected", anchor="w")
        self.lbl_files.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Output folder selection
        tk.Label(self.root, text="Select output folder:").pack(pady=(10,0))
        frame_output = tk.Frame(self.root)
        frame_output.pack(pady=5, padx=10, fill=tk.X)

        self.btn_select_output = tk.Button(frame_output, text="Browse Folder", command=self.select_output)
        self.btn_select_output.pack(side=tk.LEFT, padx=5)

        self.lbl_output = tk.Label(frame_output, text="No folder selected", anchor="w")
        self.lbl_output.pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Extract button
        self.btn_extract = tk.Button(self.root, text="Extract Images", command=self.extract_images, state=tk.DISABLED)
        self.btn_extract.pack(pady=10)

        # Log area
        tk.Label(self.root, text="Progress Log:").pack()
        self.log_area = scrolledtext.ScrolledText(self.root, height=10, state=tk.DISABLED)
        self.log_area.pack(padx=10, pady=5, fill=tk.BOTH, expand=True)

    def log(self, message):
        """Append message to log area."""
        self.log_area.config(state=tk.NORMAL)
        self.log_area.insert(tk.END, message + "\n")
        self.log_area.see(tk.END)
        self.log_area.config(state=tk.DISABLED)
        self.root.update_idletasks()

    def select_files(self):
        files = filedialog.askopenfilenames(
            title="Select NPZ or NPY files",
            filetypes=[("NumPy files", "*.npz *.npy"), ("All files", "*.*")]
        )
        if files:
            self.input_files = list(files)
            self.lbl_files.config(text=f"{len(files)} file(s) selected")
            self.check_extract_ready()
        else:
            self.input_files = []
            self.lbl_files.config(text="No files selected")
            self.check_extract_ready()

    def select_output(self):
        folder = filedialog.askdirectory(title="Select output folder")
        if folder:
            self.output_dir = folder
            self.lbl_output.config(text=folder)
            self.check_extract_ready()
        else:
            self.output_dir = ""
            self.lbl_output.config(text="No folder selected")
            self.check_extract_ready()

    def check_extract_ready(self):
        """Enable extract button if both files and output folder are selected."""
        if self.input_files and self.output_dir:
            self.btn_extract.config(state=tk.NORMAL)
        else:
            self.btn_extract.config(state=tk.DISABLED)

    def save_array_as_image(self, arr, base_path, base_name, idx=None):
        """
        Save a numpy array as an image file.
        - arr: numpy array
        - base_path: directory to save in
        - base_name: base filename (without extension)
        - idx: optional index for multiple images
        """
        # Ensure array is 2D or 3D with appropriate channels
        if arr.ndim not in (2, 3):
            self.log(f"  Skipping array with shape {arr.shape} (not 2D/3D)")
            return

        # Convert to uint8 if not already
        if arr.dtype != np.uint8:
            # Normalize if needed (simple rescale to 0-255)
            if arr.max() > 255 or arr.min() < 0:
                arr = ((arr - arr.min()) / (arr.max() - arr.min()) * 255).astype(np.uint8)
            else:
                arr = arr.astype(np.uint8)

        # Determine filename
        if idx is not None:
            filename = f"{base_name}_{idx:04d}.png"
        else:
            filename = f"{base_name}.png"

        filepath = os.path.join(base_path, filename)

        try:
            img = Image.fromarray(arr)
            img.save(filepath)
            self.log(f"  Saved: {filename}")
        except Exception as e:
            self.log(f"  Error saving {filename}: {e}")

    def process_npy(self, file_path, output_subdir):
        """Process a single .npy file."""
        self.log(f"Processing NPY: {os.path.basename(file_path)}")
        try:
            data = np.load(file_path)
        except Exception as e:
            self.log(f"Error loading {file_path}: {e}")
            return

        # Get base name without extension
        base = os.path.splitext(os.path.basename(file_path))[0]

        # Determine if data contains multiple images
        if data.ndim == 2:
            # Single grayscale image
            self.save_array_as_image(data, output_subdir, base)
        elif data.ndim == 3:
            # Could be (H, W, C) or (N, H, W)
            if data.shape[-1] in (1, 3, 4):
                # Single image with channels
                self.save_array_as_image(data, output_subdir, base)
            else:
                # Multiple images (N, H, W)
                for i in range(data.shape[0]):
                    self.save_array_as_image(data[i], output_subdir, base, i)
        elif data.ndim == 4:
            # Multiple images with channels (N, H, W, C)
            for i in range(data.shape[0]):
                self.save_array_as_image(data[i], output_subdir, base, i)
        else:
            self.log(f"Unsupported array dimensions: {data.ndim}")

    def process_npz(self, file_path, output_subdir):
        """Process a single .npz file, creating its own subfolder."""
        base = os.path.splitext(os.path.basename(file_path))[0]
        npz_subdir = os.path.join(output_subdir, base)
        os.makedirs(npz_subdir, exist_ok=True)
        self.log(f"Processing NPZ: {os.path.basename(file_path)} -> folder '{base}'")

        try:
            npz = np.load(file_path)
        except Exception as e:
            self.log(f"Error loading {file_path}: {e}")
            return

        for key in npz.files:
            arr = npz[key]
            self.log(f"  Array: '{key}' shape {arr.shape}")
            if arr.ndim == 2:
                # Single grayscale image
                self.save_array_as_image(arr, npz_subdir, key)
            elif arr.ndim == 3:
                if arr.shape[-1] in (1, 3, 4):
                    # Single image with channels
                    self.save_array_as_image(arr, npz_subdir, key)
                else:
                    # Multiple images (N, H, W)
                    for i in range(arr.shape[0]):
                        self.save_array_as_image(arr[i], npz_subdir, f"{key}_{i}")
            elif arr.ndim == 4:
                # Multiple images with channels (N, H, W, C)
                for i in range(arr.shape[0]):
                    self.save_array_as_image(arr[i], npz_subdir, f"{key}_{i}")
            else:
                self.log(f"    Skipping array with unsupported dimensions: {arr.ndim}")

    def extract_images(self):
        """Main extraction routine."""
        if not self.input_files or not self.output_dir:
            messagebox.showerror("Error", "Please select files and output folder.")
            return

        self.btn_extract.config(state=tk.DISABLED)
        self.log("=== Extraction started ===")

        try:
            for file_path in self.input_files:
                if file_path.endswith('.npy'):
                    self.process_npy(file_path, self.output_dir)
                elif file_path.endswith('.npz'):
                    self.process_npz(file_path, self.output_dir)
                else:
                    self.log(f"Skipping unsupported file: {file_path}")
        except Exception as e:
            self.log(f"Unexpected error: {e}")
        finally:
            self.log("=== Extraction finished ===")
            self.btn_extract.config(state=tk.NORMAL)

if __name__ == "__main__":
    root = tk.Tk()
    app = ImageExtractorApp(root)
    root.mainloop()