import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import os
import pandas as pd
import threading
import time

class ToolTip:
    """Simple tooltip class"""
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tip_window = None
        widget.bind('<Enter>', self.show_tip)
        widget.bind('<Leave>', self.hide_tip)

    def show_tip(self, event=None):
        x, y, _, _ = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        self.tip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        label = tk.Label(tw, text=self.text, justify=tk.LEFT,
                         background="#ffffe0", relief=tk.SOLID, borderwidth=1)
        label.pack()

    def hide_tip(self, event=None):
        if self.tip_window:
            self.tip_window.destroy()
        self.tip_window = None


class ColumnSeparatorTool:
    def __init__(self, root):
        self.root = root
        self.root.title("Multi-Format Column Separator & Combiner Tool")
        self.root.geometry("1100x900")
        self.root.minsize(800, 600)

        # Variables
        self.file_path = tk.StringVar()
        self.column_index = tk.StringVar(value="0")
        self.output_prefix = tk.StringVar(value="column")
        self.delimiter = tk.StringVar(value="auto")
        self.has_header = tk.BooleanVar(value=True)
        self.sheet_name = tk.StringVar(value="")
        self.encoding = tk.StringVar(value="utf-8")
        self.limit_rows = tk.BooleanVar(value=False)
        self.row_limit = tk.IntVar(value=100000)
        self.add_blank_lines = tk.BooleanVar(value=True)   # new: blank lines between rows
        self.output_dir = tk.StringVar(value="")

        self.original_data = None
        self.full_data = None          # may hold full data if needed
        self.headers = []
        self.preview_data = {}
        self.column_preview_texts = {}
        self.file_format = "csv"

        # Combine variables
        self.combine_columns = tk.StringVar(value="0,1")
        self.combine_separator = tk.StringVar(value=": ")
        self.combine_include_header = tk.BooleanVar(value=False)

        self.setup_ui()
        self.setup_styles()
        self.add_tooltips()

    def setup_ui(self):
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # === File selection ===
        file_frame = ttk.LabelFrame(main_frame, text="1. Select Dataset", padding="10")
        file_frame.pack(fill=tk.X, pady=(0, 10))

        top_row = ttk.Frame(file_frame)
        top_row.pack(fill=tk.X)
        ttk.Button(top_row, text="Browse...", command=self.browse_file).pack(side=tk.LEFT, padx=(0,5))
        ttk.Entry(top_row, textvariable=self.file_path).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(top_row, text="Load", command=self.start_load).pack(side=tk.LEFT, padx=5)

        # Format options
        format_frame = ttk.Frame(file_frame)
        format_frame.pack(fill=tk.X, pady=(10,0))

        ttk.Label(format_frame, text="Delimiter:").grid(row=0, column=0, padx=5)
        self.delimiter_combo = ttk.Combobox(format_frame, textvariable=self.delimiter,
                                            values=["auto", ",", ";", "\t", "|", " "], width=8)
        self.delimiter_combo.grid(row=0, column=1, padx=5)

        ttk.Checkbutton(format_frame, text="Has header", variable=self.has_header,
                       command=self.update_column_info).grid(row=0, column=2, padx=10)

        ttk.Label(format_frame, text="Encoding:").grid(row=0, column=3, padx=5)
        encoding_combo = ttk.Combobox(format_frame, textvariable=self.encoding,
                                      values=["utf-8", "latin1", "cp1252", "iso-8859-1"], width=10)
        encoding_combo.grid(row=0, column=4, padx=5)

        ttk.Checkbutton(format_frame, text="Limit rows", variable=self.limit_rows,
                       command=self.toggle_limit).grid(row=0, column=5, padx=10)
        self.limit_spin = tk.Spinbox(format_frame, from_=1, to=1000000, textvariable=self.row_limit, width=10, state='disabled')
        self.limit_spin.grid(row=0, column=6, padx=5)

        # Excel sheet selector
        sheet_frame = ttk.Frame(format_frame)
        sheet_frame.grid(row=1, column=0, columnspan=7, sticky=tk.W, pady=(5,0))
        ttk.Label(sheet_frame, text="Excel sheet:").pack(side=tk.LEFT, padx=5)
        self.sheet_combo = ttk.Combobox(sheet_frame, textvariable=self.sheet_name, width=20, state='disabled')
        self.sheet_combo.pack(side=tk.LEFT, padx=5)
        ttk.Button(sheet_frame, text="Refresh sheets", command=self.load_sheet_list, state='disabled').pack(side=tk.LEFT, padx=5)

        # Info bar
        info_frame = ttk.Frame(main_frame)
        info_frame.pack(fill=tk.X, pady=5)
        ttk.Label(info_frame, text="Columns:").pack(side=tk.LEFT, padx=5)
        self.total_columns_label = ttk.Label(info_frame, text="0")
        self.total_columns_label.pack(side=tk.LEFT, padx=5)
        ttk.Label(info_frame, text="Rows:").pack(side=tk.LEFT, padx=5)
        self.total_rows_label = ttk.Label(info_frame, text="0")
        self.total_rows_label.pack(side=tk.LEFT, padx=5)

        # Progress bar
        self.progress = ttk.Progressbar(main_frame, mode='indeterminate')
        self.progress.pack(fill=tk.X, pady=5)

        # === Notebook for operations ===
        self.operation_notebook = ttk.Notebook(main_frame)
        self.operation_notebook.pack(fill=tk.X, pady=10)

        self.separate_tab = ttk.Frame(self.operation_notebook)
        self.operation_notebook.add(self.separate_tab, text="Separate Columns")
        self.setup_separate_tab()

        self.combine_tab = ttk.Frame(self.operation_notebook)
        self.operation_notebook.add(self.combine_tab, text="Combine Columns")
        self.setup_combine_tab()

        # === Preview Notebook ===
        preview_frame = ttk.LabelFrame(main_frame, text="Preview", padding="10")
        preview_frame.pack(fill=tk.BOTH, expand=True)

        self.preview_notebook = ttk.Notebook(preview_frame)
        self.preview_notebook.pack(fill=tk.BOTH, expand=True)

        self.original_frame = ttk.Frame(self.preview_notebook)
        self.preview_notebook.add(self.original_frame, text="Original Data")
        self.original_text = scrolledtext.ScrolledText(self.original_frame, wrap=tk.NONE,
                                                        font=('Courier', 10))
        self.original_text.pack(fill=tk.BOTH, expand=True)

        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(fill=tk.X, pady=(5,0))

    def setup_styles(self):
        style = ttk.Style()
        style.configure("Accent.TButton", font=('Helvetica', 9, 'bold'))

    def add_tooltips(self):
        ToolTip(self.delimiter_combo, "Column separator for CSV/TXT files")
        ToolTip(self.sheet_combo, "Select which sheet to use (Excel only)")
        ToolTip(self.limit_spin, "Load only first N rows (faster for huge files)")

    def toggle_limit(self):
        if self.limit_rows.get():
            self.limit_spin.config(state='normal')
        else:
            self.limit_spin.config(state='disabled')

    def setup_separate_tab(self):
        col_frame = ttk.LabelFrame(self.separate_tab, text="Column Selection", padding="10")
        col_frame.pack(fill=tk.X, pady=5)

        ttk.Label(col_frame, text="Column index (0-based):").grid(row=0, column=0, sticky=tk.W)
        self.column_combo = ttk.Combobox(col_frame, textvariable=self.column_index, width=10)
        self.column_combo.grid(row=0, column=1, padx=5)
        self.column_combo.bind('<<ComboboxSelected>>', lambda e: self.update_column_info())

        ttk.Label(col_frame, text="Column name:").grid(row=0, column=2, padx=(15,5))
        self.column_name_label = ttk.Label(col_frame, text="-")
        self.column_name_label.grid(row=0, column=3, padx=5)

        ttk.Button(col_frame, text="Preview Column", command=self.preview_column).grid(row=0, column=4, padx=15)

        out_frame = ttk.LabelFrame(self.separate_tab, text="Output Settings", padding="10")
        out_frame.pack(fill=tk.X, pady=5)

        ttk.Label(out_frame, text="Output prefix:").grid(row=0, column=0, padx=5)
        ttk.Entry(out_frame, textvariable=self.output_prefix, width=30).grid(row=0, column=1, padx=5)

        ttk.Label(out_frame, text="Add blank lines:").grid(row=1, column=0, padx=5, pady=5)
        ttk.Checkbutton(out_frame, variable=self.add_blank_lines).grid(row=1, column=1, sticky=tk.W, padx=5)

        ttk.Label(out_frame, text="Output folder:").grid(row=2, column=0, padx=5, pady=5)
        folder_frame = ttk.Frame(out_frame)
        folder_frame.grid(row=2, column=1, columnspan=2, sticky=tk.W)
        ttk.Entry(folder_frame, textvariable=self.output_dir, width=40).pack(side=tk.LEFT, padx=5)
        ttk.Button(folder_frame, text="Browse", command=self.select_output_folder).pack(side=tk.LEFT)

        btn_frame = ttk.Frame(self.separate_tab)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Separate All Columns", command=self.separate_all_columns,
                  style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Separate Selected Column", command=self.separate_selected_column).pack(side=tk.LEFT, padx=5)

    def setup_combine_tab(self):
        combine_frame = ttk.LabelFrame(self.combine_tab, text="Combine Settings", padding="10")
        combine_frame.pack(fill=tk.X, pady=10)

        ttk.Label(combine_frame, text="Columns (comma-separated indices):").grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Entry(combine_frame, textvariable=self.combine_columns, width=30).grid(row=0, column=1, sticky=tk.W, padx=5)

        ttk.Label(combine_frame, text="Separator string:").grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Entry(combine_frame, textvariable=self.combine_separator, width=20).grid(row=1, column=1, sticky=tk.W, padx=5)

        ttk.Checkbutton(combine_frame, text="Add blank lines between rows", variable=self.add_blank_lines).grid(row=2, column=0, columnspan=2, sticky=tk.W, pady=5)
        ttk.Checkbutton(combine_frame, text="Include header as first line", variable=self.combine_include_header).grid(row=3, column=0, columnspan=2, sticky=tk.W)

        btn_frame = ttk.Frame(self.combine_tab)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Preview Combined", command=self.preview_combined).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Save Combined As...", command=self.save_combined, style="Accent.TButton").pack(side=tk.LEFT, padx=5)

    def select_output_folder(self):
        folder = filedialog.askdirectory(title="Select Output Folder")
        if folder:
            self.output_dir.set(folder)

    def browse_file(self):
        filename = filedialog.askopenfilename(
            title="Select dataset file",
            filetypes=[("All supported", "*.csv *.txt *.tsv *.xlsx *.xls"),
                       ("CSV files", "*.csv"),
                       ("Text files", "*.txt"),
                       ("Excel files", "*.xlsx *.xls"),
                       ("All files", "*.*")]
        )
        if filename:
            self.file_path.set(filename)
            self.detect_format()
            self.start_load()

    def detect_format(self):
        ext = os.path.splitext(self.file_path.get())[1].lower()
        if ext in ['.xlsx', '.xls']:
            self.file_format = 'excel'
            self.delimiter_combo.config(state='disabled')
            self.sheet_combo.config(state='readonly')
            self.sheet_combo.master.master.children['!labelframe'].children['!frame'].children['!button'].config(state='normal')
        else:
            self.file_format = 'csv'
            self.delimiter_combo.config(state='normal')
            self.sheet_combo.config(state='disabled')
            self.sheet_combo.master.master.children['!labelframe'].children['!frame'].children['!button'].config(state='disabled')
            self.sheet_name.set('')

    def start_load(self):
        """Load file in a separate thread to keep UI responsive"""
        if not self.file_path.get():
            messagebox.showwarning("Warning", "Please choose a file first.")
            return
        self.progress.start()
        self.status_var.set("Loading file...")
        thread = threading.Thread(target=self.load_file, daemon=True)
        thread.start()

    def load_file(self):
        try:
            if self.file_format == 'excel':
                self.load_excel()
            else:
                self.load_csv()

            self.root.after(0, self.on_load_finished)

        except Exception as e:
            self.root.after(0, lambda: self.on_load_error(str(e)))

    def load_csv(self):
        delimiter = self.delimiter.get()
        if delimiter == "auto":
            with open(self.file_path.get(), 'r', encoding=self.encoding.get()) as f:
                first_line = f.readline()
                if '\t' in first_line:
                    delimiter = '\t'
                elif ';' in first_line:
                    delimiter = ';'
                elif '|' in first_line:
                    delimiter = '|'
                else:
                    delimiter = ','

        header = 0 if self.has_header.get() else None
        nrows = self.row_limit.get() if self.limit_rows.get() else None

        # For huge CSV, warn and suggest limiting rows
        file_size = os.path.getsize(self.file_path.get()) / (1024*1024)  # MB
        if file_size > 100 and not self.limit_rows.get():
            self.root.after(0, lambda: messagebox.showwarning(
                "Large File",
                f"File size: {file_size:.1f} MB.\nLoading full file may be slow or cause memory issues.\nConsider enabling 'Limit rows'."
            ))

        self.original_data = pd.read_csv(
            self.file_path.get(),
            delimiter=delimiter,
            header=header,
            encoding=self.encoding.get(),
            nrows=nrows,
            low_memory=False
        )

    def load_excel(self):
        sheet = self.sheet_name.get() if self.sheet_name.get() else 0
        header = 0 if self.has_header.get() else None
        nrows = self.row_limit.get() if self.limit_rows.get() else None
        self.original_data = pd.read_excel(
            self.file_path.get(),
            sheet_name=sheet,
            header=header,
            nrows=nrows
        )

    def on_load_finished(self):
        self.progress.stop()
        if self.original_data is not None and not self.original_data.empty:
            num_columns = len(self.original_data.columns)
            num_rows = len(self.original_data)
            self.column_combo['values'] = list(range(num_columns))
            self.total_columns_label.config(text=str(num_columns))
            self.total_rows_label.config(text=str(num_rows))

            if self.has_header.get():
                self.headers = list(self.original_data.columns)
            else:
                self.headers = [f"Column_{i}" for i in range(num_columns)]

            self.show_original_preview()
            self.status_var.set(f"Loaded: {os.path.basename(self.file_path.get())} | {num_rows} rows, {num_columns} columns")
            # Clear old column previews
            for tab_id in self.preview_notebook.tabs():
                if self.preview_notebook.tab(tab_id, "text") != "Original Data":
                    self.preview_notebook.forget(tab_id)
            self.preview_data.clear()
            self.column_preview_texts.clear()
        else:
            self.status_var.set("No data loaded (file empty?)")

    def on_load_error(self, err_msg):
        self.progress.stop()
        messagebox.showerror("Load Error", f"Failed to load file:\n{err_msg}")
        self.status_var.set("Error loading file")
        self.original_data = None

    def load_sheet_list(self):
        try:
            xl = pd.ExcelFile(self.file_path.get())
            sheets = xl.sheet_names
            self.sheet_combo['values'] = sheets
            if sheets:
                self.sheet_name.set(sheets[0])
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read Excel sheets:\n{str(e)}")

    def show_original_preview(self):
        self.original_text.delete(1.0, tk.END)
        preview_df = self.original_data.head(20)
        lines = preview_df.to_string(index=True, header=self.has_header.get()).split('\n')
        for i, line in enumerate(lines):
            if i == 0 and self.has_header.get():
                self.original_text.insert(tk.END, line + '\n', "header")
            else:
                self.original_text.insert(tk.END, line + '\n')
        if len(self.original_data) > 20:
            self.original_text.insert(tk.END, f"\n... and {len(self.original_data) - 20} more rows")
        self.original_text.tag_config("header", foreground="blue", font=('Courier', 10, 'bold'))

    def update_column_info(self):
        if self.original_data is not None:
            try:
                col_idx = int(self.column_index.get())
                if self.has_header.get() and col_idx < len(self.headers):
                    self.column_name_label.config(text=self.headers[col_idx])
                else:
                    self.column_name_label.config(text=f"Column_{col_idx}")
            except:
                self.column_name_label.config(text="-")

    def preview_column(self):
        if self.original_data is None:
            messagebox.showwarning("Warning", "Load a file first")
            return
        try:
            col_idx = int(self.column_index.get())
            if col_idx >= len(self.original_data.columns):
                messagebox.showerror("Error", f"Column index out of range. Max index: {len(self.original_data.columns)-1}")
                return

            col_data = self.original_data.iloc[:, col_idx].tolist()
            tab_name = f"Column {col_idx}"
            if self.has_header.get() and col_idx < len(self.headers):
                tab_name += f": {self.headers[col_idx]}"

            # Check if already open
            for tab_id in self.preview_notebook.tabs():
                if self.preview_notebook.tab(tab_id, "text") == tab_name:
                    self.preview_notebook.select(tab_id)
                    return

            frame = ttk.Frame(self.preview_notebook)
            self.preview_notebook.add(frame, text=tab_name)
            text_widget = scrolledtext.ScrolledText(frame, wrap=tk.NONE, font=('Courier', 10))
            text_widget.pack(fill=tk.BOTH, expand=True)

            for i, val in enumerate(col_data[:30]):
                text_widget.insert(tk.END, f"{i:4d}: {val}\n\n")
            if len(col_data) > 30:
                text_widget.insert(tk.END, f"\n... and {len(col_data)-30} more")

            self.preview_notebook.select(frame)
            self.status_var.set(f"Previewing column {col_idx} ({len(col_data)} rows)")

        except ValueError:
            messagebox.showerror("Error", "Enter a valid column number")
        except Exception as e:
            messagebox.showerror("Error", f"Preview failed: {str(e)}")

    def separate_selected_column(self):
        if self.original_data is None:
            messagebox.showwarning("Warning", "Load a file first")
            return
        try:
            col_idx = int(self.column_index.get())
            self.separate_column(col_idx, ask_filename=True)
        except ValueError:
            messagebox.showerror("Error", "Invalid column index")

    def separate_all_columns(self):
        if self.original_data is None:
            messagebox.showwarning("Warning", "Load a file first")
            return

        num_cols = len(self.original_data.columns)
        if messagebox.askyesno("Confirm", f"Create {num_cols} separate files?\nOutput folder: {self.output_dir.get() or '(same as input)'}"):
            self.progress.start()
            self.status_var.set("Separating all columns...")
            # Run in thread to avoid UI freeze
            thread = threading.Thread(target=self._separate_all_columns_thread, daemon=True)
            thread.start()

    def _separate_all_columns_thread(self):
        errors = []
        for col in range(len(self.original_data.columns)):
            try:
                self.separate_column(col, ask_filename=False)
            except Exception as e:
                errors.append((col, str(e)))
        self.root.after(0, lambda: self._all_columns_finished(errors))

    def _all_columns_finished(self, errors):
        self.progress.stop()
        if errors:
            msg = "Some columns failed:\n" + "\n".join(f"Col {c}: {e}" for c, e in errors[:5])
            messagebox.showwarning("Partial Success", msg)
            self.status_var.set(f"Separated with {len(errors)} errors")
        else:
            messagebox.showinfo("Success", f"All {len(self.original_data.columns)} columns saved.")
            self.status_var.set("All columns separated successfully")

    def separate_column(self, col_idx, ask_filename=True):
        col_data = self.original_data.iloc[:, col_idx].tolist()

        # Build filename
        if self.has_header.get() and col_idx < len(self.headers):
            col_name = str(self.headers[col_idx])
            col_name = "".join(c for c in col_name if c.isalnum() or c in (' ', '-', '_')).strip() or f"col{col_idx}"
            base_filename = f"{self.output_prefix.get()}_{col_name}.txt"
        else:
            base_filename = f"{self.output_prefix.get()}_column_{col_idx}.txt"

        if ask_filename:
            save_path = filedialog.asksaveasfilename(
                title=f"Save column {col_idx}",
                defaultextension=".txt",
                filetypes=[("Text files", "*.txt")],
                initialfile=base_filename
            )
            if not save_path:
                return
        else:
            # Use output folder if set, else same as input file
            folder = self.output_dir.get()
            if not folder:
                folder = os.path.dirname(self.file_path.get()) or "."
            save_path = os.path.join(folder, base_filename)

        # Write with or without blank lines
        with open(save_path, 'w', encoding='utf-8') as f:
            for i, val in enumerate(col_data):
                f.write(str(val) + "\n")
                if self.add_blank_lines.get() and i < len(col_data)-1:
                    f.write("\n")

        if ask_filename:
            messagebox.showinfo("Saved", f"Column saved to:\n{save_path}")
            self.status_var.set(f"Saved: {os.path.basename(save_path)}")

    # ---------- Combine Methods ----------
    def preview_combined(self):
        if self.original_data is None:
            messagebox.showwarning("Warning", "Load a file first")
            return
        try:
            indices = self._parse_indices()
            if indices is None:
                return
            rows = self._build_combined(indices)
            if not rows:
                return

            tab_name = f"Combined ({','.join(map(str, indices))})"
            for tab_id in self.preview_notebook.tabs():
                if self.preview_notebook.tab(tab_id, "text") == tab_name:
                    self.preview_notebook.select(tab_id)
                    return

            frame = ttk.Frame(self.preview_notebook)
            self.preview_notebook.add(frame, text=tab_name)
            text_widget = scrolledtext.ScrolledText(frame, wrap=tk.NONE, font=('Courier', 10))
            text_widget.pack(fill=tk.BOTH, expand=True)

            for i, line in enumerate(rows[:20]):
                text_widget.insert(tk.END, f"{i:4d}: {line}\n\n")
            if len(rows) > 20:
                text_widget.insert(tk.END, f"\n... and {len(rows)-20} more")
            self.preview_notebook.select(frame)
            self.status_var.set(f"Preview combined ({len(rows)} rows)")
        except Exception as e:
            messagebox.showerror("Error", f"Preview failed: {str(e)}")

    def save_combined(self):
        if self.original_data is None:
            messagebox.showwarning("Warning", "Load a file first")
            return
        indices = self._parse_indices()
        if indices is None:
            return
        rows = self._build_combined(indices)
        save_path = filedialog.asksaveasfilename(
            title="Save Combined",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt")],
            initialfile="combined.txt"
        )
        if not save_path:
            return
        with open(save_path, 'w', encoding='utf-8') as f:
            for i, line in enumerate(rows):
                f.write(line + "\n")
                if self.add_blank_lines.get() and i < len(rows)-1:
                    f.write("\n")
        messagebox.showinfo("Saved", f"Combined file saved to:\n{save_path}")
        self.status_var.set(f"Saved combined to {os.path.basename(save_path)}")

    def _parse_indices(self):
        col_str = self.combine_columns.get().strip()
        if not col_str:
            messagebox.showerror("Error", "Enter column indices")
            return None
        indices = []
        for part in col_str.split(','):
            part = part.strip()
            if part:
                try:
                    idx = int(part)
                    indices.append(idx)
                except ValueError:
                    messagebox.showerror("Error", f"Invalid integer: {part}")
                    return None
        if not indices:
            return None
        max_col = len(self.original_data.columns) - 1
        for idx in indices:
            if idx < 0 or idx > max_col:
                messagebox.showerror("Error", f"Column {idx} out of range (0-{max_col})")
                return None
        return indices

    def _build_combined(self, indices):
        rows = []
        if self.combine_include_header.get() and self.has_header.get():
            header_parts = [self.headers[i] for i in indices]
            rows.append(self.combine_separator.get().join(header_parts))

        for row_idx in range(len(self.original_data)):
            values = [str(self.original_data.iloc[row_idx, col]) if not pd.isna(self.original_data.iloc[row_idx, col]) else ""
                      for col in indices]
            rows.append(self.combine_separator.get().join(values))
        return rows


def main():
    root = tk.Tk()
    app = ColumnSeparatorTool(root)
    root.mainloop()

if __name__ == "__main__":
    main()