import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os
import math
import threading
import queue
import traceback
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import pandas as pd
import xml.etree.ElementTree as ET
from pathlib import Path

# ==================== FIXED VOCABULARY ====================
class FixedVocab:
    """Fixed vocabulary of ~500 characters + special tokens."""
    def __init__(self):
        self.special_tokens = ['<PAD>', '<UNK>', '<SOS>', '<EOS>']
        self.allowed_chars = self._build_allowed_chars()
        self.char_to_idx, self.idx_to_char = self._build_mapping()
        self.pad_idx = self.char_to_idx['<PAD>']
        self.unk_idx = self.char_to_idx['<UNK>']
        self.sos_idx = self.char_to_idx['<SOS>']
        self.eos_idx = self.char_to_idx['<EOS>']
        print(f"Fixed vocabulary size: {len(self.char_to_idx)}")

    def _build_allowed_chars(self):
        chars = set()
        # Basic Latin (space to ~)
        for code in range(32, 127):
            chars.add(chr(code))
        # Cyrillic
        for code in range(0x0400, 0x0500):
            try:
                ch = chr(code)
                if ch.isprintable():
                    chars.add(ch)
            except:
                pass
        # Greek
        for code in range(0x0370, 0x0400):
            try:
                ch = chr(code)
                if ch.isprintable():
                    chars.add(ch)
            except:
                pass
        # Essential whitespace
        chars.update(['\n', '\r', '\t'])
        # Common typographic extras
        chars.update(['—', '–', '“', '”', '‘', '’', '…', '•'])
        return sorted(chars)

    def _build_mapping(self):
        char_to_idx = {}
        idx_to_char = {}
        for i, tok in enumerate(self.special_tokens):
            char_to_idx[tok] = i
            idx_to_char[i] = tok
        for i, ch in enumerate(self.allowed_chars, start=len(self.special_tokens)):
            char_to_idx[ch] = i
            idx_to_char[i] = ch
        return char_to_idx, idx_to_char

    def encode(self, text):
        """Convert string to list of token ids (unknown chars become <UNK>)."""
        return [self.char_to_idx.get(c, self.unk_idx) for c in text]

    def decode(self, ids, skip_special=True):
        """Convert list of token ids back to string, optionally skipping special tokens."""
        chars = []
        for i in ids:
            ch = self.idx_to_char.get(i, '')
            if skip_special and ch in self.special_tokens:
                continue
            chars.append(ch)
        return ''.join(chars)

# ==================== POSITIONAL ENCODING (for Transformer) ====================
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)  # [1, max_len, d_model]
        self.register_buffer('pe', pe)

    def forward(self, x):
        return x + self.pe[:, :x.size(1)]

# ==================== ATTENTION (for GRU) ====================
class LuongAttention(nn.Module):
    """Luong attention (general score)."""
    def __init__(self, hidden_size):
        super().__init__()
        self.attn = nn.Linear(hidden_size, hidden_size)

    def forward(self, hidden, encoder_outputs):
        # hidden: (batch, hidden_size)
        # encoder_outputs: (batch, src_len, hidden_size)
        attn_energies = torch.bmm(encoder_outputs, self.attn(hidden).unsqueeze(2)).squeeze(2)  # (batch, src_len)
        return F.softmax(attn_energies, dim=1).unsqueeze(1)  # (batch, 1, src_len)

# ==================== GRU SEQ2SEQ WITH ATTENTION ====================
class GRUSeq2Seq(nn.Module):
    def __init__(self, vocab_size, max_len=32, embed_size=128,
                 num_encoder_layers=4, num_decoder_layers=4, dropout=0.1):
        super().__init__()
        self.vocab_size = vocab_size
        self.max_len = max_len
        self.embed_size = embed_size
        self.num_encoder_layers = num_encoder_layers
        self.num_decoder_layers = num_decoder_layers
        self.dropout = dropout

        self.embedding = nn.Embedding(vocab_size, embed_size, padding_idx=0)

        # Encoder
        self.encoder = nn.GRU(embed_size, embed_size, num_layers=num_encoder_layers,
                               batch_first=True, dropout=dropout if num_encoder_layers > 1 else 0)

        # Decoder
        self.decoder = nn.GRU(embed_size + embed_size, embed_size, num_layers=num_decoder_layers,
                               batch_first=True, dropout=dropout if num_decoder_layers > 1 else 0)

        # Attention
        self.attention = LuongAttention(embed_size)

        # Output projection
        self.fc_out = nn.Linear(embed_size, vocab_size)

        # Start token embedding
        self.start_embed = nn.Parameter(torch.randn(1, 1, embed_size))

        self._init_weights()
        print(f"GRU Seq2Seq parameters: {sum(p.numel() for p in self.parameters()):,}")

    def _init_weights(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def forward(self, src, tgt, teacher_forcing_ratio=0.5):
        """
        src: (batch, src_len)
        tgt: (batch, tgt_len)  # includes SOS and EOS
        Returns: (batch, tgt_len-1, vocab_size)  # predictions for positions 1..tgt_len-1
        """
        batch_size = src.size(0)
        src_len = src.size(1)
        tgt_len = tgt.size(1)

        # Decoder input is tgt without the last token (so we have tgt_len-1 tokens to feed)
        decoder_input = tgt[:, :-1]  # (batch, tgt_len-1)

        # Embed source
        src_emb = self.embedding(src)  # (batch, src_len, embed)
        encoder_outputs, hidden = self.encoder(src_emb)  # hidden: (num_layers, batch, embed)

        # Prepare decoder states
        decoder_hidden = hidden

        # Decide teacher forcing for the whole batch
        use_teacher_forcing = torch.rand(1).item() < teacher_forcing_ratio

        outputs = []
        if use_teacher_forcing:
            # Feed ground truth at each step
            for t in range(decoder_input.size(1)):
                current_input = decoder_input[:, t].unsqueeze(1)  # (batch, 1)
                dec_emb = self.embedding(current_input)

                # Attention
                attn_weights = self.attention(decoder_hidden[-1], encoder_outputs)
                context = torch.bmm(attn_weights, encoder_outputs)

                rnn_input = torch.cat([dec_emb, context], dim=2)
                dec_output, decoder_hidden = self.decoder(rnn_input, decoder_hidden)
                output = self.fc_out(dec_output.squeeze(1))
                outputs.append(output.unsqueeze(1))
        else:
            # Start with SOS token
            current_input = decoder_input[:, 0].unsqueeze(1)  # SOS
            for t in range(decoder_input.size(1)):
                dec_emb = self.embedding(current_input)
                attn_weights = self.attention(decoder_hidden[-1], encoder_outputs)
                context = torch.bmm(attn_weights, encoder_outputs)
                rnn_input = torch.cat([dec_emb, context], dim=2)
                dec_output, decoder_hidden = self.decoder(rnn_input, decoder_hidden)
                output = self.fc_out(dec_output.squeeze(1))
                outputs.append(output.unsqueeze(1))

                # Next input is predicted token
                _, topi = output.topk(1)
                current_input = topi.detach()

        outputs = torch.cat(outputs, dim=1)  # (batch, tgt_len-1, vocab_size)
        return outputs

    @torch.no_grad()
    def generate(self, src, sos_idx, eos_idx, max_len=None, temperature=1.0):
        self.eval()
        if max_len is None:
            max_len = self.max_len

        batch_size = src.size(0)
        src_len = src.size(1)

        src_emb = self.embedding(src)
        encoder_outputs, hidden = self.encoder(src_emb)

        decoder_input = torch.full((batch_size, 1), sos_idx, dtype=torch.long, device=src.device)
        decoder_hidden = hidden
        generated = [sos_idx]

        for _ in range(max_len):
            dec_emb = self.embedding(decoder_input)
            attn_weights = self.attention(decoder_hidden[-1], encoder_outputs)
            context = torch.bmm(attn_weights, encoder_outputs)
            rnn_input = torch.cat([dec_emb, context], dim=2)
            dec_output, decoder_hidden = self.decoder(rnn_input, decoder_hidden)
            logits = self.fc_out(dec_output.squeeze(1)) / temperature
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, 1).item()

            if next_token == eos_idx:
                break

            generated.append(next_token)
            decoder_input = torch.tensor([[next_token]], device=src.device)

        return generated

    def get_config(self):
        return {
            'arch': 'GRU',
            'vocab_size': self.vocab_size,
            'max_len': self.max_len,
            'embed_size': self.embed_size,
            'num_encoder_layers': self.num_encoder_layers,
            'num_decoder_layers': self.num_decoder_layers,
            'dropout': self.dropout
        }

    def save(self, path):
        torch.save({
            'config': self.get_config(),
            'state_dict': self.state_dict()
        }, path)

    @classmethod
    def load(cls, path):
        checkpoint = torch.load(path, map_location='cpu')
        config = checkpoint['config']
        model = cls(**{k: v for k, v in config.items() if k != 'arch'})
        model.load_state_dict(checkpoint['state_dict'])
        model.eval()
        return model

# ==================== TRANSFORMER SEQ2SEQ (fixed interface) ====================
class TransformerSeq2Seq(nn.Module):
    def __init__(self, vocab_size, max_len=32, embed_size=128, nhead=8,
                 num_encoder_layers=4, num_decoder_layers=4, dim_feedforward=512,
                 dropout=0.1, activation='gelu'):
        super().__init__()
        self.vocab_size = vocab_size
        self.max_len = max_len
        self.embed_size = embed_size
        self.nhead = nhead
        self.num_encoder_layers = num_encoder_layers
        self.num_decoder_layers = num_decoder_layers
        self.dim_feedforward = dim_feedforward
        self.dropout = dropout
        self.activation = activation

        self.embedding = nn.Embedding(vocab_size, embed_size, padding_idx=0)
        self.pos_encoder = PositionalEncoding(embed_size, max_len)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=embed_size,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            activation=activation,
            batch_first=True
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_encoder_layers)

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=embed_size,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            activation=activation,
            batch_first=True
        )
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=num_decoder_layers)

        self.fc_out = nn.Linear(embed_size, vocab_size)
        self.start_embed = nn.Parameter(torch.randn(1, 1, embed_size))
        self._init_weights()
        print(f"Transformer Seq2Seq parameters: {sum(p.numel() for p in self.parameters()):,}")

    def _init_weights(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def generate_padding_mask(self, x):
        return (x == 0)

    def generate_causal_mask(self, sz):
        mask = torch.triu(torch.ones(sz, sz) * float('-inf'), diagonal=1)
        return mask

    def forward(self, src, tgt):
        """
        src: (batch, src_len)
        tgt: (batch, tgt_len)  # includes SOS and EOS
        Returns: (batch, tgt_len-1, vocab_size)  # predictions for positions 1..tgt_len-1
        """
        batch_size = src.size(0)
        src_len = src.size(1)
        tgt_len = tgt.size(1)

        # Decoder input is tgt without the last token
        decoder_input = tgt[:, :-1]  # (batch, tgt_len-1)

        src_pad_mask = self.generate_padding_mask(src)
        tgt_pad_mask = self.generate_padding_mask(decoder_input)
        tgt_causal_mask = self.generate_causal_mask(decoder_input.size(1)).to(src.device)

        src_emb = self.embedding(src) * math.sqrt(self.embed_size)
        src_emb = self.pos_encoder(src_emb)

        tgt_emb = self.embedding(decoder_input) * math.sqrt(self.embed_size)
        tgt_emb = self.pos_encoder(tgt_emb)

        memory = self.encoder(src_emb, src_key_padding_mask=src_pad_mask)

        output = self.decoder(
            tgt_emb,
            memory,
            tgt_mask=tgt_causal_mask,
            tgt_key_padding_mask=tgt_pad_mask,
            memory_key_padding_mask=src_pad_mask
        )

        logits = self.fc_out(output)
        return logits

    @torch.no_grad()
    def generate(self, src, sos_idx, eos_idx, max_len=None, temperature=1.0):
        self.eval()
        if max_len is None:
            max_len = self.max_len

        batch_size = src.size(0)
        src_len = src.size(1)

        src_pad_mask = self.generate_padding_mask(src)
        src_emb = self.embedding(src) * math.sqrt(self.embed_size)
        src_emb = self.pos_encoder(src_emb)
        memory = self.encoder(src_emb, src_key_padding_mask=src_pad_mask)

        tgt = torch.full((batch_size, 1), sos_idx, dtype=torch.long, device=src.device)
        generated = [sos_idx]

        for _ in range(max_len):
            tgt_len = tgt.size(1)
            tgt_causal_mask = self.generate_causal_mask(tgt_len).to(src.device)
            tgt_pad_mask = (tgt == 0)

            tgt_emb = self.embedding(tgt) * math.sqrt(self.embed_size)
            tgt_emb = self.pos_encoder(tgt_emb)

            output = self.decoder(
                tgt_emb,
                memory,
                tgt_mask=tgt_causal_mask,
                tgt_key_padding_mask=tgt_pad_mask,
                memory_key_padding_mask=src_pad_mask
            )
            logits = self.fc_out(output[:, -1:, :]) / temperature
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs.squeeze(1), 1).item()

            if next_token == eos_idx:
                break

            generated.append(next_token)
            tgt = torch.cat([tgt, torch.tensor([[next_token]], device=src.device)], dim=1)

        return generated

    def get_config(self):
        return {
            'arch': 'Transformer',
            'vocab_size': self.vocab_size,
            'max_len': self.max_len,
            'embed_size': self.embed_size,
            'nhead': self.nhead,
            'num_encoder_layers': self.num_encoder_layers,
            'num_decoder_layers': self.num_decoder_layers,
            'dim_feedforward': self.dim_feedforward,
            'dropout': self.dropout,
            'activation': self.activation
        }

    def save(self, path):
        torch.save({
            'config': self.get_config(),
            'state_dict': self.state_dict()
        }, path)

    @classmethod
    def load(cls, path):
        checkpoint = torch.load(path, map_location='cpu')
        config = checkpoint['config']
        model = cls(**{k: v for k, v in config.items() if k != 'arch'})
        model.load_state_dict(checkpoint['state_dict'])
        model.eval()
        return model

# ==================== DATASET ====================
class WordPairDataset(Dataset):
    def __init__(self, pairs, vocab, max_len=32):
        self.pairs = pairs
        self.vocab = vocab
        self.max_len = max_len

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        input_word, output_word = self.pairs[idx]

        input_ids = self.vocab.encode(input_word)
        if len(input_ids) > self.max_len:
            input_ids = input_ids[:self.max_len]
        input_ids += [self.vocab.pad_idx] * (self.max_len - len(input_ids))

        output_ids = [self.vocab.sos_idx] + self.vocab.encode(output_word) + [self.vocab.eos_idx]
        if len(output_ids) > self.max_len:
            output_ids = output_ids[:self.max_len-1] + [self.vocab.eos_idx]
        output_ids += [self.vocab.pad_idx] * (self.max_len - len(output_ids))

        return torch.tensor(input_ids, dtype=torch.long), torch.tensor(output_ids, dtype=torch.long)

# ==================== DATA LOADING ====================
def parse_text_pairs(text):
    pairs = []
    for line in text.strip().split('\n'):
        parts = line.strip().split()
        if len(parts) >= 2:
            pairs.append((parts[0], parts[1]))
    return pairs

def load_pairs_from_csv(file_path, input_col, output_col, has_header=True, delimiter=','):
    if file_path.endswith(('.xlsx', '.xls')):
        df = pd.read_excel(file_path, header=0 if has_header else None, dtype=str)
    else:
        df = pd.read_csv(file_path, delimiter=delimiter, header=0 if has_header else None, dtype=str)
    pairs = []
    for _, row in df.iterrows():
        inp = str(row[input_col]) if input_col in df.columns else str(row.iloc[int(input_col)])
        out = str(row[output_col]) if output_col in df.columns else str(row.iloc[int(output_col)])
        pairs.append((inp.strip(), out.strip()))
    return pairs

def load_pairs_from_xml(file_path, input_tag, output_tag):
    tree = ET.parse(file_path)
    root = tree.getroot()
    pairs = []
    for elem in root.findall('.//' + input_tag):
        parent = elem.getparent()
        out_elem = parent.find(output_tag)
        if out_elem is not None:
            pairs.append((elem.text.strip() if elem.text else '',
                          out_elem.text.strip() if out_elem.text else ''))
    return pairs

# ==================== MODEL CONFIGURATION ====================
def get_model_config(size, arch, override_heads=None):
    base = {}
    if size == "Small":
        base = {'embed_size': 64, 'num_encoder_layers': 3, 'num_decoder_layers': 3}
        if arch == "Transformer":
            base.update({'nhead': 4, 'dim_feedforward': 256})
    elif size == "Medium":
        base = {'embed_size': 128, 'num_encoder_layers': 4, 'num_decoder_layers': 4}
        if arch == "Transformer":
            base.update({'nhead': 8, 'dim_feedforward': 512})
    else:  # Large
        base = {'embed_size': 192, 'num_encoder_layers': 6, 'num_decoder_layers': 6}
        if arch == "Transformer":
            base.update({'nhead': 12, 'dim_feedforward': 768})

    if arch == "Transformer" and override_heads and override_heads > 0:
        base['nhead'] = override_heads
    return base

# ==================== TRAINING FUNCTION ====================
def train_model(pairs, vocab, model, epochs=100, batch_size=16, lr=0.0003, device='cpu'):
    max_len = model.max_len
    dataset = WordPairDataset(pairs, vocab, max_len)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    criterion = nn.CrossEntropyLoss(ignore_index=vocab.pad_idx)
    optimizer = optim.AdamW(model.parameters(), lr=lr)

    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for src, tgt in dataloader:
            src, tgt = src.to(device), tgt.to(device)

            # Model now expects full tgt (including SOS) and returns logits of shape (batch, tgt_len-1, vocab_size)
            output = model(src, tgt)
            targets = tgt[:, 1:].contiguous()  # shape (batch, tgt_len-1)

            loss = criterion(output.reshape(-1, len(vocab.char_to_idx)), targets.view(-1))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            total_loss += loss.item()

        avg_loss = total_loss / len(dataloader)

        if epoch % 10 == 0:
            model.eval()
            test_results = []
            for inp_word, exp_word in pairs[:min(3, len(pairs))]:
                src_ids = vocab.encode(inp_word)
                if len(src_ids) > max_len:
                    src_ids = src_ids[:max_len]
                src_tensor = torch.tensor([src_ids + [vocab.pad_idx]*(max_len - len(src_ids))],
                                           dtype=torch.long, device=device)
                gen_ids = model.generate(src_tensor, vocab.sos_idx, vocab.eos_idx, max_len)
                result = vocab.decode(gen_ids[1:])
                test_results.append(f"{inp_word}->{result}")
            yield epoch+1, avg_loss, f" | Test: {' '.join(test_results)}"
        else:
            yield epoch+1, avg_loss, ""

    yield None, None, ""

# ==================== CSV IMPORT DIALOG ====================
class CSVImportDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title("Import from CSV/Excel")
        self.geometry("650x450")
        self.result = None

        self.file_path = tk.StringVar()
        self.delimiter = tk.StringVar(value=",")
        self.has_header = tk.BooleanVar(value=True)
        self.sheet_name = tk.StringVar()
        self.input_col = tk.StringVar()
        self.output_col = tk.StringVar()
        self.df = None

        self.setup_ui()
        self.transient(parent)
        self.grab_set()

    def setup_ui(self):
        main = ttk.Frame(self, padding="10")
        main.pack(fill='both', expand=True)

        ttk.Label(main, text="File:").grid(row=0, column=0, sticky='w', pady=5)
        ttk.Entry(main, textvariable=self.file_path, width=50).grid(row=0, column=1, padx=5, sticky='ew')
        ttk.Button(main, text="Browse", command=self.browse).grid(row=0, column=2, padx=5)
        main.columnconfigure(1, weight=1)

        ttk.Label(main, text="Delimiter (CSV):").grid(row=1, column=0, sticky='w', pady=5)
        self.delimiter_combo = ttk.Combobox(main, textvariable=self.delimiter,
                                            values=[",", ";", "\t", "|"], width=10)
        self.delimiter_combo.grid(row=1, column=1, sticky='w', padx=5)

        ttk.Checkbutton(main, text="File has header row", variable=self.has_header,
                        command=self.load_preview).grid(row=2, column=1, sticky='w', pady=5)

        ttk.Label(main, text="Excel sheet:").grid(row=3, column=0, sticky='w', pady=5)
        self.sheet_combo = ttk.Combobox(main, textvariable=self.sheet_name, width=30)
        self.sheet_combo.grid(row=3, column=1, sticky='w', padx=5)
        ttk.Button(main, text="Load sheets", command=self.load_sheets).grid(row=3, column=2)

        ttk.Button(main, text="Load Preview", command=self.load_preview).grid(row=4, column=1, pady=10)

        col_frame = ttk.LabelFrame(main, text="Select Columns", padding="10")
        col_frame.grid(row=5, column=0, columnspan=3, sticky='ew', pady=10)
        col_frame.columnconfigure(1, weight=1)
        col_frame.columnconfigure(3, weight=1)

        ttk.Label(col_frame, text="Input column:").grid(row=0, column=0, sticky='w')
        self.input_combo = ttk.Combobox(col_frame, textvariable=self.input_col, width=20)
        self.input_combo.grid(row=0, column=1, padx=5, sticky='ew')

        ttk.Label(col_frame, text="Output column:").grid(row=0, column=2, sticky='w', padx=(20,0))
        self.output_combo = ttk.Combobox(col_frame, textvariable=self.output_col, width=20)
        self.output_combo.grid(row=0, column=3, padx=5, sticky='ew')

        preview_frame = ttk.LabelFrame(main, text="Preview", padding="5")
        preview_frame.grid(row=6, column=0, columnspan=3, sticky='nsew', pady=10)
        main.rowconfigure(6, weight=1)

        self.preview_text = scrolledtext.ScrolledText(preview_frame, height=8, font=('Courier', 9))
        self.preview_text.pack(fill='both', expand=True)

        btn_frame = ttk.Frame(main)
        btn_frame.grid(row=7, column=0, columnspan=3, pady=10)
        ttk.Button(btn_frame, text="Import", command=self.import_data).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="Cancel", command=self.destroy).pack(side='left')

    def browse(self):
        filename = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("Excel files", "*.xlsx *.xls"), ("All files", "*.*")])
        if filename:
            self.file_path.set(filename)
            self.load_preview()

    def load_sheets(self):
        try:
            xl = pd.ExcelFile(self.file_path.get())
            self.sheet_combo['values'] = xl.sheet_names
            if xl.sheet_names:
                self.sheet_name.set(xl.sheet_names[0])
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read sheets: {e}")

    def load_preview(self):
        path = self.file_path.get()
        if not path:
            return
        try:
            if path.endswith(('.xlsx', '.xls')):
                sheet = self.sheet_name.get() if self.sheet_name.get() else 0
                self.df = pd.read_excel(path, sheet_name=sheet, header=0 if self.has_header.get() else None, dtype=str)
            else:
                delim = self.delimiter.get()
                self.df = pd.read_csv(path, delimiter=delim, header=0 if self.has_header.get() else None, dtype=str)

            if self.has_header.get():
                cols = list(self.df.columns)
            else:
                cols = [str(i) for i in range(len(self.df.columns))]
            self.input_combo['values'] = cols
            self.output_combo['values'] = cols
            if cols:
                self.input_col.set(cols[0])
                self.output_col.set(cols[1] if len(cols) > 1 else cols[0])

            self.preview_text.delete('1.0', 'end')
            preview_str = self.df.head(10).to_string(index=False)
            self.preview_text.insert('1.0', preview_str)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load file: {e}")

    def import_data(self):
        if self.df is None or not self.input_col.get() or not self.output_col.get():
            messagebox.showerror("Error", "Please load a file and select columns.")
            return
        try:
            input_idx = self.input_col.get()
            output_idx = self.output_col.get()
            if not self.has_header.get():
                input_idx = int(input_idx)
                output_idx = int(output_idx)
            pairs = []
            for _, row in self.df.iterrows():
                inp = str(row[input_idx]) if isinstance(input_idx, str) else str(row.iloc[input_idx])
                out = str(row[output_idx]) if isinstance(output_idx, str) else str(row.iloc[output_idx])
                pairs.append((inp.strip(), out.strip()))
            self.result = pairs
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Import failed: {e}")

# ==================== XML IMPORT DIALOG ====================
class XMLImportDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title("Import from XML")
        self.geometry("500x300")
        self.result = None

        self.file_path = tk.StringVar()
        self.input_tag = tk.StringVar(value="input")
        self.output_tag = tk.StringVar(value="output")

        self.setup_ui()
        self.transient(parent)
        self.grab_set()

    def setup_ui(self):
        main = ttk.Frame(self, padding="10")
        main.pack(fill='both', expand=True)

        ttk.Label(main, text="XML File:").grid(row=0, column=0, sticky='w', pady=5)
        ttk.Entry(main, textvariable=self.file_path, width=40).grid(row=0, column=1, padx=5)
        ttk.Button(main, text="Browse", command=self.browse).grid(row=0, column=2)

        ttk.Label(main, text="Input tag name:").grid(row=1, column=0, sticky='w', pady=5)
        ttk.Entry(main, textvariable=self.input_tag, width=30).grid(row=1, column=1, padx=5, sticky='w')

        ttk.Label(main, text="Output tag name:").grid(row=2, column=0, sticky='w', pady=5)
        ttk.Entry(main, textvariable=self.output_tag, width=30).grid(row=2, column=1, padx=5, sticky='w')

        self.preview_text = scrolledtext.ScrolledText(main, height=10, font=('Courier', 9))
        self.preview_text.grid(row=3, column=0, columnspan=3, sticky='nsew', pady=10)
        main.rowconfigure(3, weight=1)
        main.columnconfigure(1, weight=1)

        ttk.Button(main, text="Load Preview", command=self.load_preview).grid(row=4, column=1, pady=5)

        btn_frame = ttk.Frame(main)
        btn_frame.grid(row=5, column=0, columnspan=3, pady=10)
        ttk.Button(btn_frame, text="Import", command=self.import_data).pack(side='left', padx=5)
        ttk.Button(btn_frame, text="Cancel", command=self.destroy).pack(side='left')

    def browse(self):
        filename = filedialog.askopenfilename(filetypes=[("XML files", "*.xml"), ("All files", "*.*")])
        if filename:
            self.file_path.set(filename)

    def load_preview(self):
        path = self.file_path.get()
        if not path:
            return
        try:
            tree = ET.parse(path)
            root = tree.getroot()
            pairs = []
            for elem in root.findall('.//' + self.input_tag.get()):
                parent = elem.getparent()
                out_elem = parent.find(self.output_tag.get())
                if out_elem is not None:
                    pairs.append((elem.text.strip() if elem.text else '',
                                  out_elem.text.strip() if out_elem.text else ''))
            preview = "\n".join([f"{i}: {p[0]} -> {p[1]}" for i, p in enumerate(pairs[:10])])
            self.preview_text.delete('1.0', 'end')
            self.preview_text.insert('1.0', preview)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to parse XML: {e}")

    def import_data(self):
        path = self.file_path.get()
        if not path:
            messagebox.showerror("Error", "Please select a file.")
            return
        try:
            tree = ET.parse(path)
            root = tree.getroot()
            pairs = []
            for elem in root.findall('.//' + self.input_tag.get()):
                parent = elem.getparent()
                out_elem = parent.find(self.output_tag.get())
                if out_elem is not None:
                    pairs.append((elem.text.strip() if elem.text else '',
                                  out_elem.text.strip() if out_elem.text else ''))
            self.result = pairs
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Import failed: {e}")

# ==================== MAIN UI ====================
class TransformerPredictorUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Word Predictor: GRU vs Transformer")
        self.root.geometry("900x700")

        # Fixed vocabulary
        self.vocab = FixedVocab()

        # State
        self.model = None
        self.pairs = []
        self.training_thread = None
        self.stop_training = False
        self.queue = queue.Queue()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        self.setup_ui()
        self.root.after(100, self.process_queue)

    def setup_ui(self):
        main = ttk.Frame(self.root, padding="10")
        main.pack(fill='both', expand=True)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(0, weight=1)

        notebook = ttk.Notebook(main)
        notebook.grid(row=0, column=0, sticky='nsew')

        # Data tab
        self.data_tab = ttk.Frame(notebook, padding="10")
        notebook.add(self.data_tab, text="Data")
        self.setup_data_tab()

        # Train tab
        self.train_tab = ttk.Frame(notebook, padding="10")
        notebook.add(self.train_tab, text="Train")
        self.setup_train_tab()

        # Test tab
        self.test_tab = ttk.Frame(notebook, padding="10")
        notebook.add(self.test_tab, text="Test")
        self.setup_test_tab()

        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status = ttk.Label(main, textvariable=self.status_var, relief='sunken', anchor='w')
        status.grid(row=1, column=0, sticky='ew', pady=(5,0))

    def setup_data_tab(self):
        list_frame = ttk.LabelFrame(self.data_tab, text="Word Pairs", padding="5")
        list_frame.pack(fill='both', expand=True, pady=5)

        columns = ('#', 'Input', 'Output')
        self.pair_tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=12)
        self.pair_tree.heading('#', text='#')
        self.pair_tree.heading('Input', text='Input')
        self.pair_tree.heading('Output', text='Output')
        self.pair_tree.column('#', width=40, anchor='center')
        self.pair_tree.column('Input', width=200)
        self.pair_tree.column('Output', width=200)

        scrollbar = ttk.Scrollbar(list_frame, orient='vertical', command=self.pair_tree.yview)
        self.pair_tree.configure(yscrollcommand=scrollbar.set)
        self.pair_tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')

        btn_frame = ttk.Frame(self.data_tab)
        btn_frame.pack(fill='x', pady=5)

        ttk.Button(btn_frame, text="Add Pair", command=self.add_pair_dialog).pack(side='left', padx=2)
        ttk.Button(btn_frame, text="Remove Selected", command=self.remove_selected_pair).pack(side='left', padx=2)
        ttk.Button(btn_frame, text="Clear All", command=self.clear_all_pairs).pack(side='left', padx=2)

        ttk.Separator(btn_frame, orient='vertical').pack(side='left', padx=10, fill='y')

        ttk.Button(btn_frame, text="Load Text File", command=self.load_text_file).pack(side='left', padx=2)
        ttk.Button(btn_frame, text="Load CSV/Excel", command=self.load_csv_dialog).pack(side='left', padx=2)
        ttk.Button(btn_frame, text="Load XML", command=self.load_xml_dialog).pack(side='left', padx=2)

        self.pair_count_label = ttk.Label(self.data_tab, text="Total pairs: 0")
        self.pair_count_label.pack(anchor='w', pady=5)

    def setup_train_tab(self):
        # Settings frame
        settings = ttk.LabelFrame(self.train_tab, text="Training Settings", padding="10")
        settings.pack(fill='x', pady=5)

        # Architecture
        ttk.Label(settings, text="Architecture:").grid(row=0, column=0, sticky='w', padx=5, pady=2)
        self.arch = tk.StringVar(value="Transformer")
        arch_combo = ttk.Combobox(settings, textvariable=self.arch,
                                   values=["GRU (with attention)", "Transformer"], width=20)
        arch_combo.grid(row=0, column=1, padx=5, pady=2, sticky='w')

        # Model size
        ttk.Label(settings, text="Model size:").grid(row=1, column=0, sticky='w', padx=5, pady=2)
        self.model_size = tk.StringVar(value="Medium")
        size_combo = ttk.Combobox(settings, textvariable=self.model_size,
                                   values=["Small", "Medium", "Large"], width=10)
        size_combo.grid(row=1, column=1, padx=5, pady=2, sticky='w')

        # Heads (only for transformer, but we keep it)
        ttk.Label(settings, text="Heads (0 = preset):").grid(row=1, column=2, sticky='w', padx=(20,5), pady=2)
        self.heads_var = tk.StringVar(value="0")
        ttk.Entry(settings, textvariable=self.heads_var, width=6).grid(row=1, column=3, padx=5, pady=2)

        # Epochs
        ttk.Label(settings, text="Epochs:").grid(row=2, column=0, sticky='w', padx=5, pady=2)
        self.epochs_var = tk.StringVar(value="100")
        ttk.Entry(settings, textvariable=self.epochs_var, width=8).grid(row=2, column=1, padx=5, pady=2, sticky='w')

        # Batch size
        ttk.Label(settings, text="Batch size:").grid(row=2, column=2, sticky='w', padx=(20,5), pady=2)
        self.batch_var = tk.StringVar(value="16")
        ttk.Entry(settings, textvariable=self.batch_var, width=8).grid(row=2, column=3, padx=5, pady=2)

        # Learning rate
        ttk.Label(settings, text="Learning rate:").grid(row=3, column=0, sticky='w', padx=5, pady=2)
        self.lr_var = tk.StringVar(value="0.0003")
        ttk.Entry(settings, textvariable=self.lr_var, width=8).grid(row=3, column=1, padx=5, pady=2, sticky='w')

        # Buttons row 1: Init, Save, Load
        btn_frame1 = ttk.Frame(self.train_tab)
        btn_frame1.pack(pady=5)
        self.init_btn = ttk.Button(btn_frame1, text="Init Model", command=self.init_model)
        self.init_btn.pack(side='left', padx=5)
        self.save_btn = ttk.Button(btn_frame1, text="Save Model", command=self.save_model, state='disabled')
        self.save_btn.pack(side='left', padx=5)
        self.load_btn = ttk.Button(btn_frame1, text="Load Model", command=self.load_model)
        self.load_btn.pack(side='left', padx=5)

        # Buttons row 2: Train / Stop
        btn_frame2 = ttk.Frame(self.train_tab)
        btn_frame2.pack(pady=5)
        self.train_btn = ttk.Button(btn_frame2, text="Start Training", command=self.start_training, state='disabled')
        self.train_btn.pack(side='left', padx=5)
        self.stop_btn = ttk.Button(btn_frame2, text="Stop", command=self.stop_training_cmd, state='disabled')
        self.stop_btn.pack(side='left', padx=5)

        # Progress
        self.progress = ttk.Progressbar(self.train_tab, mode='indeterminate', length=400)
        self.progress.pack(pady=5)

        # Loss display
        loss_frame = ttk.Frame(self.train_tab)
        loss_frame.pack(pady=5)
        ttk.Label(loss_frame, text="Current Loss:").pack(side='left')
        self.loss_label = ttk.Label(loss_frame, text="0.0000", font='Arial 10 bold', foreground='blue')
        self.loss_label.pack(side='left', padx=5)

        # Log area
        ttk.Label(self.train_tab, text="Training Log:").pack(anchor='w', pady=(10,5))
        self.log = scrolledtext.ScrolledText(self.train_tab, height=12, state='disabled')
        self.log.pack(fill='both', expand=True)

    def setup_test_tab(self):
        # Single word transformation
        single_frame = ttk.LabelFrame(self.test_tab, text="Single Word", padding="10")
        single_frame.pack(fill='x', pady=5)

        ttk.Label(single_frame, text="Input:").grid(row=0, column=0, sticky='w')
        self.input_var = tk.StringVar()
        ttk.Entry(single_frame, textvariable=self.input_var, width=40).grid(row=0, column=1, padx=5, sticky='w')
        ttk.Button(single_frame, text="Transform", command=self.process_input).grid(row=0, column=2, padx=5)

        # Output text area
        ttk.Label(single_frame, text="Output:").grid(row=1, column=0, sticky='nw', pady=(10,0))
        self.output_text = scrolledtext.ScrolledText(single_frame, height=5, wrap='word', width=60)
        self.output_text.grid(row=2, column=0, columnspan=3, pady=5, sticky='ew')

        # Batch test
        batch_frame = ttk.LabelFrame(self.test_tab, text="Batch Test", padding="10")
        batch_frame.pack(fill='both', expand=True, pady=5)

        ttk.Button(batch_frame, text="Test All Pairs", command=self.test_all_pairs).pack(anchor='w', pady=5)

        self.test_output = scrolledtext.ScrolledText(batch_frame, height=15, font=('Courier', 10))
        self.test_output.pack(fill='both', expand=True)

    # ========== DATA TAB METHODS ==========
    def refresh_pair_list(self):
        for item in self.pair_tree.get_children():
            self.pair_tree.delete(item)
        for i, (inp, out) in enumerate(self.pairs):
            self.pair_tree.insert('', 'end', values=(i+1, inp, out))
        self.pair_count_label.config(text=f"Total pairs: {len(self.pairs)}")

    def add_pair_dialog(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Add Pair")
        dialog.geometry("400x150")
        dialog.transient(self.root)
        dialog.grab_set()

        ttk.Label(dialog, text="Input:").grid(row=0, column=0, padx=10, pady=10, sticky='w')
        input_var = tk.StringVar()
        ttk.Entry(dialog, textvariable=input_var, width=30).grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(dialog, text="Output:").grid(row=1, column=0, padx=10, pady=10, sticky='w')
        output_var = tk.StringVar()
        ttk.Entry(dialog, textvariable=output_var, width=30).grid(row=1, column=1, padx=10, pady=10)

        def add():
            inp = input_var.get().strip()
            out = output_var.get().strip()
            if inp and out:
                self.pairs.append((inp, out))
                self.refresh_pair_list()
                dialog.destroy()

        ttk.Button(dialog, text="Add", command=add).grid(row=2, column=0, columnspan=2, pady=10)

    def remove_selected_pair(self):
        selected = self.pair_tree.selection()
        if not selected:
            return
        for item in selected:
            idx = int(self.pair_tree.item(item, 'values')[0]) - 1
            if 0 <= idx < len(self.pairs):
                self.pairs.pop(idx)
        self.refresh_pair_list()

    def clear_all_pairs(self):
        if messagebox.askyesno("Confirm", "Clear all pairs?"):
            self.pairs.clear()
            self.refresh_pair_list()

    def load_text_file(self):
        path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if path:
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    text = f.read()
                new_pairs = parse_text_pairs(text)
                self.pairs.extend(new_pairs)
                self.refresh_pair_list()
                self.status_var.set(f"Loaded {len(new_pairs)} pairs from {os.path.basename(path)}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load file: {e}")

    def load_csv_dialog(self):
        dlg = CSVImportDialog(self.root)
        self.root.wait_window(dlg)
        if dlg.result:
            self.pairs.extend(dlg.result)
            self.refresh_pair_list()
            self.status_var.set(f"Imported {len(dlg.result)} pairs from CSV")

    def load_xml_dialog(self):
        dlg = XMLImportDialog(self.root)
        self.root.wait_window(dlg)
        if dlg.result:
            self.pairs.extend(dlg.result)
            self.refresh_pair_list()
            self.status_var.set(f"Imported {len(dlg.result)} pairs from XML")

    # ========== TRAIN TAB METHODS ==========
    def init_model(self):
        """Initialize model with current settings."""
        arch = self.arch.get()
        size = self.model_size.get()
        try:
            heads = int(self.heads_var.get())
        except:
            heads = 0

        base_config = get_model_config(size, arch, heads)
        common_params = {
            'vocab_size': len(self.vocab.char_to_idx),
            'max_len': 32,
            'embed_size': base_config['embed_size'],
            'num_encoder_layers': base_config['num_encoder_layers'],
            'num_decoder_layers': base_config['num_decoder_layers'],
            'dropout': 0.1
        }

        if arch.startswith("GRU"):
            self.model = GRUSeq2Seq(**common_params)
        else:
            # Transformer
            trans_params = {
                **common_params,
                'nhead': base_config.get('nhead', 8),
                'dim_feedforward': base_config.get('dim_feedforward', 512),
                'activation': 'gelu'
            }
            self.model = TransformerSeq2Seq(**trans_params)

        self.model.to(self.device)
        self.log_message(f"Model initialized: {arch}, {size} size")
        self.save_btn.config(state='normal')
        self.train_btn.config(state='normal')
        self.status_var.set("Model initialized")

    def save_model(self):
        if self.model is None:
            messagebox.showerror("Error", "No model to save.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".pth",
                                            filetypes=[("PyTorch model", "*.pth")])
        if path:
            try:
                self.model.save(path)
                self.log_message(f"Model saved to {os.path.basename(path)}")
                self.status_var.set("Model saved")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save model: {e}")

    def load_model(self):
        path = filedialog.askopenfilename(filetypes=[("PyTorch model", "*.pth")])
        if path:
            try:
                checkpoint = torch.load(path, map_location='cpu')
                config = checkpoint['config']
                arch = config.get('arch', 'Transformer')  # default for backward compat
                if arch == 'GRU':
                    self.model = GRUSeq2Seq.load(path)
                else:
                    self.model = TransformerSeq2Seq.load(path)
                self.model.to(self.device)

                # Update UI to reflect loaded config
                self.arch.set(arch)
                # Try to map size preset (approximate)
                embed = config['embed_size']
                if embed == 64:
                    self.model_size.set("Small")
                elif embed == 128:
                    self.model_size.set("Medium")
                elif embed == 192:
                    self.model_size.set("Large")
                if arch == 'Transformer':
                    self.heads_var.set(str(config.get('nhead', 0)))

                self.log_message(f"Model loaded from {os.path.basename(path)}")
                self.log_message(f"  Architecture: {arch}, Embed: {embed}")
                self.save_btn.config(state='normal')
                self.train_btn.config(state='normal')
                self.status_var.set("Model loaded")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load model: {e}")
                traceback.print_exc()

    def start_training(self):
        if self.model is None:
            messagebox.showwarning("Warning", "Please initialize or load a model first.")
            return
        if self.training_thread and self.training_thread.is_alive():
            return
        if len(self.pairs) < 2:
            messagebox.showwarning("Warning", "Need at least 2 pairs to train.")
            return

        epochs = int(self.epochs_var.get())
        batch_size = int(self.batch_var.get())
        lr = float(self.lr_var.get())

        self.log_message("Training started...")
        self.progress.start()
        self.train_btn.config(state='disabled')
        self.stop_btn.config(state='normal')
        self.init_btn.config(state='disabled')
        self.save_btn.config(state='disabled')
        self.load_btn.config(state='disabled')
        self.status_var.set("Training...")

        self.stop_training = False
        self.training_thread = threading.Thread(
            target=self.training_worker,
            args=(self.pairs.copy(), epochs, batch_size, lr),
            daemon=True
        )
        self.training_thread.start()

    def training_worker(self, pairs, epochs, batch_size, lr):
        try:
            for epoch, loss, info in train_model(pairs, self.vocab, self.model,
                                                  epochs, batch_size, lr, self.device):
                if self.stop_training:
                    self.queue.put(("status", "Training stopped"))
                    break
                if epoch is not None:
                    self.queue.put(("progress", f"Epoch {epoch}, Loss: {loss:.4f}{info}"))
                else:
                    self.queue.put(("progress", "Training complete"))
                    self.queue.put(("status", "Training complete"))
            self.queue.put(("training_done", None))
        except Exception as e:
            self.queue.put(("error", str(e)))
            traceback.print_exc()

    def stop_training_cmd(self):
        self.stop_training = True
        self.stop_btn.config(state='disabled')
        self.status_var.set("Stopping...")

    def log_message(self, msg):
        self.log.config(state='normal')
        self.log.insert('end', msg + '\n')
        self.log.see('end')
        self.log.config(state='disabled')

    # ========== TEST TAB METHODS ==========
    def process_input(self):
        if self.model is None:
            messagebox.showwarning("Warning", "Please train or load a model first.")
            return
        word = self.input_var.get().strip()
        if not word:
            return
        result = self.transform_word(word)
        self.output_text.delete('1.0', 'end')
        self.output_text.insert('1.0', result)
        self.status_var.set(f"{word} → {result}")

    def transform_word(self, word):
        self.model.eval()
        max_len = self.model.max_len
        ids = self.vocab.encode(word)
        if len(ids) > max_len:
            ids = ids[:max_len]
        src = torch.tensor([ids + [self.vocab.pad_idx] * (max_len - len(ids))],
                           dtype=torch.long, device=self.device)
        gen = self.model.generate(src, self.vocab.sos_idx, self.vocab.eos_idx, max_len)
        return self.vocab.decode(gen[1:])

    def test_all_pairs(self):
        if self.model is None:
            messagebox.showwarning("Warning", "Please train or load a model first.")
            return
        self.test_output.delete('1.0', 'end')
        correct = 0
        total = len(self.pairs)
        for i, (inp, exp) in enumerate(self.pairs):
            res = self.transform_word(inp)
            ok = (res == exp)
            if ok:
                correct += 1
            mark = "✓" if ok else "✗"
            self.test_output.insert('end', f"{inp:20} → {res:20}  ({exp}) {mark}\n")
            if i % 10 == 0:
                self.test_output.see('end')
                self.root.update()
        acc = correct / total * 100
        self.test_output.insert('end', f"\nAccuracy: {correct}/{total} ({acc:.1f}%)")
        self.status_var.set(f"Tested {total} pairs, accuracy {acc:.1f}%")

    # ========== QUEUE PROCESSING ==========
    def process_queue(self):
        try:
            while True:
                msg, data = self.queue.get_nowait()
                if msg == "progress":
                    self.log_message(data)
                    if "Loss:" in data:
                        try:
                            loss_part = data.split("Loss:")[1].split()[0]
                            self.loss_label.config(text=loss_part)
                        except:
                            pass
                elif msg == "status":
                    self.status_var.set(data)
                elif msg == "error":
                    messagebox.showerror("Error", data)
                    self.train_btn.config(state='normal')
                    self.stop_btn.config(state='disabled')
                    self.init_btn.config(state='normal')
                    self.save_btn.config(state='normal')
                    self.load_btn.config(state='normal')
                    self.progress.stop()
                elif msg == "training_done":
                    self.train_btn.config(state='normal')
                    self.stop_btn.config(state='disabled')
                    self.init_btn.config(state='normal')
                    self.save_btn.config(state='normal')
                    self.load_btn.config(state='normal')
                    self.progress.stop()
        except queue.Empty:
            pass
        self.root.after(100, self.process_queue)

    def run(self):
        self.root.mainloop()

# ==================== MAIN ====================
if __name__ == "__main__":
    app = TransformerPredictorUI()
    app.run()