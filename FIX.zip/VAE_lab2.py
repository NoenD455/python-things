import tkinter as tk
from tkinter import filedialog, ttk, simpledialog
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F_vision
import torch.nn.functional as F_nn
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
import math
import traceback

# ==================== Helper ====================

def load_image_as_rgb(path):
    img = Image.open(path)
    if img.mode == 'RGBA':
        bg = Image.new('RGB', img.size, (0, 0, 0))
        bg.paste(img, mask=img.split()[3])
        return bg
    else:
        return img.convert('RGB')

def load_image_as_grayscale(path):
    return Image.open(path).convert('L')

# ==================== VAE Components (Flexible, from LDM) ====================
# Channel multiplier configurations for different VAE sizes.
VAE_SIZE_CONFIGS = {
    'tiny':   (2, [0.25, 0.5]),          # 2 down/up blocks, very narrow
    'small':  (3, [0.25, 0.5, 1.0]),     # 3 blocks, 4x smaller than big
    'medium': (3, [0.5, 1.0, 2.0]),      # 3 blocks, 2x smaller
    'big':    (3, [1.0, 2.0, 4.0]),      # 3 blocks, default
    'large':  (3, [2.0, 4.0, 8.0]),      # 3 blocks, 2x larger
}

class FlexEncoder(nn.Module):
    """
    Encodes input image (resized to img_size×img_size) to latent (latent_channels, latent_h, latent_w).
    Network depth and channel multipliers controlled by 'size' parameter.
    """
    def __init__(self, in_channels=3, base_channels=32, latent_channels=8,
                 latent_h=4, latent_w=4, size='big'):
        super().__init__()
        self.latent_channels = latent_channels
        self.latent_h = latent_h
        self.latent_w = latent_w
        self.size = size

        if size not in VAE_SIZE_CONFIGS:
            raise ValueError(f"Unknown VAE size '{size}'. Choose from {list(VAE_SIZE_CONFIGS.keys())}")
        num_blocks, multipliers = VAE_SIZE_CONFIGS[size]

        # Build downsampling blocks
        self.down_blocks = nn.ModuleList()
        in_ch = in_channels
        for i, mult in enumerate(multipliers):
            out_ch = int(base_channels * mult)
            self.down_blocks.append(nn.Conv2d(in_ch, out_ch, 3, stride=2, padding=1))
            self.down_blocks.append(nn.LeakyReLU(0.2))
            in_ch = out_ch

        # Final convs for mu and logvar
        self.conv_mu = nn.Conv2d(in_ch, latent_channels, 3, padding=1)
        self.conv_logvar = nn.Conv2d(in_ch, latent_channels, 3, padding=1)

        # Adaptive pooling to force latent_h × latent_w
        self.adaptive_pool = nn.AdaptiveAvgPool2d((latent_h, latent_w))

    def forward(self, x):
        for layer in self.down_blocks:
            x = layer(x)
        mu = self.conv_mu(x)
        logvar = self.conv_logvar(x)
        mu = self.adaptive_pool(mu)
        logvar = self.adaptive_pool(logvar)
        return mu, logvar


class FlexDecoder(nn.Module):
    """
    Decodes latent of size (latent_channels, latent_h, latent_w) to a square image.
    The upsampling depth and channel multipliers mirror the encoder's size.
    Fixed to respect latent_h/latent_w (not hardcoded to 4).
    """
    def __init__(self, latent_channels=8, base_channels=32, out_channels=3,
                 latent_h=4, latent_w=4, size='big'):
        super().__init__()
        self.latent_h = latent_h
        self.latent_w = latent_w
        self.size = size

        if size not in VAE_SIZE_CONFIGS:
            raise ValueError(f"Unknown VAE size '{size}'. Choose from {list(VAE_SIZE_CONFIGS.keys())}")
        num_blocks, multipliers = VAE_SIZE_CONFIGS[size]

        # Start with a conv that projects latent to the highest channel count
        highest_mult = multipliers[-1]
        highest_ch = int(base_channels * highest_mult)
        self.init_conv = nn.Conv2d(latent_channels, highest_ch, 3, padding=1)
        self.act = nn.LeakyReLU(0.2)

        # Adaptive pooling to ensure latent matches (latent_h, latent_w) before upsampling
        self.adapt = nn.AdaptiveAvgPool2d((latent_h, latent_w))

        # Build upsampling blocks (reverse of multipliers)
        self.up_blocks = nn.ModuleList()
        in_ch = highest_ch
        for i in range(num_blocks):
            if i < num_blocks - 1:
                out_mult = multipliers[num_blocks - 2 - i]  # reverse order
                out_ch = int(base_channels * out_mult)
            else:
                out_ch = base_channels if multipliers[0] != 1.0 else base_channels
            self.up_blocks.append(nn.ConvTranspose2d(in_ch, out_ch, 4, stride=2, padding=1))
            self.up_blocks.append(nn.LeakyReLU(0.2))
            in_ch = out_ch

        # Final conv to output image
        self.conv_out = nn.Conv2d(in_ch, out_channels, 3, padding=1)

    def forward(self, z, target_size=None):
        # If latent spatial size differs from expected, interpolate first
        if z.shape[2] != self.latent_h or z.shape[3] != self.latent_w:
            z = self.adapt(z)

        x = self.act(self.init_conv(z))
        for layer in self.up_blocks:
            x = layer(x)
        out = torch.tanh(self.conv_out(x))

        if target_size is not None and (out.shape[2] != target_size[0] or out.shape[3] != target_size[1]):
            out = F_nn.interpolate(out, size=target_size, mode='bilinear', align_corners=False)
        return out


class FlexVAE(nn.Module):
    def __init__(self, in_channels=3, base_channels=32, latent_channels=8,
                 latent_h=4, latent_w=4, size='big'):
        super().__init__()
        self.encoder = FlexEncoder(in_channels, base_channels, latent_channels, latent_h, latent_w, size)
        self.decoder = FlexDecoder(latent_channels, base_channels, in_channels, latent_h, latent_w, size)
        self.latent_channels = latent_channels
        self.latent_h = latent_h
        self.latent_w = latent_w
        self.size = size

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        mu, logvar = self.encoder(x)
        z = self.reparameterize(mu, logvar)
        recon = self.decoder(z, target_size=(x.shape[2], x.shape[3]))
        return recon, mu, logvar

    def encode(self, x):
        mu, _ = self.encoder(x)
        return mu

    def decode(self, z, target_size=None):
        return self.decoder(z, target_size=target_size)

# ==================== Unconditional Dataset ====================

class UnconditionalImageDataset(Dataset):
    def __init__(self, image_paths, img_size=32, color_mode='rgb', aug_settings=None):
        self.image_paths = image_paths
        self.img_size = img_size
        self.color_mode = color_mode.lower()
        self.aug_settings = aug_settings or {}

        if self.color_mode == 'rgb':
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.5,))
            ])

    def __len__(self):
        return len(self.image_paths)

    def apply_augmentations(self, pil_img):
        img = pil_img.copy()
        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F_vision.hflip(img)
        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F_vision.rotate(img, angle, interpolation=Image.BICUBIC)
        return img

    def __getitem__(self, idx):
        try:
            if self.color_mode == 'rgb':
                pil_img = load_image_as_rgb(self.image_paths[idx])
            else:
                pil_img = load_image_as_grayscale(self.image_paths[idx])
            pil_img = self.apply_augmentations(pil_img)
            img_tensor = self.transform(pil_img)
            return img_tensor
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            traceback.print_exc()
            if self.color_mode == 'rgb':
                return torch.zeros(3, self.img_size, self.img_size)
            else:
                return torch.zeros(1, self.img_size, self.img_size)

# ==================== GUI Application ====================

class VAEArithmeticApp:
    def __init__(self, root):
        self.root = root
        self.root.title("VAE Latent Arithmetic Lab")
        self.root.geometry("1200x800")

        self.image_paths = []
        self.training_vae = False
        self.vae_model = None
        self.vae_optimizer = None
        self.current_epoch_vae = 0
        self.message_queue_vae = queue.Queue()

        # Stored latent vectors for arithmetic: name -> (vector, description)
        self.latent_vectors = {}
        self.next_letter = ord('A')

        # Settings variables
        self.settings = {
            'img_size': tk.IntVar(value=32),
            'color_mode': tk.StringVar(value='rgb'),
            'vae_size': tk.StringVar(value='big'),           # NEW: VAE size selector
            'vae_base_channels': tk.IntVar(value=32),
            'vae_latent_channels': tk.IntVar(value=8),
            'vae_latent_h': tk.IntVar(value=4),
            'vae_latent_w': tk.IntVar(value=4),
            'vae_batch_size': tk.IntVar(value=16),
            'vae_lr': tk.DoubleVar(value=1e-3),
            'vae_num_workers': tk.IntVar(value=0),
            'vae_kl_weight': tk.DoubleVar(value=0.0001),
        }

        self.aug_settings = {
            'flip_horizontal': tk.BooleanVar(value=True),
            'rotation': tk.BooleanVar(value=False),
        }

        self.thumbnail_size = 128

        self.setup_gui()
        self.root.after(100, self.process_messages_vae)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.vae_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.vae_tab, text='VAE Training')
        self.setup_vae_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.arithmetic_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.arithmetic_tab, text='Latent Arithmetic')
        self.setup_arithmetic_tab()

        self.status_label = tk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    # ------------------------------------------------------------------
    # VAE Training Tab
    # ------------------------------------------------------------------
    def setup_vae_tab(self):
        main_frame = tk.Frame(self.vae_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="VAE Training", font=("Arial",12,"bold")).pack(pady=(0,10))

        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=5, pady=5)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=2)
        tk.Button(img_frame, text="Add Folder (recursive)", command=self.add_folder, width=20).pack(pady=2)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=2)
        self.image_listbox = tk.Listbox(img_frame, height=5)
        self.image_listbox.pack(fill=tk.X, pady=2)

        tk.Button(left_frame, text="Initialize VAE", command=self.initialize_vae, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.vae_epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.vae_epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start VAE Training", command=self.start_vae_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop VAE Training", command=self.stop_vae_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save VAE", command=self.save_vae, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load VAE", command=self.load_vae, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Reconstructions (Top: Real, Bottom: Recon)", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.vae_preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=128)
        self.vae_preview_canvas.pack()

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.vae_log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.vae_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.vae_log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.vae_log_text.config(yscrollcommand=scrollbar.set)

    # ------------------------------------------------------------------
    # Settings Tab
    # ------------------------------------------------------------------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Model Settings", font=("Arial",14,"bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Image Settings
        img_frame = tk.LabelFrame(scrollable_frame, text="Image", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=5)

        f = tk.Frame(img_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Color mode:", width=20, anchor='w').pack(side=tk.LEFT)
        om = ttk.Combobox(f, textvariable=self.settings['color_mode'], values=['rgb', 'grayscale'], state='readonly', width=10)
        om.pack(side=tk.RIGHT)

        f = tk.Frame(img_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Image size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=16, to=128, variable=self.settings['img_size'],
                 orient=tk.HORIZONTAL, length=200, resolution=1).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['img_size'], width=5).pack(side=tk.RIGHT)

        # VAE Settings
        vae_frame = tk.LabelFrame(scrollable_frame, text="VAE", padx=10, pady=10)
        vae_frame.pack(fill=tk.X, pady=5)

        # VAE size selector (NEW)
        f_size = tk.Frame(vae_frame)
        f_size.pack(fill=tk.X, pady=2)
        tk.Label(f_size, text="VAE size:", width=20, anchor='w').pack(side=tk.LEFT)
        size_combo = ttk.Combobox(f_size, textvariable=self.settings['vae_size'],
                                  values=['tiny', 'small', 'medium', 'big', 'large'],
                                  state='readonly', width=10)
        size_combo.pack(side=tk.RIGHT)

        vae_params = [
            ("Base channels:", 'vae_base_channels', 16, 128),
            ("Latent channels:", 'vae_latent_channels', 1, 32),
            ("Latent height:", 'vae_latent_h', 1, 32),
            ("Latent width:", 'vae_latent_w', 1, 32),
            ("Batch size:", 'vae_batch_size', 1, 32),
            ("Learning rate:", 'vae_lr', 1e-5, 1e-2),
            ("KL weight:", 'vae_kl_weight', 1e-6, 1e-2),
            ("Workers:", 'vae_num_workers', 0, 4),
        ]
        for label, key, low, high in vae_params:
            f = tk.Frame(vae_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            res = 0.00001 if 'lr' in key or 'kl' in key else 1
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Augmentations
        aug_frame = tk.LabelFrame(scrollable_frame, text="Augmentations", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)

        augs = [
            ("Horizontal Flip", 'flip_horizontal'),
            ("Rotation (±30°)", 'rotation'),
        ]
        for label, key in augs:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=5)
        cpu = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU cores: {cpu}").pack(anchor='w')
        tk.Label(sys_frame, text=f"PyTorch threads: {torch.get_num_threads()}").pack(anchor='w')
        tk.Label(sys_frame, text=f"Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}").pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ------------------------------------------------------------------
    # Latent Arithmetic Tab
    # ------------------------------------------------------------------
    def setup_arithmetic_tab(self):
        main = tk.Frame(self.arithmetic_tab)
        main.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left = tk.LabelFrame(main, text="Stored Vectors", padx=5, pady=5, width=300)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left.pack_propagate(False)

        list_frame = tk.Frame(left)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.vector_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set, height=15)
        self.vector_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.vector_listbox.yview)

        btn_frame = tk.Frame(left)
        btn_frame.pack(fill=tk.X, pady=5)
        tk.Button(btn_frame, text="Add Single Image", command=self.add_single_vector, width=18).pack(pady=2)
        tk.Button(btn_frame, text="Add Multiple (Avg)", command=self.add_multiple_avg, width=18).pack(pady=2)
        tk.Button(btn_frame, text="Add with Name", command=self.add_named_vector, width=18).pack(pady=2)
        tk.Button(btn_frame, text="Delete Selected", command=self.delete_selected_vector, width=18).pack(pady=2)
        tk.Button(btn_frame, text="Clear All", command=self.clear_all_vectors, width=18).pack(pady=2)

        right = tk.Frame(main)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        expr_frame = tk.LabelFrame(right, text="Expression", padx=5, pady=5)
        expr_frame.pack(fill=tk.X, pady=(0,10))
        tk.Label(expr_frame, text="Use vector names (e.g., A - B, sqrt(A*A + B*B), sin(A) )").pack(anchor='w')
        self.expr_var = tk.StringVar(value="A - B")
        expr_entry = tk.Entry(expr_frame, textvariable=self.expr_var, font=("Courier",12))
        expr_entry.pack(fill=tk.X, pady=5)
        tk.Button(expr_frame, text="Compute", command=self.compute_expression, bg="lightblue", width=15).pack(pady=5)

        result_frame = tk.LabelFrame(right, text="Result", padx=5, pady=5)
        result_frame.pack(fill=tk.BOTH, expand=True)
        self.result_canvas = tk.Canvas(result_frame, bg='gray', width=256, height=256)
        self.result_canvas.pack(pady=5)
        self.result_photo = None

        store_frame = tk.Frame(result_frame)
        store_frame.pack(fill=tk.X, pady=5)
        tk.Label(store_frame, text="Store as:").pack(side=tk.LEFT)
        self.store_name_var = tk.StringVar()
        store_entry = tk.Entry(store_frame, textvariable=self.store_name_var, width=10)
        store_entry.pack(side=tk.LEFT, padx=5)
        tk.Button(store_frame, text="Store", command=self.store_result).pack(side=tk.LEFT)

        tk.Button(right, text="Decode Random Latent", command=self.decode_random, bg="lightgray").pack(pady=5)

        self.arithmetic_status = tk.Label(right, text="", fg="blue")
        self.arithmetic_status.pack()

    # ========== VAE Training Methods ==========
    def log_vae(self, msg):
        self.message_queue_vae.put(msg)

    def process_messages_vae(self):
        try:
            while True:
                msg = self.message_queue_vae.get_nowait()
                self.vae_log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.vae_log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
                print(f"VAE: {msg}")
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages_vae)

    def add_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp")])
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_vae(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def add_folder(self):
        folder = filedialog.askdirectory()
        if not folder:
            return
        count = 0
        for root_dir, _, files in os.walk(folder):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg', '.jfif', '.webp', '.bmp')):
                    full_path = os.path.join(root_dir, file)
                    if full_path not in self.image_paths:
                        self.image_paths.append(full_path)
                        self.image_listbox.insert(tk.END, os.path.basename(full_path))
                        count += 1
        self.log_vae(f"Added {count} images from folder. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_vae("Cleared all images")

    def initialize_vae(self):
        try:
            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            self.vae_model = FlexVAE(
                in_channels=in_channels,
                base_channels=self.settings['vae_base_channels'].get(),
                latent_channels=self.settings['vae_latent_channels'].get(),
                latent_h=self.settings['vae_latent_h'].get(),
                latent_w=self.settings['vae_latent_w'].get(),
                size=self.settings['vae_size'].get()          # <-- NOW USES SIZE
            )
            self.vae_model.to('cpu')
            self.vae_optimizer = optim.Adam(self.vae_model.parameters(), lr=self.settings['vae_lr'].get())
            self.log_vae(f"VAE initialized (size '{self.settings['vae_size'].get()}').")
        except Exception as e:
            self.log_vae(f"Error initializing VAE: {e}")
            traceback.print_exc()

    def start_vae_training(self):
        if not self.image_paths:
            self.log_vae("No images!")
            return
        if not self.vae_model:
            self.log_vae("VAE not initialized!")
            return
        if self.training_vae:
            self.log_vae("Already training VAE.")
            return

        try:
            epochs = int(self.vae_epoch_var.get())
        except:
            self.log_vae("Invalid epochs")
            return

        self.training_vae = True
        self.current_epoch_vae = 0
        self.vae_start_time = time.time()

        thread = threading.Thread(target=self.train_vae_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_vae(f"VAE training started for {epochs} epochs.")

    def train_vae_loop(self, epochs):
        try:
            batch_size = self.settings['vae_batch_size'].get()
            num_workers = self.settings['vae_num_workers'].get()
            img_size = self.settings['img_size'].get()
            kl_weight = self.settings['vae_kl_weight'].get()
            color_mode = self.settings['color_mode'].get()

            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}
            dataset = UnconditionalImageDataset(self.image_paths, img_size, color_mode, aug_settings=aug_dict)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=False,
                                persistent_workers=False if num_workers==0 else True)

            for epoch in range(epochs):
                if not self.training_vae:
                    break
                self.current_epoch_vae = epoch
                epoch_loss = 0.0
                batches = 0

                for images in loader:
                    if not self.training_vae:
                        break
                    images = images.to('cpu')
                    recon, mu, logvar = self.vae_model(images)
                    recon_loss = nn.functional.mse_loss(recon, images)
                    kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
                    kl_loss = kl_loss / images.size(0)
                    loss = recon_loss + kl_weight * kl_loss

                    self.vae_optimizer.zero_grad()
                    loss.backward()
                    self.vae_optimizer.step()

                    epoch_loss += loss.item()
                    batches += 1

                avg_loss = epoch_loss / batches if batches else 0
                elapsed = time.time() - self.vae_start_time
                self.log_vae(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s")

                if (epoch+1) % 5 == 0:
                    self.show_vae_preview()

            self.training_vae = False
            self.log_vae("VAE training finished.")
        except Exception as e:
            self.log_vae(f"VAE training error: {e}")
            traceback.print_exc()
            self.training_vae = False

    def show_vae_preview(self):
        if not self.vae_model:
            return
        try:
            color_mode = self.settings['color_mode'].get()
            dataset = UnconditionalImageDataset(self.image_paths[:16], img_size=self.settings['img_size'].get(),
                                                color_mode=color_mode)
            loader = DataLoader(dataset, batch_size=16, shuffle=True)
            images = next(iter(loader))
            with torch.no_grad():
                recon, _, _ = self.vae_model(images)
            images = (images + 1) / 2
            recon = (recon + 1) / 2
            images = images.clamp(0,1).cpu().numpy()
            recon = recon.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size // 2
            grid = Image.new('RGB', (8*thumb, 4*thumb))
            for i in range(4):
                for j in range(4):
                    idx = i*4 + j
                    if idx < len(images):
                        if images[idx].shape[0] == 1:
                            img = images[idx][0] * 255
                            img = np.stack([img, img, img], axis=-1).astype(np.uint8)
                        else:
                            img = images[idx].transpose(1,2,0) * 255
                            img = img.astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img, (j*thumb*2, i*thumb))
                        if recon[idx].shape[0] == 1:
                            img_r = recon[idx][0] * 255
                            img_r = np.stack([img_r, img_r, img_r], axis=-1).astype(np.uint8)
                        else:
                            img_r = recon[idx].transpose(1,2,0) * 255
                            img_r = img_r.astype(np.uint8)
                        pil_img_r = Image.fromarray(img_r).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img_r, (j*thumb*2 + thumb, i*thumb))
            grid = grid.resize((256,128), Image.NEAREST)
            self.vae_preview_photo = ImageTk.PhotoImage(grid)
            self.vae_preview_canvas.delete("all")
            self.vae_preview_canvas.create_image(128,64, image=self.vae_preview_photo)
        except Exception as e:
            self.log_vae(f"Preview error: {e}")
            traceback.print_exc()

    def stop_vae_training(self):
        self.training_vae = False
        self.log_vae("VAE training stopped.")

    def save_vae(self):
        if not self.vae_model:
            self.log_vae("No VAE model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth",
                                              filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'model_state': self.vae_model.state_dict(),
                'optimizer_state': self.vae_optimizer.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items() if k.startswith('vae') or k in ['img_size','color_mode']},
            }, fname)
            self.log_vae(f"VAE saved to {fname}")

    def load_vae(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            if 'settings' in ckpt:
                s = ckpt['settings']
                for k, v in s.items():
                    if k in self.settings:
                        self.settings[k].set(v)

            self.initialize_vae()
            self.vae_model.load_state_dict(ckpt['model_state'])
            self.vae_optimizer.load_state_dict(ckpt['optimizer_state'])
            self.log_vae(f"VAE loaded from {fname}")
        except Exception as e:
            self.log_vae(f"Load error: {e}")
            traceback.print_exc()

    # ========== Latent Arithmetic Methods ==========
    def _get_next_index(self):
        n = len(self.latent_vectors)
        if n < 26:
            return chr(ord('A') + n)
        else:
            first = (n - 26) // 26
            second = (n - 26) % 26
            return chr(ord('A') + first) + chr(ord('A') + second)

    def _compute_latent(self, image_path):
        if not self.vae_model:
            raise RuntimeError("VAE not loaded")
        color_mode = self.settings['color_mode'].get()
        if color_mode == 'rgb':
            pil = load_image_as_rgb(image_path)
        else:
            pil = load_image_as_grayscale(image_path)
        transform = transforms.Compose([
            transforms.Resize((self.settings['img_size'].get(), self.settings['img_size'].get())),
            transforms.ToTensor(),
            transforms.Normalize((0.5,)* (3 if color_mode=='rgb' else 1), (0.5,)* (3 if color_mode=='rgb' else 1))
        ])
        img_tensor = transform(pil).unsqueeze(0)
        with torch.no_grad():
            latent = self.vae_model.encode(img_tensor)
        return latent.squeeze(0)

    def _add_vector(self, vector, description, name=None):
        if name is None:
            name = self._get_next_index()
        if name in self.latent_vectors:
            self.arithmetic_status.config(text=f"Name {name} already exists, overwriting.")
        self.latent_vectors[name] = (vector.cpu().clone(), description)
        self._refresh_vector_listbox()
        return name

    def _refresh_vector_listbox(self):
        self.vector_listbox.delete(0, tk.END)
        for name in sorted(self.latent_vectors.keys()):
            vec, desc = self.latent_vectors[name]
            self.vector_listbox.insert(tk.END, f"{name}: {desc}")

    def add_single_vector(self):
        if not self.vae_model:
            self.arithmetic_status.config(text="Load VAE first!")
            return
        path = filedialog.askopenfilename(filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp")])
        if not path:
            return
        try:
            vec = self._compute_latent(path)
            desc = os.path.basename(path)
            name = self._add_vector(vec, desc)
            self.arithmetic_status.config(text=f"Added {name} from {desc}")
        except Exception as e:
            self.arithmetic_status.config(text=f"Error: {e}")
            traceback.print_exc()

    def add_multiple_avg(self):
        if not self.vae_model:
            self.arithmetic_status.config(text="Load VAE first!")
            return
        paths = filedialog.askopenfilenames(filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp")])
        if len(paths) == 0:
            return
        try:
            vecs = []
            for p in paths:
                vec = self._compute_latent(p)
                vecs.append(vec)
            avg_vec = torch.stack(vecs).mean(dim=0)
            desc = f"avg of {len(paths)} images"
            name = self._add_vector(avg_vec, desc)
            self.arithmetic_status.config(text=f"Added {name} ({desc})")
        except Exception as e:
            self.arithmetic_status.config(text=f"Error: {e}")
            traceback.print_exc()

    def add_named_vector(self):
        if not self.vae_model:
            self.arithmetic_status.config(text="Load VAE first!")
            return
        name = simpledialog.askstring("Name", "Enter vector name (e.g., 'myVec'):")
        if not name:
            return
        path = filedialog.askopenfilename(filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp")])
        if not path:
            return
        try:
            vec = self._compute_latent(path)
            desc = os.path.basename(path)
            self._add_vector(vec, desc, name)
            self.arithmetic_status.config(text=f"Added {name} from {desc}")
        except Exception as e:
            self.arithmetic_status.config(text=f"Error: {e}")
            traceback.print_exc()

    def delete_selected_vector(self):
        sel = self.vector_listbox.curselection()
        if not sel:
            return
        full = self.vector_listbox.get(sel[0])
        name = full.split(":")[0].strip()
        if name in self.latent_vectors:
            del self.latent_vectors[name]
            self._refresh_vector_listbox()
            self.arithmetic_status.config(text=f"Deleted {name}")

    def clear_all_vectors(self):
        self.latent_vectors.clear()
        self._refresh_vector_listbox()
        self.arithmetic_status.config(text="All vectors cleared")

    def compute_expression(self):
        if not self.vae_model:
            self.arithmetic_status.config(text="Load VAE first!")
            return
        expr = self.expr_var.get().strip()
        if not expr:
            return
        safe_dict = {
            'torch': torch,
            'max': torch.max,
            'min': torch.min,
            'mean': torch.mean,
            'abs': torch.abs,
            'sqrt': torch.sqrt,
            'sin': torch.sin,
            'cos': torch.cos,
            'tan': torch.tan,
            'asin': torch.asin,
            'acos': torch.acos,
            'atan': torch.atan,
            'exp': torch.exp,
            'log': torch.log,
            'log10': torch.log10,
            'pi': math.pi,
        }
        for name, (vec, _) in self.latent_vectors.items():
            safe_dict[name] = vec
        try:
            result_vec = eval(expr, {"__builtins__": {}}, safe_dict)
            if not isinstance(result_vec, torch.Tensor):
                self.arithmetic_status.config(text="Expression did not return a tensor")
                return
            expected_shape = (self.settings['vae_latent_channels'].get(),
                              self.settings['vae_latent_h'].get(),
                              self.settings['vae_latent_w'].get())
            if result_vec.shape != expected_shape:
                self.arithmetic_status.config(text=f"Shape mismatch: got {result_vec.shape}, expected {expected_shape}")
                return
            with torch.no_grad():
                result_img = self.vae_model.decode(result_vec.unsqueeze(0))
            self._display_result(result_img)
            self.last_result = result_vec
            self.arithmetic_status.config(text="Computed successfully")
        except Exception as e:
            self.arithmetic_status.config(text=f"Error: {e}")
            traceback.print_exc()

    def _display_result(self, img_tensor):
        img = (img_tensor.squeeze(0) + 1) / 2
        img = img.clamp(0,1).cpu().numpy()
        if img.shape[0] == 1:
            img = np.stack([img[0], img[0], img[0]], axis=-1) * 255
        else:
            img = img.transpose(1,2,0) * 255
        img = img.astype(np.uint8)
        pil_img = Image.fromarray(img).resize((256,256), Image.NEAREST)
        self.result_photo = ImageTk.PhotoImage(pil_img)
        self.result_canvas.delete("all")
        self.result_canvas.create_image(128,128, image=self.result_photo)

    def store_result(self):
        if not hasattr(self, 'last_result'):
            self.arithmetic_status.config(text="No result to store")
            return
        name = self.store_name_var.get().strip()
        if not name:
            self.arithmetic_status.config(text="Enter a name")
            return
        desc = f"computed: {self.expr_var.get()}"
        self._add_vector(self.last_result, desc, name)
        self.store_name_var.set("")
        self.arithmetic_status.config(text=f"Stored as {name}")

    def decode_random(self):
        if not self.vae_model:
            self.arithmetic_status.config(text="Load VAE first!")
            return
        latent_shape = (self.settings['vae_latent_channels'].get(),
                        self.settings['vae_latent_h'].get(),
                        self.settings['vae_latent_w'].get())
        z = torch.randn(latent_shape)
        with torch.no_grad():
            img = self.vae_model.decode(z.unsqueeze(0))
        self._display_result(img)
        self.arithmetic_status.config(text="Random latent decoded")

# ==================== Main ====================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = VAEArithmeticApp(root)
    root.mainloop()