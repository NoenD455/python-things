import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F_vision
import torch.nn.functional as F
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
import math
import csv
from typing import Optional, Tuple, List

# ==================== Helper ====================

def load_image_as_rgb(path):
    img = Image.open(path)
    if img.mode == 'RGBA':
        bg = Image.new('RGB', img.size, (0, 0, 0))
        bg.paste(img, mask=img.split()[3])
        return bg
    else:
        return img.convert('RGB')

def load_image_as_grayscale(path):
    return Image.open(path).convert('L')

def text_to_indices(text, max_len=128):
    """Convert text to list of char indices (ASCII based). Unknown chars -> 0."""
    indices = []
    for ch in text[:max_len]:
        idx = ord(ch) if ord(ch) < 256 else 0
        indices.append(idx)
    # pad
    if len(indices) < max_len:
        indices += [0] * (max_len - len(indices))
    return indices

# ==================== Text Encoder (from VQGAN) ====================

class TextEncoder(nn.Module):
    def __init__(self, vocab_size=256, embed_dim=64, hidden_size=64, num_layers=2, cond_dim=256):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.gru = nn.GRU(embed_dim, hidden_size, num_layers,
                          batch_first=True, bidirectional=True, dropout=0.1 if num_layers>1 else 0)
        self.fc = nn.Linear(hidden_size * 2, cond_dim)  # bidirectional -> *2

    def forward(self, x):
        # x: (B, T) long tensor of char indices
        emb = self.embedding(x)                       # (B, T, embed_dim)
        _, h = self.gru(emb)                           # h: (num_layers*2, B, hidden_size)
        # take last layer forward and backward
        h_fwd = h[-2, :, :]                            # (B, hidden_size)
        h_bwd = h[-1, :, :]                            # (B, hidden_size)
        h_cat = torch.cat([h_fwd, h_bwd], dim=1)       # (B, hidden_size*2)
        cond = self.fc(h_cat)                           # (B, cond_dim)
        return cond

# ==================== Diffusion Model Components ====================

class SinusoidalPositionEmbeddings(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, time):
        device = time.device
        half_dim = self.dim // 2
        embeddings = math.log(10000) / (half_dim - 1)
        embeddings = torch.exp(torch.arange(half_dim, device=device) * -embeddings)
        embeddings = time[:, None] * embeddings[None, :]
        embeddings = torch.cat((embeddings.sin(), embeddings.cos()), dim=-1)
        return embeddings

class AttentionBlock(nn.Module):
    def __init__(self, dim, num_heads=4):
        super().__init__()
        self.norm = nn.GroupNorm(32, dim)
        self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True)

    def forward(self, x):
        B, C, H, W = x.shape
        residual = x
        x = self.norm(x)
        x = x.view(B, C, H * W).transpose(1, 2)  # (B, H*W, C)
        x, _ = self.attn(x, x, x)
        x = x.transpose(1, 2).view(B, C, H, W)
        return x + residual

class DownBlock(nn.Module):
    def __init__(self, in_channels, out_channels, time_emb_dim, cond_dim, dropout=0.1, has_attn=False):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1)
        self.norm1 = nn.GroupNorm(32, out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1)
        self.norm2 = nn.GroupNorm(32, out_channels)
        self.time_mlp = nn.Sequential(
            nn.SiLU(),
            nn.Linear(time_emb_dim, out_channels)
        )
        self.cond_mlp = nn.Sequential(
            nn.SiLU(),
            nn.Linear(cond_dim, out_channels)
        )
        self.res_conv = nn.Conv2d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()
        self.dropout = nn.Dropout(dropout)
        self.attn = AttentionBlock(out_channels) if has_attn else nn.Identity()

    def forward(self, x, t_emb, c_emb):
        # t_emb: (B, time_emb_dim)
        # c_emb: (B, cond_dim)
        time_out = self.time_mlp(t_emb)[:, :, None, None]
        cond_out = self.cond_mlp(c_emb)[:, :, None, None]
        h = self.conv1(x)
        h = self.norm1(h)
        h = h + time_out + cond_out
        h = F.silu(h)
        h = self.dropout(h)
        h = self.conv2(h)
        h = self.norm2(h)
        h = F.silu(h)
        res = self.res_conv(x)
        h = h + res
        h = self.attn(h)
        return h

class UpBlock(nn.Module):
    def __init__(self, in_channels, out_channels, time_emb_dim, cond_dim, dropout=0.1, has_attn=False):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1)
        self.norm1 = nn.GroupNorm(32, out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1)
        self.norm2 = nn.GroupNorm(32, out_channels)
        self.time_mlp = nn.Sequential(
            nn.SiLU(),
            nn.Linear(time_emb_dim, out_channels)
        )
        self.cond_mlp = nn.Sequential(
            nn.SiLU(),
            nn.Linear(cond_dim, out_channels)
        )
        self.res_conv = nn.Conv2d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()
        self.dropout = nn.Dropout(dropout)
        self.attn = AttentionBlock(out_channels) if has_attn else nn.Identity()

    def forward(self, x, t_emb, c_emb):
        time_out = self.time_mlp(t_emb)[:, :, None, None]
        cond_out = self.cond_mlp(c_emb)[:, :, None, None]
        h = self.conv1(x)
        h = self.norm1(h)
        h = h + time_out + cond_out
        h = F.silu(h)
        h = self.dropout(h)
        h = self.conv2(h)
        h = self.norm2(h)
        h = F.silu(h)
        res = self.res_conv(x)
        h = h + res
        h = self.attn(h)
        return h

class DenoisingUNet(nn.Module):
    def __init__(self, in_channels=3, base_channels=64, time_emb_dim=256, cond_dim=256,
                 channel_mult=(1, 2, 3, 4), dropout=0.1, attn_resolutions=(16,)):
        super().__init__()
        self.in_channels = in_channels
        self.base_channels = base_channels
        self.time_emb_dim = time_emb_dim
        self.cond_dim = cond_dim
        self.channel_mult = channel_mult
        self.attn_resolutions = attn_resolutions

        self.time_mlp = nn.Sequential(
            SinusoidalPositionEmbeddings(time_emb_dim),
            nn.Linear(time_emb_dim, time_emb_dim),
            nn.SiLU(),
            nn.Linear(time_emb_dim, time_emb_dim)
        )

        # Optional conditioning projection (if we want to keep separate)
        # Already handled inside blocks.

        self.init_conv = nn.Conv2d(in_channels, base_channels, 3, padding=1)

        # downsampling
        self.downs = nn.ModuleList()
        cur_channels = base_channels
        for i, mult in enumerate(channel_mult):
            out_channels = base_channels * mult
            has_attn = (2 ** i) in attn_resolutions or (64 // (2 ** i) in attn_resolutions)
            block = DownBlock(cur_channels, out_channels, time_emb_dim, cond_dim, dropout, has_attn)
            self.downs.append(block)
            if i != len(channel_mult) - 1:
                self.downs.append(nn.Conv2d(out_channels, out_channels, 4, stride=2, padding=1))
            cur_channels = out_channels

        # middle
        self.mid_block1 = DownBlock(cur_channels, cur_channels, time_emb_dim, cond_dim, dropout, True)
        self.mid_block2 = UpBlock(cur_channels, cur_channels, time_emb_dim, cond_dim, dropout, True)

        # upsampling
        self.ups = nn.ModuleList()
        for i, mult in reversed(list(enumerate(channel_mult))):
            out_channels = base_channels * mult
            has_attn = (2 ** i) in attn_resolutions or (64 // (2 ** i) in attn_resolutions)
            block = UpBlock(cur_channels + out_channels, out_channels, time_emb_dim, cond_dim, dropout, has_attn)
            self.ups.append(block)
            if i != 0:
                self.ups.append(nn.ConvTranspose2d(out_channels, out_channels, 4, stride=2, padding=1))
            cur_channels = out_channels

        self.final_conv = nn.Sequential(
            nn.GroupNorm(32, cur_channels),
            nn.SiLU(),
            nn.Conv2d(cur_channels, in_channels, 3, padding=1)
        )

    def forward(self, x, t, c):
        t_emb = self.time_mlp(t)
        # c is already conditioning vector of shape (B, cond_dim)
        x = self.init_conv(x)

        # store skip connections
        skips = []
        for i, layer in enumerate(self.downs):
            if isinstance(layer, DownBlock):
                x = layer(x, t_emb, c)
                skips.append(x)
            else:
                x = layer(x)  # downsampling conv

        x = self.mid_block1(x, t_emb, c)
        x = self.mid_block2(x, t_emb, c)

        for i, layer in enumerate(self.ups):
            if isinstance(layer, UpBlock):
                # skip connection from the matching down block
                x = torch.cat([x, skips.pop()], dim=1)
                x = layer(x, t_emb, c)
            else:
                x = layer(x)  # upsampling conv

        return self.final_conv(x)

class ConditionedDDPM:
    def __init__(self, model: nn.Module, text_encoder: nn.Module, T=1000, beta_start=1e-4, beta_end=0.02,
                 schedule='linear', device='cpu'):
        self.model = model.to(device)
        self.text_encoder = text_encoder.to(device)
        self.T = T
        self.device = device
        self.schedule = schedule

        if schedule == 'linear':
            beta = torch.linspace(beta_start, beta_end, T, device=device)
        elif schedule == 'cosine':
            # Cosine schedule as in https://arxiv.org/abs/2102.09672
            t = torch.linspace(0, T-1, T, device=device) / T
            alpha_bar = torch.cos((t + 0.008) / (1 + 0.008) * math.pi / 2) ** 2
            alpha_bar = alpha_bar / alpha_bar[0]
            alpha_bar = torch.clamp(alpha_bar, min=0.001)
            beta = 1 - alpha_bar / torch.cat([torch.tensor([1.0], device=device), alpha_bar[:-1]])
            beta = torch.clamp(beta, min=0.001, max=0.999)
        else:
            raise ValueError(f"Unknown schedule {schedule}")

        self.beta = beta
        self.alpha = 1.0 - self.beta
        self.alpha_bar = torch.cumprod(self.alpha, dim=0)
        self.sqrt_alpha_bar = torch.sqrt(self.alpha_bar)
        self.sqrt_one_minus_alpha_bar = torch.sqrt(1.0 - self.alpha_bar)

    def forward_diffusion(self, x0, t):
        """Add noise to x0 at timestep t."""
        noise = torch.randn_like(x0)
        sqrt_alpha_bar_t = self.sqrt_alpha_bar[t].view(-1, 1, 1, 1)
        sqrt_one_minus_alpha_bar_t = self.sqrt_one_minus_alpha_bar[t].view(-1, 1, 1, 1)
        xt = sqrt_alpha_bar_t * x0 + sqrt_one_minus_alpha_bar_t * noise
        return xt, noise

    def training_loss(self, x0, text_indices, cfg_dropout_prob=0.0):
        """Compute simplified loss for a batch with optional CFG dropout."""
        B = x0.size(0)
        t = torch.randint(0, self.T, (B,), device=self.device)
        xt, noise = self.forward_diffusion(x0, t)
        cond = self.text_encoder(text_indices)  # (B, cond_dim)

        # Apply CFG dropout: randomly set cond to zeros
        if cfg_dropout_prob > 0:
            mask = torch.rand(B, 1, device=self.device) > cfg_dropout_prob
            cond = cond * mask.float()

        noise_pred = self.model(xt, t, cond)
        return F.mse_loss(noise_pred, noise)

    @torch.no_grad()
    def sample_ddpm(self, n_samples, img_shape, text_condition, n_steps=None, cfg_scale=1.0, progress_callback=None):
        """Generate samples using DDPM with Classifier-Free Guidance.
        text_condition: (B, max_len) tensor of char indices.
        cfg_scale: guidance scale (1.0 = no guidance, >1.0 increases adherence to prompt)
        """
        cond = self.text_encoder(text_condition)  # (n_samples, cond_dim)
        null_cond = torch.zeros_like(cond)

        if n_steps is None:
            n_steps = self.T
        timesteps = torch.linspace(self.T-1, 0, n_steps, dtype=torch.long, device=self.device)
        x = torch.randn(n_samples, *img_shape, device=self.device)

        for i, t in enumerate(timesteps):
            t_tensor = torch.full((n_samples,), t, device=self.device, dtype=torch.long)
            # Conditional prediction
            noise_pred_cond = self.model(x, t_tensor, cond)
            # Unconditional prediction
            noise_pred_uncond = self.model(x, t_tensor, null_cond)
            # CFG combination
            noise_pred = noise_pred_uncond + cfg_scale * (noise_pred_cond - noise_pred_uncond)

            alpha_t = self.alpha[t]
            alpha_bar_t = self.alpha_bar[t]
            beta_t = self.beta[t]

            coeff_x = 1.0 / torch.sqrt(alpha_t)
            coeff_noise = beta_t / torch.sqrt(1.0 - alpha_bar_t)

            if t > 0:
                z = torch.randn_like(x)
                sigma_t = torch.sqrt(beta_t)
            else:
                z = 0.0

            x = coeff_x * (x - coeff_noise * noise_pred) + sigma_t * z

            if progress_callback is not None:
                x0_est = (x - self.sqrt_one_minus_alpha_bar[t] * noise_pred) / self.sqrt_alpha_bar[t]
                progress_callback(i+1, x, x0_est)

        return x

    @torch.no_grad()
    def sample_ddim(self, n_samples, img_shape, text_condition, n_steps=100, eta=0.0, cfg_scale=1.0, progress_callback=None):
        """Generate samples using DDIM with Classifier-Free Guidance.
        text_condition: (B, max_len) tensor of char indices.
        cfg_scale: guidance scale (1.0 = no guidance, >1.0 increases adherence to prompt)
        """
        cond = self.text_encoder(text_condition)
        null_cond = torch.zeros_like(cond)

        step_seq = torch.linspace(0, self.T - 1, n_steps, dtype=torch.long, device=self.device)
        step_seq = step_seq.flip(0)

        x = torch.randn(n_samples, *img_shape, device=self.device)

        for i in range(len(step_seq) - 1):
            t = step_seq[i]
            t_next = step_seq[i + 1]

            t_tensor = torch.full((n_samples,), t, device=self.device, dtype=torch.long)
            # Conditional prediction
            noise_pred_cond = self.model(x, t_tensor, cond)
            # Unconditional prediction
            noise_pred_uncond = self.model(x, t_tensor, null_cond)
            # CFG combination
            noise_pred = noise_pred_uncond + cfg_scale * (noise_pred_cond - noise_pred_uncond)

            alpha_bar_t = self.alpha_bar[t]
            alpha_bar_t_next = self.alpha_bar[t_next]

            x0_pred = (x - torch.sqrt(1.0 - alpha_bar_t) * noise_pred) / torch.sqrt(alpha_bar_t)

            sigma = eta * torch.sqrt((1.0 - alpha_bar_t_next) / (1.0 - alpha_bar_t) *
                                     (1.0 - alpha_bar_t / alpha_bar_t_next))

            dir_xt = torch.sqrt(1.0 - alpha_bar_t_next - sigma ** 2) * noise_pred

            x = torch.sqrt(alpha_bar_t_next) * x0_pred + dir_xt
            if eta > 0:
                x = x + sigma * torch.randn_like(x)

            if progress_callback is not None:
                progress_callback(i+1, x, x0_pred)

        return x

# ==================== Dataset ====================

class TextConditionedImageDataset(Dataset):
    def __init__(self, image_paths, labels, img_size=32, color_mode='rgb',
                 aug_settings=None, text_max_len=128):
        """
        labels: list of strings (same length as image_paths)
        """
        self.image_paths = image_paths
        self.labels = labels
        self.img_size = img_size
        self.color_mode = color_mode.lower()
        self.aug_settings = aug_settings or {}
        self.text_max_len = text_max_len
        if self.color_mode == 'rgb':
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.5,))
            ])

    def __len__(self):
        return len(self.image_paths)

    def apply_augmentations(self, pil_img):
        img = pil_img.copy()
        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F_vision.hflip(img)
        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F_vision.rotate(img, angle, interpolation=Image.BICUBIC)
        return img

    def __getitem__(self, idx):
        try:
            if self.color_mode == 'rgb':
                pil_img = load_image_as_rgb(self.image_paths[idx])
            else:
                pil_img = load_image_as_grayscale(self.image_paths[idx])
            pil_img = self.apply_augmentations(pil_img)
            img_tensor = self.transform(pil_img)

            # process text
            text = self.labels[idx].replace('_', ' ')  # replace underscores with spaces
            text_indices = text_to_indices(text, self.text_max_len)
            text_tensor = torch.tensor(text_indices, dtype=torch.long)

            return img_tensor, text_tensor
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            if self.color_mode == 'rgb':
                img_tensor = torch.zeros(3, self.img_size, self.img_size)
            else:
                img_tensor = torch.zeros(1, self.img_size, self.img_size)
            text_tensor = torch.zeros(self.text_max_len, dtype=torch.long)
            return img_tensor, text_tensor

# ==================== GUI Application ====================

class TextConditionedDiffusionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Text-to-Image Diffusion Model (DDPM/DDIM) with CFG")
        self.root.geometry("1200x800")

        self.image_paths = []
        self.labels = []               # text labels for each image
        self.csv_path = None
        self.training = False
        self.model = None
        self.text_encoder = None
        self.ddpm = None
        self.optimizer = None
        self.ema_model = None
        self.ema_enabled = False
        self.ema_decay = 0.9999

        self.current_epoch = 0
        self.message_queue = queue.Queue()

        self.settings = {
            'img_size': tk.IntVar(value=32),
            'color_mode': tk.StringVar(value='rgb'),
            'base_channels': tk.IntVar(value=64),
            'timesteps': tk.IntVar(value=500),
            'batch_size': tk.IntVar(value=16),
            'lr': tk.DoubleVar(value=2e-4),
            'num_workers': tk.IntVar(value=0),
            'sampling_steps': tk.IntVar(value=250),
            'ddim_eta': tk.DoubleVar(value=0.0),
            'use_self_attn': tk.BooleanVar(value=True),
            'use_ema': tk.BooleanVar(value=False),
            'ema_decay': tk.StringVar(value='0.9999'),
            'beta_schedule': tk.StringVar(value='linear'),
            'preview_enabled': tk.BooleanVar(value=True),
            'preview_epochs': tk.IntVar(value=5),
            # Text encoder settings
            'text_max_len': tk.IntVar(value=128),
            'text_embed_dim': tk.IntVar(value=64),
            'text_hidden_size': tk.IntVar(value=64),
            'text_num_layers': tk.IntVar(value=2),
            'cond_dim': tk.IntVar(value=256),
            # CFG settings
            'cfg_dropout_prob': tk.DoubleVar(value=0.1),   # dropout during training
            'cfg_scale': tk.DoubleVar(value=2.0),          # guidance scale for generation
        }

        self.aug_settings = {
            'flip_horizontal': tk.BooleanVar(value=True),
            'rotation': tk.BooleanVar(value=False),
        }

        self.thumbnail_size = 128
        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.train_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.train_tab, text='Training')
        self.setup_train_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.gen_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.gen_tab, text='Generation')
        self.setup_gen_tab()

        self.status_label = tk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    # ------------------------------------------------------------------
    # Training Tab
    # ------------------------------------------------------------------
    def setup_train_tab(self):
        main_frame = tk.Frame(self.train_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="Text-to-Image Diffusion", font=("Arial",12,"bold")).pack(pady=(0,10))

        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=5, pady=5)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=2)
        tk.Button(img_frame, text="Add Folder", command=self.add_folder, width=20).pack(pady=2)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=2)
        self.image_listbox = tk.Listbox(img_frame, height=5)
        self.image_listbox.pack(fill=tk.X, pady=2)

        # CSV loading for labels
        csv_frame = tk.LabelFrame(left_frame, text="Text Labels", padx=5, pady=5)
        csv_frame.pack(fill=tk.X, pady=5)
        tk.Button(csv_frame, text="Load CSV (imagename,label)", command=self.load_csv, width=20).pack(pady=2)
        tk.Button(csv_frame, text="Use Filenames as Labels", command=self.use_filenames_as_labels, width=20).pack(pady=2)
        self.csv_status = tk.Label(csv_frame, text="No CSV loaded", fg="red")
        self.csv_status.pack()

        tk.Button(left_frame, text="Initialize Model", command=self.init_model, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start Training", command=self.start_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop Training", command=self.stop_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load Model", command=self.load_model, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Samples (every N epochs)", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.train_preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=256)
        self.train_preview_canvas.pack()
        tk.Label(preview_frame, text="Test prompt:").pack()
        self.train_test_prompt = tk.Entry(preview_frame)
        self.train_test_prompt.insert(0, "a cute cat")
        self.train_test_prompt.pack(fill=tk.X)
        tk.Button(preview_frame, text="Preview Now", command=self.show_train_preview).pack(pady=2)

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

    # ------------------------------------------------------------------
    # Settings Tab
    # ------------------------------------------------------------------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Image
        img_frame = tk.LabelFrame(scrollable_frame, text="Image", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(img_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Color mode:", width=20, anchor='w').pack(side=tk.LEFT)
        om = ttk.Combobox(f, textvariable=self.settings['color_mode'], values=['rgb', 'grayscale'], state='readonly', width=10)
        om.pack(side=tk.RIGHT)
        f = tk.Frame(img_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Image size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=16, to=128, variable=self.settings['img_size'],
                 orient=tk.HORIZONTAL, length=200, resolution=1).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['img_size'], width=5).pack(side=tk.RIGHT)

        # Model
        model_frame = tk.LabelFrame(scrollable_frame, text="Diffusion Model", padx=10, pady=10)
        model_frame.pack(fill=tk.X, pady=5)
        params = [
            ("Base channels:", 'base_channels', 16, 256),
            ("Timesteps (T):", 'timesteps', 100, 1000),
            ("Batch size:", 'batch_size', 1, 64),
            ("Learning rate:", 'lr', 1e-5, 1e-2),
            ("Workers:", 'num_workers', 0, 4),
        ]
        for label, key, low, high in params:
            f = tk.Frame(model_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            res = 0.00001 if 'lr' in key else 1
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Self-attention toggle
        attn_frame = tk.LabelFrame(scrollable_frame, text="Self-Attention", padx=10, pady=10)
        attn_frame.pack(fill=tk.X, pady=5)
        cb = tk.Checkbutton(attn_frame, text="Enable Self-Attention", variable=self.settings['use_self_attn'])
        cb.pack(anchor='w')

        # Text encoder settings
        text_frame = tk.LabelFrame(scrollable_frame, text="Text Encoder", padx=10, pady=10)
        text_frame.pack(fill=tk.X, pady=5)
        text_params = [
            ("Max text length:", 'text_max_len', 32, 256),
            ("Embedding dim:", 'text_embed_dim', 32, 128),
            ("Hidden size:", 'text_hidden_size', 32, 256),
            ("Num layers:", 'text_num_layers', 1, 4),
            ("Conditioning dim:", 'cond_dim', 64, 512),
        ]
        for label, key, low, high in text_params:
            f = tk.Frame(text_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=1).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # CFG settings
        cfg_frame = tk.LabelFrame(scrollable_frame, text="Classifier-Free Guidance", padx=10, pady=10)
        cfg_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(cfg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="CFG dropout prob (training):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=0.0, to=0.5, variable=self.settings['cfg_dropout_prob'],
                 orient=tk.HORIZONTAL, length=150, resolution=0.01).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['cfg_dropout_prob'], width=5).pack(side=tk.RIGHT)
        f = tk.Frame(cfg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="CFG scale (sampling):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=1.0, to=10.0, variable=self.settings['cfg_scale'],
                 orient=tk.HORIZONTAL, length=150, resolution=0.5).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['cfg_scale'], width=5).pack(side=tk.RIGHT)

        # EMA
        ema_frame = tk.LabelFrame(scrollable_frame, text="EMA (Exponential Moving Average)", padx=10, pady=10)
        ema_frame.pack(fill=tk.X, pady=5)
        cb_ema = tk.Checkbutton(ema_frame, text="Enable EMA", variable=self.settings['use_ema'],
                                command=self.toggle_ema_settings)
        cb_ema.pack(anchor='w')
        f_ema = tk.Frame(ema_frame); f_ema.pack(fill=tk.X, pady=2)
        tk.Label(f_ema, text="EMA decay (0.9-0.9999):", width=20, anchor='w').pack(side=tk.LEFT)
        self.ema_entry = tk.Entry(f_ema, textvariable=self.settings['ema_decay'], width=10)
        self.ema_entry.pack(side=tk.RIGHT)
        self.ema_entry.config(state='normal' if self.settings['use_ema'].get() else 'disabled')

        # Beta schedule
        schedule_frame = tk.LabelFrame(scrollable_frame, text="Beta Schedule", padx=10, pady=10)
        schedule_frame.pack(fill=tk.X, pady=5)
        f_sched = tk.Frame(schedule_frame); f_sched.pack(fill=tk.X, pady=2)
        tk.Label(f_sched, text="Schedule:", width=20, anchor='w').pack(side=tk.LEFT)
        sched_combo = ttk.Combobox(f_sched, textvariable=self.settings['beta_schedule'],
                                   values=['linear', 'cosine'], state='readonly', width=10)
        sched_combo.pack(side=tk.RIGHT)

        # Preview settings
        preview_frame = tk.LabelFrame(scrollable_frame, text="Training Preview", padx=10, pady=10)
        preview_frame.pack(fill=tk.X, pady=5)
        cb_preview = tk.Checkbutton(preview_frame, text="Enable preview during training",
                                    variable=self.settings['preview_enabled'],
                                    command=self.toggle_preview_settings)
        cb_preview.pack(anchor='w')
        f_preview = tk.Frame(preview_frame); f_preview.pack(fill=tk.X, pady=2)
        tk.Label(f_preview, text="Preview every N epochs:", width=20, anchor='w').pack(side=tk.LEFT)
        self.preview_spin = tk.Spinbox(f_preview, from_=1, to=50, textvariable=self.settings['preview_epochs'], width=5)
        self.preview_spin.pack(side=tk.RIGHT)
        self.preview_spin.config(state='normal' if self.settings['preview_enabled'].get() else 'disabled')

        # Sampling settings (generation)
        sampling_frame = tk.LabelFrame(scrollable_frame, text="Sampling (Generation)", padx=10, pady=10)
        sampling_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(sampling_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Sampling steps (for both DDPM/DDIM):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=10, to=500, variable=self.settings['sampling_steps'],
                 orient=tk.HORIZONTAL, length=200, resolution=1).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['sampling_steps'], width=5).pack(side=tk.RIGHT)
        f = tk.Frame(sampling_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="DDIM eta (0=deterministic):", width=25, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=0.0, to=1.0, variable=self.settings['ddim_eta'],
                 orient=tk.HORIZONTAL, length=200, resolution=0.01).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['ddim_eta'], width=5).pack(side=tk.RIGHT)

        # Augmentations
        aug_frame = tk.LabelFrame(scrollable_frame, text="Augmentations", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)
        for label, key in [("Horizontal Flip", 'flip_horizontal'), ("Rotation (±30°)", 'rotation')]:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def toggle_ema_settings(self):
        if self.settings['use_ema'].get():
            self.ema_entry.config(state='normal')
        else:
            self.ema_entry.config(state='disabled')

    def toggle_preview_settings(self):
        if self.settings['preview_enabled'].get():
            self.preview_spin.config(state='normal')
        else:
            self.preview_spin.config(state='disabled')

    # ------------------------------------------------------------------
    # Generation Tab
    # ------------------------------------------------------------------
    def setup_gen_tab(self):
        main_frame = tk.Frame(self.gen_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        prompt_frame = tk.LabelFrame(main_frame, text="Text Prompt", padx=5, pady=5)
        prompt_frame.pack(fill=tk.X, pady=5)
        self.gen_prompt = tk.Entry(prompt_frame, width=50)
        self.gen_prompt.insert(0, "a cute cat")
        self.gen_prompt.pack(side=tk.LEFT, padx=5)

        ctrl_frame = tk.Frame(main_frame)
        ctrl_frame.pack(pady=5)

        tk.Label(ctrl_frame, text="Number:").pack(side=tk.LEFT)
        self.gen_count = tk.IntVar(value=16)
        tk.Spinbox(ctrl_frame, from_=1, to=64, textvariable=self.gen_count, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="Sampling method:").pack(side=tk.LEFT, padx=(10,0))
        self.sampling_method = tk.StringVar(value='DDPM')
        method_combo = ttk.Combobox(ctrl_frame, textvariable=self.sampling_method,
                                    values=['DDPM', 'DDIM'], state='readonly', width=6)
        method_combo.pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="CFG scale:").pack(side=tk.LEFT, padx=(10,0))
        self.cfg_scale_var = tk.DoubleVar(value=self.settings['cfg_scale'].get())
        cfg_spin = tk.Spinbox(ctrl_frame, from_=1.0, to=10.0, increment=0.5,
                              textvariable=self.cfg_scale_var, width=5)
        cfg_spin.pack(side=tk.LEFT, padx=5)

        self.real_time_preview = tk.BooleanVar(value=False)
        self.realtime_cb = tk.Checkbutton(ctrl_frame, text="Real-time preview",
                                          variable=self.real_time_preview)
        self.realtime_cb.pack(side=tk.LEFT, padx=10)

        tk.Label(ctrl_frame, text="Update interval:").pack(side=tk.LEFT)
        self.preview_interval = tk.IntVar(value=5)
        tk.Spinbox(ctrl_frame, from_=1, to=20, textvariable=self.preview_interval, width=3).pack(side=tk.LEFT, padx=5)

        self.generate_btn = tk.Button(ctrl_frame, text="Generate", command=self.generate_samples, bg="lightgreen")
        self.generate_btn.pack(side=tk.LEFT, padx=5)
        self.stop_gen_btn = tk.Button(ctrl_frame, text="Stop", command=self.stop_generation,
                                      state=tk.DISABLED, bg="salmon")
        self.stop_gen_btn.pack(side=tk.LEFT, padx=5)

        scroll_frame = tk.LabelFrame(main_frame, text="Results", padx=5, pady=5)
        scroll_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        canvas_frame = tk.Frame(scroll_frame)
        canvas_frame.pack(fill=tk.BOTH, expand=True)

        self.gen_canvas = tk.Canvas(canvas_frame, bg='lightgray')
        self.v_scroll = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.gen_canvas.yview)
        self.h_scroll = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.gen_canvas.xview)
        self.gen_canvas.configure(yscrollcommand=self.v_scroll.set, xscrollcommand=self.h_scroll.set)

        self.v_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.h_scroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.inner_frame = tk.Frame(self.gen_canvas)
        self.canvas_window = self.gen_canvas.create_window((0,0), window=self.inner_frame, anchor='nw')
        self.inner_frame.bind('<Configure>', lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all')))

        self.gen_info = tk.Label(main_frame, text="", fg="blue")
        self.gen_info.pack()

        self.generation_active = False

    # ------------------------------------------------------------------
    # Core helper methods
    # ------------------------------------------------------------------
    def log(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp *.ico *.tiff")])
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log(f"Added {len(files)} images. Total: {len(self.image_paths)}")
        # reset labels if needed
        if not self.labels or len(self.labels) != len(self.image_paths):
            self.use_filenames_as_labels()

    def add_folder(self):
        folder = filedialog.askdirectory()
        if not folder:
            return
        count = 0
        for root_dir, _, files in os.walk(folder):
            for file in files:
                if file.lower().endswith(('.png','.jpg','.jpeg','.jfif','.webp','.bmp', '.ico', '.tiff')):
                    full = os.path.join(root_dir, file)
                    if full not in self.image_paths:
                        self.image_paths.append(full)
                        self.image_listbox.insert(tk.END, os.path.basename(full))
                        count += 1
        self.log(f"Added {count} images. Total: {len(self.image_paths)}")
        if not self.labels or len(self.labels) != len(self.image_paths):
            self.use_filenames_as_labels()

    def clear_images(self):
        self.image_paths.clear()
        self.labels.clear()
        self.image_listbox.delete(0, tk.END)
        self.csv_status.config(text="No CSV loaded", fg="red")
        self.log("Cleared all images")

    # CSV handling
    def load_csv(self):
        fname = filedialog.askopenfilename(filetypes=[("CSV", "*.csv")])
        if not fname:
            return
        self.csv_path = fname
        image_to_label = {}
        try:
            with open(fname, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) >= 2:
                        img_name, label = row[0], row[1]
                        image_to_label[img_name] = label
        except Exception as e:
            self.log(f"Error reading CSV: {e}")
            return

        # Match with loaded images
        self.labels = []
        matched = 0
        for path in self.image_paths:
            base = os.path.basename(path)
            if base in image_to_label:
                self.labels.append(image_to_label[base])
                matched += 1
            else:
                # fallback to filename
                name_no_ext = os.path.splitext(base)[0]
                self.labels.append(name_no_ext)
        self.csv_status.config(text=f"CSV loaded: {matched} matched, others use filenames", fg="green")
        self.log(f"CSV loaded. {matched} images matched with labels.")

    def use_filenames_as_labels(self):
        self.labels = [os.path.splitext(os.path.basename(p))[0] for p in self.image_paths]
        self.csv_status.config(text="Using filenames as labels", fg="blue")
        self.log("Using filenames as labels (underscores replaced with spaces)")

    def init_model(self):
        try:
            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            base_channels = self.settings['base_channels'].get()
            T = self.settings['timesteps'].get()
            use_attn = self.settings['use_self_attn'].get()
            img_size = self.settings['img_size'].get()
            cond_dim = self.settings['cond_dim'].get()
            # Determine attention resolutions if enabled
            if use_attn:
                attn_res = set()
                for res in [32, 16, 8]:
                    if res <= img_size and res >= 8:
                        attn_res.add(res)
            else:
                attn_res = set()

            unet = DenoisingUNet(
                in_channels=in_channels,
                base_channels=base_channels,
                time_emb_dim=base_channels * 4,
                cond_dim=cond_dim,
                channel_mult=(1, 2, 3, 4),
                dropout=0.1,
                attn_resolutions=attn_res
            )
            self.model = unet

            # Text encoder
            self.text_encoder = TextEncoder(
                vocab_size=256,
                embed_dim=self.settings['text_embed_dim'].get(),
                hidden_size=self.settings['text_hidden_size'].get(),
                num_layers=self.settings['text_num_layers'].get(),
                cond_dim=cond_dim
            )

            schedule = self.settings['beta_schedule'].get()
            self.ddpm = ConditionedDDPM(unet, self.text_encoder, T=T, schedule=schedule, device='cpu')
            self.optimizer = optim.Adam(
                list(self.model.parameters()) + list(self.text_encoder.parameters()),
                lr=self.settings['lr'].get()
            )
            # EMA
            self.ema_enabled = self.settings['use_ema'].get()
            if self.ema_enabled:
                try:
                    self.ema_decay = float(self.settings['ema_decay'].get())
                except:
                    self.ema_decay = 0.9999
                self.ema_model = self._create_ema_model(unet)
            else:
                self.ema_model = None
            self.log("Text-conditioned diffusion model initialized.")
        except Exception as e:
            self.log(f"Error: {e}")

    def _create_ema_model(self, model):
        ema_model = DenoisingUNet(
            in_channels=model.in_channels,
            base_channels=model.base_channels,
            time_emb_dim=model.time_emb_dim,
            cond_dim=model.cond_dim,
            channel_mult=model.channel_mult,
            dropout=0.1,
            attn_resolutions=model.attn_resolutions
        )
        ema_model.load_state_dict(model.state_dict())
        return ema_model

    def _update_ema(self):
        if self.ema_model is None:
            return
        for ema_param, param in zip(self.ema_model.parameters(), self.model.parameters()):
            ema_param.data.mul_(self.ema_decay).add_(param.data, alpha=1 - self.ema_decay)

    def start_training(self):
        if not self.image_paths:
            self.log("No images!")
            return
        if not self.labels:
            self.log("No labels! Load CSV or use filenames.")
            return
        if not self.model or not self.text_encoder:
            self.log("Model not initialized!")
            return
        if self.training:
            self.log("Already training.")
            return
        try:
            epochs = int(self.epoch_var.get())
        except:
            self.log("Invalid epochs")
            return
        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()
        thread = threading.Thread(target=self.train_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log(f"Training started for {epochs} epochs.")

    def train_loop(self, epochs):
        try:
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            img_size = self.settings['img_size'].get()
            color_mode = self.settings['color_mode'].get()
            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}
            text_max_len = self.settings['text_max_len'].get()
            dataset = TextConditionedImageDataset(self.image_paths, self.labels, img_size, color_mode, aug_dict, text_max_len)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=False)

            preview_enabled = self.settings['preview_enabled'].get()
            preview_epochs = self.settings['preview_epochs'].get()
            if not preview_enabled:
                preview_epochs = epochs+1

            cfg_dropout = self.settings['cfg_dropout_prob'].get()

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                epoch_loss = 0.0
                batches = 0
                for images, text_tensors in loader:
                    if not self.training:
                        break
                    images = images
                    loss = self.ddpm.training_loss(images, text_tensors, cfg_dropout_prob=cfg_dropout)
                    self.optimizer.zero_grad()
                    loss.backward()
                    self.optimizer.step()
                    if self.ema_enabled:
                        self._update_ema()
                    epoch_loss += loss.item()
                    batches += 1
                avg_loss = epoch_loss / batches if batches else 0
                elapsed = time.time() - self.start_time
                self.log(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s")
                if (epoch+1) % preview_epochs == 0:
                    self.show_train_preview()
            self.training = False
            self.log("Training finished.")
        except Exception as e:
            self.log(f"Training error: {e}")
            import traceback; traceback.print_exc()
            self.training = False

    def show_train_preview(self):
        """Generate sample images using current model and test prompt with CFG."""
        if not self.model or not self.text_encoder:
            self.log("Model not loaded for preview")
            return
        try:
            prompt = self.train_test_prompt.get().strip()
            if not prompt:
                prompt = "a cat"
            n_samples = 16
            device = 'cpu'
            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            img_size = self.settings['img_size'].get()
            img_shape = (in_channels, img_size, img_size)

            # encode prompt to indices
            text_max_len = self.settings['text_max_len'].get()
            indices = [text_to_indices(prompt, text_max_len) for _ in range(n_samples)]
            text_tensor = torch.tensor(indices, dtype=torch.long, device=device)

            # Use current model (or EMA if enabled)
            model_for_sampling = self.ema_model if (self.ema_enabled and self.ema_model is not None) else self.model
            # Temporarily swap
            original_model = self.ddpm.model
            original_text_enc = self.ddpm.text_encoder
            self.ddpm.model = model_for_sampling
            self.ddpm.text_encoder = self.text_encoder  # same

            n_steps = min(150, self.settings['sampling_steps'].get())
            cfg_scale = self.settings['cfg_scale'].get()  # use current CFG scale from settings
            with torch.no_grad():
                samples = self.ddpm.sample_ddim(
                    n_samples=n_samples,
                    img_shape=img_shape,
                    text_condition=text_tensor,
                    n_steps=n_steps,
                    eta=0.0,
                    cfg_scale=cfg_scale
                )
            # Restore
            self.ddpm.model = original_model
            self.ddpm.text_encoder = original_text_enc

            samples = (samples + 1) / 2
            samples = samples.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size
            grid = Image.new('RGB', (4*thumb, 4*thumb))
            for i in range(4):
                for j in range(4):
                    idx = i*4 + j
                    if idx < len(samples):
                        if samples[idx].shape[0] == 1:
                            img = np.stack([samples[idx][0]]*3, axis=-1)
                        else:
                            img = samples[idx].transpose(1,2,0)
                        img = (img * 255).astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img, (j*thumb, i*thumb))
            grid = grid.resize((256,256), Image.NEAREST)
            self.train_preview_photo = ImageTk.PhotoImage(grid)
            self.train_preview_canvas.delete("all")
            self.train_preview_canvas.create_image(128,128, image=self.train_preview_photo)
        except Exception as e:
            self.log(f"Preview error: {e}")

    def stop_training(self):
        self.training = False
        self.log("Training stopped.")

    def save_model(self):
        if not self.model or not self.text_encoder:
            self.log("No model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth", filetypes=[("PyTorch","*.pth")])
        if fname:
            save_dict = {
                'model_state': self.model.state_dict(),
                'text_encoder_state': self.text_encoder.state_dict(),
                'optimizer_state': self.optimizer.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items()},
            }
            if self.ema_model is not None:
                save_dict['ema_model_state'] = self.ema_model.state_dict()
            torch.save(save_dict, fname)
            self.log(f"Model saved to {fname}")

    def load_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            if 'settings' in ckpt:
                for k,v in ckpt['settings'].items():
                    if k in self.settings:
                        self.settings[k].set(v)
            self.init_model()  # reinitialize with loaded settings
            self.model.load_state_dict(ckpt['model_state'])
            self.text_encoder.load_state_dict(ckpt['text_encoder_state'])
            self.optimizer.load_state_dict(ckpt['optimizer_state'])
            if 'ema_model_state' in ckpt and self.ema_model is not None:
                self.ema_model.load_state_dict(ckpt['ema_model_state'])
            self.log(f"Model loaded from {fname}")
        except Exception as e:
            self.log(f"Load error: {e}")

    # ========== Generation with Preview ==========
    def generate_samples(self):
        if not self.model or not self.text_encoder:
            self.gen_info.config(text="Model not loaded!")
            return
        n = self.gen_count.get()
        method = self.sampling_method.get()
        prompt = self.gen_prompt.get().strip()
        if not prompt:
            self.gen_info.config(text="Enter a text prompt")
            return
        self.generation_active = True
        self.generate_btn.config(state=tk.DISABLED)
        self.stop_gen_btn.config(state=tk.NORMAL)
        self.gen_info.config(text="Generating...")
        self.root.update()
        thread = threading.Thread(target=self._generate_thread, args=(n, method, prompt), daemon=True)
        thread.start()

    def stop_generation(self):
        self.generation_active = False
        self.stop_gen_btn.config(state=tk.DISABLED)
        self.gen_info.config(text="Generation stopped.")

    def _generate_thread(self, n, method, prompt):
        try:
            # Use EMA model if available and enabled
            model_for_sampling = self.ema_model if (self.ema_enabled and self.ema_model is not None) else self.model
            # Temporarily swap
            original_model = self.ddpm.model
            original_text_enc = self.ddpm.text_encoder
            self.ddpm.model = model_for_sampling
            self.ddpm.text_encoder = self.text_encoder

            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            img_size = self.settings['img_size'].get()
            img_shape = (in_channels, img_size, img_size)
            realtime = self.real_time_preview.get()
            interval = self.preview_interval.get()
            n_steps = self.settings['sampling_steps'].get()
            eta = self.settings['ddim_eta'].get()
            cfg_scale = self.cfg_scale_var.get()

            # encode prompt
            text_max_len = self.settings['text_max_len'].get()
            indices = [text_to_indices(prompt, text_max_len) for _ in range(n)]
            text_tensor = torch.tensor(indices, dtype=torch.long, device='cpu')

            if method == 'DDPM':
                if realtime:
                    def progress_callback(step, x_t, x0_est):
                        if not self.generation_active:
                            raise StopIteration
                        if step % interval == 0 or step == n_steps:
                            samples = (x0_est + 1) / 2
                            samples = samples.clamp(0,1).cpu().numpy()
                            self.root.after(0, lambda s=samples.copy(): self._update_gen_preview(s, step, n_steps))
                    with torch.no_grad():
                        final = self.ddpm.sample_ddpm(n, img_shape, text_tensor, n_steps=n_steps,
                                                      cfg_scale=cfg_scale, progress_callback=progress_callback)
                    if self.generation_active:
                        final_samples = (final + 1) / 2
                        final_samples = final_samples.clamp(0,1).cpu().numpy()
                        self.root.after(0, lambda s=final_samples: self._display_final(s, n))
                else:
                    with torch.no_grad():
                        final = self.ddpm.sample_ddpm(n, img_shape, text_tensor, n_steps=n_steps, cfg_scale=cfg_scale)
                    final_samples = (final + 1) / 2
                    final_samples = final_samples.clamp(0,1).cpu().numpy()
                    self.root.after(0, lambda s=final_samples: self._display_final(s, n))
            else:  # DDIM
                if realtime:
                    def progress_callback(step, x_t, x0_est):
                        if not self.generation_active:
                            raise StopIteration
                        if step % interval == 0 or step == n_steps:
                            samples = (x0_est + 1) / 2
                            samples = samples.clamp(0,1).cpu().numpy()
                            self.root.after(0, lambda s=samples.copy(): self._update_gen_preview(s, step, n_steps))
                    with torch.no_grad():
                        final = self.ddpm.sample_ddim(n, img_shape, text_tensor, n_steps=n_steps, eta=eta,
                                                      cfg_scale=cfg_scale, progress_callback=progress_callback)
                    if self.generation_active:
                        final_samples = (final + 1) / 2
                        final_samples = final_samples.clamp(0,1).cpu().numpy()
                        self.root.after(0, lambda s=final_samples: self._display_final(s, n))
                else:
                    with torch.no_grad():
                        final = self.ddpm.sample_ddim(n, img_shape, text_tensor, n_steps=n_steps, eta=eta, cfg_scale=cfg_scale)
                    final_samples = (final + 1) / 2
                    final_samples = final_samples.clamp(0,1).cpu().numpy()
                    self.root.after(0, lambda s=final_samples: self._display_final(s, n))
        except StopIteration:
            pass
        except Exception as e:
            self.root.after(0, lambda: self.gen_info.config(text=f"Error: {e}"))
            import traceback; traceback.print_exc()
        finally:
            self.ddpm.model = original_model
            self.ddpm.text_encoder = original_text_enc
            self.generation_active = False
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_gen_btn.config(state=tk.DISABLED))

    def _update_gen_preview(self, samples, step, total_steps):
        n = len(samples)
        thumb = self.thumbnail_size
        grid_size = int(math.ceil(math.sqrt(n)))
        total = grid_size * thumb
        grid_img = Image.new('RGB', (total, total), color=(128,128,128))
        for i in range(n):
            row = i // grid_size
            col = i % grid_size
            if i < len(samples):
                if samples[i].shape[0] == 1:
                    img = np.stack([samples[i][0]]*3, axis=-1)
                else:
                    img = samples[i].transpose(1,2,0)
                img = (img * 255).astype(np.uint8)
                pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                grid_img.paste(pil_img, (col*thumb, row*thumb))
        for w in self.inner_frame.winfo_children():
            w.destroy()
        self.prog_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.prog_photo)
        label.image = self.prog_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text=f"Step {step}/{total_steps}")

    def _display_final(self, samples, n):
        thumb = self.thumbnail_size
        grid_size = int(math.ceil(math.sqrt(n)))
        total = grid_size * thumb
        grid_img = Image.new('RGB', (total, total), color=(128,128,128))
        for i in range(n):
            row = i // grid_size
            col = i % grid_size
            if i < len(samples):
                if samples[i].shape[0] == 1:
                    img = np.stack([samples[i][0]]*3, axis=-1)
                else:
                    img = samples[i].transpose(1,2,0)
                img = (img * 255).astype(np.uint8)
                pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                grid_img.paste(pil_img, (col*thumb, row*thumb))
        for w in self.inner_frame.winfo_children():
            w.destroy()
        self.gen_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.gen_photo)
        label.image = self.gen_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text="Generation complete.")

# ==================== Main ====================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = TextConditionedDiffusionApp(root)
    root.mainloop()