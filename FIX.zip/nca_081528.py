import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import time
import math
from typing import List
from torchvision import transforms

# ----------------------------  Helper functions ----------------------------
def load_image_as_rgb(path):
    img = Image.open(path)
    if img.mode == 'RGBA':
        bg = Image.new('RGB', img.size, (0, 0, 0))
        bg.paste(img, mask=img.split()[3])
        return bg
    else:
        return img.convert('RGB')

def gaussian_kernel(size=5, sigma=1.0):
    k = size // 2
    x = torch.arange(-k, k+1, dtype=torch.float32)
    y = torch.arange(-k, k+1, dtype=torch.float32)
    xx, yy = torch.meshgrid(x, y, indexing='ij')
    kernel = torch.exp(-(xx**2 + yy**2) / (2 * sigma**2))
    kernel = kernel / kernel.sum()
    return kernel.view(1, 1, size, size)

# ----------------------------  μNCA Model ---------------------------------
def get_fixed_kernels(device='cpu'):
    laplacian = torch.tensor([[0, 1, 0],
                              [1,-4, 1],
                              [0, 1, 0]], dtype=torch.float32, device=device).view(1,1,3,3)
    sobel_x = torch.tensor([[-1, 0, 1],
                            [-2, 0, 2],
                            [-1, 0, 1]], dtype=torch.float32, device=device).view(1,1,3,3)
    sobel_y = torch.tensor([[-1,-2,-1],
                            [ 0, 0, 0],
                            [ 1, 2, 1]], dtype=torch.float32, device=device).view(1,1,3,3)
    return laplacian, sobel_x, sobel_y

class MicroNCA(nn.Module):
    def __init__(self, n_lap: int, n_x: int, n_y: int):
        super().__init__()
        self.n_lap = n_lap
        self.n_x = n_x
        self.n_y = n_y
        self.C = n_lap + n_x + n_y
        self.W = nn.Parameter(torch.randn(4 * self.C, self.C) * 0.02)
        self.b = nn.Parameter(torch.zeros(self.C))
        lap, sob_x, sob_y = get_fixed_kernels()
        self.register_buffer('lap_kernel', lap)
        self.register_buffer('sobel_x_kernel', sob_x)
        self.register_buffer('sobel_y_kernel', sob_y)

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        B, C, H, W = state.shape
        assert C == self.C
        filtered = []
        if self.n_lap > 0:
            lap_k = self.lap_kernel.expand(self.n_lap, 1, 3, 3)
            lap_feat = F.conv2d(state[:, :self.n_lap], lap_k, padding=1, groups=self.n_lap)
            filtered.append(lap_feat)
        if self.n_x > 0:
            sobelx_k = self.sobel_x_kernel.expand(self.n_x, 1, 3, 3)
            sobelx_feat = F.conv2d(state[:, self.n_lap:self.n_lap+self.n_x], sobelx_k, padding=1, groups=self.n_x)
            filtered.append(sobelx_feat)
        if self.n_y > 0:
            sobely_k = self.sobel_y_kernel.expand(self.n_y, 1, 3, 3)
            sobely_feat = F.conv2d(state[:, self.n_lap+self.n_x:], sobely_k, padding=1, groups=self.n_y)
            filtered.append(sobely_feat)
        f = torch.cat(filtered, dim=1)
        p = torch.cat([state, f], dim=1)               # (B, 2C, H, W)
        y = torch.cat([p, torch.abs(p)], dim=1)        # (B, 4C, H, W)
        y_flat = y.view(B, 4*C, H*W).permute(0, 2, 1) # (B, H*W, 4C)
        delta = torch.matmul(y_flat, self.W)           # (B, H*W, C)
        delta = delta.permute(0, 2, 1).view(B, C, H, W) + self.b.view(1, C, 1, 1)
        return state + delta

# ----------------------------  OTT Loss ------------------------------------
def extract_pyramid_patches(img_tensor: torch.Tensor, n_levels: int, patch_size: int,
                             subsample: int = 1024, sharpen: bool = True) -> List[torch.Tensor]:
    """
    img_tensor: (1, 3, H, W) in range [-1,1]
    Returns list of 2D tensors (N_patches, patch_size*patch_size*3) for each level.
    """
    device = img_tensor.device
    img = (img_tensor + 1) / 2
    patches_per_level = []
    gauss_kernel = gaussian_kernel(5, 1.0).to(device)
    gauss_kernel_rgb = gauss_kernel.repeat(3, 1, 1, 1)
    current = img
    for level in range(n_levels):
        if sharpen:
            blurred = F.conv2d(current, gauss_kernel_rgb, padding=2, groups=3)
            sharp = current + 2 * (current - blurred)
        else:
            sharp = current
        B, C, H, W = sharp.shape
        assert B == 1, "Only batch size 1 supported"
        # Extract patches
        patches = sharp.unfold(2, patch_size, 1).unfold(3, patch_size, 1)
        patches = patches.permute(0,2,3,1,4,5).contiguous()
        patches = patches.view(1, -1, C * patch_size * patch_size)
        n_patches = patches.size(1)
        if n_patches > subsample and subsample > 0:
            idx = torch.randperm(n_patches, device=device)[:subsample]
            patches = patches[:, idx, :]
        patches_per_level.append(patches.squeeze(0))  # (N_patches, D)
        current = F.interpolate(current, scale_factor=0.5, mode='bilinear', align_corners=False)
    return patches_per_level

def sinkhorn_divergence(X: torch.Tensor, Y: torch.Tensor, epsilon: float = 0.05, max_iter: int = 30) -> torch.Tensor:
    """
    X: (n, d), Y: (m, d)
    Returns scalar OT divergence.
    """
    n, m = X.shape[0], Y.shape[0]
    if n == 0 or m == 0:
        return torch.tensor(0.0, device=X.device)
    # Ensure 2D
    X = X.reshape(n, -1)
    Y = Y.reshape(m, -1)
    # Squared Euclidean distance
    X_norm = (X * X).sum(dim=1, keepdim=True)   # (n,1)
    Y_norm = (Y * Y).sum(dim=1, keepdim=True)   # (m,1)
    C = X_norm + Y_norm.T - 2 * torch.mm(X, Y.T)
    C = C / (C.max() + 1e-8)
    # Sinkhorn
    a = torch.ones(n, device=X.device) / n
    b = torch.ones(m, device=X.device) / m
    K = torch.exp(-C / epsilon)
    u = torch.ones_like(a)
    v = torch.ones_like(b)
    for _ in range(max_iter):
        u = a / (K @ v)
        v = b / (K.T @ u)
    P = u[:, None] * K * v[None, :]
    loss = (P * C).sum()
    return loss

def texture_loss(gen_patches: List[torch.Tensor], target_patches: List[torch.Tensor]) -> torch.Tensor:
    loss = 0.0
    for g, t in zip(gen_patches, target_patches):
        if g.shape[0] == 0 or t.shape[0] == 0:
            continue
        loss += sinkhorn_divergence(g, t)
    return loss

# ----------------------------  GUI Application ----------------------------
class MicroNCAApp:
    def __init__(self, root):
        self.root = root
        self.root.title("μNCA - Ultra‑compact Neural Cellular Automata")
        self.root.geometry("1200x800")

        self.target_image_path = None
        self.target_patches = None
        self.model = None
        self.optimizer = None
        self.training = False
        self.message_queue = queue.Queue()

        self.settings = {
            'img_size': tk.IntVar(value=64),
            'n_lap': tk.IntVar(value=2),
            'n_x': tk.IntVar(value=1),
            'n_y': tk.IntVar(value=1),
            'lr': tk.DoubleVar(value=1e-3),
            'n_steps_per_iter': tk.IntVar(value=32),
            'batch_seed_rate': tk.IntVar(value=4),
            'pool_size': tk.IntVar(value=32),
            'patch_size': tk.IntVar(value=7),
            'n_pyramid_levels': tk.IntVar(value=3),
            'subsample_patches': tk.IntVar(value=1024),
            'overflow_weight': tk.DoubleVar(value=0.01),
            'preview_epochs': tk.IntVar(value=10),
        }
        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.train_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.train_tab, text='Training')
        self.setup_train_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.gen_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.gen_tab, text='Generation')
        self.setup_gen_tab()

        self.status_label = tk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    # ----------------------------  Training Tab ----------------------------
    def setup_train_tab(self):
        main_frame = tk.Frame(self.train_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="μNCA Texture Training", font=("Arial",12,"bold")).pack(pady=(0,10))

        img_frame = tk.LabelFrame(left_frame, text="Target Texture", padx=5, pady=5)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Load Image", command=self.load_target_image, width=20).pack(pady=2)
        self.target_label = tk.Label(img_frame, text="No image loaded", fg="red")
        self.target_label.pack(pady=2)

        tk.Button(left_frame, text="Initialize Model", command=self.init_model, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start Training", command=self.start_training, width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop Training", command=self.stop_training, width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load Model", command=self.load_model, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Preview (every N epochs)", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.train_preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=256)
        self.train_preview_canvas.pack()

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

    # ----------------------------  Settings Tab ----------------------------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        arch_frame = tk.LabelFrame(scrollable_frame, text="Model Architecture", padx=10, pady=10)
        arch_frame.pack(fill=tk.X, pady=5)
        for label, key in [("Laplacian channels (n_lap):", 'n_lap'),
                           ("Sobel-X channels (n_x):", 'n_x'),
                           ("Sobel-Y channels (n_y):", 'n_y')]:
            f = tk.Frame(arch_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            tk.Scale(f, from_=0, to=8, variable=self.settings[key], orient=tk.HORIZONTAL, length=200, resolution=1).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)
        self.param_label = tk.Label(arch_frame, text="Parameters: 0", fg="blue")
        self.param_label.pack(pady=5)
        for key in ['n_lap','n_x','n_y']:
            self.settings[key].trace_add('write', lambda *a: self.update_param_count())

        train_frame = tk.LabelFrame(scrollable_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=5)
        params = [
            ("Learning rate:", 'lr', 1e-5, 1e-2, 'log'),
            ("CA steps per iteration:", 'n_steps_per_iter', 1, 100, 'int'),
            ("Seed rate (seed every N steps):", 'batch_seed_rate', 1, 20, 'int'),
            ("State pool size:", 'pool_size', 8, 64, 'int'),
            ("Overflow loss weight:", 'overflow_weight', 0.0, 0.1, 'float'),
        ]
        for label, key, low, high, typ in params:
            f = tk.Frame(train_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=30, anchor='w').pack(side=tk.LEFT)
            if typ == 'log':
                scale = tk.Scale(f, from_=math.log10(low), to=math.log10(high), resolution=0.01,
                                 orient=tk.HORIZONTAL, length=200,
                                 command=lambda v, k=key: self.settings[k].set(10**float(v)))
                scale.set(math.log10(self.settings[key].get()))
                scale.pack(side=tk.RIGHT)
            else:
                scale = tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                                 orient=tk.HORIZONTAL, length=200, resolution=1 if typ=='int' else 0.001)
                scale.pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=8).pack(side=tk.RIGHT)

        ott_frame = tk.LabelFrame(scrollable_frame, text="OTT Loss", padx=10, pady=10)
        ott_frame.pack(fill=tk.X, pady=5)
        ott_params = [
            ("Patch size:", 'patch_size', 3, 15, 'int'),
            ("Pyramid levels:", 'n_pyramid_levels', 1, 4, 'int'),
            ("Subsample patches (0 = all):", 'subsample_patches', 0, 1024, 'int'),
        ]
        for label, key, low, high, typ in ott_params:
            f = tk.Frame(ott_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=25, anchor='w').pack(side=tk.LEFT)
            scale = tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                             orient=tk.HORIZONTAL, length=200, resolution=1 if typ=='int' else 0.01)
            scale.pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        preview_frame = tk.LabelFrame(scrollable_frame, text="Preview", padx=10, pady=10)
        preview_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(preview_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Preview every N epochs:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Spinbox(f, from_=1, to=50, textvariable=self.settings['preview_epochs'], width=5).pack(side=tk.RIGHT)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def update_param_count(self):
        n_lap = self.settings['n_lap'].get()
        n_x = self.settings['n_x'].get()
        n_y = self.settings['n_y'].get()
        C = n_lap + n_x + n_y
        params = 4*C*C + C
        self.param_label.config(text=f"Parameters: {params} (C={C})")

    # ----------------------------  Generation Tab ----------------------------
    def setup_gen_tab(self):
        main_frame = tk.Frame(self.gen_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        ctrl_frame = tk.Frame(main_frame); ctrl_frame.pack(pady=5)
        tk.Label(ctrl_frame, text="Number of samples:").pack(side=tk.LEFT)
        self.gen_count = tk.IntVar(value=16)
        tk.Spinbox(ctrl_frame, from_=1, to=64, textvariable=self.gen_count, width=5).pack(side=tk.LEFT, padx=5)
        tk.Label(ctrl_frame, text="CA steps:").pack(side=tk.LEFT, padx=(10,0))
        self.gen_steps = tk.IntVar(value=256)
        tk.Spinbox(ctrl_frame, from_=1, to=1000, textvariable=self.gen_steps, width=5).pack(side=tk.LEFT, padx=5)
        self.real_time_preview = tk.BooleanVar(value=False)
        tk.Checkbutton(ctrl_frame, text="Real-time preview", variable=self.real_time_preview).pack(side=tk.LEFT, padx=10)
        self.generate_btn = tk.Button(ctrl_frame, text="Generate", command=self.generate_samples, bg="lightgreen")
        self.generate_btn.pack(side=tk.LEFT, padx=5)
        self.stop_gen_btn = tk.Button(ctrl_frame, text="Stop", command=self.stop_generation, state=tk.DISABLED, bg="salmon")
        self.stop_gen_btn.pack(side=tk.LEFT, padx=5)

        scroll_frame = tk.LabelFrame(main_frame, text="Results", padx=5, pady=5)
        scroll_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        canvas_frame = tk.Frame(scroll_frame); canvas_frame.pack(fill=tk.BOTH, expand=True)
        self.gen_canvas = tk.Canvas(canvas_frame, bg='lightgray')
        v_scroll = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.gen_canvas.yview)
        h_scroll = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.gen_canvas.xview)
        self.gen_canvas.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)
        v_scroll.pack(side=tk.RIGHT, fill=tk.Y); h_scroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.inner_frame = tk.Frame(self.gen_canvas)
        self.canvas_window = self.gen_canvas.create_window((0,0), window=self.inner_frame, anchor='nw')
        self.inner_frame.bind('<Configure>', lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all')))
        self.gen_info = tk.Label(main_frame, text="", fg="blue")
        self.gen_info.pack()
        self.generation_active = False

    # ----------------------------  Core Methods ----------------------------
    def log(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def load_target_image(self):
        path = filedialog.askopenfilename(filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp")])
        if path:
            self.target_image_path = path
            self.target_label.config(text=os.path.basename(path), fg="green")
            self.log(f"Loaded target texture: {path}")
            self.precompute_target_patches()

    def precompute_target_patches(self):
        if not self.target_image_path:
            return
        img_size = self.settings['img_size'].get()
        img = load_image_as_rgb(self.target_image_path)
        transform = transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
        img_tensor = transform(img).unsqueeze(0)  # (1,3,H,W)
        n_levels = self.settings['n_pyramid_levels'].get()
        patch_size = self.settings['patch_size'].get()
        subsample = self.settings['subsample_patches'].get()
        if subsample == 0:
            subsample = 1000000
        self.target_patches = extract_pyramid_patches(img_tensor, n_levels, patch_size, subsample, sharpen=True)
        self.log(f"Precomputed target patches: {len(self.target_patches)} levels")

    def init_model(self):
        if not self.target_image_path:
            self.log("Please load a target texture image first.")
            return
        n_lap = self.settings['n_lap'].get()
        n_x = self.settings['n_x'].get()
        n_y = self.settings['n_y'].get()
        self.model = MicroNCA(n_lap, n_x, n_y)
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.settings['lr'].get())
        self.log(f"Model initialized. Parameters: {sum(p.numel() for p in self.model.parameters())}")
        self.update_param_count()

    def overflow_loss(self, state):
        return torch.mean(F.relu(torch.abs(state) - 1.0))

    def train_loop(self, epochs):
        try:
            device = 'cpu'
            self.model.train()
            img_size = self.settings['img_size'].get()
            C = self.model.C
            batch_size = 1   # Force batch size 1 for patch extraction simplicity
            pool_size = self.settings['pool_size'].get()
            n_steps = self.settings['n_steps_per_iter'].get()
            seed_rate = self.settings['batch_seed_rate'].get()
            overflow_weight = self.settings['overflow_weight'].get()
            # State pool: each element is a single state (1, C, H, W)
            pool = [torch.rand(1, C, img_size, img_size) - 0.5 for _ in range(pool_size)]
            if self.target_patches is None:
                self.precompute_target_patches()

            for epoch in range(epochs):
                if not self.training:
                    break
                epoch_loss = 0.0
                for iter_idx in range(20):  # 20 iterations per epoch
                    # Sample one state from pool (batch size 1)
                    idx = torch.randint(0, pool_size, (1,)).item()
                    x = pool[idx].clone().detach().requires_grad_(True)
                    if iter_idx % seed_rate == 0:
                        x = torch.rand(1, C, img_size, img_size) - 0.5
                    # Apply CA steps
                    for _ in range(n_steps):
                        x = self.model(x)
                    # Compute loss
                    rgb = x[:, :3].clamp(-1, 1)
                    gen_patches = extract_pyramid_patches(rgb,
                                                          self.settings['n_pyramid_levels'].get(),
                                                          self.settings['patch_size'].get(),
                                                          self.settings['subsample_patches'].get(),
                                                          sharpen=True)
                    loss_tex = texture_loss(gen_patches, self.target_patches)
                    loss_overflow = self.overflow_loss(x)
                    loss = loss_tex + overflow_weight * loss_overflow
                    if torch.isnan(loss):
                        self.log("NaN loss - stopping training")
                        self.training = False
                        break
                    self.optimizer.zero_grad()
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                    self.optimizer.step()
                    epoch_loss += loss.item()
                    # Update pool with new state (detach)
                    pool[idx] = x.detach()
                if not self.training:
                    break
                avg_loss = epoch_loss / 20
                self.log(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f}")
                if (epoch+1) % self.settings['preview_epochs'].get() == 0:
                    self.show_train_preview()
            self.training = False
            self.log("Training finished.")
        except Exception as e:
            self.log(f"Training error: {e}")
            import traceback; traceback.print_exc()
            self.training = False

    @torch.no_grad()
    def show_train_preview(self):
        if self.model is None:
            return
        self.model.eval()
        C = self.model.C
        img_size = self.settings['img_size'].get()
        state = torch.rand(1, C, img_size, img_size) - 0.5
        for _ in range(200):
            state = self.model(state)
        rgb = state[0, :3].clamp(-1, 1).cpu().numpy().transpose(1,2,0)
        rgb = (rgb + 1) / 2
        rgb = (rgb * 255).astype(np.uint8)
        pil_img = Image.fromarray(rgb).resize((256,256), Image.NEAREST)
        self.train_preview_photo = ImageTk.PhotoImage(pil_img)
        self.train_preview_canvas.delete("all")
        self.train_preview_canvas.create_image(128,128, image=self.train_preview_photo)
        self.model.train()

    def start_training(self):
        if self.model is None:
            self.log("Model not initialized. Click 'Initialize Model' first.")
            return
        if self.target_patches is None:
            self.log("No target texture patches. Load an image and precompute.")
            return
        if self.training:
            self.log("Already training.")
            return
        try:
            epochs = int(self.epoch_var.get())
        except:
            self.log("Invalid epochs")
            return
        self.training = True
        threading.Thread(target=self.train_loop, args=(epochs,), daemon=True).start()
        self.log(f"Training started for {epochs} epochs.")

    def stop_training(self):
        self.training = False
        self.log("Stopping training...")

    def save_model(self):
        if self.model is None:
            self.log("No model to save.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".pth", filetypes=[("PyTorch", "*.pth")])
        if path:
            torch.save({
                'model_state': self.model.state_dict(),
                'optimizer_state': self.optimizer.state_dict(),
                'settings': {k: v.get() for k, v in self.settings.items()}
            }, path)
            self.log(f"Model saved to {path}")

    def load_model(self):
        path = filedialog.askopenfilename(filetypes=[("PyTorch", "*.pth")])
        if not path:
            return
        ckpt = torch.load(path, map_location='cpu')
        for k, v in ckpt['settings'].items():
            if k in self.settings:
                self.settings[k].set(v)
        n_lap = self.settings['n_lap'].get()
        n_x = self.settings['n_x'].get()
        n_y = self.settings['n_y'].get()
        self.model = MicroNCA(n_lap, n_x, n_y)
        self.model.load_state_dict(ckpt['model_state'])
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.settings['lr'].get())
        self.optimizer.load_state_dict(ckpt['optimizer_state'])
        self.log(f"Model loaded from {path}")

    # ----------------------------  Generation ----------------------------
    @torch.no_grad()
    def generate_samples(self):
        if self.model is None:
            self.gen_info.config(text="Model not loaded!")
            return
        self.generation_active = True
        self.generate_btn.config(state=tk.DISABLED)
        self.stop_gen_btn.config(state=tk.NORMAL)
        self.gen_info.config(text="Generating...")
        threading.Thread(target=self._generate_thread, daemon=True).start()

    def stop_generation(self):
        self.generation_active = False
        self.stop_gen_btn.config(state=tk.DISABLED)
        self.gen_info.config(text="Generation stopped.")

    def _generate_thread(self):
        try:
            n_samples = self.gen_count.get()
            n_steps = self.gen_steps.get()
            realtime = self.real_time_preview.get()
            C = self.model.C
            img_size = self.settings['img_size'].get()
            self.model.eval()
            states = torch.rand(n_samples, C, img_size, img_size) - 0.5
            for step in range(n_steps):
                if not self.generation_active:
                    break
                states = self.model(states)
                if realtime and (step % 20 == 0 or step == n_steps-1):
                    # FIX: detach before converting to numpy to avoid gradient error
                    rgb = states[:, :3].clamp(-1, 1).detach().cpu().numpy()
                    thumb = 128
                    grid_size = int(math.ceil(math.sqrt(n_samples)))
                    total = grid_size * thumb
                    grid_img = Image.new('RGB', (total, total), color=(128,128,128))
                    for i in range(n_samples):
                        row = i // grid_size
                        col = i % grid_size
                        img = rgb[i].transpose(1,2,0)
                        img = (img + 1) / 2
                        img = (img * 255).astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid_img.paste(pil_img, (col*thumb, row*thumb))
                    self.root.after(0, lambda g=grid_img, s=step, t=n_steps: self._update_gen_display(g, s, t))
            if self.generation_active:
                self.root.after(0, lambda: self.gen_info.config(text="Generation complete."))
            self.model.train()
        except Exception as e:
            self.root.after(0, lambda: self.gen_info.config(text=f"Error: {e}"))
        finally:
            self.generation_active = False
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_gen_btn.config(state=tk.DISABLED))

    def _update_gen_display(self, grid_img, step, total_steps):
        for w in self.inner_frame.winfo_children():
            w.destroy()
        self.gen_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.gen_photo)
        label.image = self.gen_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text=f"Step {step}/{total_steps}")

# ----------------------------  Main ----------------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = MicroNCAApp(root)
    root.mainloop()