# EDM_GUI.py – Text-conditioned diffusion using the EDM design space
import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F_vision
import torch.nn.functional as F
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
import math
import csv
from typing import Optional, Tuple, List

# ==================== Helper ====================
def load_image_as_rgb(path):
    img = Image.open(path)
    if img.mode == 'RGBA':
        bg = Image.new('RGB', img.size, (0, 0, 0))
        bg.paste(img, mask=img.split()[3])
        return bg
    else:
        return img.convert('RGB')

def load_image_as_grayscale(path):
    return Image.open(path).convert('L')

def text_to_indices(text, max_len=128):
    """Convert text to list of char indices (ASCII based). Unknown chars -> 0."""
    indices = []
    for ch in text[:max_len]:
        idx = ord(ch) if ord(ch) < 256 else 0
        indices.append(idx)
    if len(indices) < max_len:
        indices += [0] * (max_len - len(indices))
    return indices

# ==================== Text Encoder ====================
class TextEncoder(nn.Module):
    def __init__(self, vocab_size=256, embed_dim=64, hidden_size=64, num_layers=2, cond_dim=256):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.gru = nn.GRU(embed_dim, hidden_size, num_layers,
                          batch_first=True, bidirectional=True, dropout=0.1 if num_layers>1 else 0)
        self.fc = nn.Linear(hidden_size * 2, cond_dim)

    def forward(self, x):
        emb = self.embedding(x)
        _, h = self.gru(emb)
        h_fwd = h[-2, :, :]
        h_bwd = h[-1, :, :]
        h_cat = torch.cat([h_fwd, h_bwd], dim=1)
        return self.fc(h_cat)

# ==================== EDM Components ====================
def edm_sigma_embedding(sigma, dim, scale=1000.0):
    """Fourier/sinusoidal embedding for continuous sigma (EDM style)."""
    # sigma -> c_noise = 0.25 * ln(sigma)
    c_noise = 0.25 * torch.log(sigma)
    # frequencies
    freqs = torch.exp(torch.linspace(math.log(1), math.log(scale), dim // 2, device=sigma.device))
    emb = c_noise[:, None] * freqs[None, :] * (2 * math.pi)
    return torch.cat([torch.sin(emb), torch.cos(emb)], dim=1)

class AttentionBlock(nn.Module):
    def __init__(self, dim, num_heads=4):
        super().__init__()
        self.norm = nn.GroupNorm(32, dim)
        self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True)

    def forward(self, x):
        B, C, H, W = x.shape
        residual = x
        x = self.norm(x)
        x = x.view(B, C, H * W).transpose(1, 2)
        x, _ = self.attn(x, x, x)
        x = x.transpose(1, 2).view(B, C, H, W)
        return x + residual

class DownBlock(nn.Module):
    def __init__(self, in_channels, out_channels, sigma_emb_dim, cond_dim, dropout=0.1, has_attn=False):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1)
        self.norm1 = nn.GroupNorm(32, out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1)
        self.norm2 = nn.GroupNorm(32, out_channels)
        self.sigma_mlp = nn.Sequential(
            nn.SiLU(),
            nn.Linear(sigma_emb_dim, out_channels)
        )
        self.cond_mlp = nn.Sequential(
            nn.SiLU(),
            nn.Linear(cond_dim, out_channels)
        )
        self.res_conv = nn.Conv2d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()
        self.dropout = nn.Dropout(dropout)
        self.attn = AttentionBlock(out_channels) if has_attn else nn.Identity()

    def forward(self, x, sigma_emb, cond):
        sigma_out = self.sigma_mlp(sigma_emb)[:, :, None, None]
        cond_out = self.cond_mlp(cond)[:, :, None, None]
        h = self.conv1(x)
        h = self.norm1(h)
        h = h + sigma_out + cond_out
        h = F.silu(h)
        h = self.dropout(h)
        h = self.conv2(h)
        h = self.norm2(h)
        h = F.silu(h)
        res = self.res_conv(x)
        h = h + res
        h = self.attn(h)
        return h

class UpBlock(nn.Module):
    def __init__(self, in_channels, out_channels, sigma_emb_dim, cond_dim, dropout=0.1, has_attn=False):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1)
        self.norm1 = nn.GroupNorm(32, out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1)
        self.norm2 = nn.GroupNorm(32, out_channels)
        self.sigma_mlp = nn.Sequential(
            nn.SiLU(),
            nn.Linear(sigma_emb_dim, out_channels)
        )
        self.cond_mlp = nn.Sequential(
            nn.SiLU(),
            nn.Linear(cond_dim, out_channels)
        )
        self.res_conv = nn.Conv2d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()
        self.dropout = nn.Dropout(dropout)
        self.attn = AttentionBlock(out_channels) if has_attn else nn.Identity()

    def forward(self, x, sigma_emb, cond):
        sigma_out = self.sigma_mlp(sigma_emb)[:, :, None, None]
        cond_out = self.cond_mlp(cond)[:, :, None, None]
        h = self.conv1(x)
        h = self.norm1(h)
        h = h + sigma_out + cond_out
        h = F.silu(h)
        h = self.dropout(h)
        h = self.conv2(h)
        h = self.norm2(h)
        h = F.silu(h)
        res = self.res_conv(x)
        h = h + res
        h = self.attn(h)
        return h

class EDM_UNet(nn.Module):
    """U-Net that predicts the residual for EDM (F_theta)."""
    def __init__(self, in_channels=3, base_channels=64, sigma_emb_dim=256, cond_dim=256,
                 channel_mult=(1, 2, 3, 4), dropout=0.1, attn_resolutions=(16,)):
        super().__init__()
        self.in_channels = in_channels
        self.base_channels = base_channels
        self.sigma_emb_dim = sigma_emb_dim
        self.cond_dim = cond_dim
        self.channel_mult = channel_mult
        self.attn_resolutions = attn_resolutions

        self.init_conv = nn.Conv2d(in_channels, base_channels, 3, padding=1)

        # downsampling
        self.downs = nn.ModuleList()
        cur_channels = base_channels
        for i, mult in enumerate(channel_mult):
            out_channels = base_channels * mult
            has_attn = (2 ** i) in attn_resolutions or (64 // (2 ** i)) in attn_resolutions
            block = DownBlock(cur_channels, out_channels, sigma_emb_dim, cond_dim, dropout, has_attn)
            self.downs.append(block)
            if i != len(channel_mult) - 1:
                self.downs.append(nn.Conv2d(out_channels, out_channels, 4, stride=2, padding=1))
            cur_channels = out_channels

        # middle
        self.mid_block1 = DownBlock(cur_channels, cur_channels, sigma_emb_dim, cond_dim, dropout, True)
        self.mid_block2 = UpBlock(cur_channels, cur_channels, sigma_emb_dim, cond_dim, dropout, True)

        # upsampling
        self.ups = nn.ModuleList()
        for i, mult in reversed(list(enumerate(channel_mult))):
            out_channels = base_channels * mult
            has_attn = (2 ** i) in attn_resolutions or (64 // (2 ** i)) in attn_resolutions
            block = UpBlock(cur_channels + out_channels, out_channels, sigma_emb_dim, cond_dim, dropout, has_attn)
            self.ups.append(block)
            if i != 0:
                self.ups.append(nn.ConvTranspose2d(out_channels, out_channels, 4, stride=2, padding=1))
            cur_channels = out_channels

        self.final_conv = nn.Sequential(
            nn.GroupNorm(32, cur_channels),
            nn.SiLU(),
            nn.Conv2d(cur_channels, in_channels, 3, padding=1)
        )

    def forward(self, x, sigma, text_cond):
        sigma_emb = edm_sigma_embedding(sigma, self.sigma_emb_dim)
        x = self.init_conv(x)

        skips = []
        for layer in self.downs:
            if isinstance(layer, DownBlock):
                x = layer(x, sigma_emb, text_cond)
                skips.append(x)
            else:
                x = layer(x)

        x = self.mid_block1(x, sigma_emb, text_cond)
        x = self.mid_block2(x, sigma_emb, text_cond)

        for layer in self.ups:
            if isinstance(layer, UpBlock):
                skip = skips.pop()
                # Fix size mismatches (e.g. 28x28 -> 7x7 -> 6x6 after upsampling)
                if x.shape[2:] != skip.shape[2:]:
                    x = F.interpolate(x, size=skip.shape[2:], mode='nearest')
                x = torch.cat([x, skip], dim=1)
                x = layer(x, sigma_emb, text_cond)
            else:
                x = layer(x)

        return self.final_conv(x)

class EDMDenoiser(nn.Module):
    """Preconditioned denoiser D(x, sigma) = c_skip*x + c_out*F(c_in*x, sigma, cond)."""
    def __init__(self, net: EDM_UNet, sigma_data=0.5):
        super().__init__()
        self.net = net
        self.sigma_data = sigma_data

    def forward(self, x, sigma, text_cond):
        sigma = sigma.view(-1, 1, 1, 1)
        sigma_data = self.sigma_data
        c_skip = sigma_data ** 2 / (sigma ** 2 + sigma_data ** 2)
        c_out = sigma * sigma_data / (sigma ** 2 + sigma_data ** 2).sqrt()
        c_in = 1 / (sigma ** 2 + sigma_data ** 2).sqrt()
        x_in = c_in * x
        out = self.net(x_in, sigma.flatten(), text_cond)
        return c_skip * x + c_out * out

# ==================== Dataset ====================
class TextConditionedImageDataset(Dataset):
    def __init__(self, image_paths, labels, img_size=32, color_mode='rgb',
                 aug_settings=None, text_max_len=128):
        self.image_paths = image_paths
        self.labels = labels
        self.img_size = img_size
        self.color_mode = color_mode.lower()
        self.aug_settings = aug_settings or {}
        self.text_max_len = text_max_len
        if self.color_mode == 'rgb':
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.5,))
            ])

    def __len__(self):
        return len(self.image_paths)

    def apply_augmentations(self, pil_img):
        img = pil_img.copy()
        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F_vision.hflip(img)
        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F_vision.rotate(img, angle, interpolation=Image.BICUBIC)
        return img

    def __getitem__(self, idx):
        try:
            if self.color_mode == 'rgb':
                pil_img = load_image_as_rgb(self.image_paths[idx])
            else:
                pil_img = load_image_as_grayscale(self.image_paths[idx])
            pil_img = self.apply_augmentations(pil_img)
            img_tensor = self.transform(pil_img)

            text = self.labels[idx].replace('_', ' ')
            text_indices = text_to_indices(text, self.text_max_len)
            text_tensor = torch.tensor(text_indices, dtype=torch.long)

            return img_tensor, text_tensor
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            if self.color_mode == 'rgb':
                img_tensor = torch.zeros(3, self.img_size, self.img_size)
            else:
                img_tensor = torch.zeros(1, self.img_size, self.img_size)
            text_tensor = torch.zeros(self.text_max_len, dtype=torch.long)
            return img_tensor, text_tensor

# ==================== EDM Training & Sampling ====================
class EDM:
    def __init__(self, denoiser: EDMDenoiser, text_encoder: TextEncoder,
                 p_mean=-1.2, p_std=1.2, sigma_max=80.0, sigma_min=0.002, rho=7,
                 device='cpu'):
        self.denoiser = denoiser.to(device)
        self.text_encoder = text_encoder.to(device)
        self.device = device
        self.p_mean = p_mean
        self.p_std = p_std
        self.sigma_max = sigma_max
        self.sigma_min = sigma_min
        self.rho = rho

    def training_loss(self, x0, text_indices, cond_enabled, cfg_dropout_prob=0.0):
        B = x0.size(0)
        # sample sigma
        sigma = torch.randn(B, device=self.device) * self.p_std + self.p_mean
        sigma = torch.exp(sigma)
        # sample noise
        noise = torch.randn_like(x0)
        x_noisy = x0 + sigma.view(B,1,1,1) * noise

        # text condition
        if cond_enabled:
            cond = self.text_encoder(text_indices)
            if cfg_dropout_prob > 0:
                mask = (torch.rand(B, 1, device=self.device) > cfg_dropout_prob).float()
                cond = cond * mask
        else:
            cond = torch.zeros(B, self.text_encoder.fc.out_features, device=self.device)

        # preconditioning
        sigma_data = self.denoiser.sigma_data
        sigma_flat = sigma.view(B)
        c_skip = sigma_data ** 2 / (sigma_flat ** 2 + sigma_data ** 2)
        c_out = sigma_flat * sigma_data / (sigma_flat ** 2 + sigma_data ** 2).sqrt()
        c_in = 1 / (sigma_flat ** 2 + sigma_data ** 2).sqrt()

        # target for inner network
        target = (x0 - c_skip.view(B,1,1,1) * x_noisy) / c_out.view(B,1,1,1)

        # network input
        net_in = c_in.view(B,1,1,1) * x_noisy
        net_out = self.denoiser.net(net_in, sigma_flat, cond)

        loss = F.mse_loss(net_out, target)
        return loss

    @torch.no_grad()
    def sample(self, n_samples, img_shape, text_condition, cond_enabled, n_steps=35,
               solver='heun', cfg_scale=1.0, progress_callback=None):
        """EDM deterministic sampling (Euler / Heun / Midpoint)."""
        if cond_enabled:
            cond = self.text_encoder(text_condition)
            null_cond = torch.zeros_like(cond)
        else:
            cond = torch.zeros(n_samples, self.text_encoder.fc.out_features, device=self.device)
            null_cond = cond

        # time discretization (polynomial sigma schedule)
        rho = self.rho
        sigma_max = self.sigma_max
        sigma_min = self.sigma_min
        inv_rho = 1 / rho
        steps = torch.arange(n_steps, device=self.device)
        sigma = (sigma_max ** inv_rho + steps / (n_steps - 1) * (sigma_min ** inv_rho - sigma_max ** inv_rho)) ** rho
        sigma = torch.cat([sigma, torch.zeros(1, device=self.device)])  # sigma_N = 0

        x = sigma_max * torch.randn(n_samples, *img_shape, device=self.device)

        def denoiser_fn(x, s):
            """CFG applied denoiser."""
            s_tensor = s.expand(x.shape[0])
            if cond_enabled and cfg_scale != 1.0:
                d_cond = self.denoiser(x, s_tensor, cond)
                d_uncond = self.denoiser(x, s_tensor, null_cond)
                return d_uncond + cfg_scale * (d_cond - d_uncond)
            else:
                return self.denoiser(x, s_tensor, cond)

        # ODE integration
        for i in range(n_steps):
            t_i = sigma[i]
            t_next = sigma[i + 1]
            d_i = (x - denoiser_fn(x, t_i)) / t_i

            if solver == 'euler':
                x = x + (t_next - t_i) * d_i
            elif solver == 'heun':
                x_euler = x + (t_next - t_i) * d_i
                if t_next > 0:
                    d_i_prime = (x_euler - denoiser_fn(x_euler, t_next)) / t_next
                    x = x + (t_next - t_i) * (0.5 * d_i + 0.5 * d_i_prime)
                else:
                    x = x_euler  # last step fallback
            elif solver == 'midpoint':
                # explicit midpoint: evaluate at half step
                t_mid = 0.5 * (t_i + t_next)
                x_mid = x + (t_mid - t_i) * d_i
                d_mid = (x_mid - denoiser_fn(x_mid, t_mid)) / t_mid
                x = x + (t_next - t_i) * d_mid
            else:
                raise ValueError(f"Unknown solver: {solver}")

            if progress_callback is not None:
                # x0 estimate = denoiser output
                with torch.no_grad():
                    x0_est = denoiser_fn(x, t_i)  # D(x, t_i) is clean estimate
                progress_callback(i+1, x, x0_est)

        return x

# ==================== GUI Application ====================
class TextConditionedDiffusionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Text-to-Image Diffusion (EDM) with Euler/Heun/Midpoint")
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        win_width = max(1000, int(screen_width * 0.8))
        win_height = max(700, int(screen_height * 0.8))
        self.root.geometry(f"{win_width}x{win_height}")
        self.root.minsize(900, 650)
        try:
            import ctypes
            awareness = ctypes.c_int()
            ctypes.windll.shcore.GetProcessDpiAwareness(0, ctypes.byref(awareness))
            if awareness.value == 0:
                ctypes.windll.shcore.SetProcessDpiAwareness(1)
            dpi = ctypes.windll.user32.GetDpiForWindow(root.winfo_id())
            scale = dpi / 72.0
            self.root.tk.call('tk', 'scaling', scale)
        except Exception:
            pass

        self.image_paths = []
        self.labels = []
        self.csv_path = None
        self.training = False
        self.model = None          # EDM_UNet
        self.text_encoder = None
        self.edm = None
        self.optimizer = None
        self.ema_model = None
        self.ema_enabled = False
        self.ema_decay = 0.9999
        self.current_epoch = 0
        self.message_queue = queue.Queue()

        # Hyperparameters
        self.settings = {
            'img_size': tk.IntVar(value=32),
            'color_mode': tk.StringVar(value='rgb'),
            'base_channels': tk.IntVar(value=64),
            'batch_size': tk.IntVar(value=16),
            'lr': tk.DoubleVar(value=2e-4),
            'num_workers': tk.IntVar(value=0),
            'sampling_steps': tk.IntVar(value=35),
            'use_self_attn': tk.BooleanVar(value=True),
            'use_ema': tk.BooleanVar(value=False),
            'ema_decay': tk.StringVar(value='0.9999'),
            'preview_enabled': tk.BooleanVar(value=True),
            'preview_epochs': tk.IntVar(value=5),
            'text_max_len': tk.IntVar(value=128),
            'text_embed_dim': tk.IntVar(value=64),
            'text_hidden_size': tk.IntVar(value=64),
            'text_num_layers': tk.IntVar(value=2),
            'cond_dim': tk.IntVar(value=256),
            'cfg_dropout_prob': tk.DoubleVar(value=0.1),
            'cfg_scale': tk.DoubleVar(value=2.0),
            'cond_enabled': tk.BooleanVar(value=True),
            # EDM specific
            'sigma_data': tk.DoubleVar(value=0.5),
            'p_mean': tk.DoubleVar(value=-1.2),
            'p_std': tk.DoubleVar(value=1.2),
            'sigma_max': tk.DoubleVar(value=80.0),
            'sigma_min': tk.DoubleVar(value=0.002),
            'rho': tk.DoubleVar(value=7.0),
            'solver': tk.StringVar(value='heun'),
        }

        self.aug_settings = {
            'flip_horizontal': tk.BooleanVar(value=True),
            'rotation': tk.BooleanVar(value=False),
        }

        self.thumbnail_size = 128
        self.setup_gui()
        self.root.after(100, self.process_messages)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.train_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.train_tab, text='Training')
        self.setup_train_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.gen_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.gen_tab, text='Generation')
        self.setup_gen_tab()

        self.status_label = tk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    # ------------------------------------------------------------------
    # Training Tab
    # ------------------------------------------------------------------
    def setup_train_tab(self):
        main_frame = tk.Frame(self.train_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="EDM Text-to-Image", font=("Arial",12,"bold")).pack(pady=(0,10))

        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=5, pady=5)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=2)
        tk.Button(img_frame, text="Add Folder", command=self.add_folder, width=20).pack(pady=2)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=2)
        self.image_listbox = tk.Listbox(img_frame, height=5)
        self.image_listbox.pack(fill=tk.X, pady=2)

        cond_frame = tk.LabelFrame(left_frame, text="Conditional (text)", padx=5, pady=5)
        cond_frame.pack(fill=tk.X, pady=5)
        self.cond_enabled_cb = tk.Checkbutton(cond_frame, text="Enable text conditioning",
                                              variable=self.settings['cond_enabled'])
        self.cond_enabled_cb.pack(anchor='w')
        tk.Button(cond_frame, text="Load CSV (imagename,label)", command=self.load_csv, width=20).pack(pady=2)
        tk.Button(cond_frame, text="Use Filenames as Labels", command=self.use_filenames_as_labels, width=20).pack(pady=2)
        self.csv_status = tk.Label(cond_frame, text="No CSV loaded", fg="red")
        self.csv_status.pack()

        tk.Button(left_frame, text="Initialize Model", command=self.init_model, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start Training", command=self.start_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop Training", command=self.stop_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load Model", command=self.load_model, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_canvas_frame = tk.LabelFrame(right_frame, text="Generated Samples (decoded)", padx=5, pady=5)
        preview_canvas_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.train_preview_canvas = tk.Canvas(preview_canvas_frame, bg='gray', width=256, height=256)
        self.train_preview_canvas.pack()

        prompt_frame = tk.LabelFrame(right_frame, text="Test prompt (empty = unconditional)", padx=5, pady=5)
        prompt_frame.pack(fill=tk.X, pady=(0,5))
        self.train_test_prompt = tk.Entry(prompt_frame)
        self.train_test_prompt.insert(0, "a cute cat")
        self.train_test_prompt.pack(fill=tk.X, pady=2)
        tk.Button(prompt_frame, text="Preview Now", command=self.show_train_preview, width=20).pack(pady=2)

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

    # ------------------------------------------------------------------
    # Settings Tab
    # ------------------------------------------------------------------
    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Image
        img_frame = tk.LabelFrame(scrollable_frame, text="Image", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(img_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Color mode:", width=20, anchor='w').pack(side=tk.LEFT)
        om = ttk.Combobox(f, textvariable=self.settings['color_mode'], values=['rgb', 'grayscale'], state='readonly', width=10)
        om.pack(side=tk.RIGHT)
        f = tk.Frame(img_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Image size:", width=20, anchor='w').pack(side=tk.LEFT)
        spin = ttk.Spinbox(f, from_=16, to=128, textvariable=self.settings['img_size'], width=8)
        spin.pack(side=tk.RIGHT)

        # Model architecture
        model_frame = tk.LabelFrame(scrollable_frame, text="U-Net & Text Encoder", padx=10, pady=10)
        model_frame.pack(fill=tk.X, pady=5)
        params = [
            ("Base channels:", 'base_channels', 16, 256, int),
            ("Conditioning dim:", 'cond_dim', 64, 512, int),
            ("Text embed dim:", 'text_embed_dim', 32, 128, int),
            ("Text hidden size:", 'text_hidden_size', 32, 256, int),
            ("Text layers:", 'text_num_layers', 1, 4, int),
        ]
        for label, key, low, high, typ in params:
            f = tk.Frame(model_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            if typ == int:
                spin = ttk.Spinbox(f, from_=low, to=high, textvariable=self.settings[key], width=8)
            else:
                spin = ttk.Entry(f, textvariable=self.settings[key], width=8)
            spin.pack(side=tk.RIGHT)

        attn_frame = tk.LabelFrame(scrollable_frame, text="Self-Attention", padx=10, pady=10)
        attn_frame.pack(fill=tk.X, pady=5)
        cb = tk.Checkbutton(attn_frame, text="Enable Self-Attention", variable=self.settings['use_self_attn'])
        cb.pack(anchor='w')

        # EDM specific
        edm_frame = tk.LabelFrame(scrollable_frame, text="EDM Settings", padx=10, pady=10)
        edm_frame.pack(fill=tk.X, pady=5)
        for label, key, low, high in [
            ("Sigma data:", 'sigma_data', 0.1, 2.0),
            ("P_mean:", 'p_mean', -3.0, 0.0),
            ("P_std:", 'p_std', 0.5, 2.0),
            ("Sigma max:", 'sigma_max', 10.0, 100.0),
            ("Sigma min:", 'sigma_min', 0.0001, 0.1),
            ("Rho:", 'rho', 1.0, 10.0),
        ]:
            f = tk.Frame(edm_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            ttk.Entry(f, textvariable=self.settings[key], width=8).pack(side=tk.RIGHT)

        # Training details
        train_frame = tk.LabelFrame(scrollable_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=5)
        for label, key in [("Batch size:", 'batch_size'), ("Workers:", 'num_workers'), ("LR:", 'lr')]:
            f = tk.Frame(train_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            ttk.Entry(f, textvariable=self.settings[key], width=8).pack(side=tk.RIGHT)

        # EMA
        ema_frame = tk.LabelFrame(scrollable_frame, text="EMA", padx=10, pady=10)
        ema_frame.pack(fill=tk.X, pady=5)
        cb = tk.Checkbutton(ema_frame, text="Enable EMA", variable=self.settings['use_ema'],
                            command=self.toggle_ema_settings)
        cb.pack(anchor='w')
        f = tk.Frame(ema_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="EMA decay:", width=20, anchor='w').pack(side=tk.LEFT)
        ttk.Entry(f, textvariable=self.settings['ema_decay'], width=8).pack(side=tk.RIGHT)

        # CFG
        cfg_frame = tk.LabelFrame(scrollable_frame, text="Classifier-Free Guidance", padx=10, pady=10)
        cfg_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(cfg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="CFG dropout prob:", width=20, anchor='w').pack(side=tk.LEFT)
        ttk.Entry(f, textvariable=self.settings['cfg_dropout_prob'], width=8).pack(side=tk.RIGHT)
        f = tk.Frame(cfg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="CFG scale (sampling):", width=20, anchor='w').pack(side=tk.LEFT)
        ttk.Entry(f, textvariable=self.settings['cfg_scale'], width=8).pack(side=tk.RIGHT)

        # Augmentations
        aug_frame = tk.LabelFrame(scrollable_frame, text="Augmentations", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)
        for label, key in [("Horizontal Flip", 'flip_horizontal'), ("Rotation (±30°)", 'rotation')]:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def toggle_ema_settings(self):
        pass

    # ------------------------------------------------------------------
    # Generation Tab (Euler / Heun / Midpoint)
    # ------------------------------------------------------------------
    def setup_gen_tab(self):
        main_frame = tk.Frame(self.gen_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        prompt_frame = tk.LabelFrame(main_frame, text="Text Prompt (empty = unconditional)", padx=5, pady=5)
        prompt_frame.pack(fill=tk.X, pady=(0,10))
        self.gen_prompt = tk.Entry(prompt_frame, width=60)
        self.gen_prompt.insert(0, "a cute cat")
        self.gen_prompt.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)

        ctrl_frame = tk.Frame(main_frame)
        ctrl_frame.pack(pady=5)

        tk.Label(ctrl_frame, text="Number:").pack(side=tk.LEFT)
        self.gen_count = tk.IntVar(value=16)
        tk.Spinbox(ctrl_frame, from_=1, to=64, textvariable=self.gen_count, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="Steps:").pack(side=tk.LEFT, padx=(10,0))
        self.gen_steps = tk.IntVar(value=self.settings['sampling_steps'].get())
        tk.Spinbox(ctrl_frame, from_=10, to=500, textvariable=self.gen_steps, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="Solver:").pack(side=tk.LEFT, padx=(10,0))
        solver_combo = ttk.Combobox(ctrl_frame, textvariable=self.settings['solver'],
                                    values=['euler', 'heun', 'midpoint'], state='readonly', width=8)
        solver_combo.pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="CFG scale:").pack(side=tk.LEFT, padx=(10,0))
        self.cfg_scale_var = tk.DoubleVar(value=self.settings['cfg_scale'].get())
        tk.Spinbox(ctrl_frame, from_=1.0, to=10.0, increment=0.5,
                   textvariable=self.cfg_scale_var, width=5).pack(side=tk.LEFT, padx=5)

        self.real_time_preview = tk.BooleanVar(value=False)
        tk.Checkbutton(ctrl_frame, text="Real-time preview (x0 est)", variable=self.real_time_preview).pack(side=tk.LEFT, padx=10)

        tk.Label(ctrl_frame, text="Update interval:").pack(side=tk.LEFT)
        self.preview_interval = tk.IntVar(value=5)
        tk.Spinbox(ctrl_frame, from_=1, to=20, textvariable=self.preview_interval, width=3).pack(side=tk.LEFT, padx=5)

        self.generate_btn = tk.Button(ctrl_frame, text="Generate", command=self.generate_samples, bg="lightgreen")
        self.generate_btn.pack(side=tk.LEFT, padx=5)
        self.stop_gen_btn = tk.Button(ctrl_frame, text="Stop", command=self.stop_generation,
                                      state=tk.DISABLED, bg="salmon")
        self.stop_gen_btn.pack(side=tk.LEFT, padx=5)

        scroll_frame = tk.LabelFrame(main_frame, text="Results", padx=5, pady=5)
        scroll_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        canvas_frame = tk.Frame(scroll_frame)
        canvas_frame.pack(fill=tk.BOTH, expand=True)

        self.gen_canvas = tk.Canvas(canvas_frame, bg='lightgray')
        self.v_scroll = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.gen_canvas.yview)
        self.h_scroll = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.gen_canvas.xview)
        self.gen_canvas.configure(yscrollcommand=self.v_scroll.set, xscrollcommand=self.h_scroll.set)
        self.v_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.h_scroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.inner_frame = tk.Frame(self.gen_canvas)
        self.canvas_window = self.gen_canvas.create_window((0,0), window=self.inner_frame, anchor='nw')
        self.inner_frame.bind('<Configure>', lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all')))

        self.gen_info = tk.Label(main_frame, text="", fg="blue")
        self.gen_info.pack()

        self.generation_active = False

    # ------------------------------------------------------------------
    # Helper methods
    # ------------------------------------------------------------------
    def log(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    def add_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp *.ico *.tiff")])
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log(f"Added {len(files)} images. Total: {len(self.image_paths)}")
        if not self.labels or len(self.labels) != len(self.image_paths):
            self.use_filenames_as_labels()

    def add_folder(self):
        folder = filedialog.askdirectory()
        if not folder: return
        count = 0
        for root_dir, _, files in os.walk(folder):
            for file in files:
                if file.lower().endswith(('.png','.jpg','.jpeg','.jfif','.webp','.bmp', '.ico', '.tiff')):
                    full = os.path.join(root_dir, file)
                    if full not in self.image_paths:
                        self.image_paths.append(full)
                        self.image_listbox.insert(tk.END, os.path.basename(full))
                        count += 1
        self.log(f"Added {count} images. Total: {len(self.image_paths)}")
        if not self.labels or len(self.labels) != len(self.image_paths):
            self.use_filenames_as_labels()

    def clear_images(self):
        self.image_paths.clear()
        self.labels.clear()
        self.image_listbox.delete(0, tk.END)
        self.csv_status.config(text="No CSV loaded", fg="red")
        self.log("Cleared all images")

    def load_csv(self):
        fname = filedialog.askopenfilename(filetypes=[("CSV", "*.csv")])
        if not fname: return
        self.csv_path = fname
        image_to_label = {}
        try:
            with open(fname, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) >= 2:
                        image_to_label[row[0]] = row[1]
        except Exception as e:
            self.log(f"Error reading CSV: {e}")
            return
        self.labels = []
        matched = 0
        for path in self.image_paths:
            base = os.path.basename(path)
            if base in image_to_label:
                self.labels.append(image_to_label[base])
                matched += 1
            else:
                self.labels.append(os.path.splitext(base)[0])
        self.csv_status.config(text=f"CSV loaded: {matched} matched, others use filenames", fg="green")
        self.log(f"CSV loaded. {matched} images matched with labels.")

    def use_filenames_as_labels(self):
        self.labels = [os.path.splitext(os.path.basename(p))[0] for p in self.image_paths]
        self.csv_status.config(text="Using filenames as labels", fg="blue")
        self.log("Using filenames as labels (underscores replaced with spaces)")

    def init_model(self):
        try:
            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            base_channels = self.settings['base_channels'].get()
            img_size = self.settings['img_size'].get()
            use_attn = self.settings['use_self_attn'].get()
            if use_attn:
                attn_res = set()
                for res in [32, 16, 8]:
                    if res <= img_size and res >= 8:
                        attn_res.add(res)
            else:
                attn_res = set()

            cond_dim = self.settings['cond_dim'].get()

            unet = EDM_UNet(
                in_channels=in_channels,
                base_channels=base_channels,
                sigma_emb_dim=base_channels * 4,
                cond_dim=cond_dim,
                channel_mult=(1, 2, 3, 4),
                dropout=0.1,
                attn_resolutions=attn_res
            )
            self.model = unet

            self.text_encoder = TextEncoder(
                vocab_size=256,
                embed_dim=self.settings['text_embed_dim'].get(),
                hidden_size=self.settings['text_hidden_size'].get(),
                num_layers=self.settings['text_num_layers'].get(),
                cond_dim=cond_dim
            )

            denoiser = EDMDenoiser(unet, sigma_data=self.settings['sigma_data'].get())
            self.edm = EDM(
                denoiser=denoiser,
                text_encoder=self.text_encoder,
                p_mean=self.settings['p_mean'].get(),
                p_std=self.settings['p_std'].get(),
                sigma_max=self.settings['sigma_max'].get(),
                sigma_min=self.settings['sigma_min'].get(),
                rho=self.settings['rho'].get(),
                device='cpu'
            )

            self.optimizer = optim.Adam(
                list(self.model.parameters()) + list(self.text_encoder.parameters()),
                lr=self.settings['lr'].get()
            )

            if self.settings['use_ema'].get():
                try:
                    self.ema_decay = float(self.settings['ema_decay'].get())
                except:
                    self.ema_decay = 0.9999
                self.ema_model = EDM_UNet(
                    in_channels=in_channels,
                    base_channels=base_channels,
                    sigma_emb_dim=base_channels * 4,
                    cond_dim=cond_dim,
                    channel_mult=(1, 2, 3, 4),
                    dropout=0.1,
                    attn_resolutions=attn_res
                )
                self.ema_model.load_state_dict(self.model.state_dict())
            else:
                self.ema_model = None

            self.log("EDM model initialized.")
        except Exception as e:
            self.log(f"Error: {e}")

    def _update_ema(self):
        if self.ema_model is None: return
        for ema_param, param in zip(self.ema_model.parameters(), self.model.parameters()):
            ema_param.data.mul_(self.ema_decay).add_(param.data, alpha=1 - self.ema_decay)

    def start_training(self):
        if not self.image_paths:
            self.log("No images!")
            return
        if self.settings['cond_enabled'].get() and not self.labels:
            self.log("Conditional training requires labels! Load CSV or use filenames.")
            return
        if not self.model or not self.text_encoder:
            self.log("Model not initialized!")
            return
        if self.training:
            self.log("Already training.")
            return
        try:
            epochs = int(self.epoch_var.get())
        except:
            self.log("Invalid epochs")
            return
        self.training = True
        self.current_epoch = 0
        self.start_time = time.time()
        thread = threading.Thread(target=self.train_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log(f"Training started for {epochs} epochs.")

    def train_loop(self, epochs):
        try:
            batch_size = self.settings['batch_size'].get()
            num_workers = self.settings['num_workers'].get()
            img_size = self.settings['img_size'].get()
            color_mode = self.settings['color_mode'].get()
            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}
            text_max_len = self.settings['text_max_len'].get()
            cond_enabled = self.settings['cond_enabled'].get()
            dataset = TextConditionedImageDataset(self.image_paths, self.labels, img_size, color_mode, aug_dict, text_max_len)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=False)

            preview_enabled = self.settings['preview_enabled'].get()
            preview_epochs = self.settings['preview_epochs'].get()
            if not preview_enabled:
                preview_epochs = epochs + 1

            cfg_dropout = self.settings['cfg_dropout_prob'].get()

            for epoch in range(epochs):
                if not self.training:
                    break
                self.current_epoch = epoch
                epoch_loss = 0.0
                batches = 0
                for images, text_tensors in loader:
                    if not self.training:
                        break
                    loss = self.edm.training_loss(images, text_tensors, cond_enabled, cfg_dropout_prob=cfg_dropout)
                    self.optimizer.zero_grad()
                    loss.backward()
                    self.optimizer.step()
                    if self.ema_model is not None:
                        self._update_ema()
                    epoch_loss += loss.item()
                    batches += 1
                avg_loss = epoch_loss / batches if batches else 0
                elapsed = time.time() - self.start_time
                self.log(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s")
                if (epoch+1) % preview_epochs == 0:
                    self.show_train_preview()
            self.training = False
            self.log("Training finished.")
        except Exception as e:
            self.log(f"Training error: {e}")
            import traceback; traceback.print_exc()
            self.training = False

    def show_train_preview(self):
        if not self.model or not self.text_encoder:
            self.log("Model not loaded for preview")
            return
        try:
            prompt = self.train_test_prompt.get().strip()
            cond_enabled = self.settings['cond_enabled'].get()
            n_samples = 16
            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            img_size = self.settings['img_size'].get()
            img_shape = (in_channels, img_size, img_size)
            text_max_len = self.settings['text_max_len'].get()

            if cond_enabled and prompt:
                indices = [text_to_indices(prompt, text_max_len) for _ in range(n_samples)]
                text_tensor = torch.tensor(indices, dtype=torch.long, device='cpu')
                cfg_scale = self.settings['cfg_scale'].get()
            else:
                text_tensor = torch.zeros((n_samples, text_max_len), dtype=torch.long, device='cpu')
                cfg_scale = 1.0
                prompt = "unconditional"

            # Use EMA model for preview if available
            if self.ema_model is not None:
                original_unet = self.edm.denoiser.net
                self.edm.denoiser.net = self.ema_model

            solver = self.settings['solver'].get()
            n_steps = min(35, self.settings['sampling_steps'].get())
            with torch.no_grad():
                samples = self.edm.sample(
                    n_samples, img_shape, text_tensor, cond_enabled,
                    n_steps=n_steps, solver=solver, cfg_scale=cfg_scale
                )

            if self.ema_model is not None:
                self.edm.denoiser.net = original_unet

            samples = (samples + 1) / 2
            samples = samples.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size
            grid = Image.new('RGB', (4*thumb, 4*thumb))
            for i in range(4):
                for j in range(4):
                    idx = i*4 + j
                    if idx < len(samples):
                        if samples[idx].shape[0] == 1:
                            img = np.stack([samples[idx][0]]*3, axis=-1)
                        else:
                            img = samples[idx].transpose(1,2,0)
                        img = (img * 255).astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img, (j*thumb, i*thumb))
            grid = grid.resize((256,256), Image.NEAREST)
            self.train_preview_photo = ImageTk.PhotoImage(grid)
            self.train_preview_canvas.delete("all")
            self.train_preview_canvas.create_image(128,128, image=self.train_preview_photo)
            self.log(f"Preview ({solver}, steps={n_steps})")
        except Exception as e:
            self.log(f"Preview error: {e}")

    def stop_training(self):
        self.training = False
        self.log("Training stopped.")

    def save_model(self):
        if not self.model or not self.text_encoder:
            self.log("No model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth", filetypes=[("PyTorch","*.pth")])
        if fname:
            save_dict = {
                'model_state': self.model.state_dict(),
                'text_encoder_state': self.text_encoder.state_dict(),
                'optimizer_state': self.optimizer.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items()},
            }
            if self.ema_model is not None:
                save_dict['ema_model_state'] = self.ema_model.state_dict()
            torch.save(save_dict, fname)
            self.log(f"Model saved to {fname}")

    def load_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            if 'settings' in ckpt:
                for k,v in ckpt['settings'].items():
                    if k in self.settings:
                        self.settings[k].set(v)
            self.init_model()
            self.model.load_state_dict(ckpt['model_state'])
            self.text_encoder.load_state_dict(ckpt['text_encoder_state'])
            self.optimizer.load_state_dict(ckpt['optimizer_state'])
            if 'ema_model_state' in ckpt and self.ema_model is not None:
                self.ema_model.load_state_dict(ckpt['ema_model_state'])
            self.log(f"Model loaded from {fname}")
        except Exception as e:
            self.log(f"Load error: {e}")

    # ========== Generation with preview ==========
    def generate_samples(self):
        if not self.model or not self.text_encoder:
            self.gen_info.config(text="Model not loaded!")
            return
        n = self.gen_count.get()
        solver = self.settings['solver'].get()
        prompt = self.gen_prompt.get().strip()
        cond_enabled = self.settings['cond_enabled'].get()
        self.generation_active = True
        self.generate_btn.config(state=tk.DISABLED)
        self.stop_gen_btn.config(state=tk.NORMAL)
        self.gen_info.config(text=f"Generating with {solver}...")
        self.root.update()
        thread = threading.Thread(target=self._generate_thread, args=(n, solver, prompt, cond_enabled), daemon=True)
        thread.start()

    def stop_generation(self):
        self.generation_active = False
        self.stop_gen_btn.config(state=tk.DISABLED)
        self.gen_info.config(text="Generation stopped.")

    def _generate_thread(self, n, solver, prompt, cond_enabled):
        try:
            # temporarily swap in EMA model
            if self.ema_model is not None:
                original_unet = self.edm.denoiser.net
                self.edm.denoiser.net = self.ema_model

            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            img_size = self.settings['img_size'].get()
            img_shape = (in_channels, img_size, img_size)
            n_steps = self.gen_steps.get()
            cfg_scale = self.cfg_scale_var.get()
            text_max_len = self.settings['text_max_len'].get()
            realtime = self.real_time_preview.get()
            interval = self.preview_interval.get()

            if cond_enabled and prompt:
                indices = [text_to_indices(prompt, text_max_len) for _ in range(n)]
                text_tensor = torch.tensor(indices, dtype=torch.long, device='cpu')
                effective_cond = True
            else:
                text_tensor = torch.zeros((n, text_max_len), dtype=torch.long, device='cpu')
                cfg_scale = 1.0
                effective_cond = False

            if realtime:
                def progress_callback(step, x_t, x0_est):
                    if not self.generation_active:
                        raise StopIteration
                    if step % interval == 0 or step == n_steps:
                        samples = (x0_est + 1) / 2
                        samples = samples.clamp(0,1).cpu().numpy()
                        self.root.after(0, lambda s=samples.copy(): self._update_gen_preview(s, step, n_steps))
            else:
                progress_callback = None

            with torch.no_grad():
                final = self.edm.sample(
                    n, img_shape, text_tensor, effective_cond,
                    n_steps=n_steps, solver=solver, cfg_scale=cfg_scale,
                    progress_callback=progress_callback
                )

            if self.generation_active:
                final_samples = (final + 1) / 2
                final_samples = final_samples.clamp(0,1).cpu().numpy()
                self.root.after(0, lambda s=final_samples: self._display_final(s, n))
        except StopIteration:
            pass
        except Exception as e:
            self.root.after(0, lambda: self.gen_info.config(text=f"Error: {e}"))
            import traceback; traceback.print_exc()
        finally:
            if self.ema_model is not None:
                self.edm.denoiser.net = original_unet
            self.generation_active = False
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_gen_btn.config(state=tk.DISABLED))

    def _update_gen_preview(self, samples, step, total_steps):
        n = len(samples)
        thumb = self.thumbnail_size
        grid_size = int(math.ceil(math.sqrt(n)))
        total = grid_size * thumb
        grid_img = Image.new('RGB', (total, total), color=(128,128,128))
        for i in range(n):
            row = i // grid_size
            col = i % grid_size
            if i < len(samples):
                if samples[i].shape[0] == 1:
                    img = np.stack([samples[i][0]]*3, axis=-1)
                else:
                    img = samples[i].transpose(1,2,0)
                img = (img * 255).astype(np.uint8)
                pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                grid_img.paste(pil_img, (col*thumb, row*thumb))
        for w in self.inner_frame.winfo_children():
            w.destroy()
        self.prog_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.prog_photo)
        label.image = self.prog_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text=f"Step {step}/{total_steps}")

    def _display_final(self, samples, n):
        thumb = self.thumbnail_size
        grid_size = int(math.ceil(math.sqrt(n)))
        total = grid_size * thumb
        grid_img = Image.new('RGB', (total, total), color=(128,128,128))
        for i in range(n):
            row = i // grid_size
            col = i % grid_size
            if i < len(samples):
                if samples[i].shape[0] == 1:
                    img = np.stack([samples[i][0]]*3, axis=-1)
                else:
                    img = samples[i].transpose(1,2,0)
                img = (img * 255).astype(np.uint8)
                pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                grid_img.paste(pil_img, (col*thumb, row*thumb))
        for w in self.inner_frame.winfo_children():
            w.destroy()
        self.gen_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.gen_photo)
        label.image = self.gen_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text="Generation complete.")

# ==================== Main ====================
if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = TextConditionedDiffusionApp(root)
    root.mainloop()