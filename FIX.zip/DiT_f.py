import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F_vision
import torch.nn.functional as F_nn
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
import math
from typing import Optional, Tuple, List

# ==================== Helpers ====================

def load_image_as_rgb(path):
    img = Image.open(path)
    if img.mode == 'RGBA':
        bg = Image.new('RGB', img.size, (0, 0, 0))
        bg.paste(img, mask=img.split()[3])
        return bg
    else:
        return img.convert('RGB')

def load_image_as_grayscale(path):
    return Image.open(path).convert('L')

# ==================== Sinusoidal Position Embedding ====================

class SinusoidalPositionEmbeddings(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, time):
        device = time.device
        half_dim = self.dim // 2
        embeddings = math.log(10000) / (half_dim - 1)
        embeddings = torch.exp(torch.arange(half_dim, device=device) * -embeddings)
        embeddings = time[:, None] * embeddings[None, :]
        embeddings = torch.cat((embeddings.sin(), embeddings.cos()), dim=-1)
        return embeddings

# ==================== Flexible VAE (from LDM_5 fix) ====================

class FlexEncoder(nn.Module):
    def __init__(self, in_channels=3, base_channels=32, latent_channels=8, latent_h=4, latent_w=4):
        super().__init__()
        self.latent_channels = latent_channels
        self.latent_h = latent_h
        self.latent_w = latent_w

        self.conv1 = nn.Conv2d(in_channels, base_channels, 3, stride=2, padding=1)
        self.conv2 = nn.Conv2d(base_channels, base_channels*2, 3, stride=2, padding=1)
        self.conv3 = nn.Conv2d(base_channels*2, base_channels*4, 3, stride=2, padding=1)
        self.conv_mu = nn.Conv2d(base_channels*4, latent_channels, 3, padding=1)
        self.conv_logvar = nn.Conv2d(base_channels*4, latent_channels, 3, padding=1)
        self.act = nn.LeakyReLU(0.2)
        self.adaptive_pool = nn.AdaptiveAvgPool2d((latent_h, latent_w))

    def forward(self, x):
        x = self.act(self.conv1(x))
        x = self.act(self.conv2(x))
        x = self.act(self.conv3(x))
        mu = self.conv_mu(x)
        logvar = self.conv_logvar(x)
        mu = self.adaptive_pool(mu)
        logvar = self.adaptive_pool(logvar)
        return mu, logvar

class FlexDecoder(nn.Module):
    def __init__(self, latent_channels=8, base_channels=32, out_channels=3, latent_h=4, latent_w=4):
        super().__init__()
        self.latent_h = latent_h
        self.latent_w = latent_w

        # Start with a small conv to process latent
        self.init_conv = nn.Conv2d(latent_channels, base_channels*4, 3, padding=1)
        self.act = nn.LeakyReLU(0.2)

        # Upsampling layers (each doubles spatial size)
        self.deconv1 = nn.ConvTranspose2d(base_channels*4, base_channels*2, 4, stride=2, padding=1)
        self.deconv2 = nn.ConvTranspose2d(base_channels*2, base_channels, 4, stride=2, padding=1)
        self.deconv3 = nn.ConvTranspose2d(base_channels, base_channels, 4, stride=2, padding=1)
        self.conv_out = nn.Conv2d(base_channels, out_channels, 3, padding=1)

    def forward(self, z, target_size=None):
        # z: (B, C, latent_h, latent_w)
        x = self.act(self.init_conv(z))
        x = self.act(self.deconv1(x))
        x = self.act(self.deconv2(x))
        x = self.act(self.deconv3(x))
        x = torch.tanh(self.conv_out(x))

        # If target size is given, interpolate to exact size
        if target_size is not None and (x.shape[2] != target_size[0] or x.shape[3] != target_size[1]):
            x = F_nn.interpolate(x, size=target_size, mode='bilinear', align_corners=False)
        return x

class FlexVAE(nn.Module):
    def __init__(self, in_channels=3, base_channels=32, latent_channels=8, latent_h=4, latent_w=4):
        super().__init__()
        self.encoder = FlexEncoder(in_channels, base_channels, latent_channels, latent_h, latent_w)
        self.decoder = FlexDecoder(latent_channels, base_channels, in_channels, latent_h, latent_w)
        self.latent_channels = latent_channels
        self.latent_h = latent_h
        self.latent_w = latent_w

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        mu, logvar = self.encoder(x)
        z = self.reparameterize(mu, logvar)
        recon = self.decoder(z, target_size=(x.shape[2], x.shape[3]))
        return recon, mu, logvar

    def encode(self, x):
        mu, _ = self.encoder(x)
        return mu

    def decode(self, z, target_size=None):
        return self.decoder(z, target_size=target_size)

# ==================== DiT Components (following the paper) ====================

class TimestepEmbedder(nn.Module):
    """Embeds scalar timestep into a vector."""
    def __init__(self, hidden_size, frequency_embedding_size=256):
        super().__init__()
        self.mlp = nn.Sequential(
            SinusoidalPositionEmbeddings(frequency_embedding_size),
            nn.Linear(frequency_embedding_size, hidden_size),
            nn.SiLU(),
            nn.Linear(hidden_size, hidden_size),
        )
        self.hidden_size = hidden_size

    def forward(self, t):
        return self.mlp(t)

class DiTBlock(nn.Module):
    """DiT block with adaptive layer norm (adaLN) conditioning."""
    def __init__(self, hidden_size, num_heads, mlp_ratio=4.0, dropout=0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(hidden_size, elementwise_affine=False, eps=1e-6)
        self.attn = nn.MultiheadAttention(hidden_size, num_heads, dropout=dropout, batch_first=True)
        self.norm2 = nn.LayerNorm(hidden_size, elementwise_affine=False, eps=1e-6)
        self.mlp = nn.Sequential(
            nn.Linear(hidden_size, int(hidden_size * mlp_ratio)),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(int(hidden_size * mlp_ratio), hidden_size),
            nn.Dropout(dropout)
        )
        # adaLN modulation: scale and shift for each norm
        self.adaLN_modulation = nn.Sequential(
            nn.SiLU(),
            nn.Linear(hidden_size, 6 * hidden_size, bias=True)
        )

    def forward(self, x, c):
        # x: (B, N, D), c: (B, D) conditioning (time embedding)
        shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = self.adaLN_modulation(c).chunk(6, dim=1)
        # Attention with adaLN
        norm_x = self.norm1(x)
        mod_norm_x = norm_x * (1 + scale_msa.unsqueeze(1)) + shift_msa.unsqueeze(1)
        attn_out, _ = self.attn(mod_norm_x, mod_norm_x, mod_norm_x)
        x = x + gate_msa.unsqueeze(1) * attn_out
        # MLP with adaLN
        norm_x = self.norm2(x)
        mod_norm_x = norm_x * (1 + scale_mlp.unsqueeze(1)) + shift_mlp.unsqueeze(1)
        mlp_out = self.mlp(mod_norm_x)
        x = x + gate_mlp.unsqueeze(1) * mlp_out
        return x

class FinalLayer(nn.Module):
    """Final layer to predict noise (or the latent)."""
    def __init__(self, hidden_size, patch_size, out_channels):
        super().__init__()
        self.norm_final = nn.LayerNorm(hidden_size, elementwise_affine=False, eps=1e-6)
        self.linear = nn.Linear(hidden_size, patch_size * patch_size * out_channels, bias=True)
        self.adaLN_modulation = nn.Sequential(
            nn.SiLU(),
            nn.Linear(hidden_size, 2 * hidden_size, bias=True)
        )

    def forward(self, x, c):
        # x: (B, N, D), c: (B, D)
        shift, scale = self.adaLN_modulation(c).chunk(2, dim=1)
        x = self.norm_final(x)
        x = x * (1 + scale.unsqueeze(1)) + shift.unsqueeze(1)
        x = self.linear(x)  # (B, N, patch_size^2 * out_channels)
        return x

class PatchEmbed(nn.Module):
    """Convert latent map to patch embeddings."""
    def __init__(self, in_channels, patch_size, embed_dim):
        super().__init__()
        self.patch_size = patch_size
        self.proj = nn.Conv2d(in_channels, embed_dim, kernel_size=patch_size, stride=patch_size)

    def forward(self, x):
        # x: (B, C, H, W)
        x = self.proj(x)  # (B, D, Hp, Wp)
        B, D, Hp, Wp = x.shape
        x = x.flatten(2).transpose(1, 2)  # (B, N, D)
        return x, Hp, Wp

class PatchUnembed(nn.Module):
    """Convert patch embeddings back to latent map (no extra linear layer)."""
    def __init__(self, in_channels, patch_size):
        super().__init__()
        self.patch_size = patch_size
        self.in_channels = in_channels

    def forward(self, x, Hp, Wp):
        # x: (B, N, patch_size^2 * C)
        B, N, D = x.shape
        C = self.in_channels
        p = self.patch_size
        x = x.transpose(1, 2).view(B, C, p, p, Hp, Wp)
        # Rearrange: (B, C, p, p, Hp, Wp) -> (B, C, Hp*p, Wp*p)
        x = x.permute(0, 1, 4, 2, 5, 3).contiguous()
        x = x.view(B, C, Hp * p, Wp * p)
        return x

class DiT(nn.Module):
    """Diffusion Transformer (DiT) following the paper."""
    def __init__(self, latent_channels, patch_size, embed_dim, num_heads, num_layers,
                 mlp_ratio=4.0, dropout=0.1, time_emb_dim=256):
        super().__init__()
        self.latent_channels = latent_channels
        self.patch_size = patch_size
        self.embed_dim = embed_dim

        self.patch_embed = PatchEmbed(latent_channels, patch_size, embed_dim)
        self.patch_unembed = PatchUnembed(latent_channels, patch_size)

        # Positional embedding (learned)
        self.pos_embed = nn.Parameter(torch.randn(1, 1024, embed_dim) * 0.02)  # max 1024 patches

        # Timestep embedding
        self.time_embedder = TimestepEmbedder(embed_dim, time_emb_dim)

        # DiT blocks
        self.blocks = nn.ModuleList([
            DiTBlock(embed_dim, num_heads, mlp_ratio, dropout) for _ in range(num_layers)
        ])

        # Final layer
        self.final_layer = FinalLayer(embed_dim, patch_size, latent_channels)

    def forward(self, z, t):
        # z: (B, C, H, W), t: (B,)
        B, C, H, W = z.shape
        # Patchify
        x, Hp, Wp = self.patch_embed(z)  # (B, N, D)
        N = Hp * Wp
        # Add positional embedding
        pos = self.pos_embed[:, :N, :]
        x = x + pos
        # Time conditioning
        c = self.time_embedder(t)  # (B, D)
        # Apply DiT blocks
        for block in self.blocks:
            x = block(x, c)
        # Final layer (predict noise)
        x = self.final_layer(x, c)  # (B, N, patch_size^2 * C)
        # Unpatchify
        out = self.patch_unembed(x, Hp, Wp)  # (B, C, H, W)
        return out

# ==================== GRU alternative (not from paper, but kept) ====================

class GRUModel(nn.Module):
    """GRU-based diffusion model (processes patches as a sequence)."""
    def __init__(self, latent_channels, patch_size, embed_dim, time_emb_dim,
                 gru_hidden_dim, gru_num_layers, dropout=0.1):
        super().__init__()
        self.latent_channels = latent_channels
        self.patch_size = patch_size
        self.embed_dim = embed_dim

        self.patch_embed = PatchEmbed(latent_channels, patch_size, embed_dim)
        self.patch_unembed = PatchUnembed(latent_channels, patch_size)

        self.pos_embed = nn.Parameter(torch.randn(1, 1024, embed_dim) * 0.02)
        self.time_embedder = TimestepEmbedder(embed_dim, time_emb_dim)

        self.gru = nn.GRU(embed_dim, gru_hidden_dim, gru_num_layers, batch_first=True,
                          dropout=dropout if gru_num_layers > 1 else 0)
        self.out_proj = nn.Linear(gru_hidden_dim, embed_dim)
        self.final_layer = FinalLayer(embed_dim, patch_size, latent_channels)

    def forward(self, z, t):
        B, C, H, W = z.shape
        x, Hp, Wp = self.patch_embed(z)
        N = Hp * Wp
        pos = self.pos_embed[:, :N, :]
        x = x + pos
        c = self.time_embedder(t)
        # GRU processes sequence
        x, _ = self.gru(x)
        x = self.out_proj(x)
        # Final layer
        x = self.final_layer(x, c)
        out = self.patch_unembed(x, Hp, Wp)
        return out

# ==================== Latent Diffusion with DiT/GRU ====================

class LatentDiffusionDiT:
    def __init__(self, latent_channels, latent_h, latent_w, patch_size, embed_dim,
                 num_heads, num_layers, mlp_ratio=4.0, dropout=0.1,
                 time_emb_dim=256, model_type='transformer',
                 gru_hidden_dim=512, gru_num_layers=2,
                 T=200, beta_start=1e-4, beta_end=0.02, schedule='linear', device=None):
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.latent_h = latent_h
        self.latent_w = latent_w
        self.latent_channels = latent_channels
        self.patch_size = patch_size
        assert latent_h % patch_size == 0 and latent_w % patch_size == 0, \
            "Latent dimensions must be divisible by patch size"

        # Beta schedule
        if schedule == 'linear':
            beta = torch.linspace(beta_start, beta_end, T, device=self.device)
        elif schedule == 'cosine':
            t = torch.linspace(0, T-1, T, device=self.device) / T
            alpha_bar = torch.cos((t + 0.008) / (1 + 0.008) * math.pi / 2) ** 2
            alpha_bar = alpha_bar / alpha_bar[0]
            alpha_bar = torch.clamp(alpha_bar, min=0.001)
            beta = 1 - alpha_bar / torch.cat([torch.tensor([1.0], device=self.device), alpha_bar[:-1]])
            beta = torch.clamp(beta, min=0.001, max=0.999)
        else:
            raise ValueError(f"Unknown schedule {schedule}")

        self.T = T
        self.betas = beta
        self.alphas = 1 - beta
        self.alpha_bars = torch.cumprod(self.alphas, dim=0)

        # Create model
        if model_type == 'transformer':
            self.model = DiT(
                latent_channels=latent_channels,
                patch_size=patch_size,
                embed_dim=embed_dim,
                num_heads=num_heads,
                num_layers=num_layers,
                mlp_ratio=mlp_ratio,
                dropout=dropout,
                time_emb_dim=time_emb_dim
            ).to(self.device)
        elif model_type == 'gru':
            self.model = GRUModel(
                latent_channels=latent_channels,
                patch_size=patch_size,
                embed_dim=embed_dim,
                time_emb_dim=time_emb_dim,
                gru_hidden_dim=gru_hidden_dim,
                gru_num_layers=gru_num_layers,
                dropout=dropout
            ).to(self.device)
        else:
            raise ValueError(f"Unknown model_type: {model_type}")

        self.criterion = nn.MSELoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=2e-4)

    def train_step(self, z0):
        batch_size = z0.size(0)
        z0 = z0.to(self.device)
        t = torch.randint(0, self.T, (batch_size,), device=self.device).long()
        alpha_bar_t = self.alpha_bars[t].view(-1, 1, 1, 1)
        noise = torch.randn_like(z0)
        zt = torch.sqrt(alpha_bar_t) * z0 + torch.sqrt(1 - alpha_bar_t) * noise
        noise_pred = self.model(zt, t)
        loss = self.criterion(noise_pred, noise)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return loss.item()

    @torch.no_grad()
    def sample(self, n_samples=16, steps=None, method='ddpm', eta=0.0, progress_callback=None):
        if method.lower() == 'ddpm':
            return self._sample_ddpm(n_samples, steps, progress_callback)
        elif method.lower() == 'ddim':
            return self._sample_ddim(n_samples, steps, eta, progress_callback)
        else:
            raise ValueError("method must be 'ddpm' or 'ddim'")

    def _sample_ddpm(self, n_samples=16, n_steps=None, progress_callback=None):
        if n_steps is None:
            n_steps = self.T
        img_shape = (self.latent_channels, self.latent_h, self.latent_w)
        timesteps = torch.linspace(self.T-1, 0, n_steps, dtype=torch.long, device=self.device)
        x = torch.randn(n_samples, *img_shape, device=self.device)
        for i, t in enumerate(timesteps):
            t_tensor = torch.full((n_samples,), t, device=self.device, dtype=torch.long)
            noise_pred = self.model(x, t_tensor)

            alpha_t = self.alphas[t]
            alpha_bar_t = self.alpha_bars[t]
            beta_t = self.betas[t]

            coeff_x = 1.0 / torch.sqrt(alpha_t)
            coeff_noise = beta_t / torch.sqrt(1.0 - alpha_bar_t)

            if t > 0:
                z = torch.randn_like(x)
                sigma_t = torch.sqrt(beta_t)
            else:
                z = 0.0

            x = coeff_x * (x - coeff_noise * noise_pred) + sigma_t * z

            if progress_callback is not None:
                x0_est = (x - torch.sqrt(1.0 - alpha_bar_t) * noise_pred) / torch.sqrt(alpha_bar_t)
                progress_callback(i+1, x, x0_est)

        return x

    def _sample_ddim(self, n_samples=16, n_steps=50, eta=0.0, progress_callback=None):
        img_shape = (self.latent_channels, self.latent_h, self.latent_w)
        step_seq = torch.linspace(0, self.T - 1, n_steps, dtype=torch.long, device=self.device)
        step_seq = step_seq.flip(0)

        x = torch.randn(n_samples, *img_shape, device=self.device)

        for i in range(len(step_seq) - 1):
            t = step_seq[i]
            t_next = step_seq[i + 1]

            t_tensor = torch.full((n_samples,), t, device=self.device, dtype=torch.long)
            noise_pred = self.model(x, t_tensor)

            alpha_bar_t = self.alpha_bars[t]
            alpha_bar_t_next = self.alpha_bars[t_next]

            x0_pred = (x - torch.sqrt(1.0 - alpha_bar_t) * noise_pred) / torch.sqrt(alpha_bar_t)

            sigma = eta * torch.sqrt((1.0 - alpha_bar_t_next) / (1.0 - alpha_bar_t) *
                                     (1.0 - alpha_bar_t / alpha_bar_t_next))

            dir_xt = torch.sqrt(1.0 - alpha_bar_t_next - sigma ** 2) * noise_pred

            x = torch.sqrt(alpha_bar_t_next) * x0_pred + dir_xt
            if eta > 0:
                x = x + sigma * torch.randn_like(x)

            if progress_callback is not None:
                progress_callback(i+1, x, x0_pred)

        return x

    @torch.no_grad()
    def sample_step_by_step(self, n_samples=16, steps=None, method='ddpm', eta=0.0):
        if method.lower() == 'ddpm':
            yield from self._sample_step_by_step_ddpm(n_samples, steps)
        elif method.lower() == 'ddim':
            yield from self._sample_step_by_step_ddim(n_samples, steps, eta)
        else:
            raise ValueError("method must be 'ddpm' or 'ddim'")

    def _sample_step_by_step_ddpm(self, n_samples=16, n_steps=None):
        if n_steps is None:
            n_steps = self.T
        img_shape = (self.latent_channels, self.latent_h, self.latent_w)
        timesteps = torch.linspace(self.T-1, 0, n_steps, dtype=torch.long, device=self.device)
        x = torch.randn(n_samples, *img_shape, device=self.device)
        for i, t in enumerate(timesteps):
            t_tensor = torch.full((n_samples,), t, device=self.device, dtype=torch.long)
            noise_pred = self.model(x, t_tensor)

            alpha_t = self.alphas[t]
            alpha_bar_t = self.alpha_bars[t]
            beta_t = self.betas[t]

            coeff_x = 1.0 / torch.sqrt(alpha_t)
            coeff_noise = beta_t / torch.sqrt(1.0 - alpha_bar_t)

            if t > 0:
                z = torch.randn_like(x)
                sigma_t = torch.sqrt(beta_t)
            else:
                z = 0.0

            x = coeff_x * (x - coeff_noise * noise_pred) + sigma_t * z
            yield t, x.clone()

    def _sample_step_by_step_ddim(self, n_samples=16, n_steps=50, eta=0.0):
        img_shape = (self.latent_channels, self.latent_h, self.latent_w)
        step_seq = torch.linspace(0, self.T - 1, n_steps, dtype=torch.long, device=self.device)
        step_seq = step_seq.flip(0)

        x = torch.randn(n_samples, *img_shape, device=self.device)

        for i in range(len(step_seq) - 1):
            t = step_seq[i]
            t_next = step_seq[i + 1]

            t_tensor = torch.full((n_samples,), t, device=self.device, dtype=torch.long)
            noise_pred = self.model(x, t_tensor)

            alpha_bar_t = self.alpha_bars[t]
            alpha_bar_t_next = self.alpha_bars[t_next]

            x0_pred = (x - torch.sqrt(1.0 - alpha_bar_t) * noise_pred) / torch.sqrt(alpha_bar_t)

            sigma = eta * torch.sqrt((1.0 - alpha_bar_t_next) / (1.0 - alpha_bar_t) *
                                     (1.0 - alpha_bar_t / alpha_bar_t_next))

            dir_xt = torch.sqrt(1.0 - alpha_bar_t_next - sigma ** 2) * noise_pred

            x = torch.sqrt(alpha_bar_t_next) * x0_pred + dir_xt
            if eta > 0:
                x = x + sigma * torch.randn_like(x)

            yield t, x.clone()

# ==================== Dataset ====================

class UnconditionalImageDataset(Dataset):
    def __init__(self, image_paths, img_size=32, color_mode='rgb', aug_settings=None):
        self.image_paths = image_paths
        self.img_size = img_size
        self.color_mode = color_mode.lower()
        self.aug_settings = aug_settings or {}

        if self.color_mode == 'rgb':
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.5,))
            ])

    def __len__(self):
        return len(self.image_paths)

    def apply_augmentations(self, pil_img):
        img = pil_img.copy()
        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F_vision.hflip(img)
        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F_vision.rotate(img, angle, interpolation=Image.BICUBIC)
        return img

    def __getitem__(self, idx):
        try:
            if self.color_mode == 'rgb':
                pil_img = load_image_as_rgb(self.image_paths[idx])
            else:
                pil_img = load_image_as_grayscale(self.image_paths[idx])
            pil_img = self.apply_augmentations(pil_img)
            img_tensor = self.transform(pil_img)
            return img_tensor
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            if self.color_mode == 'rgb':
                return torch.zeros(3, self.img_size, self.img_size)
            else:
                return torch.zeros(1, self.img_size, self.img_size)

# ==================== GUI Application ====================

# Predefined model configurations for DiT (Transformer)
TRANSFORMER_CONFIGS = {
    'tiny': {'embed_dim': 128, 'num_heads': 4, 'num_layers': 4, 'mlp_ratio': 4.0},
    'small': {'embed_dim': 256, 'num_heads': 4, 'num_layers': 6, 'mlp_ratio': 4.0},
    'medium': {'embed_dim': 384, 'num_heads': 6, 'num_layers': 8, 'mlp_ratio': 4.0},
    'large': {'embed_dim': 512, 'num_heads': 8, 'num_layers': 10, 'mlp_ratio': 4.0},
}

GRU_CONFIGS = {
    'tiny': {'embed_dim': 128, 'gru_hidden_dim': 256, 'gru_num_layers': 2},
    'small': {'embed_dim': 256, 'gru_hidden_dim': 512, 'gru_num_layers': 2},
    'medium': {'embed_dim': 384, 'gru_hidden_dim': 768, 'gru_num_layers': 3},
    'large': {'embed_dim': 512, 'gru_hidden_dim': 1024, 'gru_num_layers': 3},
}

class DiTApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Latent Diffusion with DiT (Transformer/GRU)")
        self.root.geometry("1200x800")

        self.image_paths = []
        self.training_vae = False
        self.training_dit = False
        self.vae_model = None
        self.dit_model = None

        self.current_epoch_vae = 0
        self.current_epoch_dit = 0

        self.message_queue_vae = queue.Queue()
        self.message_queue_dit = queue.Queue()
        self.progressive_active = False

        # Device selection
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.device_var = tk.StringVar(value=str(self.device))

        # Settings variables
        self.settings = {
            # Image
            'img_size': tk.IntVar(value=32),
            'color_mode': tk.StringVar(value='rgb'),

            # VAE
            'vae_base_channels': tk.IntVar(value=32),
            'vae_latent_channels': tk.IntVar(value=8),
            'vae_latent_h': tk.IntVar(value=4),
            'vae_latent_w': tk.IntVar(value=4),
            'vae_batch_size': tk.IntVar(value=16),
            'vae_lr': tk.DoubleVar(value=1e-3),
            'vae_num_workers': tk.IntVar(value=0),
            'vae_kl_weight': tk.DoubleVar(value=0.0001),

            # DiT
            'dit_patch_size': tk.IntVar(value=1),
            'dit_model_type': tk.StringVar(value='transformer'),
            'dit_transformer_size': tk.StringVar(value='small'),
            'dit_gru_size': tk.StringVar(value='small'),
            'dit_time_emb_dim': tk.IntVar(value=256),
            'dit_dropout': tk.DoubleVar(value=0.1),
            'dit_batch_size': tk.IntVar(value=16),
            'dit_lr': tk.DoubleVar(value=2e-4),
            'dit_T': tk.IntVar(value=200),
            'dit_beta_start': tk.DoubleVar(value=1e-4),
            'dit_beta_end': tk.DoubleVar(value=0.02),
            'dit_beta_schedule': tk.StringVar(value='linear'),
        }

        # Augmentation settings
        self.aug_settings = {
            'flip_horizontal': tk.BooleanVar(value=True),
            'rotation': tk.BooleanVar(value=False),
        }

        # Generation sampler choice
        self.sampler_method = tk.StringVar(value='ddpm')
        self.thumbnail_size = 128

        self.setup_gui()
        self.root.after(100, self.process_messages_vae)
        self.root.after(100, self.process_messages_dit)

    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Tab 1: VAE Training
        self.vae_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.vae_tab, text='VAE Training')
        self.setup_vae_tab()

        # Tab 2: DiT Training
        self.dit_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.dit_tab, text='DiT Training')
        self.setup_dit_tab()

        # Tab 3: Settings
        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        # Tab 4: Generation
        self.generation_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generation_tab, text='Generation')
        self.setup_generation_tab()

        self.status_label = tk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_vae_tab(self):
        main_frame = tk.Frame(self.vae_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="VAE Training", font=("Arial",12,"bold")).pack(pady=(0,10))

        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=5, pady=5)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=2)
        tk.Button(img_frame, text="Add Folder (recursive)", command=self.add_folder, width=20).pack(pady=2)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=2)
        self.image_listbox = tk.Listbox(img_frame, height=5)
        self.image_listbox.pack(fill=tk.X, pady=2)

        tk.Button(left_frame, text="Initialize VAE", command=self.initialize_vae, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.vae_epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.vae_epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start VAE Training", command=self.start_vae_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop VAE Training", command=self.stop_vae_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save VAE", command=self.save_vae, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load VAE", command=self.load_vae, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Reconstructions (Top: Real, Bottom: Recon)", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.vae_preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=128)
        self.vae_preview_canvas.pack()

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.vae_log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.vae_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.vae_log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.vae_log_text.config(yscrollcommand=scrollbar.set)

    def setup_dit_tab(self):
        main_frame = tk.Frame(self.dit_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="DiT Training", font=("Arial",12,"bold")).pack(pady=(0,10))
        tk.Label(left_frame, text="Requires a trained VAE", fg="blue").pack(pady=5)

        tk.Button(left_frame, text="Initialize DiT", command=self.initialize_dit_model, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.dit_epoch_var = tk.StringVar(value="200")
        tk.Entry(epoch_frame, textvariable=self.dit_epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start DiT Training", command=self.start_dit_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop DiT Training", command=self.stop_dit_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save DiT Model", command=self.save_dit_model, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load DiT Model", command=self.load_dit_model, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Samples (decoded)", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.dit_preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=256)
        self.dit_preview_canvas.pack()

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.dit_log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.dit_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.dit_log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.dit_log_text.config(yscrollcommand=scrollbar.set)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Model Settings", font=("Arial",14,"bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Device selection
        dev_frame = tk.LabelFrame(scrollable_frame, text="Hardware", padx=10, pady=10)
        dev_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(dev_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Compute device:", width=20, anchor='w').pack(side=tk.LEFT)
        om = ttk.Combobox(f, textvariable=self.device_var, values=['cuda', 'cpu'], state='readonly', width=10)
        om.pack(side=tk.RIGHT)
        om.bind('<<ComboboxSelected>>', lambda e: self.set_device())

        # Image settings
        img_frame = tk.LabelFrame(scrollable_frame, text="Image", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=5)

        f = tk.Frame(img_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Color mode:", width=20, anchor='w').pack(side=tk.LEFT)
        om = ttk.Combobox(f, textvariable=self.settings['color_mode'], values=['rgb', 'grayscale'], state='readonly', width=10)
        om.pack(side=tk.RIGHT)

        f = tk.Frame(img_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Image size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=16, to=128, variable=self.settings['img_size'],
                 orient=tk.HORIZONTAL, length=200, resolution=1).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['img_size'], width=5).pack(side=tk.RIGHT)

        # VAE settings
        vae_frame = tk.LabelFrame(scrollable_frame, text="VAE", padx=10, pady=10)
        vae_frame.pack(fill=tk.X, pady=5)

        vae_params = [
            ("Base channels:", 'vae_base_channels', 16, 128),
            ("Latent channels:", 'vae_latent_channels', 1, 32),
            ("Latent height:", 'vae_latent_h', 1, 32),
            ("Latent width:", 'vae_latent_w', 1, 32),
            ("Batch size:", 'vae_batch_size', 1, 32),
            ("Learning rate:", 'vae_lr', 1e-5, 1e-2),
            ("KL weight:", 'vae_kl_weight', 1e-6, 1e-2),
            ("Workers:", 'vae_num_workers', 0, 4),
        ]
        for label, key, low, high in vae_params:
            f = tk.Frame(vae_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            res = 0.00001 if 'lr' in key or 'kl' in key else 1
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # DiT settings
        dit_frame = tk.LabelFrame(scrollable_frame, text="DiT (Diffusion Transformer)", padx=10, pady=10)
        dit_frame.pack(fill=tk.X, pady=5)

        f = tk.Frame(dit_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Patch size:", width=20, anchor='w').pack(side=tk.LEFT)
        patch_scale = tk.Scale(f, from_=1, to=4, variable=self.settings['dit_patch_size'],
                               orient=tk.HORIZONTAL, length=200, resolution=1)
        patch_scale.pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['dit_patch_size'], width=5).pack(side=tk.RIGHT)

        f = tk.Frame(dit_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Model type:", width=20, anchor='w').pack(side=tk.LEFT)
        type_combo = ttk.Combobox(f, textvariable=self.settings['dit_model_type'],
                                  values=['transformer', 'gru'], state='readonly', width=10)
        type_combo.pack(side=tk.RIGHT)

        f = tk.Frame(dit_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Transformer size:", width=20, anchor='w').pack(side=tk.LEFT)
        trans_combo = ttk.Combobox(f, textvariable=self.settings['dit_transformer_size'],
                                   values=list(TRANSFORMER_CONFIGS.keys()), state='readonly', width=10)
        trans_combo.pack(side=tk.RIGHT)

        f = tk.Frame(dit_frame)
        f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="GRU size:", width=20, anchor='w').pack(side=tk.LEFT)
        gru_combo = ttk.Combobox(f, textvariable=self.settings['dit_gru_size'],
                                 values=list(GRU_CONFIGS.keys()), state='readonly', width=10)
        gru_combo.pack(side=tk.RIGHT)

        dit_params = [
            ("Time emb dim:", 'dit_time_emb_dim', 64, 512),
            ("Dropout:", 'dit_dropout', 0.0, 0.5),
            ("Batch size:", 'dit_batch_size', 1, 32),
            ("Learning rate:", 'dit_lr', 1e-5, 1e-2),
            ("Timesteps (T):", 'dit_T', 50, 1000),
            ("Beta start:", 'dit_beta_start', 1e-5, 1e-2),
            ("Beta end:", 'dit_beta_end', 0.001, 0.1),
        ]
        for label, key, low, high in dit_params:
            f = tk.Frame(dit_frame)
            f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            res = 0.0001 if 'beta' in key else (0.00001 if 'lr' in key else (0.1 if 'dropout' in key else 1))
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        sched_frame = tk.Frame(dit_frame)
        sched_frame.pack(fill=tk.X, pady=2)
        tk.Label(sched_frame, text="Beta schedule:", width=20, anchor='w').pack(side=tk.LEFT)
        sched_combo = ttk.Combobox(sched_frame, textvariable=self.settings['dit_beta_schedule'],
                                   values=['linear', 'cosine'], state='readonly', width=10)
        sched_combo.pack(side=tk.RIGHT)

        aug_frame = tk.LabelFrame(scrollable_frame, text="Augmentations", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)
        augs = [("Horizontal Flip", 'flip_horizontal'), ("Rotation (±30°)", 'rotation')]
        for label, key in augs:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=5)
        cpu = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU cores: {cpu}").pack(anchor='w')
        tk.Label(sys_frame, text=f"PyTorch threads: {torch.get_num_threads()}").pack(anchor='w')
        tk.Label(sys_frame, text=f"Device: {self.device}").pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generation_tab(self):
        main_frame = tk.Frame(self.generation_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        tk.Label(main_frame, text="Generate Images (DiT + VAE Decoder)", font=("Arial",14,"bold")).pack(pady=(0,10))

        ctrl_frame = tk.Frame(main_frame)
        ctrl_frame.pack(pady=5)

        tk.Label(ctrl_frame, text="Number of images:").pack(side=tk.LEFT)
        self.gen_count = tk.IntVar(value=16)
        tk.Spinbox(ctrl_frame, from_=1, to=64, textvariable=self.gen_count, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="Sampling steps:").pack(side=tk.LEFT, padx=(10,0))
        self.sampling_steps = tk.IntVar(value=self.settings['dit_T'].get())
        tk.Spinbox(ctrl_frame, from_=1, to=self.settings['dit_T'].get(), textvariable=self.sampling_steps, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="Sampler:").pack(side=tk.LEFT, padx=(10,0))
        sampler_combo = ttk.Combobox(ctrl_frame, textvariable=self.sampler_method,
                                      values=['ddpm', 'ddim'], state='readonly', width=6)
        sampler_combo.pack(side=tk.LEFT, padx=5)

        self.progressive_grid = tk.BooleanVar(value=False)
        prog_check = tk.Checkbutton(ctrl_frame, text="Progressive grid", variable=self.progressive_grid)
        prog_check.pack(side=tk.LEFT, padx=10)

        tk.Label(ctrl_frame, text="Update interval:").pack(side=tk.LEFT)
        self.prog_interval = tk.IntVar(value=10)
        tk.Spinbox(ctrl_frame, from_=1, to=50, textvariable=self.prog_interval, width=5).pack(side=tk.LEFT, padx=5)

        self.generate_btn = tk.Button(ctrl_frame, text="Generate", command=self.generate_samples, bg="lightgreen")
        self.generate_btn.pack(side=tk.LEFT, padx=5)
        self.stop_prog_btn = tk.Button(ctrl_frame, text="Stop", command=self.stop_progressive, state=tk.DISABLED, bg="salmon")
        self.stop_prog_btn.pack(side=tk.LEFT, padx=5)

        scroll_frame = tk.LabelFrame(main_frame, text="Results", padx=5, pady=5)
        scroll_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        canvas_frame = tk.Frame(scroll_frame)
        canvas_frame.pack(fill=tk.BOTH, expand=True)

        self.gen_canvas = tk.Canvas(canvas_frame, bg='lightgray')
        self.v_scroll = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.gen_canvas.yview)
        self.h_scroll = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.gen_canvas.xview)
        self.gen_canvas.configure(yscrollcommand=self.v_scroll.set, xscrollcommand=self.h_scroll.set)

        self.v_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.h_scroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.inner_frame = tk.Frame(self.gen_canvas)
        self.canvas_window = self.gen_canvas.create_window((0,0), window=self.inner_frame, anchor='nw')

        def configure_inner(event):
            self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.inner_frame.bind('<Configure>', configure_inner)

        self.gen_info = tk.Label(main_frame, text="", fg="blue")
        self.gen_info.pack()

    def set_device(self):
        dev_name = self.device_var.get()
        self.device = torch.device(dev_name)
        if self.vae_model:
            self.vae_model.to(self.device)
            self.log_vae(f"VAE moved to {dev_name}")
        if self.dit_model:
            self.dit_model.device = dev_name
            self.dit_model.model.to(self.device)
            self.dit_model.betas = self.dit_model.betas.to(self.device)
            self.dit_model.alphas = self.dit_model.alphas.to(self.device)
            self.dit_model.alpha_bars = self.dit_model.alpha_bars.to(self.device)
            self.log_dit(f"DiT moved to {dev_name}")

    # ------------------------------------------------------------------
    # Core functions
    # ------------------------------------------------------------------
    def log_vae(self, msg):
        self.message_queue_vae.put(msg)

    def log_dit(self, msg):
        self.message_queue_dit.put(msg)

    def process_messages_vae(self):
        try:
            while True:
                msg = self.message_queue_vae.get_nowait()
                self.vae_log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.vae_log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages_vae)

    def process_messages_dit(self):
        try:
            while True:
                msg = self.message_queue_dit.get_nowait()
                self.dit_log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.dit_log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages_dit)

    def add_images(self):
        files = filedialog.askopenfilenames(
            filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp")]
        )
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_vae(f"Added {len(files)} images. Total: {len(self.image_paths)}")
        self.log_dit(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def add_folder(self):
        folder = filedialog.askdirectory()
        if not folder:
            return
        count = 0
        for root_dir, _, files in os.walk(folder):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg', '.jfif', '.webp', '.bmp')):
                    full_path = os.path.join(root_dir, file)
                    if full_path not in self.image_paths:
                        self.image_paths.append(full_path)
                        self.image_listbox.insert(tk.END, os.path.basename(full_path))
                        count += 1
        self.log_vae(f"Added {count} images from folder (recursive). Total: {len(self.image_paths)}")
        self.log_dit(f"Added {count} images from folder. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths = []
        self.image_listbox.delete(0, tk.END)
        self.log_vae("Cleared all images")
        self.log_dit("Cleared all images")

    # ========== VAE Methods ==========
    def initialize_vae(self):
        try:
            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            self.vae_model = FlexVAE(
                in_channels=in_channels,
                base_channels=self.settings['vae_base_channels'].get(),
                latent_channels=self.settings['vae_latent_channels'].get(),
                latent_h=self.settings['vae_latent_h'].get(),
                latent_w=self.settings['vae_latent_w'].get()
            )
            self.vae_model.to(self.device)
            self.vae_optimizer = optim.Adam(self.vae_model.parameters(), lr=self.settings['vae_lr'].get())
            self.log_vae(f"VAE initialized on {self.device}.")
        except Exception as e:
            self.log_vae(f"Error initializing VAE: {e}")

    def start_vae_training(self):
        if not self.image_paths:
            self.log_vae("No images!")
            return
        if not self.vae_model:
            self.log_vae("VAE not initialized!")
            return
        if self.training_vae:
            self.log_vae("Already training VAE.")
            return

        try:
            epochs = int(self.vae_epoch_var.get())
        except:
            self.log_vae("Invalid epochs")
            return

        img_size = self.settings['img_size'].get()
        if img_size % 8 != 0:
            self.log_vae("Warning: Image size should be divisible by 8 for optimal VAE performance.")

        self.training_vae = True
        self.current_epoch_vae = 0
        self.vae_start_time = time.time()

        thread = threading.Thread(target=self.train_vae_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_vae(f"VAE training started for {epochs} epochs.")

    def train_vae_loop(self, epochs):
        try:
            batch_size = self.settings['vae_batch_size'].get()
            num_workers = self.settings['vae_num_workers'].get()
            img_size = self.settings['img_size'].get()
            kl_weight = self.settings['vae_kl_weight'].get()
            color_mode = self.settings['color_mode'].get()

            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}
            dataset = UnconditionalImageDataset(self.image_paths, img_size, color_mode, aug_settings=aug_dict)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=(self.device.type=='cuda'),
                                persistent_workers=False if num_workers==0 else True)

            for epoch in range(epochs):
                if not self.training_vae:
                    break
                self.current_epoch_vae = epoch
                epoch_loss = 0.0
                batches = 0

                for images in loader:
                    if not self.training_vae:
                        break
                    images = images.to(self.device)
                    recon, mu, logvar = self.vae_model(images)
                    recon_loss = nn.functional.mse_loss(recon, images)
                    kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
                    kl_loss = kl_loss / images.size(0)
                    loss = recon_loss + kl_weight * kl_loss

                    self.vae_optimizer.zero_grad()
                    loss.backward()
                    self.vae_optimizer.step()

                    epoch_loss += loss.item()
                    batches += 1

                avg_loss = epoch_loss / batches if batches else 0
                elapsed = time.time() - self.vae_start_time
                self.log_vae(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s")

                if (epoch+1) % 5 == 0:
                    self.show_vae_preview()

            self.training_vae = False
            self.log_vae("VAE training finished.")
        except Exception as e:
            self.log_vae(f"VAE training error: {e}")
            import traceback
            traceback.print_exc()
            self.training_vae = False

    def show_vae_preview(self):
        if not self.vae_model:
            return
        try:
            color_mode = self.settings['color_mode'].get()
            img_size = self.settings['img_size'].get()
            dataset = UnconditionalImageDataset(self.image_paths[:16], img_size=img_size,
                                                color_mode=color_mode)
            loader = DataLoader(dataset, batch_size=16, shuffle=True)
            images = next(iter(loader))
            images = images.to(self.device)
            with torch.no_grad():
                recon, _, _ = self.vae_model(images)
            images = (images + 1) / 2
            recon = (recon + 1) / 2
            images = images.clamp(0,1).cpu().numpy()
            recon = recon.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size // 2
            grid = Image.new('RGB', (8*thumb, 4*thumb))
            for i in range(4):
                for j in range(4):
                    idx = i*4 + j
                    if idx < len(images):
                        # real
                        if images[idx].shape[0] == 1:
                            img = images[idx][0] * 255
                            img = np.stack([img, img, img], axis=-1).astype(np.uint8)
                        else:
                            img = images[idx].transpose(1,2,0) * 255
                            img = img.astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img, (j*thumb*2, i*thumb))
                        # recon
                        if recon[idx].shape[0] == 1:
                            img_r = recon[idx][0] * 255
                            img_r = np.stack([img_r, img_r, img_r], axis=-1).astype(np.uint8)
                        else:
                            img_r = recon[idx].transpose(1,2,0) * 255
                            img_r = img_r.astype(np.uint8)
                        pil_img_r = Image.fromarray(img_r).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img_r, (j*thumb*2 + thumb, i*thumb))
            grid = grid.resize((256,128), Image.NEAREST)
            self.vae_preview_photo = ImageTk.PhotoImage(grid)
            self.vae_preview_canvas.delete("all")
            self.vae_preview_canvas.create_image(128,64, image=self.vae_preview_photo)
        except Exception as e:
            self.log_vae(f"Preview error: {e}")

    def stop_vae_training(self):
        self.training_vae = False
        self.log_vae("VAE training stopped.")

    def save_vae(self):
        if not self.vae_model:
            self.log_vae("No VAE model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth",
                                              filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'model_state': self.vae_model.state_dict(),
                'optimizer_state': self.vae_optimizer.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items() if k.startswith('vae') or k in ['img_size','color_mode']},
            }, fname)
            self.log_vae(f"VAE saved to {fname}")

    def load_vae(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            if 'settings' in ckpt:
                s = ckpt['settings']
                for k, v in s.items():
                    if k in self.settings:
                        self.settings[k].set(v)

            self.initialize_vae()
            self.vae_model.load_state_dict(ckpt['model_state'])
            self.vae_optimizer.load_state_dict(ckpt['optimizer_state'])
            self.vae_model.to(self.device)
            self.log_vae(f"VAE loaded from {fname}")
        except Exception as e:
            self.log_vae(f"Load error: {e}")

    # ========== DiT Methods ==========
    def initialize_dit_model(self):
        if not self.vae_model:
            self.log_dit("Please train/load a VAE first!")
            return
        try:
            latent_channels = self.settings['vae_latent_channels'].get()
            latent_h = self.settings['vae_latent_h'].get()
            latent_w = self.settings['vae_latent_w'].get()
            patch_size = self.settings['dit_patch_size'].get()
            model_type = self.settings['dit_model_type'].get()

            if latent_h % patch_size != 0 or latent_w % patch_size != 0:
                self.log_dit(f"Latent dimensions ({latent_h}x{latent_w}) not divisible by patch size {patch_size}.")
                return

            if model_type == 'transformer':
                size_name = self.settings['dit_transformer_size'].get()
                config = TRANSFORMER_CONFIGS[size_name]
                embed_dim = config['embed_dim']
                num_heads = config['num_heads']
                num_layers = config['num_layers']
                mlp_ratio = config['mlp_ratio']
                gru_hidden_dim = None
                gru_num_layers = None
            else:  # gru
                size_name = self.settings['dit_gru_size'].get()
                config = GRU_CONFIGS[size_name]
                embed_dim = config['embed_dim']
                num_heads = None
                num_layers = None
                mlp_ratio = None
                gru_hidden_dim = config['gru_hidden_dim']
                gru_num_layers = config['gru_num_layers']

            self.dit_model = LatentDiffusionDiT(
                latent_channels=latent_channels,
                latent_h=latent_h,
                latent_w=latent_w,
                patch_size=patch_size,
                embed_dim=embed_dim,
                num_heads=num_heads,
                num_layers=num_layers,
                mlp_ratio=mlp_ratio,
                dropout=self.settings['dit_dropout'].get(),
                time_emb_dim=self.settings['dit_time_emb_dim'].get(),
                model_type=model_type,
                gru_hidden_dim=gru_hidden_dim,
                gru_num_layers=gru_num_layers,
                T=self.settings['dit_T'].get(),
                beta_start=self.settings['dit_beta_start'].get(),
                beta_end=self.settings['dit_beta_end'].get(),
                schedule=self.settings['dit_beta_schedule'].get(),
                device=self.device
            )
            for pg in self.dit_model.optimizer.param_groups:
                pg['lr'] = self.settings['dit_lr'].get()

            self.log_dit(f"DiT initialized (type={model_type}, patch_size={patch_size}) on {self.device}.")
        except Exception as e:
            self.log_dit(f"Error initializing DiT: {e}")

    def start_dit_training(self):
        if not self.image_paths:
            self.log_dit("No images!")
            return
        if not self.dit_model:
            self.log_dit("DiT not initialized!")
            return
        if not self.vae_model:
            self.log_dit("No VAE available to encode latents!")
            return
        if self.training_dit:
            self.log_dit("Already training DiT.")
            return

        try:
            epochs = int(self.dit_epoch_var.get())
        except:
            self.log_dit("Invalid epochs")
            return

        self.training_dit = True
        self.current_epoch_dit = 0
        self.dit_start_time = time.time()

        thread = threading.Thread(target=self.train_dit_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_dit(f"DiT training started for {epochs} epochs.")

    def train_dit_loop(self, epochs):
        try:
            batch_size = self.settings['dit_batch_size'].get()
            num_workers = self.settings['vae_num_workers'].get()
            img_size = self.settings['img_size'].get()
            color_mode = self.settings['color_mode'].get()

            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}
            dataset = UnconditionalImageDataset(self.image_paths, img_size, color_mode, aug_settings=aug_dict)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=(self.device.type=='cuda'),
                                persistent_workers=False if num_workers==0 else True)

            for epoch in range(epochs):
                if not self.training_dit:
                    break
                self.current_epoch_dit = epoch
                epoch_loss = 0.0
                batches = 0

                for images in loader:
                    if not self.training_dit:
                        break
                    images = images.to(self.device)
                    with torch.no_grad():
                        latents = self.vae_model.encode(images)
                    loss = self.dit_model.train_step(latents)
                    epoch_loss += loss
                    batches += 1

                avg_loss = epoch_loss / batches if batches else 0
                elapsed = time.time() - self.dit_start_time
                self.log_dit(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s")

                if (epoch+1) % 5 == 0:
                    self.show_dit_preview()

            self.training_dit = False
            self.log_dit("DiT training finished.")
        except Exception as e:
            self.log_dit(f"DiT training error: {e}")
            import traceback
            traceback.print_exc()
            self.training_dit = False

    def show_dit_preview(self):
        if not self.dit_model or not self.vae_model:
            return
        try:
            z = self.dit_model.sample(n_samples=16, steps=50, method='ddim')
            target_size = (self.settings['img_size'].get(), self.settings['img_size'].get())
            with torch.no_grad():
                samples = self.vae_model.decode(z, target_size=target_size)
            samples = (samples + 1) / 2
            samples = samples.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size
            grid = Image.new('RGB', (4*thumb, 4*thumb))
            for i in range(4):
                for j in range(4):
                    idx = i*4 + j
                    if idx < len(samples):
                        if samples[idx].shape[0] == 1:
                            img = samples[idx][0] * 255
                            img = np.stack([img, img, img], axis=-1).astype(np.uint8)
                        else:
                            img = samples[idx].transpose(1,2,0) * 255
                            img = img.astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img, (j*thumb, i*thumb))
            grid = grid.resize((256,256), Image.NEAREST)
            self.dit_preview_photo = ImageTk.PhotoImage(grid)
            self.dit_preview_canvas.delete("all")
            self.dit_preview_canvas.create_image(128,128, image=self.dit_preview_photo)
        except Exception as e:
            self.log_dit(f"Preview error: {e}")

    def stop_dit_training(self):
        self.training_dit = False
        self.log_dit("DiT training stopped.")

    def save_dit_model(self):
        if not self.dit_model:
            self.log_dit("No DiT model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth",
                                              filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'model_state': self.dit_model.model.state_dict(),
                'optimizer_state': self.dit_model.optimizer.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items() if k.startswith('dit') or k in ['vae_latent_h','vae_latent_w','vae_latent_channels']},
                'T': self.dit_model.T,
                'betas': self.dit_model.betas.cpu(),
                'alphas': self.dit_model.alphas.cpu(),
                'alpha_bars': self.dit_model.alpha_bars.cpu()
            }, fname)
            self.log_dit(f"DiT model saved to {fname}")

    def load_dit_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname:
            return
        try:
            ckpt = torch.load(fname, map_location='cpu')
            if 'settings' in ckpt:
                s = ckpt['settings']
                for k, v in s.items():
                    if k in self.settings:
                        self.settings[k].set(v)

            if not self.vae_model:
                self.log_dit("Please load VAE first, then try again.")
                return
            self.initialize_dit_model()
            self.dit_model.model.load_state_dict(ckpt['model_state'])
            self.dit_model.optimizer.load_state_dict(ckpt['optimizer_state'])
            self.dit_model.betas = ckpt['betas'].to(self.dit_model.device)
            self.dit_model.alphas = ckpt['alphas'].to(self.dit_model.device)
            self.dit_model.alpha_bars = ckpt['alpha_bars'].to(self.dit_model.device)
            self.dit_model.T = ckpt['T']

            self.log_dit(f"DiT model loaded from {fname}")
        except Exception as e:
            self.log_dit(f"Load error: {e}")

    # ========== Generation Methods ==========
    def generate_samples(self):
        if not self.dit_model or not self.vae_model:
            self.gen_info.config(text="Models not loaded!")
            return
        n = self.gen_count.get()
        steps = self.sampling_steps.get()
        method = self.sampler_method.get()
        if self.progressive_grid.get():
            self.start_progressive(n, steps, method)
        else:
            self.generate_btn.config(state=tk.DISABLED)
            self.gen_info.config(text="Generating...")
            self.root.update()
            thread = threading.Thread(target=self._generate_thread, args=(n, steps, method), daemon=True)
            thread.start()

    def stop_progressive(self):
        self.progressive_active = False
        self.stop_prog_btn.config(state=tk.DISABLED)
        self.generate_btn.config(state=tk.NORMAL)
        self.gen_info.config(text="Progressive generation stopped.")

    def start_progressive(self, n, steps, method):
        self.progressive_active = True
        self.generate_btn.config(state=tk.DISABLED)
        self.stop_prog_btn.config(state=tk.NORMAL)
        self.gen_info.config(text="Progressive generation...")
        thread = threading.Thread(target=self._progressive_thread, args=(n, steps, method), daemon=True)
        thread.start()

    def _generate_thread(self, n, steps, method):
        try:
            z = self.dit_model.sample(n_samples=n, steps=steps, method=method)
            target_size = (self.settings['img_size'].get(), self.settings['img_size'].get())
            with torch.no_grad():
                samples = self.vae_model.decode(z, target_size=target_size)
            samples = (samples + 1) / 2
            samples = samples.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size
            grid_size = int(math.ceil(math.sqrt(n)))
            total_width = grid_size * thumb
            total_height = grid_size * thumb
            grid_img = Image.new('RGB', (total_width, total_height), color=(128,128,128))
            for i in range(n):
                row = i // grid_size
                col = i % grid_size
                if samples[i].shape[0] == 1:
                    img = samples[i][0] * 255
                    img = np.stack([img, img, img], axis=-1).astype(np.uint8)
                else:
                    img = samples[i].transpose(1,2,0) * 255
                    img = img.astype(np.uint8)
                pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                grid_img.paste(pil_img, (col*thumb, row*thumb))
            self.root.after(0, lambda: self._display_generated(grid_img))
        except Exception as e:
            self.root.after(0, lambda: self.gen_info.config(text=f"Error: {e}"))
        finally:
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))

    def _progressive_thread(self, n, steps, method):
        try:
            thumb = self.thumbnail_size
            interval = self.prog_interval.get()
            generator = self.dit_model.sample_step_by_step(n_samples=n, steps=steps, method=method)
            step_count = 0
            target_size = (self.settings['img_size'].get(), self.settings['img_size'].get())
            for t, z in generator:
                if not self.progressive_active:
                    break
                step_count += 1
                if step_count % interval == 0 or t == 1:
                    with torch.no_grad():
                        samples = self.vae_model.decode(z, target_size=target_size)
                    samples = (samples + 1) / 2
                    samples = samples.clamp(0,1).cpu().numpy()
                    grid_size = int(math.ceil(math.sqrt(n)))
                    total_width = grid_size * thumb
                    total_height = grid_size * thumb
                    grid_img = Image.new('RGB', (total_width, total_height), color=(128,128,128))
                    for i in range(n):
                        row = i // grid_size
                        col = i % grid_size
                        if i < len(samples):
                            if samples[i].shape[0] == 1:
                                img = samples[i][0] * 255
                                img = np.stack([img, img, img], axis=-1).astype(np.uint8)
                            else:
                                img = samples[i].transpose(1,2,0) * 255
                                img = img.astype(np.uint8)
                            pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                            grid_img.paste(pil_img, (col*thumb, row*thumb))
                    self.root.after(0, lambda g=grid_img, t=t: self._update_progressive(g, t))
                    time.sleep(0.05)
            if not self.progressive_active:
                self.root.after(0, lambda: self.gen_info.config(text="Progressive stopped."))
            else:
                self.root.after(0, lambda: self.gen_info.config(text="Progressive finished."))
        except Exception as e:
            self.root.after(0, lambda: self.gen_info.config(text=f"Error: {e}"))
        finally:
            self.progressive_active = False
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_prog_btn.config(state=tk.DISABLED))

    def _display_generated(self, grid_img):
        for widget in self.inner_frame.winfo_children():
            widget.destroy()
        self.gen_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.gen_photo)
        label.image = self.gen_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text="Generation complete.")

    def _update_progressive(self, grid_img, t):
        for widget in self.inner_frame.winfo_children():
            widget.destroy()
        self.prog_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.prog_photo)
        label.image = self.prog_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text=f"Step {t}/{self.dit_model.T}")

# ==================== Main ====================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = DiTApp(root)
    root.mainloop()