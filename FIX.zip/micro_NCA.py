import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import time
import math
from dataclasses import dataclass
from typing import List, Optional, Dict, Any
from torchvision import transforms

# ----------------------------------------------------------------------
# Configuration dataclass (plain values, no Tkinter vars)
# ----------------------------------------------------------------------
@dataclass
class TrainConfig:
    img_size: int = 64
    n_lap: int = 2
    n_x: int = 1
    n_y: int = 1
    lr: float = 1e-3
    n_steps_per_iter: int = 32
    batch_size: int = 4
    seed_rate: int = 4
    pool_size: int = 32
    patch_size: int = 7
    n_pyramid_levels: int = 3
    subsample_patches: int = 1024
    overflow_weight: float = 0.01
    preview_epochs: int = 10
    sinkhorn_epsilon: float = 0.05
    sinkhorn_max_iter: int = 30
    grad_norm_eps: float = 1e-8

    @property
    def C(self) -> int:
        return self.n_lap + self.n_x + self.n_y

    @property
    def num_params(self) -> int:
        c = self.C
        return 4 * c * c + c

# ----------------------------------------------------------------------
# Helper functions
# ----------------------------------------------------------------------
def load_image_as_rgb(path: str) -> Image.Image:
    img = Image.open(path)
    if img.mode == 'RGBA':
        bg = Image.new('RGB', img.size, (0, 0, 0))
        bg.paste(img, mask=img.split()[3])
        return bg
    return img.convert('RGB')

def gaussian_kernel(size: int = 5, sigma: float = 1.0) -> torch.Tensor:
    k = size // 2
    x = torch.arange(-k, k+1, dtype=torch.float32)
    y = torch.arange(-k, k+1, dtype=torch.float32)
    xx, yy = torch.meshgrid(x, y, indexing='ij')
    kernel = torch.exp(-(xx**2 + yy**2) / (2 * sigma**2))
    kernel = kernel / kernel.sum()
    return kernel.view(1, 1, size, size)

# ----------------------------------------------------------------------
# μNCA Model
# ----------------------------------------------------------------------
def get_fixed_kernels(device: str = 'cpu'):
    laplacian = torch.tensor([[0, 1, 0],
                              [1,-4, 1],
                              [0, 1, 0]], dtype=torch.float32, device=device).view(1,1,3,3)
    sobel_x = torch.tensor([[-1, 0, 1],
                            [-2, 0, 2],
                            [-1, 0, 1]], dtype=torch.float32, device=device).view(1,1,3,3)
    sobel_y = torch.tensor([[-1,-2,-1],
                            [ 0, 0, 0],
                            [ 1, 2, 1]], dtype=torch.float32, device=device).view(1,1,3,3)
    return laplacian, sobel_x, sobel_y

class MicroNCA(nn.Module):
    def __init__(self, config: TrainConfig):
        super().__init__()
        self.config = config
        C = config.C
        self.W = nn.Parameter(torch.randn(4 * C, C) * 0.02)
        self.b = nn.Parameter(torch.zeros(C))
        lap, sob_x, sob_y = get_fixed_kernels()
        self.register_buffer('lap_kernel', lap)
        self.register_buffer('sobel_x_kernel', sob_x)
        self.register_buffer('sobel_y_kernel', sob_y)

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        B, C, H, W = state.shape
        assert C == self.config.C
        filtered = []
        if self.config.n_lap > 0:
            lap_k = self.lap_kernel.expand(self.config.n_lap, 1, 3, 3)
            lap_feat = F.conv2d(state[:, :self.config.n_lap], lap_k, padding=1, groups=self.config.n_lap)
            filtered.append(lap_feat)
        if self.config.n_x > 0:
            sobelx_k = self.sobel_x_kernel.expand(self.config.n_x, 1, 3, 3)
            sobelx_feat = F.conv2d(state[:, self.config.n_lap:self.config.n_lap+self.config.n_x],
                                   sobelx_k, padding=1, groups=self.config.n_x)
            filtered.append(sobelx_feat)
        if self.config.n_y > 0:
            sobely_k = self.sobel_y_kernel.expand(self.config.n_y, 1, 3, 3)
            sobely_feat = F.conv2d(state[:, self.config.n_lap+self.config.n_x:],
                                   sobely_k, padding=1, groups=self.config.n_y)
            filtered.append(sobely_feat)

        f = torch.cat(filtered, dim=1)          # (B, C, H, W)
        p = torch.cat([state, f], dim=1)        # (B, 2C, H, W)
        y = torch.cat([p, torch.abs(p)], dim=1) # (B, 4C, H, W)
        y_flat = y.view(B, 4*C, H*W).permute(0, 2, 1)  # (B, H*W, 4C)
        delta = torch.matmul(y_flat, self.W)            # (B, H*W, C)
        delta = delta.permute(0, 2, 1).view(B, C, H, W) + self.b.view(1, C, 1, 1)
        return state + delta

# ----------------------------------------------------------------------
# OTT Loss
# ----------------------------------------------------------------------
def extract_pyramid_patches(
    img_tensor: torch.Tensor,
    config: TrainConfig,
    sharpen: bool = True
) -> List[torch.Tensor]:
    device = img_tensor.device
    B = img_tensor.shape[0]
    img = (img_tensor + 1) / 2
    patches_per_level = []
    gauss_kernel = gaussian_kernel(5, 1.0).to(device)
    gauss_kernel_rgb = gauss_kernel.repeat(3, 1, 1, 1)

    current = img
    for level in range(config.n_pyramid_levels):
        if sharpen:
            blurred = F.conv2d(current, gauss_kernel_rgb, padding=2, groups=3)
            sharp = current + 2 * (current - blurred)
        else:
            sharp = current

        patches = sharp.unfold(2, config.patch_size, 1).unfold(3, config.patch_size, 1)
        B, C, Hp, Wp, pH, pW = patches.shape
        patches = patches.permute(0, 2, 3, 1, 4, 5).contiguous()
        patches = patches.view(B, Hp * Wp, C * pH * pW)

        if config.subsample_patches > 0 and patches.size(1) > config.subsample_patches:
            idx = torch.randperm(patches.size(1), device=device)[:config.subsample_patches]
            patches = patches[:, idx, :]

        patches_flat = patches.view(-1, patches.size(-1))
        # Normalize patches to unit variance to improve Sinkhorn stability
        patches_flat = patches_flat / (patches_flat.std(dim=0, keepdim=True) + 1e-8)
        patches_per_level.append(patches_flat)

        current = F.interpolate(current, scale_factor=0.5, mode='bilinear', align_corners=False)

    return patches_per_level

def sinkhorn_divergence(
    X: torch.Tensor, Y: torch.Tensor,
    epsilon: float = 0.05, max_iter: int = 30
) -> torch.Tensor:
    n, m = X.shape[0], Y.shape[0]
    if n == 0 or m == 0:
        return torch.tensor(0.0, device=X.device)

    # Compute pairwise squared Euclidean distances
    X_norm = (X * X).sum(dim=1, keepdim=True)
    Y_norm = (Y * Y).sum(dim=1, keepdim=True)
    C = X_norm + Y_norm.T - 2 * torch.mm(X, Y.T)
    # Scale to avoid numerical issues
    C = C / (C.max() + 1e-8)

    a = torch.ones(n, device=X.device) / n
    b = torch.ones(m, device=X.device) / m
    K = torch.exp(-C / epsilon)
    u = torch.ones_like(a)
    v = torch.ones_like(b)

    for _ in range(max_iter):
        u = a / (K @ v + 1e-16)
        v = b / (K.T @ u + 1e-16)

    P = u[:, None] * K * v[None, :]
    loss = (P * C).sum()
    return loss

def texture_loss(
    gen_patches: List[torch.Tensor],
    target_patches: List[torch.Tensor],
    config: TrainConfig
) -> torch.Tensor:
    loss = 0.0
    for g, t in zip(gen_patches, target_patches):
        if g.shape[0] == 0 or t.shape[0] == 0:
            continue
        loss += sinkhorn_divergence(g, t, config.sinkhorn_epsilon, config.sinkhorn_max_iter)
    return loss

# ----------------------------------------------------------------------
# Gradient normalisation hooks
# ----------------------------------------------------------------------
def norm_grad(x: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    def hook(grad: torch.Tensor) -> torch.Tensor:
        norm = grad.norm() + eps
        return grad / norm
    if x.requires_grad:
        x.register_hook(hook)
    return x

# ----------------------------------------------------------------------
# GUI Application
# ----------------------------------------------------------------------
class MicroNCAApp:
    def __init__(self, root):
        self.root = root
        self.root.title("μNCA - Ultra‑compact Neural Cellular Automata")
        self.root.geometry("1200x800")

        self.target_image_path: Optional[str] = None
        self.target_patches: Optional[List[torch.Tensor]] = None
        self.model: Optional[MicroNCA] = None
        self.optimizer: Optional[optim.Adam] = None
        self.training = False
        self.message_queue = queue.Queue()

        # Tkinter variable storage
        self.vars: Dict[str, tk.Variable] = {}
        self._init_vars()

        # Current configuration (will be rebuilt from vars when needed)
        self.config = self._build_config_from_vars()

        self.setup_gui()
        self.root.after(100, self.process_messages)

    def _init_vars(self):
        """Initialize all Tkinter variables with default values from TrainConfig."""
        defaults = TrainConfig()
        self.vars['img_size'] = tk.IntVar(value=defaults.img_size)
        self.vars['n_lap'] = tk.IntVar(value=defaults.n_lap)
        self.vars['n_x'] = tk.IntVar(value=defaults.n_x)
        self.vars['n_y'] = tk.IntVar(value=defaults.n_y)
        self.vars['lr'] = tk.DoubleVar(value=defaults.lr)
        self.vars['n_steps_per_iter'] = tk.IntVar(value=defaults.n_steps_per_iter)
        self.vars['batch_size'] = tk.IntVar(value=defaults.batch_size)
        self.vars['seed_rate'] = tk.IntVar(value=defaults.seed_rate)
        self.vars['pool_size'] = tk.IntVar(value=defaults.pool_size)
        self.vars['patch_size'] = tk.IntVar(value=defaults.patch_size)
        self.vars['n_pyramid_levels'] = tk.IntVar(value=defaults.n_pyramid_levels)
        self.vars['subsample_patches'] = tk.IntVar(value=defaults.subsample_patches)
        self.vars['overflow_weight'] = tk.DoubleVar(value=defaults.overflow_weight)
        self.vars['preview_epochs'] = tk.IntVar(value=defaults.preview_epochs)

    def _build_config_from_vars(self) -> TrainConfig:
        """Build a TrainConfig instance from the current Tkinter variable values."""
        return TrainConfig(
            img_size=self.vars['img_size'].get(),
            n_lap=self.vars['n_lap'].get(),
            n_x=self.vars['n_x'].get(),
            n_y=self.vars['n_y'].get(),
            lr=self.vars['lr'].get(),
            n_steps_per_iter=self.vars['n_steps_per_iter'].get(),
            batch_size=self.vars['batch_size'].get(),
            seed_rate=self.vars['seed_rate'].get(),
            pool_size=self.vars['pool_size'].get(),
            patch_size=self.vars['patch_size'].get(),
            n_pyramid_levels=self.vars['n_pyramid_levels'].get(),
            subsample_patches=self.vars['subsample_patches'].get(),
            overflow_weight=self.vars['overflow_weight'].get(),
            preview_epochs=self.vars['preview_epochs'].get(),
        )

    def _update_vars_from_config(self, cfg: TrainConfig):
        """Set Tkinter variables from a TrainConfig (used when loading a model)."""
        for key, var in self.vars.items():
            if hasattr(cfg, key):
                var.set(getattr(cfg, key))

    # ---------------------------- GUI Setup ----------------------------
    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.train_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.train_tab, text='Training')
        self.setup_train_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.gen_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.gen_tab, text='Generation')
        self.setup_gen_tab()

        self.status_label = tk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_train_tab(self):
        main_frame = tk.Frame(self.train_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="μNCA Texture Training", font=("Arial",12,"bold")).pack(pady=(0,10))

        img_frame = tk.LabelFrame(left_frame, text="Target Texture", padx=5, pady=5)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Load Image", command=self.load_target_image, width=20).pack(pady=2)
        self.target_label = tk.Label(img_frame, text="No image loaded", fg="red")
        self.target_label.pack(pady=2)

        tk.Button(left_frame, text="Initialize Model", command=self.init_model, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start Training", command=self.start_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop Training", command=self.stop_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save Model", command=self.save_model, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load Model", command=self.load_model, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Preview", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.train_preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=256)
        self.train_preview_canvas.pack()

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        arch_frame = tk.LabelFrame(scrollable_frame, text="Model Architecture", padx=10, pady=10)
        arch_frame.pack(fill=tk.X, pady=5)

        self._add_scale(arch_frame, "Laplacian channels (n_lap):", 'n_lap', 0, 8, 1)
        self._add_scale(arch_frame, "Sobel-X channels (n_x):", 'n_x', 0, 8, 1)
        self._add_scale(arch_frame, "Sobel-Y channels (n_y):", 'n_y', 0, 8, 1)

        self.param_label = tk.Label(arch_frame, text="Parameters: 0", fg="blue")
        self.param_label.pack(pady=5)
        for key in ['n_lap','n_x','n_y']:
            self.vars[key].trace_add('write', lambda *a: self.update_param_count())

        train_frame = tk.LabelFrame(scrollable_frame, text="Training", padx=10, pady=10)
        train_frame.pack(fill=tk.X, pady=5)
        self._add_scale(train_frame, "Learning rate:", 'lr', 1e-5, 1e-2, log=True)
        self._add_scale(train_frame, "CA steps per iteration:", 'n_steps_per_iter', 1, 100, 1)
        self._add_scale(train_frame, "Batch size:", 'batch_size', 1, 16, 1)
        self._add_scale(train_frame, "Seed rate (every N iters):", 'seed_rate', 1, 20, 1)
        self._add_scale(train_frame, "State pool size:", 'pool_size', 8, 64, 1)
        self._add_scale(train_frame, "Overflow loss weight:", 'overflow_weight', 0.0, 0.1, 0.001)

        ott_frame = tk.LabelFrame(scrollable_frame, text="OTT Loss", padx=10, pady=10)
        ott_frame.pack(fill=tk.X, pady=5)
        self._add_scale(ott_frame, "Patch size:", 'patch_size', 3, 15, 1)
        self._add_scale(ott_frame, "Pyramid levels:", 'n_pyramid_levels', 1, 4, 1)
        self._add_scale(ott_frame, "Subsample patches:", 'subsample_patches', 0, 2048, 1)

        preview_frame = tk.LabelFrame(scrollable_frame, text="Preview", padx=10, pady=10)
        preview_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(preview_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Preview every N epochs:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Spinbox(f, from_=1, to=50, textvariable=self.vars['preview_epochs'], width=5).pack(side=tk.RIGHT)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def _add_scale(self, parent, label, key, low, high, resolution=None, log=False):
        f = tk.Frame(parent); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text=label, width=30, anchor='w').pack(side=tk.LEFT)
        var = self.vars[key]
        if log:
            scale = tk.Scale(f, from_=math.log10(low), to=math.log10(high), resolution=0.01,
                             orient=tk.HORIZONTAL, length=200,
                             command=lambda v, k=key: self.vars[k].set(10**float(v)))
            scale.set(math.log10(var.get()))
        else:
            res = resolution if resolution is not None else 1
            scale = tk.Scale(f, from_=low, to=high, variable=var,
                             orient=tk.HORIZONTAL, length=200, resolution=res)
        scale.pack(side=tk.RIGHT)
        tk.Label(f, textvariable=var, width=8).pack(side=tk.RIGHT)

    def update_param_count(self):
        n_lap = self.vars['n_lap'].get()
        n_x = self.vars['n_x'].get()
        n_y = self.vars['n_y'].get()
        C = n_lap + n_x + n_y
        params = 4*C*C + C
        self.param_label.config(text=f"Parameters: {params} (C={C})")

    def setup_gen_tab(self):
        main_frame = tk.Frame(self.gen_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        ctrl_frame = tk.Frame(main_frame); ctrl_frame.pack(pady=5)
        tk.Label(ctrl_frame, text="Number of samples:").pack(side=tk.LEFT)
        self.gen_count = tk.IntVar(value=16)
        tk.Spinbox(ctrl_frame, from_=1, to=64, textvariable=self.gen_count, width=5).pack(side=tk.LEFT, padx=5)
        tk.Label(ctrl_frame, text="CA steps:").pack(side=tk.LEFT, padx=(10,0))
        self.gen_steps = tk.IntVar(value=256)
        tk.Spinbox(ctrl_frame, from_=1, to=1000, textvariable=self.gen_steps, width=5).pack(side=tk.LEFT, padx=5)
        self.real_time_preview = tk.BooleanVar(value=False)
        tk.Checkbutton(ctrl_frame, text="Real-time preview", variable=self.real_time_preview).pack(side=tk.LEFT, padx=10)
        self.generate_btn = tk.Button(ctrl_frame, text="Generate", command=self.generate_samples, bg="lightgreen")
        self.generate_btn.pack(side=tk.LEFT, padx=5)
        self.stop_gen_btn = tk.Button(ctrl_frame, text="Stop", command=self.stop_generation,
                                      state=tk.DISABLED, bg="salmon")
        self.stop_gen_btn.pack(side=tk.LEFT, padx=5)

        scroll_frame = tk.LabelFrame(main_frame, text="Results", padx=5, pady=5)
        scroll_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        canvas_frame = tk.Frame(scroll_frame); canvas_frame.pack(fill=tk.BOTH, expand=True)
        self.gen_canvas = tk.Canvas(canvas_frame, bg='lightgray')
        v_scroll = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.gen_canvas.yview)
        h_scroll = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.gen_canvas.xview)
        self.gen_canvas.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)
        v_scroll.pack(side=tk.RIGHT, fill=tk.Y); h_scroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.inner_frame = tk.Frame(self.gen_canvas)
        self.canvas_window = self.gen_canvas.create_window((0,0), window=self.inner_frame, anchor='nw')
        self.inner_frame.bind('<Configure>', lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all')))
        self.gen_info = tk.Label(main_frame, text="", fg="blue")
        self.gen_info.pack()
        self.generation_active = False

    # ---------------------------- Logging ----------------------------
    def log(self, msg):
        self.message_queue.put(msg)

    def process_messages(self):
        try:
            while True:
                msg = self.message_queue.get_nowait()
                self.log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages)

    # ---------------------------- Core Methods ----------------------------
    def load_target_image(self):
        path = filedialog.askopenfilename(filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp")])
        if path:
            self.target_image_path = path
            self.target_label.config(text=os.path.basename(path), fg="green")
            self.log(f"Loaded target texture: {path}")
            self.precompute_target_patches()

    def precompute_target_patches(self):
        if not self.target_image_path:
            return
        cfg = self._build_config_from_vars()
        img = load_image_as_rgb(self.target_image_path)
        transform = transforms.Compose([
            transforms.Resize((cfg.img_size, cfg.img_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
        img_tensor = transform(img).unsqueeze(0)
        self.target_patches = extract_pyramid_patches(img_tensor, cfg, sharpen=True)
        self.log(f"Precomputed target patches: {len(self.target_patches)} levels")

    def init_model(self):
        if not self.target_image_path:
            self.log("Please load a target texture image first.")
            return
        self.config = self._build_config_from_vars()
        self.model = MicroNCA(self.config)
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.config.lr)
        self.log(f"Model initialized. Parameters: {self.config.num_params}")
        self.update_param_count()

    def overflow_loss(self, state):
        return torch.mean(F.relu(torch.abs(state) - 1.0))

    def train_loop(self, epochs):
        try:
            cfg = self.config = self._build_config_from_vars()
            device = 'cpu'
            self.model.train()
            C = cfg.C
            img_size = cfg.img_size
            pool_size = cfg.pool_size
            n_steps = cfg.n_steps_per_iter
            seed_rate = cfg.seed_rate
            batch_size = cfg.batch_size
            overflow_weight = cfg.overflow_weight

            pool = [torch.rand(1, C, img_size, img_size) - 0.5 for _ in range(pool_size)]
            if self.target_patches is None:
                self.precompute_target_patches()

            for epoch in range(epochs):
                if not self.training:
                    break
                epoch_loss = 0.0
                for iter_idx in range(20):
                    indices = torch.randint(0, pool_size, (batch_size,)).tolist()
                    x = torch.cat([pool[i].clone().detach().requires_grad_(True) for i in indices], dim=0)

                    if iter_idx % seed_rate == 0:
                        x[0] = torch.rand(1, C, img_size, img_size) - 0.5

                    for _ in range(n_steps):
                        x = self.model(x)
                        x = norm_grad(x, cfg.grad_norm_eps)

                    rgb = x[:, :3].clamp(-1, 1)
                    gen_patches = extract_pyramid_patches(rgb, cfg, sharpen=True)
                    loss_tex = texture_loss(gen_patches, self.target_patches, cfg)
                    loss_overflow = self.overflow_loss(x)
                    loss = loss_tex + overflow_weight * loss_overflow

                    if torch.isnan(loss) or torch.isinf(loss):
                        self.log("NaN/Inf loss - stopping training")
                        self.training = False
                        break

                    self.optimizer.zero_grad()
                    loss.backward()

                    # Global gradient normalisation
                    total_norm = 0.0
                    for p in self.model.parameters():
                        if p.grad is not None:
                            total_norm += p.grad.data.norm(2).item() ** 2
                    total_norm = total_norm ** 0.5 + cfg.grad_norm_eps
                    for p in self.model.parameters():
                        if p.grad is not None:
                            p.grad.data /= total_norm

                    # Gradient clipping for extra safety
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)

                    self.optimizer.step()
                    epoch_loss += loss.item()

                    for i, idx in enumerate(indices):
                        pool[idx] = x[i].detach().unsqueeze(0)

                if not self.training:
                    break
                avg_loss = epoch_loss / 20
                self.log(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f}")
                if (epoch+1) % cfg.preview_epochs == 0:
                    self.show_train_preview(cfg)

            self.training = False
            self.log("Training finished.")
        except Exception as e:
            self.log(f"Training error: {e}")
            import traceback; traceback.print_exc()
            self.training = False

    @torch.no_grad()
    def show_train_preview(self, cfg: TrainConfig):
        if self.model is None:
            return
        self.model.eval()
        C = cfg.C
        img_size = cfg.img_size
        state = torch.rand(1, C, img_size, img_size) - 0.5
        for _ in range(200):
            state = self.model(state)
        rgb = state[0, :3].clamp(-1, 1).detach().cpu().numpy().transpose(1,2,0)
        rgb = (rgb + 1) / 2
        rgb = (rgb * 255).astype(np.uint8)
        pil_img = Image.fromarray(rgb).resize((256,256), Image.NEAREST)
        self.train_preview_photo = ImageTk.PhotoImage(pil_img)
        self.train_preview_canvas.delete("all")
        self.train_preview_canvas.create_image(128,128, image=self.train_preview_photo)
        self.model.train()

    def start_training(self):
        if self.model is None:
            self.log("Model not initialized. Click 'Initialize Model' first.")
            return
        if self.target_patches is None:
            self.log("No target texture patches. Load an image and precompute.")
            return
        if self.training:
            self.log("Already training.")
            return
        try:
            epochs = int(self.epoch_var.get())
        except:
            self.log("Invalid epochs")
            return
        self.training = True
        threading.Thread(target=self.train_loop, args=(epochs,), daemon=True).start()
        self.log(f"Training started for {epochs} epochs.")

    def stop_training(self):
        self.training = False
        self.log("Stopping training...")

    def save_model(self):
        if self.model is None:
            self.log("No model to save.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".pth", filetypes=[("PyTorch", "*.pth")])
        if path:
            cfg = self._build_config_from_vars()
            torch.save({
                'model_state': self.model.state_dict(),
                'optimizer_state': self.optimizer.state_dict(),
                'config': cfg
            }, path)
            self.log(f"Model saved to {path}")

    def load_model(self):
        path = filedialog.askopenfilename(filetypes=[("PyTorch", "*.pth")])
        if not path:
            return
        ckpt = torch.load(path, map_location='cpu')
        saved_cfg = ckpt.get('config')
        if saved_cfg:
            self._update_vars_from_config(saved_cfg)
        self.config = self._build_config_from_vars()
        self.model = MicroNCA(self.config)
        self.model.load_state_dict(ckpt['model_state'])
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.config.lr)
        if 'optimizer_state' in ckpt:
            self.optimizer.load_state_dict(ckpt['optimizer_state'])
        self.log(f"Model loaded from {path}")

    # ---------------------------- Generation ----------------------------
    @torch.no_grad()
    def generate_samples(self):
        if self.model is None:
            self.gen_info.config(text="Model not loaded!")
            return
        self.generation_active = True
        self.generate_btn.config(state=tk.DISABLED)
        self.stop_gen_btn.config(state=tk.NORMAL)
        self.gen_info.config(text="Generating...")
        threading.Thread(target=self._generate_thread, daemon=True).start()

    def stop_generation(self):
        self.generation_active = False
        self.stop_gen_btn.config(state=tk.DISABLED)
        self.gen_info.config(text="Generation stopped.")

    def _generate_thread(self):
        try:
            n_samples = self.gen_count.get()
            n_steps = self.gen_steps.get()
            realtime = self.real_time_preview.get()
            cfg = self.config
            C = cfg.C
            img_size = cfg.img_size
            self.model.eval()
            states = torch.rand(n_samples, C, img_size, img_size) - 0.5
            for step in range(n_steps):
                if not self.generation_active:
                    break
                states = self.model(states)
                if realtime and (step % 20 == 0 or step == n_steps-1):
                    rgb = states[:, :3].clamp(-1, 1).detach().cpu().numpy()
                    thumb = 128
                    grid_size = int(math.ceil(math.sqrt(n_samples)))
                    total = grid_size * thumb
                    grid_img = Image.new('RGB', (total, total), color=(128,128,128))
                    for i in range(n_samples):
                        row = i // grid_size
                        col = i % grid_size
                        img = rgb[i].transpose(1,2,0)
                        img = (img + 1) / 2
                        img = (img * 255).astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid_img.paste(pil_img, (col*thumb, row*thumb))
                    self.root.after(0, lambda g=grid_img, s=step, t=n_steps: self._update_gen_display(g, s, t))
            if self.generation_active:
                self.root.after(0, lambda: self.gen_info.config(text="Generation complete."))
            self.model.train()
        except Exception as e:
            self.root.after(0, lambda e=e: self.gen_info.config(text=f"Error: {e}"))
        finally:
            self.generation_active = False
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_gen_btn.config(state=tk.DISABLED))

    def _update_gen_display(self, grid_img, step, total_steps):
        for w in self.inner_frame.winfo_children():
            w.destroy()
        self.gen_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.gen_photo)
        label.image = self.gen_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text=f"Step {step}/{total_steps}")

# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = MicroNCAApp(root)
    root.mainloop()