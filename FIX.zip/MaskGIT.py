import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F_vision
import torch.nn.functional as F
from PIL import Image, ImageTk, ImageDraw
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
import math
from typing import Optional, List, Tuple

# ==================== Helper Functions ====================

def load_image_as_rgb(path):
    img = Image.open(path)
    if img.mode == 'RGBA':
        bg = Image.new('RGB', img.size, (0, 0, 0))
        bg.paste(img, mask=img.split()[3])
        return bg
    else:
        return img.convert('RGB')

def load_image_as_grayscale(path):
    return Image.open(path).convert('L')

def text_to_indices(text, max_len=128):
    indices = [ord(ch) if ord(ch) < 256 else 0 for ch in text[:max_len]]
    if len(indices) < max_len:
        indices += [0] * (max_len - len(indices))
    return indices

# ==================== VQVAE with flexible downsampling ====================

class VectorQuantizer(nn.Module):
    def __init__(self, num_embeddings, embedding_dim, commitment_cost=0.25):
        super().__init__()
        self.num_embeddings = num_embeddings
        self.embedding_dim = embedding_dim
        self.commitment_cost = commitment_cost
        self.embedding = nn.Embedding(num_embeddings, embedding_dim)
        self.embedding.weight.data.uniform_(-1/num_embeddings, 1/num_embeddings)

    def forward(self, z):
        z_flattened = z.permute(0, 2, 3, 1).contiguous()
        z_flattened = z_flattened.view(-1, self.embedding_dim)
        distances = (z_flattened.pow(2).sum(1, keepdim=True)
                     - 2 * z_flattened @ self.embedding.weight.t()
                     + self.embedding.weight.pow(2).sum(1, keepdim=True).t())
        indices = distances.argmin(dim=1)
        z_q = self.embedding(indices).view(z.shape[0], z.shape[2], z.shape[3], self.embedding_dim)
        z_q = z_q.permute(0, 3, 1, 2).contiguous()
        codebook_loss = F.mse_loss(z_q.detach(), z)
        commitment_loss = F.mse_loss(z_q, z.detach())
        vq_loss = codebook_loss + self.commitment_cost * commitment_loss
        z_q_st = z + (z_q - z).detach()
        return z_q_st, vq_loss, indices

class VQEncoder(nn.Module):
    def __init__(self, in_channels=3, base_channels=32, embed_dim=64, num_stages=2):
        super().__init__()
        self.num_stages = num_stages
        layers = []
        ch = in_channels
        for i in range(num_stages):
            out_ch = base_channels * (2 ** i) if i < num_stages-1 else embed_dim
            layers.append(nn.Conv2d(ch, out_ch, 4, stride=2, padding=1))
            if i < num_stages-1:
                layers.append(nn.LeakyReLU(0.2))
            ch = out_ch
        self.net = nn.Sequential(*layers)
        self.act = nn.LeakyReLU(0.2)

    def forward(self, x):
        return self.act(self.net(x))

class VQDecoder(nn.Module):
    def __init__(self, embed_dim=64, base_channels=32, out_channels=3, num_stages=2):
        super().__init__()
        self.num_stages = num_stages
        layers = []
        ch = embed_dim
        for i in range(num_stages-1, -1, -1):
            out_ch = base_channels * (2 ** i) if i > 0 else out_channels
            layers.append(nn.ConvTranspose2d(ch, out_ch, 4, stride=2, padding=1))
            if i > 0:
                layers.append(nn.LeakyReLU(0.2))
            ch = out_ch
        self.net = nn.Sequential(*layers)

    def forward(self, z):
        return torch.tanh(self.net(z))

class VQVAE(nn.Module):
    def __init__(self, in_channels=3, base_channels=32, embed_dim=64,
                 num_embeddings=512, commitment_cost=0.25, img_size=32, downsample_factor=4):
        super().__init__()
        import math
        self.num_stages = int(math.log2(downsample_factor))
        if 2**self.num_stages != downsample_factor:
            raise ValueError(f"downsample_factor must be a power of 2, got {downsample_factor}")

        self.encoder = VQEncoder(in_channels, base_channels, embed_dim, self.num_stages)
        self.quantizer = VectorQuantizer(num_embeddings, embed_dim, commitment_cost)
        self.decoder = VQDecoder(embed_dim, base_channels, in_channels, self.num_stages)
        self.embed_dim = embed_dim
        self.num_embeddings = num_embeddings
        self.img_size = img_size
        self.downsample_factor = downsample_factor
        self.latent_h = img_size // downsample_factor
        self.latent_w = img_size // downsample_factor
        if img_size % downsample_factor != 0:
            raise ValueError(f"Image size {img_size} must be divisible by downsample factor {downsample_factor}")

    def forward(self, x):
        z = self.encoder(x)
        z_q, vq_loss, indices = self.quantizer(z)
        recon = self.decoder(z_q)
        return recon, vq_loss, indices

    def encode_indices(self, x):
        z = self.encoder(x)
        _, _, indices = self.quantizer(z)
        return indices.view(x.size(0), -1)

    def decode_from_indices(self, indices):
        if indices.dim() == 1:
            indices = indices.unsqueeze(0)
        device = next(self.parameters()).device
        indices = indices.to(device)
        indices = torch.where(indices >= self.num_embeddings, torch.zeros_like(indices), indices)
        if indices.shape[-1] != self.latent_h * self.latent_w:
            raise ValueError(f"Token length {indices.shape[-1]} != latent size {self.latent_h*self.latent_w}")
        z_q = self.quantizer.embedding(indices)
        z_q = z_q.view(-1, self.latent_h, self.latent_w, self.embed_dim).permute(0,3,1,2)
        return self.decoder(z_q)

# VQVAE size presets
VQVAE_SIZE_CONFIGS = {
    'tiny':   {'base_channels': 16, 'embed_dim': 32,  'num_embeddings': 256},
    'small':  {'base_channels': 24, 'embed_dim': 48,  'num_embeddings': 384},
    'medium': {'base_channels': 32, 'embed_dim': 64,  'num_embeddings': 512},
    'big':    {'base_channels': 48, 'embed_dim': 96,  'num_embeddings': 768},
    'large':  {'base_channels': 64, 'embed_dim': 128, 'num_embeddings': 1024},
}

# ==================== Text Encoder ====================

class TextEncoder(nn.Module):
    def __init__(self, vocab_size=256, embed_dim=64, hidden_size=64, num_layers=2, cond_dim=256):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.gru = nn.GRU(embed_dim, hidden_size, num_layers,
                          batch_first=True, bidirectional=True, dropout=0.1 if num_layers>1 else 0)
        self.fc = nn.Linear(hidden_size * 2, cond_dim)

    def forward(self, x):
        emb = self.embedding(x)
        _, h = self.gru(emb)
        h_fwd = h[-2, :, :]
        h_bwd = h[-1, :, :]
        h_cat = torch.cat([h_fwd, h_bwd], dim=1)
        return self.fc(h_cat)

# ==================== MaskGIT Models ====================

class BidirectionalTransformerBlock(nn.Module):
    def __init__(self, embed_dim, num_heads, mlp_ratio=4.0, dropout=0.1):
        super().__init__()
        self.ln1 = nn.LayerNorm(embed_dim)
        self.attn = nn.MultiheadAttention(embed_dim, num_heads, dropout=dropout, batch_first=True)
        self.ln2 = nn.LayerNorm(embed_dim)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, int(embed_dim * mlp_ratio)),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(int(embed_dim * mlp_ratio), embed_dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        residual = x
        x = self.ln1(x)
        x, _ = self.attn(x, x, x, need_weights=False)
        x = residual + x
        residual = x
        x = self.ln2(x)
        x = self.mlp(x)
        x = residual + x
        return x

class MaskGITBiTransformer(nn.Module):
    def __init__(self, vocab_size, max_seq_len, embed_dim=256, num_layers=6,
                 num_heads=4, mlp_ratio=4.0, dropout=0.1, cond_dim=None):
        super().__init__()
        self.vocab_size = vocab_size
        self.max_seq_len = max_seq_len
        self.embed_dim = embed_dim
        self.cond_dim = cond_dim

        self.token_embedding = nn.Embedding(vocab_size, embed_dim)
        self.pos_embedding = nn.Embedding(max_seq_len, embed_dim)

        if cond_dim is not None:
            self.cond_proj = nn.Linear(cond_dim, embed_dim)

        self.blocks = nn.ModuleList([
            BidirectionalTransformerBlock(embed_dim, num_heads, mlp_ratio, dropout)
            for _ in range(num_layers)
        ])
        self.ln_f = nn.LayerNorm(embed_dim)
        self.head = nn.Linear(embed_dim, vocab_size)

    def forward(self, x, cond=None):
        B, T = x.shape
        tok_emb = self.token_embedding(x)
        pos_emb = self.pos_embedding(torch.arange(T, device=x.device))
        x_emb = tok_emb + pos_emb.unsqueeze(0)

        if cond is not None and self.cond_dim is not None:
            cond_emb = self.cond_proj(cond).unsqueeze(1)
            x_emb = x_emb + cond_emb

        for block in self.blocks:
            x_emb = block(x_emb)

        x_emb = self.ln_f(x_emb)
        logits = self.head(x_emb)
        return logits

class MaskGITBiGRU(nn.Module):
    def __init__(self, vocab_size, max_seq_len, embed_dim=128, hidden_size=256,
                 num_layers=2, dropout=0.1, cond_dim=None):
        super().__init__()
        self.vocab_size = vocab_size
        self.max_seq_len = max_seq_len
        self.embed_dim = embed_dim
        self.hidden_size = hidden_size
        self.cond_dim = cond_dim

        self.token_embedding = nn.Embedding(vocab_size, embed_dim)
        self.pos_embedding = nn.Parameter(torch.randn(1, max_seq_len, embed_dim))

        self.gru = nn.GRU(embed_dim, hidden_size, num_layers,
                          batch_first=True, bidirectional=True,
                          dropout=dropout if num_layers>1 else 0)

        if cond_dim is not None:
            self.cond_proj = nn.Linear(cond_dim, embed_dim)

        self.fc = nn.Linear(hidden_size * 2, vocab_size)

    def forward(self, x, cond=None):
        B, T = x.shape
        emb = self.token_embedding(x) + self.pos_embedding[:, :T, :]
        if cond is not None and self.cond_dim is not None:
            cond_emb = self.cond_proj(cond).unsqueeze(1)
            emb = emb + cond_emb
        out, _ = self.gru(emb)
        logits = self.fc(out)
        return logits

# ==================== MaskGIT Utilities ====================

def cosine_mask_schedule(t, T, s=0.008):
    if isinstance(t, (int, float)) and isinstance(T, (int, float)):
        return math.cos((t/T + s) / (1 + s) * math.pi / 2) ** 2
    else:
        pi = torch.pi if hasattr(torch, 'pi') else math.pi
        return torch.cos((t/T + s) / (1 + s) * pi / 2) ** 2

def get_mask_ratio(step, total_steps, schedule='cosine'):
    if schedule == 'cosine':
        return cosine_mask_schedule(step, total_steps)
    elif schedule == 'linear':
        return 1 - step / total_steps
    else:
        raise ValueError(f"Unknown schedule {schedule}")

class MaskGITWrapper:
    def __init__(self, model, mask_token_id, T=8, schedule='cosine', device='cpu'):
        self.model = model
        self.mask_token_id = mask_token_id
        self.T = T
        self.schedule = schedule
        self.device = device

    def train_step(self, x, cond=None, mask_ratio=None):
        B, L = x.shape
        if mask_ratio is None:
            mask_ratio = random.random() * 0.9 + 0.05
        mask = torch.rand(B, L, device=self.device) < mask_ratio
        masked_x = x.clone()
        masked_x[mask] = self.mask_token_id

        logits = self.model(masked_x, cond=cond)
        loss = F.cross_entropy(logits[mask], x[mask])
        return loss

    @torch.no_grad()
    def sample(self, n_samples, cond=None, steps=None, temperature=1.0, fixed_tokens=None, fixed_mask=None):
        if steps is None:
            steps = self.T
        L = self.model.max_seq_len
        device = self.device

        x = torch.full((n_samples, L), self.mask_token_id, dtype=torch.long, device=device)
        if fixed_tokens is not None and fixed_mask is not None:
            fixed_tokens = fixed_tokens.to(device)
            fixed_mask = fixed_mask.to(device)
            x = torch.where(fixed_mask, fixed_tokens, x)
            mask = ~fixed_mask
        else:
            mask = torch.ones_like(x, dtype=torch.bool)

        for t in range(steps):
            ratio = get_mask_ratio(t, steps, self.schedule)
            num_to_keep = int(L * (1 - ratio))
            num_to_keep = max(num_to_keep, 1)

            logits = self.model(x, cond=cond)
            probs = F.softmax(logits / temperature, dim=-1)

            sampled = torch.multinomial(probs.view(-1, probs.size(-1)), 1).view(n_samples, L)
            confidence = probs.gather(-1, sampled.unsqueeze(-1)).squeeze(-1)

            x = torch.where(mask, sampled, x)
            confidence = torch.where(mask, confidence, torch.ones_like(confidence))

            if t == steps - 1:
                break

            conf_masked = torch.where(mask, confidence, torch.full_like(confidence, -1e9))
            sorted_conf, _ = torch.sort(conf_masked.view(n_samples, -1), dim=1, descending=True)
            threshold = sorted_conf[:, num_to_keep-1:num_to_keep]
            keep = confidence >= threshold
            mask = (~keep) & (~fixed_mask if fixed_mask is not None else ~keep)
            x = torch.where(mask, torch.full_like(x, self.mask_token_id), x)

        return x

    @torch.no_grad()
    def sample_step_by_step(self, n_samples, cond=None, steps=None, temperature=1.0):
        if steps is None:
            steps = self.T
        L = self.model.max_seq_len
        device = self.device

        x = torch.full((n_samples, L), self.mask_token_id, dtype=torch.long, device=device)
        mask = torch.ones_like(x, dtype=torch.bool)

        for t in range(steps):
            ratio = get_mask_ratio(t, steps, self.schedule)
            num_to_keep = int(L * (1 - ratio))
            num_to_keep = max(num_to_keep, 1)

            logits = self.model(x, cond=cond)
            probs = F.softmax(logits / temperature, dim=-1)

            sampled = torch.multinomial(probs.view(-1, probs.size(-1)), 1).view(n_samples, L)
            confidence = probs.gather(-1, sampled.unsqueeze(-1)).squeeze(-1)

            x = torch.where(mask, sampled, x)
            confidence = torch.where(mask, confidence, torch.ones_like(confidence))

            if t < steps - 1:
                sorted_conf, _ = torch.sort(confidence.view(n_samples, -1), dim=1, descending=True)
                threshold = sorted_conf[:, num_to_keep-1:num_to_keep]
                keep = confidence >= threshold
                mask = ~keep
                x = torch.where(mask, torch.full_like(x, self.mask_token_id), x)

            yield t, x.clone()

# ==================== Dataset ====================

class ConditionalImageDataset(Dataset):
    def __init__(self, image_paths, labels, img_size=32, color_mode='rgb',
                 aug_settings=None, text_max_len=128):
        self.image_paths = image_paths
        self.labels = labels
        self.img_size = img_size
        self.color_mode = color_mode.lower()
        self.aug_settings = aug_settings or {}
        self.text_max_len = text_max_len
        if self.color_mode == 'rgb':
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.5,))
            ])

    def __len__(self):
        return len(self.image_paths)

    def apply_augmentations(self, pil_img):
        img = pil_img.copy()
        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F_vision.hflip(img)
        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F_vision.rotate(img, angle, interpolation=Image.BICUBIC)
        return img

    def __getitem__(self, idx):
        try:
            if self.color_mode == 'rgb':
                pil_img = load_image_as_rgb(self.image_paths[idx])
            else:
                pil_img = load_image_as_grayscale(self.image_paths[idx])
            pil_img = self.apply_augmentations(pil_img)
            img_tensor = self.transform(pil_img)

            text = self.labels[idx].replace('_', ' ')
            text_indices = text_to_indices(text, self.text_max_len)
            text_tensor = torch.tensor(text_indices, dtype=torch.long)

            return img_tensor, text_tensor
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            if self.color_mode == 'rgb':
                img_tensor = torch.zeros(3, self.img_size, self.img_size)
            else:
                img_tensor = torch.zeros(1, self.img_size, self.img_size)
            text_tensor = torch.zeros(self.text_max_len, dtype=torch.long)
            return img_tensor, text_tensor

# ==================== Model size configs ====================

TRANSFORMER_CONFIGS = {
    'tiny':   {'embed_dim': 128, 'num_layers': 4, 'num_heads': 4},
    'small':  {'embed_dim': 256, 'num_layers': 6, 'num_heads': 4},
    'medium': {'embed_dim': 384, 'num_layers': 8, 'num_heads': 6},
    'large':  {'embed_dim': 512, 'num_layers': 10, 'num_heads': 8},
}

BIGRU_CONFIGS = {
    'tiny':   {'embed_dim': 64,  'hidden_size': 128, 'num_layers': 2},
    'small':  {'embed_dim': 128, 'hidden_size': 256, 'num_layers': 2},
    'medium': {'embed_dim': 256, 'hidden_size': 512, 'num_layers': 3},
    'large':  {'embed_dim': 384, 'hidden_size': 768, 'num_layers': 3},
}

# ==================== GUI Application ====================

class MaskGITApp:
    def __init__(self, root):
        self.root = root
        self.root.title("MaskGIT - Masked Generative Image Transformer")
        self.root.geometry("1200x800")

        self.image_paths = []
        self.labels = []
        self.training_vqvae = False
        self.training_maskgit = False
        self.vqvae_model = None
        self.maskgit_model = None
        self.text_encoder = None
        self.maskgit_wrapper = None
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        self.current_epoch_vqvae = 0
        self.current_epoch_maskgit = 0

        self.message_queue_vqvae = queue.Queue()
        self.message_queue_maskgit = queue.Queue()

        self.settings = {
            'img_size': tk.IntVar(value=32),
            'color_mode': tk.StringVar(value='rgb'),
            'compression': tk.IntVar(value=4),  # downsample factor

            # VQVAE settings
            'vq_preset': tk.StringVar(value='medium'),
            'vq_base_channels': tk.IntVar(value=32),
            'vq_embed_dim': tk.IntVar(value=64),
            'vq_num_embeddings': tk.IntVar(value=512),
            'vq_commitment_cost': tk.DoubleVar(value=0.25),
            'vq_batch_size': tk.IntVar(value=16),
            'vq_lr': tk.DoubleVar(value=1e-3),
            'vq_num_workers': tk.IntVar(value=0),

            # MaskGIT settings
            'seq_model_type': tk.StringVar(value='transformer'),
            'transformer_size': tk.StringVar(value='small'),
            'bigru_size': tk.StringVar(value='small'),
            'maskgit_T': tk.IntVar(value=8),
            'mask_schedule': tk.StringVar(value='cosine'),
            'seq_dropout': tk.DoubleVar(value=0.1),
            'seq_batch_size': tk.IntVar(value=32),
            'seq_lr': tk.DoubleVar(value=5e-4),
            'seq_temperature': tk.DoubleVar(value=1.0),

            # Text conditioning settings
            'cond_enabled': tk.BooleanVar(value=False),
            'cond_embed_dim': tk.IntVar(value=64),
            'cond_hidden_size': tk.IntVar(value=64),
            'cond_num_layers': tk.IntVar(value=2),
            'cond_dim': tk.IntVar(value=256),
            'cond_text_max_len': tk.IntVar(value=128),
            'cond_lr': tk.DoubleVar(value=5e-4),
        }

        self.aug_settings = {
            'flip_horizontal': tk.BooleanVar(value=True),
            'rotation': tk.BooleanVar(value=False),
        }

        self.thumbnail_size = 128
        self.setup_gui()
        self.root.after(100, self.process_messages_vqvae)
        self.root.after(100, self.process_messages_maskgit)

    # ------------------ GUI Setup ------------------
    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.vqvae_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.vqvae_tab, text='VQVAE Training')
        self.setup_vqvae_tab()

        self.maskgit_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.maskgit_tab, text='MaskGIT Training')
        self.setup_maskgit_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.generation_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generation_tab, text='Generation')
        self.setup_generation_tab()

        self.inpainting_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.inpainting_tab, text='Inpainting/Editing')
        self.setup_inpainting_tab()

        self.status_label = tk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_vqvae_tab(self):
        main_frame = tk.Frame(self.vqvae_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="VQVAE Training", font=("Arial",12,"bold")).pack(pady=(0,10))

        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=5, pady=5)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=2)
        tk.Button(img_frame, text="Add Folder", command=self.add_folder, width=20).pack(pady=2)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=2)
        self.image_listbox = tk.Listbox(img_frame, height=5)
        self.image_listbox.pack(fill=tk.X, pady=2)

        tk.Button(left_frame, text="Initialize VQVAE", command=self.initialize_vqvae, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.vqvae_epoch_var = tk.StringVar(value="50")
        tk.Entry(epoch_frame, textvariable=self.vqvae_epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start VQVAE Training", command=self.start_vqvae_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop VQVAE Training", command=self.stop_vqvae_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save VQVAE", command=self.save_vqvae, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load VQVAE", command=self.load_vqvae, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Reconstructions", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.vqvae_preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=128)
        self.vqvae_preview_canvas.pack()

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.vqvae_log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.vqvae_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.vqvae_log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.vqvae_log_text.config(yscrollcommand=scrollbar.set)

    def setup_maskgit_tab(self):
        main_frame = tk.Frame(self.maskgit_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="MaskGIT Training", font=("Arial",12,"bold")).pack(pady=(0,10))
        tk.Label(left_frame, text="Requires a trained VQVAE", fg="blue").pack(pady=5)

        cond_frame = tk.LabelFrame(left_frame, text="Conditional (text)", padx=5, pady=5)
        cond_frame.pack(fill=tk.X, pady=5)
        self.cond_enabled_cb = tk.Checkbutton(cond_frame, text="Enable text conditioning",
                                              variable=self.settings['cond_enabled'])
        self.cond_enabled_cb.pack(anchor='w')
        tk.Button(cond_frame, text="Load CSV (image,label)", command=self.load_csv, width=20).pack(pady=2)
        tk.Button(cond_frame, text="Use filenames as labels", command=self.use_filenames_as_labels, width=20).pack(pady=2)
        self.csv_status = tk.Label(cond_frame, text="No CSV loaded", fg="red")
        self.csv_status.pack()

        tk.Button(left_frame, text="Initialize MaskGIT", command=self.initialize_maskgit, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.maskgit_epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.maskgit_epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start Training", command=self.start_maskgit_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop Training", command=self.stop_maskgit_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save Model", command=self.save_maskgit_model, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load Model", command=self.load_maskgit_model, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Generated Samples", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.maskgit_preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=256)
        self.maskgit_preview_canvas.pack()

        prompt_frame = tk.LabelFrame(right_frame, text="Test prompt (leave empty for unconditional)", padx=5, pady=5)
        prompt_frame.pack(fill=tk.X, pady=(0,5))
        self.test_prompt_entry = tk.Entry(prompt_frame)
        self.test_prompt_entry.insert(0, "a cute cat")
        self.test_prompt_entry.pack(fill=tk.X, pady=2)
        tk.Button(prompt_frame, text="Generate Preview", command=self.maskgit_preview_with_prompt, width=20).pack(pady=2)

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.maskgit_log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.maskgit_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.maskgit_log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.maskgit_log_text.config(yscrollcommand=scrollbar.set)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Model Settings", font=("Arial",14,"bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Image
        img_frame = tk.LabelFrame(scrollable_frame, text="Image", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(img_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Color mode:", width=20, anchor='w').pack(side=tk.LEFT)
        om = ttk.Combobox(f, textvariable=self.settings['color_mode'], values=['rgb', 'grayscale'], state='readonly', width=10)
        om.pack(side=tk.RIGHT)
        f = tk.Frame(img_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Image size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=16, to=128, variable=self.settings['img_size'], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['img_size'], width=5).pack(side=tk.RIGHT)
        f = tk.Frame(img_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Compression (downsample):", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=2, to=8, variable=self.settings['compression'], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['compression'], width=5).pack(side=tk.RIGHT)

        # VQVAE
        vqvae_frame = tk.LabelFrame(scrollable_frame, text="VQVAE", padx=10, pady=10)
        vqvae_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(vqvae_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Preset:", width=20, anchor='w').pack(side=tk.LEFT)
        preset_combo = ttk.Combobox(f, textvariable=self.settings['vq_preset'],
                                    values=list(VQVAE_SIZE_CONFIGS.keys()), state='readonly', width=10)
        preset_combo.pack(side=tk.RIGHT)
        preset_combo.bind('<<ComboboxSelected>>', self.on_vq_preset_change)
        vqvae_params = [
            ("Base channels:", 'vq_base_channels', 16, 128),
            ("Embedding dim:", 'vq_embed_dim', 32, 256),
            ("Codebook size:", 'vq_num_embeddings', 128, 1024),
            ("Commitment cost:", 'vq_commitment_cost', 0.1, 1.0),
            ("Batch size:", 'vq_batch_size', 1, 32),
            ("Learning rate:", 'vq_lr', 1e-5, 1e-2),
            ("Workers:", 'vq_num_workers', 0, 4),
        ]
        for label, key, low, high in vqvae_params:
            f = tk.Frame(vqvae_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            res = 0.01 if 'cost' in key else (0.00001 if 'lr' in key else 1)
            tk.Scale(f, from_=low, to=high, variable=self.settings[key],
                     orient=tk.HORIZONTAL, length=200, resolution=res).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # MaskGIT
        mg_frame = tk.LabelFrame(scrollable_frame, text="MaskGIT", padx=10, pady=10)
        mg_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(mg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Model type:", width=20, anchor='w').pack(side=tk.LEFT)
        type_combo = ttk.Combobox(f, textvariable=self.settings['seq_model_type'],
                                  values=['transformer', 'bigru'], state='readonly', width=10)
        type_combo.pack(side=tk.RIGHT)
        f = tk.Frame(mg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Transformer size:", width=20, anchor='w').pack(side=tk.LEFT)
        trans_combo = ttk.Combobox(f, textvariable=self.settings['transformer_size'],
                                   values=list(TRANSFORMER_CONFIGS.keys()), state='readonly', width=10)
        trans_combo.pack(side=tk.RIGHT)
        f = tk.Frame(mg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="BiGRU size:", width=20, anchor='w').pack(side=tk.LEFT)
        gru_combo = ttk.Combobox(f, textvariable=self.settings['bigru_size'],
                                 values=list(BIGRU_CONFIGS.keys()), state='readonly', width=10)
        gru_combo.pack(side=tk.RIGHT)
        f = tk.Frame(mg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Iterations (T):", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=4, to=32, variable=self.settings['maskgit_T'], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['maskgit_T'], width=5).pack(side=tk.RIGHT)
        f = tk.Frame(mg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Mask schedule:", width=20, anchor='w').pack(side=tk.LEFT)
        sched_combo = ttk.Combobox(f, textvariable=self.settings['mask_schedule'],
                                   values=['cosine', 'linear'], state='readonly', width=10)
        sched_combo.pack(side=tk.RIGHT)
        f = tk.Frame(mg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Dropout:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=0.0, to=0.5, resolution=0.05, variable=self.settings['seq_dropout'], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['seq_dropout'], width=5).pack(side=tk.RIGHT)
        f = tk.Frame(mg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Batch size:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=1, to=64, variable=self.settings['seq_batch_size'], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['seq_batch_size'], width=5).pack(side=tk.RIGHT)
        f = tk.Frame(mg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Learning rate:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=1e-5, to=2e-3, resolution=1e-5, variable=self.settings['seq_lr'], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['seq_lr'], width=8).pack(side=tk.RIGHT)
        f = tk.Frame(mg_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Sampling temp:", width=20, anchor='w').pack(side=tk.LEFT)
        tk.Scale(f, from_=0.1, to=2.0, resolution=0.1, variable=self.settings['seq_temperature'], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
        tk.Label(f, textvariable=self.settings['seq_temperature'], width=5).pack(side=tk.RIGHT)

        # Conditioning
        cond_frame = tk.LabelFrame(scrollable_frame, text="Text Conditioning (GRU)", padx=10, pady=10)
        cond_frame.pack(fill=tk.X, pady=5)
        cond_params = [
            ("Embed dim:", 'cond_embed_dim', 32, 256),
            ("Hidden size:", 'cond_hidden_size', 32, 512),
            ("Num layers:", 'cond_num_layers', 1, 4),
            ("Conditioning dim:", 'cond_dim', 64, 512),
            ("Max text length:", 'cond_text_max_len', 32, 256),
            ("Learning rate:", 'cond_lr', 1e-5, 1e-2),
        ]
        for label, key, low, high in cond_params:
            f = tk.Frame(cond_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            if 'lr' in key:
                tk.Scale(f, from_=low, to=high, resolution=1e-5, variable=self.settings[key], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            else:
                tk.Scale(f, from_=low, to=high, variable=self.settings[key], orient=tk.HORIZONTAL, length=200).pack(side=tk.RIGHT)
            tk.Label(f, textvariable=self.settings[key], width=5).pack(side=tk.RIGHT)

        # Augmentations
        aug_frame = tk.LabelFrame(scrollable_frame, text="Augmentations", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)
        for label, key in [("Horizontal Flip", 'flip_horizontal'), ("Rotation (±30°)", 'rotation')]:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=5)
        cpu = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU cores: {cpu}").pack(anchor='w')
        tk.Label(sys_frame, text=f"PyTorch threads: {torch.get_num_threads()}").pack(anchor='w')
        tk.Label(sys_frame, text=f"Device: {self.device}").pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def on_vq_preset_change(self, event=None):
        preset = self.settings['vq_preset'].get()
        cfg = VQVAE_SIZE_CONFIGS[preset]
        self.settings['vq_base_channels'].set(cfg['base_channels'])
        self.settings['vq_embed_dim'].set(cfg['embed_dim'])
        self.settings['vq_num_embeddings'].set(cfg['num_embeddings'])

    def setup_generation_tab(self):
        main_frame = tk.Frame(self.generation_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        tk.Label(main_frame, text="Generate Images", font=("Arial",14,"bold")).pack(pady=(0,10))

        prompt_frame = tk.LabelFrame(main_frame, text="Text Prompt (leave empty for unconditional)", padx=5, pady=5)
        prompt_frame.pack(fill=tk.X, pady=(0,10))
        self.gen_prompt = tk.Entry(prompt_frame, width=60)
        self.gen_prompt.insert(0, "a cute cat")
        self.gen_prompt.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)

        ctrl_frame = tk.Frame(main_frame)
        ctrl_frame.pack(pady=5)

        tk.Label(ctrl_frame, text="Number:").pack(side=tk.LEFT)
        self.gen_count = tk.IntVar(value=16)
        tk.Spinbox(ctrl_frame, from_=1, to=64, textvariable=self.gen_count, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="Iterations:").pack(side=tk.LEFT, padx=(10,0))
        self.gen_steps = tk.IntVar(value=self.settings['maskgit_T'].get())
        tk.Spinbox(ctrl_frame, from_=1, to=32, textvariable=self.gen_steps, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="Temperature:").pack(side=tk.LEFT, padx=(10,0))
        self.gen_temp = tk.DoubleVar(value=self.settings['seq_temperature'].get())
        tk.Spinbox(ctrl_frame, from_=0.1, to=2.0, increment=0.1, textvariable=self.gen_temp, width=5).pack(side=tk.LEFT, padx=5)

        self.progressive_grid = tk.BooleanVar(value=False)
        prog_check = tk.Checkbutton(ctrl_frame, text="Progressive preview", variable=self.progressive_grid)
        prog_check.pack(side=tk.LEFT, padx=10)

        tk.Label(ctrl_frame, text="Update interval:").pack(side=tk.LEFT)
        self.prog_interval = tk.IntVar(value=2)
        tk.Spinbox(ctrl_frame, from_=1, to=10, textvariable=self.prog_interval, width=5).pack(side=tk.LEFT, padx=5)

        self.generate_btn = tk.Button(ctrl_frame, text="Generate", command=self.generate_samples, bg="lightgreen")
        self.generate_btn.pack(side=tk.LEFT, padx=5)
        self.stop_gen_btn = tk.Button(ctrl_frame, text="Stop", command=self.stop_generation,
                                      state=tk.DISABLED, bg="salmon")
        self.stop_gen_btn.pack(side=tk.LEFT, padx=5)

        scroll_frame = tk.LabelFrame(main_frame, text="Results", padx=5, pady=5)
        scroll_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        canvas_frame = tk.Frame(scroll_frame)
        canvas_frame.pack(fill=tk.BOTH, expand=True)

        self.gen_canvas = tk.Canvas(canvas_frame, bg='lightgray')
        self.v_scroll = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.gen_canvas.yview)
        self.h_scroll = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.gen_canvas.xview)
        self.gen_canvas.configure(yscrollcommand=self.v_scroll.set, xscrollcommand=self.h_scroll.set)

        self.v_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.h_scroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.inner_frame = tk.Frame(self.gen_canvas)
        self.canvas_window = self.gen_canvas.create_window((0,0), window=self.inner_frame, anchor='nw')
        self.inner_frame.bind('<Configure>', lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all')))

        self.gen_info = tk.Label(main_frame, text="", fg="blue")
        self.gen_info.pack()

        self.generation_active = False

    def setup_inpainting_tab(self):
        main_frame = tk.Frame(self.inpainting_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=350)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="MaskGIT Inpainting & Editing", font=("Arial",12,"bold")).pack(pady=(0,10))

        load_frame = tk.LabelFrame(left_frame, text="Input Image", padx=5, pady=5)
        load_frame.pack(fill=tk.X, pady=5)
        tk.Button(load_frame, text="Load Image", command=self.load_inpaint_image, width=20).pack(pady=2)
        self.inpaint_image_label = tk.Label(load_frame, text="No image loaded", fg="gray")
        self.inpaint_image_label.pack()

        mask_frame = tk.LabelFrame(left_frame, text="Mask Type", padx=5, pady=5)
        mask_frame.pack(fill=tk.X, pady=5)
        self.mask_type = tk.StringVar(value="checkerboard")
        mask_types = ['checkerboard', 'half_right', 'half_left', 'half_top', 'half_bottom',
                      'center_square', 'center_circle', 'random', 'custom']
        ttk.Combobox(mask_frame, textvariable=self.mask_type, values=mask_types, state='readonly').pack(fill=tk.X, pady=2)
        self.custom_mask_btn = tk.Button(mask_frame, text="Draw Custom Mask", command=self.open_custom_mask_editor, state=tk.DISABLED)
        self.custom_mask_btn.pack(pady=2)
        tk.Button(mask_frame, text="Preview Mask", command=self.update_mask_preview).pack(pady=2)

        param_frame = tk.LabelFrame(left_frame, text="Mask Parameters", padx=5, pady=5)
        param_frame.pack(fill=tk.X, pady=5)
        tk.Label(param_frame, text="Mask ratio (0-1):").pack(anchor='w')
        self.mask_ratio = tk.DoubleVar(value=0.5)
        tk.Scale(param_frame, from_=0.0, to=1.0, resolution=0.05, variable=self.mask_ratio, orient=tk.HORIZONTAL, length=200).pack(fill=tk.X)

        gen_frame = tk.LabelFrame(left_frame, text="Inpainting Settings", padx=5, pady=5)
        gen_frame.pack(fill=tk.X, pady=5)
        tk.Label(gen_frame, text="Iterations:").pack(anchor='w')
        self.inpaint_steps = tk.IntVar(value=self.settings['maskgit_T'].get())
        tk.Spinbox(gen_frame, from_=1, to=32, textvariable=self.inpaint_steps, width=10).pack(anchor='w')
        tk.Label(gen_frame, text="Temperature:").pack(anchor='w')
        self.inpaint_temp = tk.DoubleVar(value=self.settings['seq_temperature'].get())
        tk.Spinbox(gen_frame, from_=0.1, to=2.0, increment=0.1, textvariable=self.inpaint_temp, width=10).pack(anchor='w')
        tk.Label(gen_frame, text="Number of variations:").pack(anchor='w')
        self.inpaint_num = tk.IntVar(value=4)
        tk.Spinbox(gen_frame, from_=1, to=16, textvariable=self.inpaint_num, width=10).pack(anchor='w')

        tk.Button(gen_frame, text="Run Inpainting", command=self.run_inpainting, bg="lightblue", width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Mask Preview & Results", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True)

        self.inpaint_canvas = tk.Canvas(preview_frame, bg='lightgray', width=400, height=400)
        self.inpaint_canvas.pack()

        self.inpaint_info = tk.Label(preview_frame, text="", fg="blue")
        self.inpaint_info.pack()

        self.inpaint_image = None
        self.inpaint_tensor = None
        self.inpaint_photo = None
        self.custom_mask = None  # store custom mask as PIL image (latent size)

    # ------------------ Logging ------------------
    def log_vqvae(self, msg):
        self.message_queue_vqvae.put(msg)

    def log_maskgit(self, msg):
        self.message_queue_maskgit.put(msg)

    def process_messages_vqvae(self):
        try:
            while True:
                msg = self.message_queue_vqvae.get_nowait()
                self.vqvae_log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.vqvae_log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages_vqvae)

    def process_messages_maskgit(self):
        try:
            while True:
                msg = self.message_queue_maskgit.get_nowait()
                self.maskgit_log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.maskgit_log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages_maskgit)

    # ------------------ Image Management ------------------
    def add_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp")])
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_vqvae(f"Added {len(files)} images. Total: {len(self.image_paths)}")
        self.log_maskgit(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def add_folder(self):
        folder = filedialog.askdirectory()
        if not folder:
            return
        count = 0
        for root_dir, _, files in os.walk(folder):
            for file in files:
                if file.lower().endswith(('.png','.jpg','.jpeg','.jfif','.webp','.bmp')):
                    full = os.path.join(root_dir, file)
                    if full not in self.image_paths:
                        self.image_paths.append(full)
                        self.image_listbox.insert(tk.END, os.path.basename(full))
                        count += 1
        self.log_vqvae(f"Added {count} images. Total: {len(self.image_paths)}")
        self.log_maskgit(f"Added {count} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths.clear()
        self.labels.clear()
        self.image_listbox.delete(0, tk.END)
        self.csv_status.config(text="No CSV loaded", fg="red")
        self.log_vqvae("Cleared all images")
        self.log_maskgit("Cleared all images")

    def load_csv(self):
        fname = filedialog.askopenfilename(filetypes=[("CSV", "*.csv")])
        if not fname:
            return
        import csv
        image_to_label = {}
        try:
            with open(fname, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) >= 2:
                        img_name, label = row[0], row[1]
                        image_to_label[img_name] = label
        except Exception as e:
            self.log_maskgit(f"Error reading CSV: {e}")
            return

        self.labels = []
        matched = 0
        for path in self.image_paths:
            base = os.path.basename(path)
            if base in image_to_label:
                self.labels.append(image_to_label[base])
                matched += 1
            else:
                name_no_ext = os.path.splitext(base)[0]
                self.labels.append(name_no_ext)
        self.csv_status.config(text=f"CSV loaded: {matched} matched", fg="green")
        self.log_maskgit(f"CSV loaded. {matched} images matched.")

    def use_filenames_as_labels(self):
        self.labels = [os.path.splitext(os.path.basename(p))[0] for p in self.image_paths]
        self.csv_status.config(text="Using filenames as labels", fg="blue")
        self.log_maskgit("Using filenames as labels.")

    # ------------------ VQVAE Methods ------------------
    def initialize_vqvae(self):
        try:
            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            self.vqvae_model = VQVAE(
                in_channels=in_channels,
                base_channels=self.settings['vq_base_channels'].get(),
                embed_dim=self.settings['vq_embed_dim'].get(),
                num_embeddings=self.settings['vq_num_embeddings'].get(),
                commitment_cost=self.settings['vq_commitment_cost'].get(),
                img_size=self.settings['img_size'].get(),
                downsample_factor=self.settings['compression'].get()
            )
            self.vqvae_model.to(self.device)
            self.vqvae_optimizer = optim.Adam(self.vqvae_model.parameters(), lr=self.settings['vq_lr'].get())
            self.log_vqvae(f"VQVAE initialized on {self.device}. Latent size: {self.vqvae_model.latent_h}x{self.vqvae_model.latent_w}")
        except Exception as e:
            self.log_vqvae(f"Error: {e}")

    def start_vqvae_training(self):
        if not self.image_paths: self.log_vqvae("No images!"); return
        if not self.vqvae_model: self.log_vqvae("VQVAE not initialized!"); return
        if self.training_vqvae: self.log_vqvae("Already training."); return
        try:
            epochs = int(self.vqvae_epoch_var.get())
        except:
            self.log_vqvae("Invalid epochs"); return
        self.training_vqvae = True
        self.current_epoch_vqvae = 0
        self.vqvae_start_time = time.time()
        thread = threading.Thread(target=self.train_vqvae_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_vqvae(f"VQVAE training started for {epochs} epochs.")

    def train_vqvae_loop(self, epochs):
        try:
            batch_size = self.settings['vq_batch_size'].get()
            num_workers = self.settings['vq_num_workers'].get()
            img_size = self.settings['img_size'].get()
            color_mode = self.settings['color_mode'].get()
            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}
            dummy_labels = [""] * len(self.image_paths)
            dataset = ConditionalImageDataset(self.image_paths, dummy_labels, img_size, color_mode, aug_dict)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=False)
            self.vqvae_model.train()
            for epoch in range(epochs):
                if not self.training_vqvae: break
                self.current_epoch_vqvae = epoch
                epoch_loss = 0.0
                batches = 0
                for images, _ in loader:
                    if not self.training_vqvae: break
                    images = images.to(self.device)
                    recon, vq_loss, _ = self.vqvae_model(images)
                    recon_loss = F.mse_loss(recon, images)
                    loss = recon_loss + vq_loss
                    self.vqvae_optimizer.zero_grad()
                    loss.backward()
                    self.vqvae_optimizer.step()
                    epoch_loss += loss.item()
                    batches += 1
                avg_loss = epoch_loss / batches if batches else 0
                elapsed = time.time() - self.vqvae_start_time
                self.log_vqvae(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s")
                if (epoch+1) % 5 == 0:
                    self.show_vqvae_preview()
            self.training_vqvae = False
            self.log_vqvae("VQVAE training finished.")
        except Exception as e:
            self.log_vqvae(f"Training error: {e}")
            import traceback; traceback.print_exc()
            self.training_vqvae = False

    def show_vqvae_preview(self):
        if not self.vqvae_model or len(self.image_paths) == 0:
            return
        try:
            n_samples = min(16, len(self.image_paths))
            indices = random.sample(range(len(self.image_paths)), n_samples)
            color_mode = self.settings['color_mode'].get()
            dataset = ConditionalImageDataset([self.image_paths[i] for i in indices],
                                              [""]*n_samples, img_size=self.settings['img_size'].get(),
                                              color_mode=color_mode)
            loader = DataLoader(dataset, batch_size=n_samples, shuffle=False)
            images, _ = next(iter(loader))
            images = images.to(self.device)
            self.vqvae_model.eval()
            with torch.no_grad():
                recon, _, _ = self.vqvae_model(images)
            self.vqvae_model.train()
            images = (images + 1) / 2
            recon = (recon + 1) / 2
            images = images.clamp(0,1).cpu().numpy()
            recon = recon.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size // 2
            grid = Image.new('RGB', (8*thumb, 4*thumb))
            for i in range(4):
                for j in range(4):
                    idx = i*4 + j
                    if idx < len(images):
                        if images[idx].shape[0] == 1:
                            img = np.stack([images[idx][0]]*3, axis=-1)
                        else:
                            img = images[idx].transpose(1,2,0)
                        img = (img * 255).astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img, (j*thumb*2, i*thumb))
                        if recon[idx].shape[0] == 1:
                            img_r = np.stack([recon[idx][0]]*3, axis=-1)
                        else:
                            img_r = recon[idx].transpose(1,2,0)
                        img_r = (img_r * 255).astype(np.uint8)
                        pil_img_r = Image.fromarray(img_r).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img_r, (j*thumb*2 + thumb, i*thumb))
            grid = grid.resize((256,128), Image.NEAREST)
            self.vqvae_preview_photo = ImageTk.PhotoImage(grid)
            self.vqvae_preview_canvas.delete("all")
            self.vqvae_preview_canvas.create_image(128,64, image=self.vqvae_preview_photo)
        except Exception as e:
            self.log_vqvae(f"Preview error: {e}")

    def stop_vqvae_training(self):
        self.training_vqvae = False
        self.log_vqvae("VQVAE training stopped.")

    def save_vqvae(self):
        if not self.vqvae_model: self.log_vqvae("No VQVAE."); return
        fname = filedialog.asksaveasfilename(defaultextension=".pth", filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'model_state': self.vqvae_model.state_dict(),
                'optimizer_state': self.vqvae_optimizer.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items() if k.startswith('vq') or k in ['img_size','color_mode','compression']},
                'vq_preset': self.settings['vq_preset'].get(),
            }, fname)
            self.log_vqvae(f"VQVAE saved to {fname}")

    def load_vqvae(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname: return
        try:
            ckpt = torch.load(fname, map_location='cpu', weights_only=False)
            if 'settings' in ckpt:
                for k,v in ckpt['settings'].items():
                    if k in self.settings:
                        self.settings[k].set(v)
            if 'vq_preset' in ckpt:
                self.settings['vq_preset'].set(ckpt['vq_preset'])
            self.initialize_vqvae()
            self.vqvae_model.load_state_dict(ckpt['model_state'])
            self.vqvae_optimizer.load_state_dict(ckpt['optimizer_state'])
            self.log_vqvae(f"VQVAE loaded from {fname}")
        except Exception as e:
            self.log_vqvae(f"Load error: {e}")

    # ------------------ MaskGIT Methods ------------------
    def initialize_maskgit(self):
        if not self.vqvae_model:
            self.log_maskgit("Please train/load a VQVAE first!")
            return
        try:
            vocab_size = self.vqvae_model.num_embeddings + 1
            max_seq_len = self.vqvae_model.latent_h * self.vqvae_model.latent_w
            model_type = self.settings['seq_model_type'].get()
            dropout = self.settings['seq_dropout'].get()
            cond_enabled = self.settings['cond_enabled'].get()
            cond_dim = self.settings['cond_dim'].get() if cond_enabled else None

            if model_type == 'transformer':
                size_name = self.settings['transformer_size'].get()
                config = TRANSFORMER_CONFIGS[size_name]
                model = MaskGITBiTransformer(
                    vocab_size=vocab_size,
                    max_seq_len=max_seq_len,
                    embed_dim=config['embed_dim'],
                    num_layers=config['num_layers'],
                    num_heads=config['num_heads'],
                    mlp_ratio=4.0,
                    dropout=dropout,
                    cond_dim=cond_dim
                )
                self.log_maskgit(f"BiTransformer initialized ({size_name}).")
            else:
                size_name = self.settings['bigru_size'].get()
                config = BIGRU_CONFIGS[size_name]
                model = MaskGITBiGRU(
                    vocab_size=vocab_size,
                    max_seq_len=max_seq_len,
                    embed_dim=config['embed_dim'],
                    hidden_size=config['hidden_size'],
                    num_layers=config['num_layers'],
                    dropout=dropout,
                    cond_dim=cond_dim
                )
                self.log_maskgit(f"BiGRU initialized ({size_name}).")

            model.to(self.device)
            self.maskgit_model = model

            if cond_enabled:
                self.text_encoder = TextEncoder(
                    vocab_size=256,
                    embed_dim=self.settings['cond_embed_dim'].get(),
                    hidden_size=self.settings['cond_hidden_size'].get(),
                    num_layers=self.settings['cond_num_layers'].get(),
                    cond_dim=cond_dim
                ).to(self.device)
                params = list(model.parameters()) + list(self.text_encoder.parameters())
            else:
                self.text_encoder = None
                params = model.parameters()

            self.maskgit_optimizer = optim.Adam(params, lr=self.settings['seq_lr'].get())
            self.maskgit_wrapper = MaskGITWrapper(
                model, mask_token_id=vocab_size-1,
                T=self.settings['maskgit_T'].get(),
                schedule=self.settings['mask_schedule'].get(),
                device=self.device
            )
        except Exception as e:
            self.log_maskgit(f"Error: {e}")

    def start_maskgit_training(self):
        if not self.image_paths: self.log_maskgit("No images!"); return
        if not self.maskgit_model: self.log_maskgit("Model not initialized!"); return
        if not self.vqvae_model: self.log_maskgit("No VQVAE!"); return
        if self.training_maskgit: self.log_maskgit("Already training."); return
        cond_enabled = self.settings['cond_enabled'].get()
        if cond_enabled and not self.labels:
            self.log_maskgit("Conditional training requires labels. Load CSV or use filenames as labels.")
            return
        try:
            epochs = int(self.maskgit_epoch_var.get())
        except:
            self.log_maskgit("Invalid epochs"); return
        self.training_maskgit = True
        self.current_epoch_maskgit = 0
        self.maskgit_start_time = time.time()
        thread = threading.Thread(target=self.train_maskgit_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_maskgit(f"MaskGIT training started for {epochs} epochs.")

    def train_maskgit_loop(self, epochs):
        try:
            batch_size = self.settings['seq_batch_size'].get()
            num_workers = self.settings['vq_num_workers'].get()
            img_size = self.settings['img_size'].get()
            color_mode = self.settings['color_mode'].get()
            cond_enabled = self.settings['cond_enabled'].get()
            text_max_len = self.settings['cond_text_max_len'].get()
            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}

            if cond_enabled:
                dataset = ConditionalImageDataset(self.image_paths, self.labels, img_size, color_mode, aug_dict, text_max_len)
            else:
                dummy_labels = [""] * len(self.image_paths)
                dataset = ConditionalImageDataset(self.image_paths, dummy_labels, img_size, color_mode, aug_dict, text_max_len)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=False)
            self.vqvae_model.eval()
            self.maskgit_model.train()
            if self.text_encoder:
                self.text_encoder.train()

            for epoch in range(epochs):
                if not self.training_maskgit: break
                self.current_epoch_maskgit = epoch
                epoch_loss = 0.0
                batches = 0
                for images, text_tensors in loader:
                    if not self.training_maskgit: break
                    images = images.to(self.device)
                    with torch.no_grad():
                        indices = self.vqvae_model.encode_indices(images)
                    if cond_enabled and self.text_encoder is not None:
                        cond = self.text_encoder(text_tensors.to(self.device))
                    else:
                        cond = None
                    loss = self.maskgit_wrapper.train_step(indices, cond=cond)
                    self.maskgit_optimizer.zero_grad()
                    loss.backward()
                    self.maskgit_optimizer.step()
                    epoch_loss += loss.item()
                    batches += 1
                avg_loss = epoch_loss / batches if batches else 0
                elapsed = time.time() - self.maskgit_start_time
                self.log_maskgit(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s")
                if (epoch+1) % 5 == 0:
                    self.maskgit_preview_with_prompt()
            self.training_maskgit = False
            self.log_maskgit("MaskGIT training finished.")
        except Exception as e:
            self.log_maskgit(f"Training error: {e}")
            import traceback; traceback.print_exc()
            self.training_maskgit = False

    def maskgit_preview_with_prompt(self):
        if not self.maskgit_wrapper or not self.vqvae_model: return
        try:
            prompt = self.test_prompt_entry.get().strip()
            unconditional = (prompt == "") or (not self.settings['cond_enabled'].get())
            cond = None
            if not unconditional and self.settings['cond_enabled'].get() and self.text_encoder is not None:
                text_indices = text_to_indices(prompt, self.settings['cond_text_max_len'].get())
                text_tensor = torch.tensor([text_indices] * 16, dtype=torch.long, device=self.device)
                with torch.no_grad():
                    cond = self.text_encoder(text_tensor)
                self.log_maskgit(f"Preview: conditional with prompt '{prompt}'")
            else:
                self.log_maskgit("Preview: unconditional")

            self.maskgit_model.eval()
            if self.text_encoder:
                self.text_encoder.eval()
            self.vqvae_model.eval()

            tokens = self.maskgit_wrapper.sample(n_samples=16, cond=cond,
                                                 steps=self.settings['maskgit_T'].get(),
                                                 temperature=self.settings['seq_temperature'].get())
            with torch.no_grad():
                samples = self.vqvae_model.decode_from_indices(tokens)
            samples = (samples + 1) / 2
            samples = samples.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size
            grid = Image.new('RGB', (4*thumb, 4*thumb))
            for i in range(4):
                for j in range(4):
                    idx = i*4 + j
                    if idx < len(samples):
                        if samples[idx].shape[0] == 1:
                            img = np.stack([samples[idx][0]]*3, axis=-1)
                        else:
                            img = samples[idx].transpose(1,2,0)
                        img = (img * 255).astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img, (j*thumb, i*thumb))
            grid = grid.resize((256,256), Image.NEAREST)
            self.maskgit_preview_photo = ImageTk.PhotoImage(grid)
            self.maskgit_preview_canvas.delete("all")
            self.maskgit_preview_canvas.create_image(128,128, image=self.maskgit_preview_photo)

            if self.training_maskgit:
                self.maskgit_model.train()
                if self.text_encoder:
                    self.text_encoder.train()
        except Exception as e:
            self.log_maskgit(f"Preview error: {e}")

    def stop_maskgit_training(self):
        self.training_maskgit = False
        self.log_maskgit("MaskGIT training stopped.")

    def save_maskgit_model(self):
        if not self.maskgit_model: self.log_maskgit("No model."); return
        fname = filedialog.asksaveasfilename(defaultextension=".pth", filetypes=[("PyTorch","*.pth")])
        if fname:
            save_dict = {
                'model_state': self.maskgit_model.state_dict(),
                'optimizer_state': self.maskgit_optimizer.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items() if k.startswith('seq') or k.startswith('maskgit') or k.startswith('cond')},
                'model_type': self.settings['seq_model_type'].get(),
            }
            if self.text_encoder is not None:
                save_dict['text_encoder_state'] = self.text_encoder.state_dict()
            torch.save(save_dict, fname)
            self.log_maskgit(f"Model saved to {fname}")

    def load_maskgit_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname: return
        try:
            ckpt = torch.load(fname, map_location='cpu', weights_only=False)
            if 'settings' in ckpt:
                for k,v in ckpt['settings'].items():
                    if k in self.settings:
                        self.settings[k].set(v)
            if not self.vqvae_model:
                self.log_maskgit("Please load VQVAE first.")
                return
            self.initialize_maskgit()
            self.maskgit_model.load_state_dict(ckpt['model_state'])
            self.maskgit_optimizer.load_state_dict(ckpt['optimizer_state'])
            if 'text_encoder_state' in ckpt and self.text_encoder is not None:
                self.text_encoder.load_state_dict(ckpt['text_encoder_state'])
            self.log_maskgit(f"Model loaded from {fname}")
        except Exception as e:
            self.log_maskgit(f"Load error: {e}")

    # ------------------ Generation ------------------
    def generate_samples(self):
        if not self.maskgit_wrapper or not self.vqvae_model:
            self.gen_info.config(text="Models not loaded!")
            return
        n = self.gen_count.get()
        steps = self.gen_steps.get()
        temp = self.gen_temp.get()
        prompt = self.gen_prompt.get().strip()
        unconditional = (prompt == "") or (not self.settings['cond_enabled'].get())
        cond = None
        if not unconditional and self.settings['cond_enabled'].get() and self.text_encoder is not None:
            text_indices = text_to_indices(prompt, self.settings['cond_text_max_len'].get())
            text_tensor = torch.tensor([text_indices] * n, dtype=torch.long, device=self.device)
            with torch.no_grad():
                cond = self.text_encoder(text_tensor)
        self.generation_active = True
        self.generate_btn.config(state=tk.DISABLED)
        self.stop_gen_btn.config(state=tk.NORMAL)
        if self.progressive_grid.get():
            thread = threading.Thread(target=self._progressive_generation, args=(n, steps, temp, cond), daemon=True)
        else:
            thread = threading.Thread(target=self._generate_thread, args=(n, steps, temp, cond), daemon=True)
        thread.start()

    def stop_generation(self):
        self.generation_active = False
        self.stop_gen_btn.config(state=tk.DISABLED)
        self.gen_info.config(text="Generation stopped.")

    def _generate_thread(self, n, steps, temp, cond):
        try:
            self.maskgit_model.eval()
            if self.text_encoder:
                self.text_encoder.eval()
            self.vqvae_model.eval()
            tokens = self.maskgit_wrapper.sample(n_samples=n, steps=steps, temperature=temp, cond=cond)
            with torch.no_grad():
                samples = self.vqvae_model.decode_from_indices(tokens)
            samples = (samples + 1) / 2
            samples = samples.clamp(0,1).cpu().numpy()
            self.root.after(0, lambda s=samples: self._display_generated(s, n))
        except Exception as e:
            self.root.after(0, lambda err=e: self.gen_info.config(text=f"Error: {err}"))
        finally:
            self.generation_active = False
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_gen_btn.config(state=tk.DISABLED))

    def _progressive_generation(self, n, steps, temp, cond):
        try:
            interval = self.prog_interval.get()
            self.maskgit_model.eval()
            if self.text_encoder:
                self.text_encoder.eval()
            self.vqvae_model.eval()
            generator = self.maskgit_wrapper.sample_step_by_step(n_samples=n, steps=steps, temperature=temp, cond=cond)
            for t, tokens in generator:
                if not self.generation_active:
                    break
                if t % interval == 0 or t == steps - 1:
                    with torch.no_grad():
                        samples = self.vqvae_model.decode_from_indices(tokens)
                    samples = (samples + 1) / 2
                    samples = samples.clamp(0,1).cpu().numpy()
                    self.root.after(0, lambda s=samples, step=t: self._update_progressive(s, step))
            if self.generation_active:
                self.root.after(0, lambda: self.gen_info.config(text="Generation complete."))
            else:
                self.root.after(0, lambda: self.gen_info.config(text="Generation stopped."))
        except Exception as e:
            self.root.after(0, lambda err=e: self.gen_info.config(text=f"Error: {err}"))
        finally:
            self.generation_active = False
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_gen_btn.config(state=tk.DISABLED))

    def _display_generated(self, samples, n):
        if len(samples) == 0:
            self.gen_info.config(text="No samples generated.")
            return
        thumb = self.thumbnail_size
        grid_size = int(math.ceil(math.sqrt(n)))
        total = grid_size * thumb
        grid_img = Image.new('RGB', (total, total), color=(128,128,128))
        for i in range(min(n, len(samples))):
            row = i // grid_size
            col = i % grid_size
            img = samples[i].transpose(1,2,0) if samples[i].shape[0]==3 else np.stack([samples[i][0]]*3, axis=-1)
            img = (img * 255).astype(np.uint8)
            pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
            grid_img.paste(pil_img, (col*thumb, row*thumb))
        for w in self.inner_frame.winfo_children():
            w.destroy()
        self.gen_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.gen_photo)
        label.image = self.gen_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text="Generation complete.")

    def _update_progressive(self, samples, step):
        thumb = self.thumbnail_size
        n = len(samples)
        grid_size = int(math.ceil(math.sqrt(n)))
        total = grid_size * thumb
        grid_img = Image.new('RGB', (total, total), color=(128,128,128))
        for i in range(n):
            row = i // grid_size
            col = i % grid_size
            img = samples[i].transpose(1,2,0) if samples[i].shape[0]==3 else np.stack([samples[i][0]]*3, axis=-1)
            img = (img * 255).astype(np.uint8)
            pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
            grid_img.paste(pil_img, (col*thumb, row*thumb))
        for w in self.inner_frame.winfo_children():
            w.destroy()
        self.prog_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.prog_photo)
        label.image = self.prog_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text=f"Iteration {step+1}")

    # ------------------ Inpainting (Fixed) ------------------
    def load_inpaint_image(self):
        fname = filedialog.askopenfilename(filetypes=[("Images", "*.jpg *.jpeg *.png *.bmp")])
        if not fname:
            return
        try:
            color_mode = self.settings['color_mode'].get()
            if color_mode == 'rgb':
                self.inpaint_image = load_image_as_rgb(fname)
            else:
                self.inpaint_image = load_image_as_grayscale(fname)
            img_size = self.settings['img_size'].get()
            self.inpaint_image = self.inpaint_image.resize((img_size, img_size), Image.LANCZOS)
            self.inpaint_image_label.config(text=os.path.basename(fname))
            self.custom_mask = None  # reset custom mask
            self.custom_mask_btn.config(state=tk.NORMAL if self.vqvae_model else tk.DISABLED)
            self.update_mask_preview()
        except Exception as e:
            self.log_maskgit(f"Inpaint load error: {e}")

    def create_mask(self, h, w, mask_type, ratio):
        """Create mask for latent grid: True = keep original, False = mask out"""
        mask = np.ones((h, w), dtype=bool)
        if mask_type == 'checkerboard':
            block_size = max(1, int((h * ratio) ** 0.5))
            for i in range(h):
                for j in range(w):
                    if ((i // block_size) + (j // block_size)) % 2 == 0:
                        mask[i, j] = False
        elif mask_type == 'half_right':
            mask[:, w//2:] = False
        elif mask_type == 'half_left':
            mask[:, :w//2] = False
        elif mask_type == 'half_top':
            mask[:h//2, :] = False
        elif mask_type == 'half_bottom':
            mask[h//2:, :] = False
        elif mask_type == 'center_square':
            size = int(min(h, w) * ratio)
            y1 = (h - size) // 2
            x1 = (w - size) // 2
            mask[y1:y1+size, x1:x1+size] = False
        elif mask_type == 'center_circle':
            center = (w//2, h//2)
            radius = int(min(h, w) * ratio / 2)
            Y, X = np.ogrid[:h, :w]
            dist = np.sqrt((X - center[0])**2 + (Y - center[1])**2)
            mask[dist <= radius] = False
        elif mask_type == 'random':
            rand = np.random.rand(h, w)
            mask[rand < ratio] = False
        elif mask_type == 'custom' and self.custom_mask is not None:
            # custom_mask is already a latent-sized boolean array (True=keep)
            mask = self.custom_mask
        return mask

    def update_mask_preview(self):
        if self.inpaint_image is None:
            return
        if not self.vqvae_model:
            self.inpaint_info.config(text="VQVAE not initialized. Cannot preview mask properly.")
            return
        h_latent = self.vqvae_model.latent_h
        w_latent = self.vqvae_model.latent_w
        mask_type = self.mask_type.get()
        if mask_type == 'custom' and self.custom_mask is not None:
            mask_latent = self.custom_mask
        else:
            mask_latent = self.create_mask(h_latent, w_latent, mask_type, self.mask_ratio.get())
        # Upsample mask to image size for preview
        mask_img = Image.fromarray((~mask_latent).astype(np.uint8) * 255)  # invert for display: masked=white
        mask_img = mask_img.resize((self.settings['img_size'].get(), self.settings['img_size'].get()), Image.NEAREST)
        mask_array = np.array(mask_img) / 255.0
        # Overlay red on masked areas
        img_array = np.array(self.inpaint_image.convert('RGB'))
        overlay = img_array.copy()
        overlay[mask_array > 0] = [255, 0, 0]
        blended = Image.blend(self.inpaint_image.convert('RGB'), Image.fromarray(overlay), alpha=0.5)
        blended = blended.resize((400, 400), Image.NEAREST)
        self.inpaint_photo = ImageTk.PhotoImage(blended)
        self.inpaint_canvas.delete("all")
        self.inpaint_canvas.create_image(200, 200, image=self.inpaint_photo)
        self.inpaint_info.config(text=f"Mask: {mask_type}, ratio={self.mask_ratio.get():.2f}")

    def open_custom_mask_editor(self):
        if self.inpaint_image is None:
            self.inpaint_info.config(text="Load an image first.")
            return
        if not self.vqvae_model:
            self.inpaint_info.config(text="VQVAE not initialized.")
            return
        # Create a new top-level window for drawing
        editor = tk.Toplevel(self.root)
        editor.title("Draw Custom Mask")
        editor.geometry("500x550")
        # Latent dimensions
        h_latent = self.vqvae_model.latent_h
        w_latent = self.vqvae_model.latent_w
        # Create a blank mask (all keep = True)
        if self.custom_mask is not None:
            mask_np = self.custom_mask.copy()
        else:
            mask_np = np.ones((h_latent, w_latent), dtype=bool)
        # Scale up for drawing
        scale = 8  # factor to make it drawable
        draw_size = (w_latent * scale, h_latent * scale)
        mask_img = Image.fromarray((~mask_np).astype(np.uint8) * 255)
        mask_img = mask_img.resize(draw_size, Image.NEAREST)
        self.draw_photo = ImageTk.PhotoImage(mask_img)
        canvas = tk.Canvas(editor, width=draw_size[0], height=draw_size[1], bg='white')
        canvas.pack(pady=10)
        canvas.create_image(0, 0, anchor=tk.NW, image=self.draw_photo)
        # Drawing variables
        drawing = False
        last_x, last_y = None, None
        brush_size = tk.IntVar(value=2)
        def draw_line(event):
            nonlocal last_x, last_y
            if drawing:
                x, y = event.x, event.y
                if last_x is not None and last_y is not None:
                    canvas.create_line(last_x, last_y, x, y, width=brush_size.get(), fill='black', capstyle=tk.ROUND, joinstyle=tk.ROUND)
                last_x, last_y = x, y
        def start_draw(event):
            nonlocal drawing, last_x, last_y
            drawing = True
            last_x, last_y = event.x, event.y
            canvas.create_oval(event.x-brush_size.get()//2, event.y-brush_size.get()//2,
                               event.x+brush_size.get()//2, event.y+brush_size.get()//2,
                               fill='black', outline='black')
        def stop_draw(event):
            nonlocal drawing, last_x, last_y
            drawing = False
            last_x, last_y = None, None
        canvas.bind("<Button-1>", start_draw)
        canvas.bind("<B1-Motion>", draw_line)
        canvas.bind("<ButtonRelease-1>", stop_draw)
        # Brush size slider
        brush_frame = tk.Frame(editor)
        brush_frame.pack(pady=5)
        tk.Label(brush_frame, text="Brush size:").pack(side=tk.LEFT)
        tk.Scale(brush_frame, from_=1, to=scale*2, orient=tk.HORIZONTAL, variable=brush_size).pack(side=tk.LEFT, padx=5)
        def clear_mask():
            nonlocal mask_np
            canvas.delete("all")
            mask_np = np.ones((h_latent, w_latent), dtype=bool)
            blank_img = Image.new('L', draw_size, 255)
            self.draw_photo = ImageTk.PhotoImage(blank_img)
            canvas.create_image(0, 0, anchor=tk.NW, image=self.draw_photo)
        tk.Button(editor, text="Clear Mask", command=clear_mask).pack(pady=5)
        def apply_mask():
            # Convert canvas drawing to latent mask
            # Get the drawn image from canvas as PIL
            ps = canvas.postscript(colormode='color')
            from io import BytesIO
            import subprocess
            # Alternative: use PIL ImageGrab (simpler)
            from PIL import ImageGrab
            x0 = editor.winfo_rootx() + canvas.winfo_x()
            y0 = editor.winfo_rooty() + canvas.winfo_y()
            x1 = x0 + canvas.winfo_width()
            y1 = y0 + canvas.winfo_height()
            img = ImageGrab.grab(bbox=(x0, y0, x1, y1)).convert('L')
            img = img.resize((w_latent, h_latent), Image.NEAREST)
            # White = keep, Black = mask
            mask_np = np.array(img) < 128  # black areas become masked (False)
            self.custom_mask = ~mask_np  # True = keep
            editor.destroy()
            self.update_mask_preview()
        tk.Button(editor, text="Apply Mask", command=apply_mask, bg="lightgreen").pack(pady=5)

    def run_inpainting(self):
        if self.inpaint_image is None:
            self.inpaint_info.config(text="Load an image first.")
            return
        if not self.maskgit_wrapper or not self.vqvae_model:
            self.inpaint_info.config(text="Models not loaded!")
            return

        img_size = self.settings['img_size'].get()
        color_mode = self.settings['color_mode'].get()
        if color_mode == 'rgb':
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
            img_tensor = transform(self.inpaint_image).unsqueeze(0).to(self.device)
        else:
            transform = transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.5,))
            ])
            img_tensor = transform(self.inpaint_image).unsqueeze(0).to(self.device)

        self.vqvae_model.eval()
        with torch.no_grad():
            indices = self.vqvae_model.encode_indices(img_tensor)
        h_latent = self.vqvae_model.latent_h
        w_latent = self.vqvae_model.latent_w

        mask_type = self.mask_type.get()
        if mask_type == 'custom' and self.custom_mask is not None:
            mask_latent = self.custom_mask
        else:
            mask_latent = self.create_mask(h_latent, w_latent, mask_type, self.mask_ratio.get())
        mask_flat = torch.from_numpy(mask_latent.flatten()).bool().to(self.device).unsqueeze(0)

        n_variations = self.inpaint_num.get()
        steps = self.inpaint_steps.get()
        temp = self.inpaint_temp.get()

        self.maskgit_model.eval()
        if self.text_encoder:
            self.text_encoder.eval()

        fixed_tokens = indices.expand(n_variations, -1)
        fixed_mask = mask_flat.expand(n_variations, -1)

        with torch.no_grad():
            generated_tokens = self.maskgit_wrapper.sample(
                n_samples=n_variations,
                cond=None,
                steps=steps,
                temperature=temp,
                fixed_tokens=fixed_tokens,
                fixed_mask=fixed_mask
            )
            samples = self.vqvae_model.decode_from_indices(generated_tokens)
        samples = (samples + 1) / 2
        samples = samples.clamp(0,1).cpu().numpy()

        self.display_inpaint_results(samples, n_variations)

    def display_inpaint_results(self, samples, n):
        thumb = 128
        grid_size = int(math.ceil(math.sqrt(n)))
        total = grid_size * thumb
        grid_img = Image.new('RGB', (total, total), color=(128,128,128))
        for i in range(n):
            row = i // grid_size
            col = i % grid_size
            if i < len(samples):
                if samples[i].shape[0] == 1:
                    img = np.stack([samples[i][0]]*3, axis=-1)
                else:
                    img = samples[i].transpose(1,2,0)
                img = (img * 255).astype(np.uint8)
                pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                grid_img.paste(pil_img, (col*thumb, row*thumb))
        canvas_w = min(400, grid_img.width)
        canvas_h = min(400, grid_img.height)
        display_img = grid_img.resize((canvas_w, canvas_h), Image.NEAREST)
        self.inpaint_photo = ImageTk.PhotoImage(display_img)
        self.inpaint_canvas.delete("all")
        self.inpaint_canvas.create_image(canvas_w//2, canvas_h//2, image=self.inpaint_photo)
        self.inpaint_info.config(text=f"Inpainting done ({n} variations)")

# ==================== Main ====================
if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = MaskGITApp(root)
    root.mainloop()