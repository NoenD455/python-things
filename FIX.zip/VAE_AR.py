import tkinter as tk
from tkinter import filedialog, ttk
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from torchvision.transforms import functional as F_vision
import torch.nn.functional as F
from PIL import Image, ImageTk
import os
import threading
import queue
import numpy as np
import multiprocessing
import time
import random
import math
import csv

# ==================== Helper ====================

def load_image_as_rgb(path):
    img = Image.open(path)
    if img.mode == 'RGBA':
        bg = Image.new('RGB', img.size, (0, 0, 0))
        bg.paste(img, mask=img.split()[3])
        return bg
    else:
        return img.convert('RGB')

def load_image_as_grayscale(path):
    return Image.open(path).convert('L')

def text_to_indices(text, max_len=128):
    indices = []
    for ch in text[:max_len]:
        idx = ord(ch) if ord(ch) < 256 else 0
        indices.append(idx)
    if len(indices) < max_len:
        indices += [0] * (max_len - len(indices))
    return indices

# ==================== Scalar Quantizer ====================

class ScalarQuantizer(nn.Module):
    def __init__(self, num_levels, commitment_cost=0.25, value_range=(-1.0, 1.0)):
        super().__init__()
        self.num_levels = num_levels
        self.commitment_cost = commitment_cost
        self.value_range = value_range
        levels = torch.linspace(value_range[0], value_range[1], num_levels)
        self.register_buffer('levels', levels)

    def forward(self, z):
        B, C, H, W = z.shape
        z_flat = z.view(B, C, H, W, 1)
        levels = self.levels.view(1, 1, 1, 1, -1)
        dist = (z_flat - levels).pow(2)
        indices = dist.argmin(dim=-1)
        z_q = self.levels[indices]
        commitment_loss = F.mse_loss(z, z_q.detach()) * self.commitment_cost
        z_q_st = z + (z_q - z).detach()
        return z_q_st, commitment_loss, indices

# ==================== FlexVAE (from LDM) ====================

VAE_SIZE_CONFIGS = {
    'tiny':   (2, [0.25, 0.5]),
    'small':  (3, [0.25, 0.5, 1.0]),
    'medium': (3, [0.5, 1.0, 2.0]),
    'big':    (3, [1.0, 2.0, 4.0]),
    'large':  (3, [2.0, 4.0, 8.0]),
}

class FlexEncoder(nn.Module):
    def __init__(self, in_channels=3, base_channels=32, latent_channels=8,
                 latent_h=4, latent_w=4, size='big'):
        super().__init__()
        self.latent_channels = latent_channels
        self.latent_h = latent_h
        self.latent_w = latent_w
        self.size = size
        if size not in VAE_SIZE_CONFIGS:
            raise ValueError(f"Unknown VAE size '{size}'")
        num_blocks, multipliers = VAE_SIZE_CONFIGS[size]
        self.down_blocks = nn.ModuleList()
        in_ch = in_channels
        for i, mult in enumerate(multipliers):
            out_ch = int(base_channels * mult)
            self.down_blocks.append(nn.Conv2d(in_ch, out_ch, 3, stride=2, padding=1))
            self.down_blocks.append(nn.LeakyReLU(0.2))
            in_ch = out_ch
        self.conv_mu = nn.Conv2d(in_ch, latent_channels, 3, padding=1)
        self.conv_logvar = nn.Conv2d(in_ch, latent_channels, 3, padding=1)
        self.adaptive_pool = nn.AdaptiveAvgPool2d((latent_h, latent_w))

    def forward(self, x):
        for layer in self.down_blocks:
            x = layer(x)
        mu = self.conv_mu(x)
        logvar = self.conv_logvar(x)
        mu = self.adaptive_pool(mu)
        logvar = self.adaptive_pool(logvar)
        return mu, logvar

class FlexDecoder(nn.Module):
    def __init__(self, latent_channels=8, base_channels=32, out_channels=3,
                 latent_h=4, latent_w=4, size='big'):
        super().__init__()
        self.latent_h = latent_h
        self.latent_w = latent_w
        self.size = size
        if size not in VAE_SIZE_CONFIGS:
            raise ValueError(f"Unknown VAE size '{size}'")
        num_blocks, multipliers = VAE_SIZE_CONFIGS[size]
        highest_mult = multipliers[-1]
        highest_ch = int(base_channels * highest_mult)
        self.init_conv = nn.Conv2d(latent_channels, highest_ch, 3, padding=1)
        self.act = nn.LeakyReLU(0.2)
        self.up_blocks = nn.ModuleList()
        in_ch = highest_ch
        for i in range(num_blocks):
            if i < num_blocks - 1:
                out_mult = multipliers[num_blocks - 2 - i]
                out_ch = int(base_channels * out_mult)
            else:
                out_ch = base_channels if multipliers[0] != 1.0 else base_channels
            self.up_blocks.append(nn.ConvTranspose2d(in_ch, out_ch, 4, stride=2, padding=1))
            self.up_blocks.append(nn.LeakyReLU(0.2))
            in_ch = out_ch
        self.conv_out = nn.Conv2d(in_ch, out_channels, 3, padding=1)

    def forward(self, z, target_size=None):
        if z.shape[2] != self.latent_h or z.shape[3] != self.latent_w:
            z = F.interpolate(z, size=(self.latent_h, self.latent_w), mode='bilinear', align_corners=False)
        x = self.act(self.init_conv(z))
        for layer in self.up_blocks:
            x = layer(x)
        out = torch.tanh(self.conv_out(x))
        if target_size is not None and (out.shape[2] != target_size[0] or out.shape[3] != target_size[1]):
            out = F.interpolate(out, size=target_size, mode='bilinear', align_corners=False)
        return out

class FlexVAE(nn.Module):
    def __init__(self, in_channels=3, base_channels=32, latent_channels=8,
                 latent_h=4, latent_w=4, size='big'):
        super().__init__()
        self.encoder = FlexEncoder(in_channels, base_channels, latent_channels, latent_h, latent_w, size)
        self.decoder = FlexDecoder(latent_channels, base_channels, in_channels, latent_h, latent_w, size)
        self.latent_channels = latent_channels
        self.latent_h = latent_h
        self.latent_w = latent_w
        self.size = size

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        mu, logvar = self.encoder(x)
        z = self.reparameterize(mu, logvar)
        recon = self.decoder(z, target_size=(x.shape[2], x.shape[3]))
        return recon, mu, logvar

    def encode(self, x):
        mu, _ = self.encoder(x)
        return mu

    def decode(self, z, target_size=None):
        return self.decoder(z, target_size=target_size)

# ==================== Quantized VAE ====================

class QuantizedVAE(nn.Module):
    def __init__(self, in_channels=3, base_channels=32, latent_channels=8,
                 latent_h=4, latent_w=4, size='big', num_levels=256, commitment_cost=0.25):
        super().__init__()
        self.vae = FlexVAE(in_channels, base_channels, latent_channels, latent_h, latent_w, size)
        self.quantizer = ScalarQuantizer(num_levels, commitment_cost)
        self.latent_channels = latent_channels
        self.latent_h = latent_h
        self.latent_w = latent_w
        self.num_levels = num_levels

    def forward(self, x):
        mu, logvar = self.vae.encoder(x)
        z = self.vae.reparameterize(mu, logvar)
        z_q, vq_loss, indices = self.quantizer(z)
        recon = self.vae.decode(z_q, target_size=(x.shape[2], x.shape[3]))
        kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp()) / x.size(0)
        return recon, vq_loss, kl_loss, indices

    def encode_indices(self, x):
        mu, _ = self.vae.encoder(x)
        _, _, indices = self.quantizer(mu)
        return indices.view(x.size(0), -1)  # (B, C*H*W)

    def decode_from_indices(self, indices):
        B = indices.size(0)
        indices = torch.clamp(indices, 0, self.num_levels - 1)
        z_q = self.quantizer.levels[indices]
        z_q = z_q.view(B, self.latent_channels, self.latent_h, self.latent_w)
        return self.vae.decode(z_q)

# ==================== Text Encoder ====================

class TextEncoder(nn.Module):
    def __init__(self, vocab_size=256, embed_dim=64, hidden_size=64, num_layers=2, cond_dim=256):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.gru = nn.GRU(embed_dim, hidden_size, num_layers,
                          batch_first=True, bidirectional=True, dropout=0.1 if num_layers>1 else 0)
        self.fc = nn.Linear(hidden_size * 2, cond_dim)

    def forward(self, x):
        emb = self.embedding(x)
        _, h = self.gru(emb)
        h_fwd = h[-2, :, :]
        h_bwd = h[-1, :, :]
        h_cat = torch.cat([h_fwd, h_bwd], dim=1)
        return self.fc(h_cat)

# ==================== 2D Positional Embedding ====================

class PositionalEmbedding2D(nn.Module):
    """Learnable positional embeddings for flattened (C, H, W) sequence."""
    def __init__(self, embed_dim, max_C=32, max_H=16, max_W=16):
        super().__init__()
        self.embed_dim = embed_dim
        self.channel_emb = nn.Embedding(max_C, embed_dim)
        self.row_emb = nn.Embedding(max_H, embed_dim)
        self.col_emb = nn.Embedding(max_W, embed_dim)

    def forward(self, C, H, W, device):
        # Create position indices for each element in flattened order
        idx = torch.arange(C * H * W, device=device)
        c_idx = idx // (H * W)
        h_idx = (idx % (H * W)) // W
        w_idx = idx % W
        return self.channel_emb(c_idx) + self.row_emb(h_idx) + self.col_emb(w_idx)

# ==================== Conditional Sequence Models (modified) ====================

class ConditionalCausalSelfAttention(nn.Module):
    def __init__(self, embed_dim, num_heads, dropout=0.1):
        super().__init__()
        assert embed_dim % num_heads == 0
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.qkv = nn.Linear(embed_dim, 3 * embed_dim)
        self.proj = nn.Linear(embed_dim, embed_dim)
        self.attn_drop = nn.Dropout(dropout)
        self.proj_drop = nn.Dropout(dropout)

    def forward(self, x, mask=None):
        B, T, C = x.shape
        qkv = self.qkv(x).reshape(B, T, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        attn = (q @ k.transpose(-2, -1)) / (self.head_dim ** 0.5)
        if mask is not None:
            attn = attn.masked_fill(mask == 0, float('-inf'))
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        y = (attn @ v).transpose(1, 2).reshape(B, T, C)
        y = self.proj_drop(self.proj(y))
        return y

class ConditionalTransformerBlock(nn.Module):
    def __init__(self, embed_dim, num_heads, mlp_ratio=4.0, dropout=0.1):
        super().__init__()
        self.ln1 = nn.LayerNorm(embed_dim)
        self.attn = ConditionalCausalSelfAttention(embed_dim, num_heads, dropout)
        self.ln2 = nn.LayerNorm(embed_dim)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, int(embed_dim * mlp_ratio)),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(int(embed_dim * mlp_ratio), embed_dim),
            nn.Dropout(dropout)
        )

    def forward(self, x, mask=None):
        x = x + self.attn(self.ln1(x), mask)
        x = x + self.mlp(self.ln2(x))
        return x

class ConditionalGPT(nn.Module):
    def __init__(self, vocab_size, max_seq_len, cond_dim=256, embed_dim=256, num_layers=6,
                 num_heads=4, mlp_ratio=4.0, dropout=0.1, use_2d_pos=False, latent_C=8, latent_H=4, latent_W=4):
        super().__init__()
        self.vocab_size = vocab_size
        self.max_seq_len = max_seq_len
        self.embed_dim = embed_dim
        self.use_2d_pos = use_2d_pos
        self.token_embedding = nn.Embedding(vocab_size, embed_dim)
        if use_2d_pos:
            self.pos_embedding = PositionalEmbedding2D(embed_dim, max_C=latent_C, max_H=latent_H, max_W=latent_W)
        else:
            self.pos_embedding = nn.Embedding(max_seq_len, embed_dim)
        self.cond_proj = nn.Linear(cond_dim, embed_dim) if cond_dim is not None else None
        self.blocks = nn.ModuleList([
            ConditionalTransformerBlock(embed_dim, num_heads, mlp_ratio, dropout)
            for _ in range(num_layers)
        ])
        self.ln_f = nn.LayerNorm(embed_dim)
        self.head = nn.Linear(embed_dim, vocab_size, bias=False)
        self.register_buffer('causal_mask',
                             torch.tril(torch.ones(max_seq_len, max_seq_len)).view(1,1,max_seq_len,max_seq_len))

    def forward(self, x, cond=None, C=None, H=None, W=None):
        B, T = x.shape
        tok_emb = self.token_embedding(x)
        if self.use_2d_pos and C is not None:
            pos_emb = self.pos_embedding(C, H, W, x.device)[:T]  # (T, embed_dim)
        else:
            pos_emb = self.pos_embedding(torch.arange(T, device=x.device))
        x_emb = tok_emb + pos_emb.unsqueeze(0)
        if cond is not None and self.cond_proj is not None:
            cond_emb = self.cond_proj(cond).unsqueeze(1)
            x_emb = x_emb + cond_emb
        mask = self.causal_mask[:, :, :T, :T]
        for block in self.blocks:
            x_emb = block(x_emb, mask)
        x_emb = self.ln_f(x_emb)
        logits = self.head(x_emb)
        return logits

class ConditionalGRUModel(nn.Module):
    def __init__(self, vocab_size, max_seq_len, cond_dim=256, embed_dim=128, hidden_size=256,
                 num_layers=2, dropout=0.1, use_2d_pos=False, latent_C=8, latent_H=4, latent_W=4):
        super().__init__()
        self.vocab_size = vocab_size
        self.max_seq_len = max_seq_len
        self.embed_dim = embed_dim
        self.hidden_size = hidden_size
        self.use_2d_pos = use_2d_pos
        self.token_embedding = nn.Embedding(vocab_size, embed_dim)
        if use_2d_pos:
            self.pos_embedding = PositionalEmbedding2D(embed_dim, max_C=latent_C, max_H=latent_H, max_W=latent_W)
        else:
            self.pos_embedding = nn.Parameter(torch.randn(1, max_seq_len, embed_dim))
        self.cond_proj = nn.Linear(cond_dim, num_layers * hidden_size) if cond_dim is not None else None
        self.gru = nn.GRU(embed_dim, hidden_size, num_layers,
                          batch_first=True, dropout=dropout if num_layers > 1 else 0)
        self.fc = nn.Linear(hidden_size, vocab_size)

    def forward(self, x, cond=None, C=None, H=None, W=None):
        B, T = x.shape
        emb = self.token_embedding(x)
        if self.use_2d_pos and C is not None:
            pos = self.pos_embedding(C, H, W, x.device)[:T]  # (T, embed_dim)
            emb = emb + pos.unsqueeze(0)
        else:
            emb = emb + self.pos_embedding[:, :T, :]
        if cond is not None and self.cond_proj is not None:
            h0 = self.cond_proj(cond).view(B, -1, self.hidden_size).permute(1, 0, 2).contiguous()
        else:
            h0 = torch.zeros(self.gru.num_layers, B, self.hidden_size, device=x.device)
        out, _ = self.gru(emb, h0)
        logits = self.fc(out)
        return logits

class ConditionalMaskedConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, mask_type='A', padding=1):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, padding=padding)
        self.register_buffer('mask', self._create_mask(mask_type, in_channels, out_channels, kernel_size))

    def _create_mask(self, mask_type, in_c, out_c, k):
        mask = torch.ones(out_c, in_c, k, k)
        center = k // 2
        for i in range(k):
            for j in range(k):
                if i > center or (i == center and j > center):
                    mask[:, :, i, j] = 0
        if mask_type == 'A':
            mask[:, :, center, center] = 0
        return mask

    def forward(self, x):
        self.conv.weight.data *= self.mask
        return self.conv(x)

class ConditionalPixelCNN(nn.Module):
    def __init__(self, vocab_size, cond_dim=256, embed_dim=64, num_layers=6, hidden_dim=128, kernel_size=3):
        super().__init__()
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        self.num_layers = num_layers
        self.hidden_dim = hidden_dim
        self.kernel_size = kernel_size
        self.padding = kernel_size // 2
        self.token_embedding = nn.Embedding(vocab_size, embed_dim)
        self.cond_proj = nn.Linear(cond_dim, embed_dim) if cond_dim is not None else None
        in_ch = embed_dim * 2 if cond_dim is not None else embed_dim
        self.conv_in = ConditionalMaskedConv2d(in_ch, hidden_dim, kernel_size, mask_type='A', padding=self.padding)
        self.act_in = nn.ReLU()
        self.blocks = nn.ModuleList()
        for _ in range(num_layers - 1):
            block = nn.Sequential(
                ConditionalMaskedConv2d(hidden_dim, hidden_dim, kernel_size, mask_type='B', padding=self.padding),
                nn.ReLU(),
                ConditionalMaskedConv2d(hidden_dim, hidden_dim, kernel_size, mask_type='B', padding=self.padding),
                nn.ReLU()
            )
            self.blocks.append(block)
        self.conv_out = nn.Conv2d(hidden_dim, vocab_size - 1, kernel_size=1)

    def forward(self, x, cond=None):
        B, H, W = x.shape
        x_emb = self.token_embedding(x).permute(0, 3, 1, 2)
        if cond is not None and self.cond_proj is not None:
            cond_emb = self.cond_proj(cond).view(B, -1, 1, 1).expand(-1, -1, H, W)
            h = torch.cat([x_emb, cond_emb], dim=1)
        else:
            h = x_emb
        h = self.act_in(self.conv_in(h))
        for block in self.blocks:
            h = h + block(h)
        logits = self.conv_out(h)
        return logits

# ==================== Datasets ====================

class UnconditionalImageDataset(Dataset):
    def __init__(self, image_paths, img_size=32, color_mode='rgb', aug_settings=None):
        self.image_paths = image_paths
        self.img_size = img_size
        self.color_mode = color_mode.lower()
        self.aug_settings = aug_settings or {}
        if self.color_mode == 'rgb':
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.5,))
            ])

    def __len__(self):
        return len(self.image_paths)

    def apply_augmentations(self, pil_img):
        img = pil_img.copy()
        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F_vision.hflip(img)
        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F_vision.rotate(img, angle, interpolation=Image.BICUBIC)
        return img

    def __getitem__(self, idx):
        try:
            if self.color_mode == 'rgb':
                pil_img = load_image_as_rgb(self.image_paths[idx])
            else:
                pil_img = load_image_as_grayscale(self.image_paths[idx])
            pil_img = self.apply_augmentations(pil_img)
            img_tensor = self.transform(pil_img)
            return img_tensor
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            if self.color_mode == 'rgb':
                return torch.zeros(3, self.img_size, self.img_size)
            else:
                return torch.zeros(1, self.img_size, self.img_size)

class ConditionalImageDataset(Dataset):
    def __init__(self, image_paths, labels, img_size=32, color_mode='rgb', aug_settings=None, text_max_len=128):
        self.image_paths = image_paths
        self.labels = labels
        self.img_size = img_size
        self.color_mode = color_mode.lower()
        self.aug_settings = aug_settings or {}
        self.text_max_len = text_max_len
        if self.color_mode == 'rgb':
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
            ])
        else:
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize((0.5,), (0.5,))
            ])

    def __len__(self):
        return len(self.image_paths)

    def apply_augmentations(self, pil_img):
        img = pil_img.copy()
        if self.aug_settings.get('flip_horizontal', False) and random.random() < 0.5:
            img = F_vision.hflip(img)
        if self.aug_settings.get('rotation', False) and random.random() < 0.5:
            angle = random.uniform(-30, 30)
            img = F_vision.rotate(img, angle, interpolation=Image.BICUBIC)
        return img

    def __getitem__(self, idx):
        try:
            if self.color_mode == 'rgb':
                pil_img = load_image_as_rgb(self.image_paths[idx])
            else:
                pil_img = load_image_as_grayscale(self.image_paths[idx])
            pil_img = self.apply_augmentations(pil_img)
            img_tensor = self.transform(pil_img)
            text = self.labels[idx].replace('_', ' ')
            text_indices = text_to_indices(text, self.text_max_len)
            text_tensor = torch.tensor(text_indices, dtype=torch.long)
            return img_tensor, text_tensor
        except Exception as e:
            print(f"Error loading {self.image_paths[idx]}: {e}")
            if self.color_mode == 'rgb':
                img_tensor = torch.zeros(3, self.img_size, self.img_size)
            else:
                img_tensor = torch.zeros(1, self.img_size, self.img_size)
            text_tensor = torch.zeros(self.text_max_len, dtype=torch.long)
            return img_tensor, text_tensor

# ==================== Model Configs ====================

TRANSFORMER_CONFIGS = {
    'GPT-tiny': {'embed_dim': 128, 'num_layers': 4, 'num_heads': 4},
    'GPT-small': {'embed_dim': 256, 'num_layers': 6, 'num_heads': 4},
    'GPT-medium': {'embed_dim': 384, 'num_layers': 8, 'num_heads': 6},
    'GPT-large': {'embed_dim': 512, 'num_layers': 10, 'num_heads': 8},
}

GRU_CONFIGS = {
    'GRU-tiny': {'embed_dim': 64, 'hidden_size': 128, 'num_layers': 2},
    'GRU-small': {'embed_dim': 128, 'hidden_size': 256, 'num_layers': 2},
    'GRU-medium': {'embed_dim': 256, 'hidden_size': 512, 'num_layers': 3},
    'GRU-large': {'embed_dim': 384, 'hidden_size': 768, 'num_layers': 3},
}

PIXELCNN_CONFIGS = {
    'pixelcnn-tiny': {'embed_dim': 32, 'num_layers': 4, 'hidden_dim': 64},
    'pixelcnn-small': {'embed_dim': 64, 'num_layers': 6, 'hidden_dim': 128},
    'pixelcnn-medium': {'embed_dim': 128, 'num_layers': 8, 'hidden_dim': 256},
}

# ==================== GUI Application ====================

class QuantizedVAETransformerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Scalar-Quantized VAE + Conditional Transformer/GRU/PixelCNN")
        self.root.geometry("1200x800")

        self.image_paths = []
        self.labels = []
        self.csv_path = None
        self.training_vae = False
        self.training_cond_seq = False
        self.vae_model = None
        self.cond_seq_model = None
        self.cond_seq_model_type = None
        self.text_encoder = None
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        self.current_epoch_vae = 0
        self.current_epoch_cond_seq = 0

        self.message_queue_vae = queue.Queue()
        self.message_queue_cond_seq = queue.Queue()

        self.settings = {
            'img_size': tk.IntVar(value=32),
            'color_mode': tk.StringVar(value='rgb'),

            # VAE settings
            'vae_size': tk.StringVar(value='big'),
            'vae_base_channels': tk.IntVar(value=32),
            'vae_latent_channels': tk.IntVar(value=8),
            'vae_latent_h': tk.IntVar(value=4),
            'vae_latent_w': tk.IntVar(value=4),
            'vae_num_levels': tk.IntVar(value=256),
            'vae_commitment_cost': tk.DoubleVar(value=0.25),
            'vae_kl_weight': tk.DoubleVar(value=0.0001),
            'vae_batch_size': tk.IntVar(value=16),
            'vae_lr': tk.DoubleVar(value=1e-3),
            'vae_num_workers': tk.IntVar(value=0),

            # Sequence settings
            'seq_len_override': tk.IntVar(value=0),  # 0 = use C*H*W
            'use_2d_pos_emb': tk.BooleanVar(value=False),

            'seq_model_type': tk.StringVar(value='transformer'),
            'transformer_model_size': tk.StringVar(value='GPT-small'),
            'gru_model_size': tk.StringVar(value='GRU-small'),
            'pixelcnn_model_size': tk.StringVar(value='pixelcnn-small'),
            'seq_dropout': tk.DoubleVar(value=0.1),

            'cond_enabled': tk.BooleanVar(value=False),
            'cond_embed_dim': tk.IntVar(value=64),
            'cond_hidden_size': tk.IntVar(value=64),
            'cond_num_layers': tk.IntVar(value=2),
            'cond_dim': tk.IntVar(value=128),
            'cond_text_max_len': tk.IntVar(value=128),
            'cond_batch_size': tk.IntVar(value=16),
            'cond_lr': tk.DoubleVar(value=5e-4),
            'cond_temperature': tk.DoubleVar(value=0.8),
            'cond_dropout_prob': tk.DoubleVar(value=0.1),
        }

        self.aug_settings = {
            'flip_horizontal': tk.BooleanVar(value=True),
            'rotation': tk.BooleanVar(value=False),
        }

        self.real_time_preview = tk.BooleanVar(value=False)
        self.preview_interval = tk.IntVar(value=5)

        self.thumbnail_size = 128
        self.setup_gui()
        self.root.after(100, self.process_messages_vae)
        self.root.after(100, self.process_messages_cond_seq)

    # ------------------ GUI Setup ------------------
    def setup_gui(self):
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.vae_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.vae_tab, text='VAE Training')
        self.setup_vae_tab()

        self.cond_seq_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.cond_seq_tab, text='Conditional Seq Training')
        self.setup_cond_seq_tab()

        self.settings_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.settings_tab, text='Settings')
        self.setup_settings_tab()

        self.generation_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.generation_tab, text='Generation')
        self.setup_generation_tab()

        self.status_label = tk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_vae_tab(self):
        main_frame = tk.Frame(self.vae_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="Quantized VAE Training", font=("Arial",12,"bold")).pack(pady=(0,10))

        img_frame = tk.LabelFrame(left_frame, text="Training Images", padx=5, pady=5)
        img_frame.pack(fill=tk.X, pady=(0,10))
        tk.Button(img_frame, text="Add Images", command=self.add_images, width=20).pack(pady=2)
        tk.Button(img_frame, text="Add Folder", command=self.add_folder, width=20).pack(pady=2)
        tk.Button(img_frame, text="Clear All", command=self.clear_images, width=20).pack(pady=2)
        self.image_listbox = tk.Listbox(img_frame, height=5)
        self.image_listbox.pack(fill=tk.X, pady=2)

        tk.Button(left_frame, text="Initialize VAE", command=self.initialize_vae, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.vae_epoch_var = tk.StringVar(value="50")
        tk.Entry(epoch_frame, textvariable=self.vae_epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start VAE Training", command=self.start_vae_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop VAE Training", command=self.stop_vae_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save VAE", command=self.save_vae, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load VAE", command=self.load_vae, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Reconstructions (random images)", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.vae_preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=128)
        self.vae_preview_canvas.pack()

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.vae_log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.vae_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.vae_log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.vae_log_text.config(yscrollcommand=scrollbar.set)

    def setup_cond_seq_tab(self):
        main_frame = tk.Frame(self.cond_seq_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = tk.Frame(main_frame, width=300)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0,10))
        left_frame.pack_propagate(False)

        tk.Label(left_frame, text="Conditional Sequence Model", font=("Arial",12,"bold")).pack(pady=(0,10))
        tk.Label(left_frame, text="Requires a trained VAE", fg="blue").pack(pady=5)

        cond_frame = tk.LabelFrame(left_frame, text="Text Conditioning", padx=5, pady=5)
        cond_frame.pack(fill=tk.X, pady=5)
        self.cond_enabled_cb = tk.Checkbutton(cond_frame, text="Enable text conditioning",
                                              variable=self.settings['cond_enabled'])
        self.cond_enabled_cb.pack(anchor='w')
        tk.Button(cond_frame, text="Load CSV (imagename,label)", command=self.load_csv, width=20).pack(pady=2)
        tk.Button(cond_frame, text="Use Filenames as Labels", command=self.use_filenames_as_labels, width=20).pack(pady=2)
        self.csv_status = tk.Label(cond_frame, text="No CSV loaded", fg="red")
        self.csv_status.pack()

        tk.Button(left_frame, text="Initialize Models", command=self.initialize_cond_models, width=20).pack(pady=5)
        epoch_frame = tk.Frame(left_frame)
        epoch_frame.pack(pady=5)
        tk.Label(epoch_frame, text="Epochs:").pack(side=tk.LEFT)
        self.cond_epoch_var = tk.StringVar(value="100")
        tk.Entry(epoch_frame, textvariable=self.cond_epoch_var, width=8).pack(side=tk.LEFT, padx=5)

        tk.Button(left_frame, text="Start Training", command=self.start_cond_training,
                  width=20, bg="lightgreen").pack(pady=5)
        tk.Button(left_frame, text="Stop Training", command=self.stop_cond_training,
                  width=20, bg="salmon").pack(pady=5)
        tk.Button(left_frame, text="Save Model", command=self.save_cond_model, width=20).pack(pady=5)
        tk.Button(left_frame, text="Load Model", command=self.load_cond_model, width=20).pack(pady=5)

        right_frame = tk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        preview_frame = tk.LabelFrame(right_frame, text="Conditional Samples (fixed prompt test)", padx=5, pady=5)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0,5))
        self.cond_preview_canvas = tk.Canvas(preview_frame, bg='gray', width=256, height=256)
        self.cond_preview_canvas.pack()
        tk.Label(preview_frame, text="Test prompt (leave empty for unconditional):").pack()
        self.cond_test_prompt = tk.Entry(preview_frame)
        self.cond_test_prompt.insert(0, "a cute cat")
        self.cond_test_prompt.pack(fill=tk.X)
        tk.Button(preview_frame, text="Generate Preview", command=self.cond_preview).pack(pady=2)

        log_frame = tk.LabelFrame(right_frame, text="Log", padx=5, pady=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.cond_log_text = tk.Text(log_frame, height=15, font=("Courier",9))
        self.cond_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.cond_log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.cond_log_text.config(yscrollcommand=scrollbar.set)

    def setup_settings_tab(self):
        main_frame = tk.Frame(self.settings_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(main_frame, text="Model Settings", font=("Arial",14,"bold")).pack(pady=(0,20))

        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Image
        img_frame = tk.LabelFrame(scrollable_frame, text="Image", padx=10, pady=10)
        img_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(img_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Color mode:", width=20, anchor='w').pack(side=tk.LEFT)
        om = ttk.Combobox(f, textvariable=self.settings['color_mode'], values=['rgb', 'grayscale'], state='readonly', width=10)
        om.pack(side=tk.RIGHT)
        f = tk.Frame(img_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Image size:", width=20, anchor='w').pack(side=tk.LEFT)
        spin = ttk.Spinbox(f, from_=16, to=128, textvariable=self.settings['img_size'], width=8)
        spin.pack(side=tk.RIGHT)

        # VAE Settings
        vae_frame = tk.LabelFrame(scrollable_frame, text="VAE (Scalar-Quantized)", padx=10, pady=10)
        vae_frame.pack(fill=tk.X, pady=5)

        f_size = tk.Frame(vae_frame); f_size.pack(fill=tk.X, pady=2)
        tk.Label(f_size, text="VAE size:", width=20, anchor='w').pack(side=tk.LEFT)
        size_combo = ttk.Combobox(f_size, textvariable=self.settings['vae_size'],
                                  values=list(VAE_SIZE_CONFIGS.keys()), state='readonly', width=10)
        size_combo.pack(side=tk.RIGHT)

        vae_params = [
            ("Base channels:", 'vae_base_channels', 16, 128, int),
            ("Latent channels:", 'vae_latent_channels', 1, 32, int),
            ("Latent height:", 'vae_latent_h', 1, 16, int),
            ("Latent width:", 'vae_latent_w', 1, 16, int),
            ("Num Levels:", 'vae_num_levels', 16, 2048, int),
            ("Commitment cost:", 'vae_commitment_cost', 0.1, 1.0, float),
            ("KL weight:", 'vae_kl_weight', 1e-6, 1e-2, float),
            ("Batch size:", 'vae_batch_size', 1, 32, int),
            ("Learning rate:", 'vae_lr', 1e-5, 1e-2, float),
            ("Workers:", 'vae_num_workers', 0, 4, int),
        ]
        for label, key, low, high, typ in vae_params:
            f = tk.Frame(vae_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            if typ == int:
                spin = ttk.Spinbox(f, from_=low, to=high, textvariable=self.settings[key], width=8)
            else:
                spin = ttk.Entry(f, textvariable=self.settings[key], width=8)
            spin.pack(side=tk.RIGHT)

        # Sequence Settings
        seq_frame = tk.LabelFrame(scrollable_frame, text="Sequence Settings", padx=10, pady=10)
        seq_frame.pack(fill=tk.X, pady=5)
        f = tk.Frame(seq_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Seq len override (0=auto):", width=20, anchor='w').pack(side=tk.LEFT)
        spin = ttk.Spinbox(f, from_=0, to=4096, textvariable=self.settings['seq_len_override'], width=8)
        spin.pack(side=tk.RIGHT)
        cb = tk.Checkbutton(seq_frame, text="Use 2D Positional Embeddings (Transformer/GRU only)",
                            variable=self.settings['use_2d_pos_emb'])
        cb.pack(anchor='w', pady=2)

        # Conditional Model Settings
        cond_frame = tk.LabelFrame(scrollable_frame, text="Conditional Model", padx=10, pady=10)
        cond_frame.pack(fill=tk.X, pady=5)

        f = tk.Frame(cond_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Model type:", width=20, anchor='w').pack(side=tk.LEFT)
        type_combo = ttk.Combobox(f, textvariable=self.settings['seq_model_type'],
                                   values=['transformer', 'gru', 'pixelcnn'], state='readonly', width=10)
        type_combo.pack(side=tk.RIGHT)

        f = tk.Frame(cond_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="Transformer size:", width=20, anchor='w').pack(side=tk.LEFT)
        trans_combo = ttk.Combobox(f, textvariable=self.settings['transformer_model_size'],
                                    values=list(TRANSFORMER_CONFIGS.keys()), state='readonly', width=10)
        trans_combo.pack(side=tk.RIGHT)

        f = tk.Frame(cond_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="GRU size:", width=20, anchor='w').pack(side=tk.LEFT)
        gru_combo = ttk.Combobox(f, textvariable=self.settings['gru_model_size'],
                                  values=list(GRU_CONFIGS.keys()), state='readonly', width=10)
        gru_combo.pack(side=tk.RIGHT)

        f = tk.Frame(cond_frame); f.pack(fill=tk.X, pady=2)
        tk.Label(f, text="PixelCNN size:", width=20, anchor='w').pack(side=tk.LEFT)
        pixel_combo = ttk.Combobox(f, textvariable=self.settings['pixelcnn_model_size'],
                                    values=list(PIXELCNN_CONFIGS.keys()), state='readonly', width=10)
        pixel_combo.pack(side=tk.RIGHT)

        seq_params = [("Dropout:", 'seq_dropout', 0.0, 0.5, float)]
        for label, key, low, high, typ in seq_params:
            f = tk.Frame(cond_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            spin = ttk.Entry(f, textvariable=self.settings[key], width=8)
            spin.pack(side=tk.RIGHT)

        # Text encoder settings
        text_frame = tk.LabelFrame(cond_frame, text="Text Encoder", padx=10, pady=10)
        text_frame.pack(fill=tk.X, pady=5)
        cond_params = [
            ("Text embed dim:", 'cond_embed_dim', 32, 256, int),
            ("Text hidden size:", 'cond_hidden_size', 64, 512, int),
            ("Text num layers:", 'cond_num_layers', 1, 4, int),
            ("Conditioning dim:", 'cond_dim', 64, 512, int),
            ("Max text length:", 'cond_text_max_len', 32, 256, int),
            ("Batch size:", 'cond_batch_size', 1, 32, int),
            ("Learning rate:", 'cond_lr', 1e-5, 1e-2, float),
            ("Sampling temp:", 'cond_temperature', 0.1, 2.0, float),
            ("CFG dropout prob:", 'cond_dropout_prob', 0.0, 0.5, float),
        ]
        for label, key, low, high, typ in cond_params:
            f = tk.Frame(text_frame); f.pack(fill=tk.X, pady=2)
            tk.Label(f, text=label, width=20, anchor='w').pack(side=tk.LEFT)
            if typ == int:
                spin = ttk.Spinbox(f, from_=low, to=high, textvariable=self.settings[key], width=8)
            else:
                spin = ttk.Entry(f, textvariable=self.settings[key], width=8)
            spin.pack(side=tk.RIGHT)

        # Augmentations
        aug_frame = tk.LabelFrame(scrollable_frame, text="Augmentations", padx=10, pady=10)
        aug_frame.pack(fill=tk.X, pady=5)
        for label, key in [("Horizontal Flip", 'flip_horizontal'), ("Rotation (±30°)", 'rotation')]:
            cb = tk.Checkbutton(aug_frame, text=label, variable=self.aug_settings[key])
            cb.pack(anchor='w')

        # System info
        sys_frame = tk.LabelFrame(scrollable_frame, text="System", padx=10, pady=10)
        sys_frame.pack(fill=tk.X, pady=5)
        cpu = multiprocessing.cpu_count()
        tk.Label(sys_frame, text=f"CPU cores: {cpu}").pack(anchor='w')
        tk.Label(sys_frame, text=f"PyTorch threads: {torch.get_num_threads()}").pack(anchor='w')
        tk.Label(sys_frame, text=f"Device: {self.device}").pack(anchor='w')

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def setup_generation_tab(self):
        main_frame = tk.Frame(self.generation_tab)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        tk.Label(main_frame, text="Generate Images", font=("Arial",14,"bold")).pack(pady=(0,10))

        prompt_frame = tk.LabelFrame(main_frame, text="Text Prompt (leave empty for unconditional generation)", padx=5, pady=5)
        prompt_frame.pack(fill=tk.X, pady=5)
        self.gen_prompt = tk.Entry(prompt_frame, width=50)
        self.gen_prompt.insert(0, "a cute cat")
        self.gen_prompt.pack(side=tk.LEFT, padx=5)

        ctrl_frame = tk.Frame(main_frame)
        ctrl_frame.pack(pady=5)

        tk.Label(ctrl_frame, text="Number:").pack(side=tk.LEFT)
        self.gen_count = tk.IntVar(value=16)
        tk.Spinbox(ctrl_frame, from_=1, to=64, textvariable=self.gen_count, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="Temperature:").pack(side=tk.LEFT, padx=(10,0))
        self.gen_temp = tk.DoubleVar(value=self.settings['cond_temperature'].get())
        tk.Spinbox(ctrl_frame, from_=0.1, to=2.0, increment=0.1, textvariable=self.gen_temp, width=5).pack(side=tk.LEFT, padx=5)

        tk.Label(ctrl_frame, text="CFG Scale:").pack(side=tk.LEFT, padx=(10,0))
        self.cfg_scale = tk.DoubleVar(value=2.0)
        tk.Spinbox(ctrl_frame, from_=0.0, to=10.0, increment=0.5, textvariable=self.cfg_scale, width=5).pack(side=tk.LEFT, padx=5)

        self.realtime_cb = tk.Checkbutton(ctrl_frame, text="Real-time preview",
                                          variable=self.real_time_preview)
        self.realtime_cb.pack(side=tk.LEFT, padx=10)

        tk.Label(ctrl_frame, text="Update interval:").pack(side=tk.LEFT)
        tk.Spinbox(ctrl_frame, from_=1, to=20, textvariable=self.preview_interval, width=3).pack(side=tk.LEFT, padx=5)

        self.generate_btn = tk.Button(ctrl_frame, text="Generate", command=self.generate_samples, bg="lightgreen")
        self.generate_btn.pack(side=tk.LEFT, padx=5)

        self.stop_gen_btn = tk.Button(ctrl_frame, text="Stop", command=self.stop_generation,
                                      state=tk.DISABLED, bg="salmon")
        self.stop_gen_btn.pack(side=tk.LEFT, padx=5)

        scroll_frame = tk.LabelFrame(main_frame, text="Results", padx=5, pady=5)
        scroll_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        canvas_frame = tk.Frame(scroll_frame)
        canvas_frame.pack(fill=tk.BOTH, expand=True)

        self.gen_canvas = tk.Canvas(canvas_frame, bg='lightgray')
        self.v_scroll = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.gen_canvas.yview)
        self.h_scroll = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.gen_canvas.xview)
        self.gen_canvas.configure(yscrollcommand=self.v_scroll.set, xscrollcommand=self.h_scroll.set)

        self.v_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.h_scroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.gen_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.inner_frame = tk.Frame(self.gen_canvas)
        self.canvas_window = self.gen_canvas.create_window((0,0), window=self.inner_frame, anchor='nw')
        self.inner_frame.bind('<Configure>', lambda e: self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all')))

        self.gen_info = tk.Label(main_frame, text="", fg="blue")
        self.gen_info.pack()

        self.generation_active = False

    # ------------------------------------------------------------------
    # Core helper methods
    # ------------------------------------------------------------------
    def log_vae(self, msg):
        self.message_queue_vae.put(msg)

    def log_cond_seq(self, msg):
        self.message_queue_cond_seq.put(msg)

    def process_messages_vae(self):
        try:
            while True:
                msg = self.message_queue_vae.get_nowait()
                self.vae_log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.vae_log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages_vae)

    def process_messages_cond_seq(self):
        try:
            while True:
                msg = self.message_queue_cond_seq.get_nowait()
                self.cond_log_text.insert(tk.END, f"{time.strftime('%H:%M:%S')} - {msg}\n")
                self.cond_log_text.see(tk.END)
                self.status_label.config(text=msg[:50])
        except queue.Empty:
            pass
        self.root.after(100, self.process_messages_cond_seq)

    def add_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Images", "*.jpg *.jpeg *.png *.jfif *.webp *.bmp *.ico *.tiff")])
        for f in files:
            if f not in self.image_paths:
                self.image_paths.append(f)
                self.image_listbox.insert(tk.END, os.path.basename(f))
        self.log_vae(f"Added {len(files)} images. Total: {len(self.image_paths)}")
        self.log_cond_seq(f"Added {len(files)} images. Total: {len(self.image_paths)}")

    def add_folder(self):
        folder = filedialog.askdirectory()
        if not folder:
            return
        count = 0
        for root_dir, _, files in os.walk(folder):
            for file in files:
                if file.lower().endswith(('.png','.jpg','.jpeg','.jfif','.webp','.bmp', '.ico', '.tiff')):
                    full = os.path.join(root_dir, file)
                    if full not in self.image_paths:
                        self.image_paths.append(full)
                        self.image_listbox.insert(tk.END, os.path.basename(full))
                        count += 1
        self.log_vae(f"Added {count} images. Total: {len(self.image_paths)}")
        self.log_cond_seq(f"Added {count} images. Total: {len(self.image_paths)}")

    def clear_images(self):
        self.image_paths.clear()
        self.labels.clear()
        self.image_listbox.delete(0, tk.END)
        self.csv_status.config(text="No CSV loaded", fg="red")
        self.log_vae("Cleared all images")
        self.log_cond_seq("Cleared all images")

    def load_csv(self):
        fname = filedialog.askopenfilename(filetypes=[("CSV", "*.csv")])
        if not fname:
            return
        self.csv_path = fname
        image_to_label = {}
        try:
            with open(fname, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) >= 2:
                        img_name, label = row[0], row[1]
                        image_to_label[img_name] = label
        except Exception as e:
            self.log_cond_seq(f"Error reading CSV: {e}")
            return

        self.labels = []
        matched = 0
        for path in self.image_paths:
            base = os.path.basename(path)
            if base in image_to_label:
                self.labels.append(image_to_label[base])
                matched += 1
            else:
                name_no_ext = os.path.splitext(base)[0]
                self.labels.append(name_no_ext)
        self.csv_status.config(text=f"CSV loaded: {matched} matched, others use filenames", fg="green")
        self.log_cond_seq(f"CSV loaded. {matched} images matched with labels.")

    def use_filenames_as_labels(self):
        self.labels = [os.path.splitext(os.path.basename(p))[0] for p in self.image_paths]
        self.csv_status.config(text="Using filenames as labels", fg="blue")
        self.log_cond_seq("Using filenames as labels (underscores replaced with spaces)")

    # ========== VAE Methods ==========
    def initialize_vae(self):
        try:
            in_channels = 3 if self.settings['color_mode'].get() == 'rgb' else 1
            self.vae_model = QuantizedVAE(
                in_channels=in_channels,
                base_channels=self.settings['vae_base_channels'].get(),
                latent_channels=self.settings['vae_latent_channels'].get(),
                latent_h=self.settings['vae_latent_h'].get(),
                latent_w=self.settings['vae_latent_w'].get(),
                size=self.settings['vae_size'].get(),
                num_levels=self.settings['vae_num_levels'].get(),
                commitment_cost=self.settings['vae_commitment_cost'].get()
            )
            self.vae_model.to(self.device)
            self.vae_optimizer = optim.Adam(self.vae_model.parameters(), lr=self.settings['vae_lr'].get())
            seq_len = self.settings['vae_latent_channels'].get() * self.settings['vae_latent_h'].get() * self.settings['vae_latent_w'].get()
            self.log_vae(f"VAE initialized on {self.device}. Latent shape: {self.vae_model.latent_channels}x{self.vae_model.latent_h}x{self.vae_model.latent_w} -> seq len {seq_len}")
        except Exception as e:
            self.log_vae(f"Error: {e}")

    def start_vae_training(self):
        if not self.image_paths: self.log_vae("No images!"); return
        if not self.vae_model: self.log_vae("VAE not initialized!"); return
        if self.training_vae: self.log_vae("Already training."); return
        try:
            epochs = int(self.vae_epoch_var.get())
        except:
            self.log_vae("Invalid epochs")
            return
        self.training_vae = True
        self.current_epoch_vae = 0
        self.vae_start_time = time.time()
        thread = threading.Thread(target=self.train_vae_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_vae(f"VAE training started for {epochs} epochs.")

    def train_vae_loop(self, epochs):
        try:
            batch_size = self.settings['vae_batch_size'].get()
            num_workers = self.settings['vae_num_workers'].get()
            img_size = self.settings['img_size'].get()
            kl_weight = self.settings['vae_kl_weight'].get()
            color_mode = self.settings['color_mode'].get()
            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}
            dataset = UnconditionalImageDataset(self.image_paths, img_size, color_mode, aug_dict)
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=False)
            self.vae_model.train()
            for epoch in range(epochs):
                if not self.training_vae: break
                self.current_epoch_vae = epoch
                epoch_loss = 0.0
                batches = 0
                for images in loader:
                    if not self.training_vae: break
                    images = images.to(self.device)
                    recon, vq_loss, kl_loss, _ = self.vae_model(images)
                    recon_loss = F.mse_loss(recon, images)
                    loss = recon_loss + vq_loss + kl_weight * kl_loss
                    self.vae_optimizer.zero_grad()
                    loss.backward()
                    self.vae_optimizer.step()
                    epoch_loss += loss.item()
                    batches += 1
                avg_loss = epoch_loss / batches if batches else 0
                elapsed = time.time() - self.vae_start_time
                self.log_vae(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s")
                if (epoch+1) % 5 == 0:
                    self.show_vae_preview()
            self.training_vae = False
            self.log_vae("VAE training finished.")
        except Exception as e:
            self.log_vae(f"Training error: {e}")
            import traceback; traceback.print_exc()
            self.training_vae = False

    def show_vae_preview(self):
        if not self.vae_model or len(self.image_paths) == 0:
            return
        try:
            n_samples = min(16, len(self.image_paths))
            indices = random.sample(range(len(self.image_paths)), n_samples)
            color_mode = self.settings['color_mode'].get()
            dataset = UnconditionalImageDataset([self.image_paths[i] for i in indices],
                                                img_size=self.settings['img_size'].get(),
                                                color_mode=color_mode)
            loader = DataLoader(dataset, batch_size=n_samples, shuffle=False)
            images = next(iter(loader)).to(self.device)

            self.vae_model.eval()
            with torch.no_grad():
                recon, _, _, _ = self.vae_model(images)
            self.vae_model.train()

            images = (images + 1) / 2
            recon = (recon + 1) / 2
            images = images.clamp(0,1).cpu().numpy()
            recon = recon.clamp(0,1).cpu().numpy()

            thumb = self.thumbnail_size // 2
            grid = Image.new('RGB', (8*thumb, 4*thumb))
            for i in range(4):
                for j in range(4):
                    idx = i*4 + j
                    if idx < len(images):
                        if images[idx].shape[0] == 1:
                            img = np.stack([images[idx][0]]*3, axis=-1)
                        else:
                            img = images[idx].transpose(1,2,0)
                        img = (img * 255).astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img, (j*thumb*2, i*thumb))
                        if recon[idx].shape[0] == 1:
                            img_r = np.stack([recon[idx][0]]*3, axis=-1)
                        else:
                            img_r = recon[idx].transpose(1,2,0)
                        img_r = (img_r * 255).astype(np.uint8)
                        pil_img_r = Image.fromarray(img_r).resize((thumb, thumb), Image.NEAREST)
                        grid.paste(pil_img_r, (j*thumb*2 + thumb, i*thumb))
            grid = grid.resize((256,128), Image.NEAREST)
            self.vae_preview_photo = ImageTk.PhotoImage(grid)
            self.vae_preview_canvas.delete("all")
            self.vae_preview_canvas.create_image(128,64, image=self.vae_preview_photo)
        except Exception as e:
            self.log_vae(f"Preview error: {e}")

    def stop_vae_training(self):
        self.training_vae = False
        self.log_vae("VAE training stopped.")

    def save_vae(self):
        if not self.vae_model: self.log_vae("No VAE."); return
        fname = filedialog.asksaveasfilename(defaultextension=".pth", filetypes=[("PyTorch","*.pth")])
        if fname:
            torch.save({
                'model_state': self.vae_model.state_dict(),
                'optimizer_state': self.vae_optimizer.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items() if k.startswith('vae') or k in ['img_size','color_mode']},
                'vae_size': self.settings['vae_size'].get(),
            }, fname)
            self.log_vae(f"VAE saved to {fname}")

    def load_vae(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname: return
        try:
            ckpt = torch.load(fname, map_location='cpu', weights_only=False)
            if 'settings' in ckpt:
                for k,v in ckpt['settings'].items():
                    if k in self.settings:
                        self.settings[k].set(v)
            if 'vae_size' in ckpt:
                self.settings['vae_size'].set(ckpt['vae_size'])
            self.initialize_vae()
            self.vae_model.load_state_dict(ckpt['model_state'])
            self.vae_optimizer.load_state_dict(ckpt['optimizer_state'])
            self.log_vae(f"VAE loaded from {fname}")
        except Exception as e:
            self.log_vae(f"Load error: {e}")

    # ========== Conditional Sequence Model Methods ==========
    def _get_seq_len(self):
        full_len = self.settings['vae_latent_channels'].get() * self.settings['vae_latent_h'].get() * self.settings['vae_latent_w'].get()
        override = self.settings['seq_len_override'].get()
        return override if override > 0 else full_len

    def _adjust_sequence(self, indices, target_len):
        B = indices.size(0)
        current_len = indices.size(1)
        if current_len > target_len:
            return indices[:, :target_len]
        elif current_len < target_len:
            pad = torch.full((B, target_len - current_len), self.vae_model.num_levels, device=indices.device)
            return torch.cat([indices, pad], dim=1)
        else:
            return indices

    def initialize_cond_models(self):
        if not self.vae_model:
            self.log_cond_seq("Please train/load a VAE first!")
            return
        try:
            vocab_size = self.vae_model.num_levels + 1
            max_seq_len = self._get_seq_len()
            cond_enabled = self.settings['cond_enabled'].get()
            cond_dim = self.settings['cond_dim'].get() if cond_enabled else None

            if cond_enabled:
                self.text_encoder = TextEncoder(
                    vocab_size=256,
                    embed_dim=self.settings['cond_embed_dim'].get(),
                    hidden_size=self.settings['cond_hidden_size'].get(),
                    num_layers=self.settings['cond_num_layers'].get(),
                    cond_dim=cond_dim
                ).to(self.device)
            else:
                self.text_encoder = None

            model_type = self.settings['seq_model_type'].get()
            dropout = self.settings['seq_dropout'].get()
            use_2d = self.settings['use_2d_pos_emb'].get()
            C, H, W = self.vae_model.latent_channels, self.vae_model.latent_h, self.vae_model.latent_w

            if model_type == 'transformer':
                size_name = self.settings['transformer_model_size'].get()
                config = TRANSFORMER_CONFIGS[size_name]
                self.cond_seq_model = ConditionalGPT(
                    vocab_size=vocab_size,
                    max_seq_len=max_seq_len,
                    cond_dim=cond_dim,
                    embed_dim=config['embed_dim'],
                    num_layers=config['num_layers'],
                    num_heads=config['num_heads'],
                    mlp_ratio=4.0,
                    dropout=dropout,
                    use_2d_pos=use_2d,
                    latent_C=C, latent_H=H, latent_W=W
                ).to(self.device)
                self.log_cond_seq(f"Conditional Transformer initialized ({size_name}). Max seq len: {max_seq_len}")
            elif model_type == 'gru':
                size_name = self.settings['gru_model_size'].get()
                config = GRU_CONFIGS[size_name]
                self.cond_seq_model = ConditionalGRUModel(
                    vocab_size=vocab_size,
                    max_seq_len=max_seq_len,
                    cond_dim=cond_dim,
                    embed_dim=config['embed_dim'],
                    hidden_size=config['hidden_size'],
                    num_layers=config['num_layers'],
                    dropout=dropout,
                    use_2d_pos=use_2d,
                    latent_C=C, latent_H=H, latent_W=W
                ).to(self.device)
                self.log_cond_seq(f"Conditional GRU initialized ({size_name}).")
            elif model_type == 'pixelcnn':
                size_name = self.settings['pixelcnn_model_size'].get()
                config = PIXELCNN_CONFIGS[size_name]
                self.cond_seq_model = ConditionalPixelCNN(
                    vocab_size=vocab_size,
                    cond_dim=cond_dim,
                    embed_dim=config['embed_dim'],
                    num_layers=config['num_layers'],
                    hidden_dim=config['hidden_dim'],
                    kernel_size=3
                ).to(self.device)
                self.log_cond_seq(f"Conditional PixelCNN initialized ({size_name}).")
            else:
                self.log_cond_seq("Unknown model type.")
                return

            self.cond_seq_model_type = model_type
            params = list(self.cond_seq_model.parameters())
            if self.text_encoder is not None:
                params += list(self.text_encoder.parameters())
            self.cond_optimizer = optim.Adam(params, lr=self.settings['cond_lr'].get())
        except Exception as e:
            self.log_cond_seq(f"Error: {e}")

    def start_cond_training(self):
        if not self.image_paths: self.log_cond_seq("No images!"); return
        if not self.cond_seq_model: self.log_cond_seq("Models not initialized!"); return
        if not self.vae_model: self.log_cond_seq("No VAE!"); return
        if self.training_cond_seq: self.log_cond_seq("Already training."); return
        cond_enabled = self.settings['cond_enabled'].get()
        if cond_enabled and not self.labels:
            self.log_cond_seq("Conditional training requires labels. Load CSV or use filenames.")
            return
        try:
            epochs = int(self.cond_epoch_var.get())
        except:
            self.log_cond_seq("Invalid epochs")
            return
        self.training_cond_seq = True
        self.current_epoch_cond_seq = 0
        self.cond_start_time = time.time()
        thread = threading.Thread(target=self.train_cond_loop, args=(epochs,), daemon=True)
        thread.start()
        self.log_cond_seq(f"Conditional training started for {epochs} epochs.")

    def train_cond_loop(self, epochs):
        try:
            batch_size = self.settings['cond_batch_size'].get()
            num_workers = self.settings['vae_num_workers'].get()
            img_size = self.settings['img_size'].get()
            color_mode = self.settings['color_mode'].get()
            aug_dict = {k: v.get() for k, v in self.aug_settings.items()}
            text_max_len = self.settings['cond_text_max_len'].get()
            cond_enabled = self.settings['cond_enabled'].get()
            cond_dropout_prob = self.settings['cond_dropout_prob'].get() if cond_enabled else 0.0

            if cond_enabled:
                dataset = ConditionalImageDataset(self.image_paths, self.labels, img_size, color_mode, aug_dict, text_max_len)
            else:
                dummy_labels = [""] * len(self.image_paths)
                dataset = ConditionalImageDataset(self.image_paths, dummy_labels, img_size, color_mode, aug_dict, text_max_len)

            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True,
                                num_workers=num_workers, pin_memory=False)
            criterion = nn.CrossEntropyLoss()
            self.vae_model.eval()
            self.cond_seq_model.train()
            if self.text_encoder is not None:
                self.text_encoder.train()

            start_token = self.vae_model.num_levels
            model_type = self.cond_seq_model_type
            target_len = self._get_seq_len()
            C, H, W = self.vae_model.latent_channels, self.vae_model.latent_h, self.vae_model.latent_w

            for epoch in range(epochs):
                if not self.training_cond_seq: break
                self.current_epoch_cond_seq = epoch
                epoch_loss = 0.0
                batches = 0
                for images, text_tensors in loader:
                    if not self.training_cond_seq: break
                    images = images.to(self.device)
                    with torch.no_grad():
                        indices = self.vae_model.encode_indices(images)
                        indices = self._adjust_sequence(indices, target_len)

                    if cond_enabled and self.text_encoder is not None:
                        cond = self.text_encoder(text_tensors.to(self.device))
                        if cond_dropout_prob > 0:
                            mask = torch.rand(cond.size(0), 1, device=self.device) > cond_dropout_prob
                            cond = cond * mask.float()
                    else:
                        cond = None

                    if model_type in ['transformer', 'gru']:
                        B, T = indices.shape
                        start = torch.full((B, 1), start_token, dtype=torch.long, device=self.device)
                        inp = torch.cat([start, indices[:, :-1]], dim=1)
                        target = indices
                        if model_type == 'transformer' and self.settings['use_2d_pos_emb'].get():
                            logits = self.cond_seq_model(inp, cond, C=C, H=H, W=W)
                        elif model_type == 'gru' and self.settings['use_2d_pos_emb'].get():
                            logits = self.cond_seq_model(inp, cond, C=C, H=H, W=W)
                        else:
                            logits = self.cond_seq_model(inp, cond)
                        loss = criterion(logits.view(-1, logits.size(-1)), target.view(-1))
                    elif model_type == 'pixelcnn':
                        # For PixelCNN we treat the flattened sequence as a 2D grid of size (C*H, W)
                        B = indices.size(0)
                        grid = indices.view(B, C*H, W)
                        logits = self.cond_seq_model(grid, cond)
                        loss = criterion(logits.permute(0,2,3,1).reshape(-1, logits.size(1)), grid.reshape(-1))

                    self.cond_optimizer.zero_grad()
                    loss.backward()
                    self.cond_optimizer.step()
                    epoch_loss += loss.item()
                    batches += 1

                avg_loss = epoch_loss / batches if batches else 0
                elapsed = time.time() - self.cond_start_time
                self.log_cond_seq(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.6f} | Time: {elapsed:.1f}s")
                if (epoch+1) % 5 == 0:
                    self.cond_preview()
            self.training_cond_seq = False
            self.log_cond_seq("Conditional training finished.")
        except Exception as e:
            self.log_cond_seq(f"Training error: {e}")
            import traceback; traceback.print_exc()
            self.training_cond_seq = False

    def cond_preview(self):
        if not self.cond_seq_model or not self.vae_model:
            self.log_cond_seq("Models not loaded")
            return
        prompt = self.cond_test_prompt.get().strip()
        unconditional = (prompt == "") or (not self.settings['cond_enabled'].get())
        try:
            n = 16
            cond_enabled = self.settings['cond_enabled'].get()
            model_type = self.cond_seq_model_type

            if unconditional or not cond_enabled:
                cond = None
                cfg_scale = 1.0
                self.log_cond_seq("Preview: unconditional generation")
            else:
                text_max_len = self.settings['cond_text_max_len'].get()
                text_indices = text_to_indices(prompt, text_max_len)
                text_tensor = torch.tensor([text_indices], dtype=torch.long, device=self.device).repeat(n, 1)
                with torch.no_grad():
                    cond = self.text_encoder(text_tensor)
                cfg_scale = self.cfg_scale.get()
                self.log_cond_seq(f"Preview: conditional with prompt '{prompt}'")

            self.cond_seq_model.eval()
            if self.text_encoder is not None:
                self.text_encoder.eval()
            self.vae_model.eval()

            start_token = self.vae_model.num_levels
            target_len = self._get_seq_len()
            C, H, W = self.vae_model.latent_channels, self.vae_model.latent_h, self.vae_model.latent_w
            full_len = C * H * W

            with torch.no_grad():
                if model_type in ['transformer', 'gru']:
                    x = torch.full((n, 1), start_token, dtype=torch.long, device=self.device)
                    null_cond = torch.zeros_like(cond) if cond is not None else None

                    for step in range(target_len):
                        if model_type == 'transformer' and self.settings['use_2d_pos_emb'].get():
                            logits_cond = self.cond_seq_model(x, cond, C=C, H=H, W=W)[:, -1, :]
                            if cond is not None:
                                logits_uncond = self.cond_seq_model(x, null_cond, C=C, H=H, W=W)[:, -1, :]
                                logits = logits_uncond + cfg_scale * (logits_cond - logits_uncond)
                            else:
                                logits = logits_cond
                        elif model_type == 'gru' and self.settings['use_2d_pos_emb'].get():
                            logits_cond = self.cond_seq_model(x, cond, C=C, H=H, W=W)[:, -1, :]
                            if cond is not None:
                                logits_uncond = self.cond_seq_model(x, null_cond, C=C, H=H, W=W)[:, -1, :]
                                logits = logits_uncond + cfg_scale * (logits_cond - logits_uncond)
                            else:
                                logits = logits_cond
                        else:
                            logits_cond = self.cond_seq_model(x, cond)[:, -1, :]
                            if cond is not None:
                                logits_uncond = self.cond_seq_model(x, null_cond)[:, -1, :]
                                logits = logits_uncond + cfg_scale * (logits_cond - logits_uncond)
                            else:
                                logits = logits_cond
                        temp = self.settings['cond_temperature'].get()
                        if temp > 0:
                            probs = F.softmax(logits / temp, dim=-1)
                            next_token = torch.multinomial(probs, 1)
                        else:
                            next_token = logits.argmax(dim=-1, keepdim=True)
                        x = torch.cat([x, next_token], dim=1)
                    indices = x[:, 1:]
                else:  # pixelcnn
                    # Generate autoregressively over flattened grid
                    x = torch.full((n, 1), start_token, dtype=torch.long, device=self.device)
                    null_cond = torch.zeros_like(cond) if cond is not None else None
                    for step in range(target_len):
                        logits_cond = self.cond_seq_model(x, cond)[:, -1, :]
                        if cond is not None:
                            logits_uncond = self.cond_seq_model(x, null_cond)[:, -1, :]
                            logits = logits_uncond + cfg_scale * (logits_cond - logits_uncond)
                        else:
                            logits = logits_cond
                        temp = self.settings['cond_temperature'].get()
                        if temp > 0:
                            probs = F.softmax(logits / temp, dim=-1)
                            next_token = torch.multinomial(probs, 1)
                        else:
                            next_token = logits.argmax(dim=-1, keepdim=True)
                        x = torch.cat([x, next_token], dim=1)
                    indices = x[:, 1:]

                # Ensure we have the correct number of tokens for decoding
                if indices.size(1) < full_len:
                    pad = torch.full((n, full_len - indices.size(1)), start_token, device=self.device)
                    indices = torch.cat([indices, pad], dim=1)
                elif indices.size(1) > full_len:
                    indices = indices[:, :full_len]
                samples = self.vae_model.decode_from_indices(indices)
            samples = (samples + 1) / 2
            samples = samples.clamp(0,1).cpu().numpy()
            thumb = self.thumbnail_size
            grid_img = Image.new('RGB', (4*thumb, 4*thumb))
            for i in range(4):
                for j in range(4):
                    idx = i*4 + j
                    if idx < len(samples):
                        if samples[idx].shape[0] == 1:
                            img = np.stack([samples[idx][0]]*3, axis=-1)
                        else:
                            img = samples[idx].transpose(1,2,0)
                        img = (img * 255).astype(np.uint8)
                        pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                        grid_img.paste(pil_img, (j*thumb, i*thumb))
            grid_img = grid_img.resize((256,256), Image.NEAREST)
            self.cond_preview_photo = ImageTk.PhotoImage(grid_img)
            self.cond_preview_canvas.delete("all")
            self.cond_preview_canvas.create_image(128,128, image=self.cond_preview_photo)

            if self.training_cond_seq:
                self.cond_seq_model.train()
                if self.text_encoder is not None:
                    self.text_encoder.train()
        except Exception as e:
            self.log_cond_seq(f"Preview error: {e}")

    def stop_cond_training(self):
        self.training_cond_seq = False
        self.log_cond_seq("Conditional training stopped.")

    def save_cond_model(self):
        if not self.cond_seq_model:
            self.log_cond_seq("No model.")
            return
        fname = filedialog.asksaveasfilename(defaultextension=".pth", filetypes=[("PyTorch","*.pth")])
        if fname:
            save_dict = {
                'cond_seq_model_state': self.cond_seq_model.state_dict(),
                'optimizer_state': self.cond_optimizer.state_dict(),
                'settings': {k:v.get() for k,v in self.settings.items() if k.startswith('cond') or k in ['seq_model_type','transformer_model_size','gru_model_size','pixelcnn_model_size', 'seq_dropout', 'seq_len_override', 'use_2d_pos_emb']},
                'model_type': self.cond_seq_model_type,
            }
            if self.text_encoder is not None:
                save_dict['text_encoder_state'] = self.text_encoder.state_dict()
            torch.save(save_dict, fname)
            self.log_cond_seq(f"Conditional model saved to {fname}")

    def load_cond_model(self):
        fname = filedialog.askopenfilename(filetypes=[("PyTorch","*.pth")])
        if not fname: return
        try:
            ckpt = torch.load(fname, map_location='cpu', weights_only=False)
            if 'settings' in ckpt:
                for k,v in ckpt['settings'].items():
                    if k in self.settings:
                        self.settings[k].set(v)
            if not self.vae_model:
                self.log_cond_seq("Please load VAE first.")
                return
            self.cond_seq_model_type = ckpt.get('model_type', 'transformer')
            self.initialize_cond_models()
            self.cond_seq_model.load_state_dict(ckpt['cond_seq_model_state'])
            self.cond_optimizer.load_state_dict(ckpt['optimizer_state'])
            if 'text_encoder_state' in ckpt and self.text_encoder is not None:
                self.text_encoder.load_state_dict(ckpt['text_encoder_state'])
            self.log_cond_seq(f"Conditional model loaded from {fname}")
        except Exception as e:
            self.log_cond_seq(f"Load error: {e}")

    # ========== Generation ==========
    def generate_samples(self):
        if not self.cond_seq_model or not self.vae_model:
            self.gen_info.config(text="Models not loaded!")
            return
        n = self.gen_count.get()
        temp = self.gen_temp.get()
        prompt = self.gen_prompt.get().strip()
        self.generation_active = True
        self.generate_btn.config(state=tk.DISABLED)
        self.stop_gen_btn.config(state=tk.NORMAL)
        self.gen_info.config(text=f"Generating with prompt: {prompt}" if prompt else "Generating unconditionally...")
        self.root.update()
        thread = threading.Thread(target=self._generate_thread, args=(n, temp, prompt), daemon=True)
        thread.start()

    def stop_generation(self):
        self.generation_active = False
        self.stop_gen_btn.config(state=tk.DISABLED)
        self.gen_info.config(text="Generation stopped.")

    def _generate_thread(self, n, temp, prompt):
        try:
            realtime = self.real_time_preview.get()
            interval = self.preview_interval.get()
            model_type = self.cond_seq_model_type
            cfg_scale = self.cfg_scale.get()
            cond_enabled = self.settings['cond_enabled'].get()
            unconditional = (prompt == "") or (not cond_enabled)

            if unconditional:
                cond = None
                effective_cfg_scale = 1.0
            else:
                if self.text_encoder is None:
                    self.root.after(0, lambda: self.gen_info.config(text="Text encoder not initialized!"))
                    return
                text_max_len = self.settings['cond_text_max_len'].get()
                text_indices = text_to_indices(prompt, text_max_len)
                text_tensor = torch.tensor([text_indices], dtype=torch.long, device=self.device).repeat(n, 1)
                with torch.no_grad():
                    cond = self.text_encoder(text_tensor)
                effective_cfg_scale = cfg_scale

            self.cond_seq_model.eval()
            if self.text_encoder is not None:
                self.text_encoder.eval()
            self.vae_model.eval()

            start_token = self.vae_model.num_levels
            target_len = self._get_seq_len()
            C, H, W = self.vae_model.latent_channels, self.vae_model.latent_h, self.vae_model.latent_w
            full_len = C * H * W

            with torch.no_grad():
                # Use transformer/GRU style generation
                x = torch.full((n, 1), start_token, dtype=torch.long, device=self.device)
                null_cond = torch.zeros_like(cond) if cond is not None else None

                if realtime:
                    for step in range(target_len):
                        if not self.generation_active:
                            break
                        if model_type == 'transformer' and self.settings['use_2d_pos_emb'].get():
                            logits_cond = self.cond_seq_model(x, cond, C=C, H=H, W=W)[:, -1, :]
                            if cond is not None:
                                logits_uncond = self.cond_seq_model(x, null_cond, C=C, H=H, W=W)[:, -1, :]
                                logits = logits_uncond + effective_cfg_scale * (logits_cond - logits_uncond)
                            else:
                                logits = logits_cond
                        elif model_type == 'gru' and self.settings['use_2d_pos_emb'].get():
                            logits_cond = self.cond_seq_model(x, cond, C=C, H=H, W=W)[:, -1, :]
                            if cond is not None:
                                logits_uncond = self.cond_seq_model(x, null_cond, C=C, H=H, W=W)[:, -1, :]
                                logits = logits_uncond + effective_cfg_scale * (logits_cond - logits_uncond)
                            else:
                                logits = logits_cond
                        else:
                            logits_cond = self.cond_seq_model(x, cond)[:, -1, :]
                            if cond is not None:
                                logits_uncond = self.cond_seq_model(x, null_cond)[:, -1, :]
                                logits = logits_uncond + effective_cfg_scale * (logits_cond - logits_uncond)
                            else:
                                logits = logits_cond
                        if temp > 0:
                            probs = F.softmax(logits / temp, dim=-1)
                            next_token = torch.multinomial(probs, 1)
                        else:
                            next_token = logits.argmax(dim=-1, keepdim=True)
                        x = torch.cat([x, next_token], dim=1)

                        if (step+1) % interval == 0 or step+1 == target_len:
                            current_tokens = x[:, 1:]
                            # Pad to full_len for decoding
                            pad_len = full_len - current_tokens.size(1)
                            if pad_len > 0:
                                padded = torch.cat([current_tokens, torch.full((n, pad_len), start_token, device=self.device)], dim=1)
                            else:
                                padded = current_tokens[:, :full_len]
                            samples = self.vae_model.decode_from_indices(padded)
                            self.root.after(0, lambda s=samples.clone(), st=step+1: self._update_preview(s, st))
                    if self.generation_active:
                        indices = x[:, 1:full_len+1]
                        if indices.size(1) < full_len:
                            pad = torch.full((n, full_len - indices.size(1)), start_token, device=self.device)
                            indices = torch.cat([indices, pad], dim=1)
                        samples = self.vae_model.decode_from_indices(indices)
                        self.root.after(0, lambda: self._display_final(samples, n))
                else:
                    for step in range(target_len):
                        if not self.generation_active:
                            break
                        if model_type == 'transformer' and self.settings['use_2d_pos_emb'].get():
                            logits_cond = self.cond_seq_model(x, cond, C=C, H=H, W=W)[:, -1, :]
                            if cond is not None:
                                logits_uncond = self.cond_seq_model(x, null_cond, C=C, H=H, W=W)[:, -1, :]
                                logits = logits_uncond + effective_cfg_scale * (logits_cond - logits_uncond)
                            else:
                                logits = logits_cond
                        elif model_type == 'gru' and self.settings['use_2d_pos_emb'].get():
                            logits_cond = self.cond_seq_model(x, cond, C=C, H=H, W=W)[:, -1, :]
                            if cond is not None:
                                logits_uncond = self.cond_seq_model(x, null_cond, C=C, H=H, W=W)[:, -1, :]
                                logits = logits_uncond + effective_cfg_scale * (logits_cond - logits_uncond)
                            else:
                                logits = logits_cond
                        else:
                            logits_cond = self.cond_seq_model(x, cond)[:, -1, :]
                            if cond is not None:
                                logits_uncond = self.cond_seq_model(x, null_cond)[:, -1, :]
                                logits = logits_uncond + effective_cfg_scale * (logits_cond - logits_uncond)
                            else:
                                logits = logits_cond
                        if temp > 0:
                            probs = F.softmax(logits / temp, dim=-1)
                            next_token = torch.multinomial(probs, 1)
                        else:
                            next_token = logits.argmax(dim=-1, keepdim=True)
                        x = torch.cat([x, next_token], dim=1)
                    if self.generation_active:
                        indices = x[:, 1:full_len+1]
                        if indices.size(1) < full_len:
                            pad = torch.full((n, full_len - indices.size(1)), start_token, device=self.device)
                            indices = torch.cat([indices, pad], dim=1)
                        samples = self.vae_model.decode_from_indices(indices)
                        self.root.after(0, lambda: self._display_final(samples, n))
        except Exception as e:
            self.root.after(0, lambda e=e: self.gen_info.config(text=f"Error: {e}"))
            import traceback; traceback.print_exc()
        finally:
            self.generation_active = False
            self.root.after(0, lambda: self.generate_btn.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_gen_btn.config(state=tk.DISABLED))

    def _update_preview(self, samples, step):
        samples = (samples + 1) / 2
        samples = samples.clamp(0,1).cpu().numpy()
        n = samples.shape[0]
        thumb = self.thumbnail_size
        grid_size = int(math.ceil(math.sqrt(n)))
        total = grid_size * thumb
        grid_img = Image.new('RGB', (total, total), color=(128,128,128))
        for i in range(n):
            row = i // grid_size
            col = i % grid_size
            if i < len(samples):
                if samples[i].shape[0] == 1:
                    img = np.stack([samples[i][0]]*3, axis=-1)
                else:
                    img = samples[i].transpose(1,2,0)
                img = (img * 255).astype(np.uint8)
                pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                grid_img.paste(pil_img, (col*thumb, row*thumb))
        for w in self.inner_frame.winfo_children():
            w.destroy()
        self.prog_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.prog_photo)
        label.image = self.prog_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        target_len = self._get_seq_len()
        self.gen_info.config(text=f"Token {step}/{target_len}")

    def _display_final(self, samples, n):
        samples = (samples + 1) / 2
        samples = samples.clamp(0,1).cpu().numpy()
        thumb = self.thumbnail_size
        grid_size = int(math.ceil(math.sqrt(n)))
        total = grid_size * thumb
        grid_img = Image.new('RGB', (total, total), color=(128,128,128))
        for i in range(n):
            row = i // grid_size
            col = i % grid_size
            if i < len(samples):
                if samples[i].shape[0] == 1:
                    img = np.stack([samples[i][0]]*3, axis=-1)
                else:
                    img = samples[i].transpose(1,2,0)
                img = (img * 255).astype(np.uint8)
                pil_img = Image.fromarray(img).resize((thumb, thumb), Image.NEAREST)
                grid_img.paste(pil_img, (col*thumb, row*thumb))
        for w in self.inner_frame.winfo_children():
            w.destroy()
        self.gen_photo = ImageTk.PhotoImage(grid_img)
        label = tk.Label(self.inner_frame, image=self.gen_photo)
        label.image = self.gen_photo
        label.pack()
        self.inner_frame.update_idletasks()
        self.gen_canvas.configure(scrollregion=self.gen_canvas.bbox('all'))
        self.gen_info.config(text="Generation complete.")

# ==================== Main ====================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    root = tk.Tk()
    app = QuantizedVAETransformerApp(root)
    root.mainloop()